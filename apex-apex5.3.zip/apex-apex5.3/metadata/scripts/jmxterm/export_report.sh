#/bin/sh

# https://github.com/jiaqi/jmxterm
# http://wiki.cyclopsgroup.org/jmxterm/manual.html
#--verbose: silent|brief|verbose
java -jar jmxterm-1.0.0-uber.jar --appendto --noninter --user mreAdmin --password "C>}44ON2U1y88ow" --url clarkkent:8118 --verbose silent --input report.jmxterm
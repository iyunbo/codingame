#!/bin/sh

#https://stackoverflow.com/questions/13814157/importing-shell-script-function

# https://stackoverflow.com/questions/8742783/returning-value-from-called-function-in-shell-script
function statusCode
{
	export curlUrl=$1$2$3
	echo "Check HTTP for $curlUrl"
	
	# We want to fetch the body to check for error, but we are interested instatus only
	# http://www.woolie.co.uk/article/curl-full-get-request-dropping-body/
	# tail -n 1 to keep last line, holding the responseCode
	# -s not to show the progress bar
	
	echo "curl -k -s -IXGET -w %{http_code} $curlUrl"
		
  	export retval=$(curl -k -s -IXGET -w %{http_code} $curlUrl -o /dev/null | tail -n 1)
	echo "$retval FROM curl -k -s -IXGET -w %{http_code} $curlUrl"
	
  	if [ "$retval" == "000" ]; then
		# Tu load with maven settings/credentials, we may prefer to use https://maven.apache.org/plugins/maven-dependency-plugin/copy-mojo.html 
		echo "Issue while doing 'curl -k -s -IXGET -w %{http_code} $curlUrl'"
	fi
	
  	echo "$retval"
}

if [ "${1}" != "--source-only" ]; then
    main "${@}"
fi

#!/bin/sh

#https://stackoverflow.com/questions/13814157/importing-shell-script-function
#https://gist.github.com/chrismdp/6c6b6c825b07f680e710

S3STORAGETYPE="STANDARD" #REDUCED_REDUNDANCY or STANDARD etc.

# http://docs.aws.amazon.com/general/latest/gr/rande.html
# ireland: eu-west-1
AWSREGION="s3-eu-west-1"

function statusCode
{
  echo "AWS_ACCESS_KEY_ID: $AWS_ACCESS_KEY_ID"
  echo "S3BUCKET: $S3BUCKET"
  
  # https://github.com/blasd/aws-maven
  # maven2.activepivot.solven.eu
  bucket="${S3BUCKET}"
  
  repo_url=$1
  
  # SKip 's3://'
  aws_path=${repo_url:5}/$2$3
  
  # https://stackoverflow.com/questions/16153446/bash-last-index-of
  aws_path="/${aws_path#*/}"
  
  echo "folder+file: $aws_path"
  date=$(date +"%a, %d %b %Y %T %z")
  acl="x-amz-acl:private"
  content_type="application/octet-stream"
  storage_type="x-amz-storage-class:${S3STORAGETYPE}"
  string="GET
$content_type
$date
$acl
$storage_type
/$bucket$aws_path"
  
  # https://docs.aws.amazon.com/AmazonS3/latest/dev/RESTAuthentication.html
  # https://stackoverflow.com/questions/28561724/amazon-s3-file-download-through-curl-by-using-iam-user-credentials
  signature=$(echo -en "${string}" | openssl sha1 -hmac "${AWS_SECRET_ACCESS_KEY}" -binary | base64)
  
  echo "Checking: 'https://$bucket.${AWSREGION}.amazonaws.com$aws_path'"
  
  echo "curl --insecure --silent -IXGET -w %{http_code}" \
    -H "Host: $bucket.${AWSREGION}.amazonaws.com" \
    -H "Date: $date" \
    -H "Content-Type: $content_type" \
    -H "$storage_type" \
    -H "$acl" \
    -H "Authorization: AWS ${AWS_ACCESS_KEY_ID}:titi$signature" \
    "https://$bucket.${AWSREGION}.amazonaws.com$aws_path"
  
  # https://curl.haxx.se/docs/manpage.html
  # -k: --insecure
  # -s: --silent
  export retval=$(curl --insecure --silent -IXGET -w %{http_code} \
    -H "Host: $bucket.${AWSREGION}.amazonaws.com" \
    -H "Date: $date" \
    -H "Content-Type: $content_type" \
    -H "$storage_type" \
    -H "$acl" \
    -H "Authorization: AWS ${AWS_ACCESS_KEY_ID}:$signature" \
    "https://$bucket.${AWSREGION}.amazonaws.com$aws_path" -o /dev/null | tail -n 1)
    
  	echo "$retval"
}

# export S3BUCKET="maven2.activepivot.solven.eu"
# sh /c/NB5419/workspace/apex/metadata/scripts/deploy/check_in_S3.sh $AWS_ACCESS_KEY_ID $AWS_SECRET_ACCESS_KEY maven2.activepivot.solven.eu /release/com/activeviam/activemonitor/activemonitor-activepivot-impl/ maven-metadata.xml
# sh check_in_S3.sh maven2.activepivot.solven.eu release/com/activeviam/activemonitor/activemonitor-activepivot-impl/ maven-metadata.xml
# getS3 $2 $3

# Ensure aws-maven-5.0.0.RELEASE.jar is in <maven>/lib/ext
# https://github.com/spring-projects/aws-maven/pull/34
# git clone git@github.com:ElectronicRemedy/aws-maven.git
# mvn -DskipTests=true clean package -PshadedWagon
# mvn -v to know where maven is installed
# cp target/aws-maven-wagon.jar /usr/local/Cellar/maven/3.6.0/libexec/lib/ext

# https://stackoverflow.com/questions/12815774/importing-functions-from-a-shell-script
main() {
	echo "param 1 $1"
    statusCode $1 $2 $3
}
if [ "${1}" != "--source-only" ]; then
    main "${@}"
fi

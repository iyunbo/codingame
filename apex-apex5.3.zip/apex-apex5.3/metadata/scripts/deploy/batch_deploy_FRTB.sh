#/bin/sh

export assembly_folder="$1"
export repoid="$2"
export repourl="$3"


./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/apps/" "frtb" &
# ./raw_deploy_jar_classes_tests.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/apps/" "frtb-activepivot" &
# ./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/apps/" "frtb-activeui" &
# ./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/apps/" "frtb-common" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/apps/" "frtb-core" &

./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/apps/test/" "postprocessor-unit-testing-framework" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/apps/" "activepivot-test-harness" &

./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/apps/services/" "context-service" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/apps/services/" "context-service-AP5.0" &
./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/apps/services/" "context-service-common-parent" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/apps/services/" "context-service-common" &

./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/apps/services/" "AP5.6" &
./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/apps/services/" "context-service" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/apps/services/" "context-service-AP5.0" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/apps/services/" "context-service-AP5.6" &
./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/apps/services/" "context-service-common-parent" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/apps/services/" "context-service-common" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/apps/services/" "context-service-messenger-AP5.6" &
./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/apps/services/" "context-service-sandbox-AP5.6" &

./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/tools/" "whatif" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/tools/" "whatif-core" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/tools/" "whatif-examples" &

./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/apps/" "doctor-pivot" &

wait
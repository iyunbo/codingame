#/bin/sh

export repourl="http://artifactory.trading.gdfsuez.net/artifactory/meteor_gemcube_maven/"
export repoid="meteor_gemcube_maven"

export assembly_folder="$1"

./deploy_to_XXX.sh "$assembly_folder" "$repoid" "$repourl"
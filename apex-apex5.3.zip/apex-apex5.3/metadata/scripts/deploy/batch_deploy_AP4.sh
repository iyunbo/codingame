#/bin/sh
export assembly_folder="$1"
export repoid="$2"
export repourl="$3"

# http://stackoverflow.com/questions/5547787/running-shell-script-in-parallel

./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/tech/" "publisher" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/tech/publisher/" "publisher-impl" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/tech/publisher/" "publisher-intf" &
./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/tech/" "streaming" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/tech/" "streaming-impl" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/tech/" "streaming-intf" &

#/bin/sh

export repourl="https://itbox-nexus-ext.fr.world.socgen/nexus-ext/content/repositories/ext-quartet-maven2-hosted-releases/"
export repoid="itbox-nexus-ext.fr.world.socgen-ext-quartet-maven2-hosted-releases"

export assembly_folder="$1"

./deploy_to_XXX.sh "$assembly_folder" "$repoid" "$repourl"
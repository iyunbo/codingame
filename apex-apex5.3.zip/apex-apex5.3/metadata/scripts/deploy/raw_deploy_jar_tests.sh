#/bin/sh
export repourl="$1"
export repositoryid="$2"

export artifactid="$5"

export extention=".jar"

if [[ $repourl == s3* ]] ;
then
	. ./check_in_S3.sh --source-only 
else
	. ./check_in_HTTP.sh --source-only 
fi

for d in "$3$4$artifactid"/*
do
	export version=$(basename "${d}")
	
	versionregex='^[0-9].*$'
	if [ "$version" == "*" ]; then
		#echo "Found no version for '$artifactid' while parsing '$d'"
		echo "Found no version for '$artifactid'"
	elif ! [[ $version =~ $versionregex ]] ; then 
		echo "Not a version: $version"
	else
		# There is 2 occurences to replace
		export partialPath="$artifactid/$version/$artifactid-$version"
		export pomFile="$3/$4$partialPath"
		
		# https://stackoverflow.com/questions/638975/how-do-i-tell-if-a-regular-file-does-not-exist-in-bash
		if [ ! -f "$3$4$partialPath.pom" ]; then
		    echo "File not found! $3$4$partialPath.pom"
		    continue
		else
		    echo "File found! $3$4$partialPath.pom"
		fi
		

		status=$(statusCode $repourl "$4$partialPath" $extention  -o /dev/null | tail -n 1)
		
		# Push with s3 wagon requires url to use s3 protocol
		if [[ $repourl == s3* ]] ;
		then
			export specialMavenRepo="s3://maven2.activepivot.solven.eu"
			export specialHttpUrlReplacement="https://s3-eu-west-1.amazonaws.com/maven2.activepivot.solven.eu"
			# http://stackoverflow.com/questions/13210880/replace-one-substring-for-another-string-in-shell-script
			repourl="${repourl//$specialHttpUrlReplacement/$specialMavenRepo}" 
		fi
		
		if [ "$status" == "000" ]; then
			echo "CURL returned $status: deploy anyway"
			
			mvn deploy:deploy-file -DgeneratePom=false -DrepositoryId=$repositoryid -Durl=$repourl -DpomFile=$pomFile.pom -Dfile=$pomFile$extention
			mvn deploy:deploy-file -DgeneratePom=false -DrepositoryId=$repositoryid -Durl=$repourl -DpomFile=$pomFile.pom -Dfile=$pomFile-tests$extention -Dpackaging=test-jar
		elif [ "$status" == "200" ]; then
			echo "Skip already existing $artifactid $version on $repourl"
		else
			echo "Existing status: '$status' About to push $4$partialPath$extention"

			mvn deploy:deploy-file -DgeneratePom=false -DrepositoryId=$repositoryid -Durl=$repourl -DpomFile=$pomFile.pom -Dfile=$pomFile$extention
			mvn deploy:deploy-file -DgeneratePom=false -DrepositoryId=$repositoryid -Durl=$repourl -DpomFile=$pomFile.pom -Dfile=$pomFile-tests$extention -Dpackaging=test-jar
		fi
	fi
done

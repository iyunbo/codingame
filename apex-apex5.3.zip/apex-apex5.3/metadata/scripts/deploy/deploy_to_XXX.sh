#/bin/sh

# https://maven.apache.org/guides/mini/guide-3rd-party-jars-remote.html
# http://stackoverflow.com/questions/6469128/how-do-i-install-a-test-jar-in-maven

# Maven refuses to deploy from the local maven repo
#export assembly_folder="C:/HOMEWARE/local-maven-repo2"

export assembly_folder="$1"
export repoid="$2"
export repourl="$3"

# https://serverfault.com/questions/7503/how-to-determine-if-a-bash-variable-is-empty
if [ -z $assembly_folder ]
then
	echo "Variable 'assembly_folder' is empty. Call '.sh deploy_to_ENV.sh <local_folder>'"
	exit
fi

echo "Exporting $assembly_folder"

# Given AP-Copper turned from jar to pom with AP5.8, we prefer to push the jar (AP5.5) before the pom (AP5.[]), else the remote get corrupted
./batch_deploy_AP5.5.sh "$assembly_folder" "$repoid" "$repourl" &

./batch_deploy_AP5.8.sh "$assembly_folder" "$repoid" "$repourl" &
./batch_deploy_AP5.sh "$assembly_folder" "$repoid" "$repourl" &
./batch_deploy_AP4.sh "$assembly_folder" "$repoid" "$repourl" &
./batch_deploy_FRTB.sh "$assembly_folder" "$repoid" "$repourl" &

wait
exit
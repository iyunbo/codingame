#/bin/sh

export assembly_folder="$1"
export repoid="$2"
export repourl="$3"

# In AP5.5, the groupId changed from 'quartetfs' to 'com/activeviam'

# Introduced with AP5.6
./raw_deploy_jar_tests.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activepivot/" "activepivot-copper" &


wait
exit

# https://support.activeviam.com/jira/browse/APS-10137
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/" "parquet-source" &


./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activeui/" "activeui" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activeui/" "activeui-sdk" &

./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activepivot/" "xmla" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activepivot/" "xmla-binary-xml" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activepivot/" "xmla-impl" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activepivot/" "xmla-intf" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activepivot/" "xmla-pivot" &



./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/contrib/" "activeviam-olap4j" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/contrib/" "activeviam-olap4j-core" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/contrib/" "activeviam-olap4j-xmla" &

./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/contrib/" "jboss-jaxb-intros" &

./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activepivotlive/" "activepivot-live" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activepivotlive/" "activepivot-live-charts" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activepivotlive/" "activepivot-live-components" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activepivotlive/" "activepivot-live-content" &
./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activepivotlive/" "activepivot-live-core" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activepivotlive/" "activepivot-live-core-main" &
./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activepivotlive/" "activepivot-live-resources" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activepivotlive/" "activepivot-live-resources-main" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activepivotlive/" "activepivot-live-resources-reference" &


# 5.5.X are provided without a jar: only 5.5.0 is provided with a jar
# https://support.activeviam.com/jira/browse/APS-9364
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activepivot/" "activepivot-ws-client" &

./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/tech/" "streaming" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/tech/" "streaming-intf" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/tech/" "streaming-impl" &


# http://stackoverflow.com/questions/5547787/running-shell-script-in-parallel
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/tech/" "numalib" &

./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/source/" "key-value-source" &

# Wait regularly to prevent pushing too many jars at the same time
wait

./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activepivot/" "activepivot-server-test" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activepivot/" "activepivot-server-ws-client" &
./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activepivot/" "activepivot" 
./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activepivot/" "activepivot-dist" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activepivot/" "activepivot-dist-impl" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activepivot/" "activepivot-impl" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activepivot/" "activepivot-intf" &
./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activepivot/" "activepivot-mdx" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activepivot/" "activepivot-mdx-impl" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activepivot/" "activepivot-mdx-intf" &
./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activepivot/" "activepivot-server" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activepivot/" "activepivot-server-spring" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activepivot/" "activepivot-server-impl" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activepivot/" "activepivot-server-intf" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activepivot/" "activepivot-server-json" &


# Wait regularly to prevent pushing too many jars at the same time
wait

./raw_deploy_jar_sources.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activepivot/" "activepivot-ext" &

./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/tech/" "composer-intf" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/tech/" "activeviam-activation" &
./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/tech/" "composer" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/tech/" "composer-api" &
./raw_deploy_jar_tests.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/tech/" "composer-impl" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/tech/" "composer-test" &


./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activepivot/" "activepivot-core" &

./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activepivot/" "activepivot-test" &

./raw_deploy_jar_tests.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/tech/" "datastore" &


# Wait regularly to prevent pushing too many jars at the same time
wait

./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/source/" "csv-source" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/source/" "jdbc-source" &

./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/" "activeviam-parent" &


./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activemonitor/" "repository" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activemonitor/" "repository-activepivot" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activemonitor/" "repository-impl" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activemonitor/" "repository-intf" &


# Wait regularly to prevent pushing too many jars at the same time
wait

./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activemonitor/" "activemonitor" &
./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activemonitor/" "activemonitor-activepivot" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activemonitor/" "activemonitor-activepivot-impl" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activemonitor/" "activemonitor-activepivot-intf" &
./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activemonitor/" "activemonitor-common" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activemonitor/" "activemonitor-common-impl" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activemonitor/" "activemonitor-common-intf" &
./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activemonitor/" "activemonitor-server" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activemonitor/" "activemonitor-server-impl" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activemonitor/" "activemonitor-server-intf" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activemonitor/" "activemonitor-web" &


# Wait regularly to prevent pushing too many jars at the same time
wait

./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/tech/" "content-server" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/tech/" "content-server-rest" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/tech/" "content-server-spring" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/tech/" "content-server-storage" &
./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/tech/" "serialization" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/tech/" "serialization-jackson" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/tech/" "serialization-jaxb" &

./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/web/" "activeviam-web" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/web/" "activeviam-web-core" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/web/" "activeviam-web-spring" &

wait
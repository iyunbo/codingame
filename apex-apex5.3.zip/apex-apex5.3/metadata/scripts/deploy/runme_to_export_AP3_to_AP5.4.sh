#/bin/sh

# https://maven.apache.org/guides/mini/guide-3rd-party-jars-remote.html
# http://stackoverflow.com/questions/6469128/how-do-i-install-a-test-jar-in-maven

# Maven refuses to deploy from the local maven repo
#export assembly_folder="C:/HOMEWARE/local-maven-repo2"

export assembly_folder="$1"
export repoid="$2"
export repourl="$3"

if [ "$assembly_folder" == "" ]; then
	export assembly_folder="A:/ActivePivot/live_3.4.0/activepivot-live-sandbox-3.4.0-repository"
	export assembly_folder="D:/blacelle112212/tmp/5.4.1/5.4.1-repository"
	export assembly_folder="C:/NB5419/ActivePivotJars/5.4.1-repository"
	export assembly_folder="C:/NB5419/ActivePivotJars/activepivot-live-sandbox-3.4.0-repository"
	export assembly_folder="C:/NB5419/ActivePivotJars/activepivot-sandbox-4.4.10-repository"
	export assembly_folder="C:/NB5419/ActivePivotJars/5.4.2-repository"
fi

echo "Exporting $assembly_folder"

./runme_to_export_AP4.sh "$assembly_folder" "$repoid" "$repourl" 
./runme_to_export_AP5.sh "$assembly_folder" "$repoid" "$repourl" 
./runme_to_export_AP5.5.sh "$assembly_folder" "$repoid" "$repourl" 

#/bin/sh

export assembly_folder="$1"
export repoid="$2"
export repourl="$3"

# In AP5.8, most jars are available in jdk8 and jdk11

# activepivot-copper turned from a 'jar' to a 'pom' with AP5.8
./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activepivot/" "activepivot-copper" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activepivot/" "activepivot-copper-impl" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/activepivot/" "activepivot-copper-test" &

./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/tech/" "datastore-parent" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/tech/" "datastore" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/tech/" "datastore-test" &


./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/source/" "key-value-source" &
./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/source/" "cloud-source" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/source/" "cloud-source-test" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/source/" "cloud-source-common" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/source/" "cloud-source-google" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/source/" "cloud-source-azure" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/source/" "cloud-source-aws" &

./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/tech/" "content-server-ui" &


# Wait regularly to prevent pushing too many jars at the same time
wait

# New in AP5.8
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/tech/" "reporting-temporary-file-consumer" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/tech/" "reporting-rest" &
./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/tech/" "reporting-producers" &
./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/tech/" "reporting-plugins" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/tech/" "reporting-pdf-producer" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/tech/" "reporting-mail-consumer" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/tech/" "reporting-download-link-consumer" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/tech/" "reporting-download-consumer" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/tech/" "reporting-core" &
./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/tech/" "reporting-consumers" &
./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/tech/" "reporting" &

./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/tech/" "scheduling-task" &
./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/tech/" "scheduling-schedules" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/tech/" "scheduling-report-task" &
./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/tech/" "scheduling-plugins" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/tech/" "scheduling-cron-schedule" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/tech/" "scheduling-core" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/tech/" "scheduling-contentservice" &
./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "com/activeviam/tech/" "scheduling" &



wait
#/bin/sh

export repoid="maven.activepivot.solven.eu-release"
export repourl="s3://maven2.activepivot.solven.eu/release"
export S3BUCKET="maven2.activepivot.solven.eu"

export assembly_folder="$1"

# https://serverfault.com/questions/7503/how-to-determine-if-a-bash-variable-is-empty
if [ -z $AWS_ACCESS_KEY_ID ]
  then
    echo "Variable 'AWS_ACCESS_KEY_ID' is empty. Call 'export AWS_ACCESS_KEY_ID=XXX'"
    exit
fi
echo "Connecting to S3 as $AWS_ACCESS_KEY_ID"

if [ -z $AWS_SECRET_ACCESS_KEY ]
  then
    echo "Variable 'AWS_SECRET_ACCESS_KEY' is empty. Call 'export AWS_SECRET_ACCESS_KEY=YYY'"
    exit
fi

if [ -z $S3BUCKET ]
  then
    echo "Variable 'S3BUCKET' is empty. Call 'export S3BUCKET=maven2.activepivot.solven.eu'"
    exit
fi

./deploy_to_XXX.sh "$assembly_folder" "$repoid" "$repourl"
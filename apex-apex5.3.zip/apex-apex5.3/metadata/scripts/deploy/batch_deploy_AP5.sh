#/bin/sh

export assembly_folder="$1"
export repoid="$2"
export repourl="$3"

# http://stackoverflow.com/questions/5547787/running-shell-script-in-parallel

./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/biz/pivot/" "activepivot-core" &

./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/biz/pivot/" "activepivot" &

./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/biz/pivot/" "activepivot-ext" &

./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/biz/pivot/" "activepivot-impl" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/biz/pivot/" "activepivot-intf" &

./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/biz/pivot/" "activepivot-mdx" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/biz/pivot/" "activepivot-mdx-impl" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/biz/pivot/" "activepivot-mdx-intf" &


./raw_deploy_jar_tests.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/biz/pivot/" "datastore" &

./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/composer/" "serialization" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/composer/serialization/" "serialization-jaxb" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/composer/serialization/" "serialization-jackson" &


./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/biz/sentinel/" "sentinel" 
./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/biz/sentinel/" "sentinel-activepivot" 
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/biz/sentinel/" "sentinel-activepivot-impl" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/biz/sentinel/" "sentinel-activepivot-intf" &
./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/biz/sentinel/" "sentinel-server" 
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/biz/sentinel/" "sentinel-server-impl" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/biz/sentinel/" "sentinel-server-intf" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/biz/sentinel/" "sentinel-web" &


./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/biz/pivot/live/" "activepivot-live" 
./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/biz/pivot/live/" "activepivot-live-core" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/biz/pivot/live/" "activepivot-live-core-main" 
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/biz/pivot/live/" "activepivot-live-components" 
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/biz/pivot/live/" "activepivot-live-content" 
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/biz/pivot/live/" "activepivot-live-charts" 
./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/biz/pivot/live/" "activepivot-live-resources" 
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/biz/pivot/live/" "activepivot-live-resources-main" 
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/biz/pivot/live/" "activepivot-live-resources-reference" 



./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/biz/pivot/" "activepivot-test" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/biz/pivot/" "activepivot-ws-client" &

./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/composer/messaging/" "messaging-csv" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/composer/messaging/" "messaging-jdbc" &
#exit

./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/biz/pivot/" "activepivot-server-json" &
#exit

./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/biz/pivot/" "activepivot-server" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/biz/pivot/" "activepivot-server-impl" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/biz/pivot/" "activepivot-server-intf" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/biz/pivot/" "activepivot-server-spring" &

./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/tech/streaming/" "streaming" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/tech/streaming/" "streaming-impl" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/tech/streaming/" "streaming-intf" &

./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/contrib/" "jboss-jaxb-intros" &

./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/composer/activation/" "qfs-activation" &

./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/contrib/" "qfs-olap4j" 
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/contrib/" "qfs-olap4j-core" 
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/contrib/" "qfs-olap4j-xmla" 

./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/composer/messaging/" "messaging-key-value" &

./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/contrib/" "qfs-jsr166" &
./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/maven/" "qfs" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/numa/" "numalib" &



./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/composer/" "qfs-web" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/composer/" "qfs-web-core" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/composer/" "qfs-web-spring" &





./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/composer/content/" "content-server" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/composer/content/" "content-server-rest" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/composer/content/" "content-server-spring" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/composer/content/" "content-server-storage" &


./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "com/github/blasd/apex/" "apex" &

./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/biz/pivot/" "amondrian" &

./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/biz/pivot/" "pivolap" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/biz/pivot/" "pivolap-intf" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/biz/pivot/" "pivolap-impl" &

./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/tech/indexer/" "indexer" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/tech/indexer/" "indexer-intf" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/tech/indexer/" "indexer-impl" &

./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/biz/sentinel/" "repository" 
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/biz/sentinel/" "repository-activepivot" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/biz/sentinel/" "repository-impl" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/biz/sentinel/" "repository-intf" &



./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/biz/pivot/" "xmla" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/biz/pivot/" "xmla-binary-xml" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/biz/pivot/" "xmla-impl" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/biz/pivot/" "xmla-intf" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/biz/pivot/" "xmla-pivot" &



./raw_deploy_pom.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/composer/" "composer" &
./raw_deploy_jar_tests.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/composer/" "composer-impl" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "quartetfs/composer/" "composer-intf" &


wait
exit

# These jars are available either in http://repository.pentaho.org/content/repositories/public-snapshots/
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "org/olap4j/" "olap4j" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "org/olap4j/" "olap4j-xmla" &

# These jars are available either in https://repository.jboss.org/
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "i18nlog/" "i18nlog" &
./raw_deploy_jar.sh "$repourl" "$repoid" "$assembly_folder" "xerces/" "xercesImpl" &

wait
exit
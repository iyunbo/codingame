# apex
## metadata
The top pom for apex. It holds the configuration specific to each apex customer environment

# To push ActivePivot jars to a customer environment
There is prepare scripts in ./scripts/deploy

    cd apex/metadata/scripts/deploy
    sh ./deploy_to_engie.sh
    sh ./deploy_to_socgen.sh

To successfully deploy in a customer environment, you will need to have proper server credentials configured in your settings.xml

		<server>
			<id>engie-thirdparty</id>
			<username>nb5419</username>
			<!-- Retrieve encrypted password in http://artifactory.trading.gdfsuez.net/artifactory/webapp/#/profile -->
			<password>XXX</password>
		</server>


# To push ActivePivot jars to AWS S3

A simple procedure is to rely on existing scripts:

    cd metadata/script/deploy
    ./deploy_to_solven.sh /root/folder/maven-repository-5.X.Y/
    
The S3 wagon will rely on credentials typically defined in .bash_profile:

    export AWS_ACCESS_KEY_ID=XXX
    export AWS_SECRET_ACCESS_KEY=YYY
    
These variables can be set as User environment variables in Windows.
    
To successfully deploy with S3, you will need the S3 Wagon to be available to script: the jar will have to be made available to maven:

    https://github.com/spring-projects/aws-maven/pull/34
    git clone https://github.com/ElectronicRemedy/aws-maven.git
    cd aws-maven
    mvn clean install -PshadedWagon
    cp target/aws-maven-wagon.jar <maven>/lib/ext
    
To prevent conflicts, this jar shall be activated (e.g. named .jar or .jar.bak) only when executing deploy_to_solven.sh 
    
Maven can be located with:

    mvn -v
    
Beware this 'aws-maven-wagon.jar' will certainly prevent other mvn commands to run properly because of class conflicts. It can be deactivated with:

    mv <maven>/lib/ext/aws-maven-wagon.jar <maven>/lib/ext/aws-maven-wagon.jar.DEACTIVATED


# Merge multiple zip assembly in a single folder

Helping commands:

    mkdir runonme
    cp -R com\ */* runonme/com/
    cp -R maven-repository-*/* runonme/ 

# To fetch ActivePivot jars from AWS S3	
Travis relies on jar deployed on a private S3 bucket. The S3 wagon relies on environment variables. Typically, in linux, add in .bash_profile:

    export AWS_ACCESS_KEY_ID=XXX
    export AWS_SECRET_ACCESS_KEY=YYY

## Gives rights to Write into S3

The role in AWS IAM is:

    READ_WRITE_MAVEN_ACTIVEPIVOT


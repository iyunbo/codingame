/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.spring;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.qfs.content.service.IContentService;
import com.qfs.pivot.content.IActivePivotContentService;

import blasd.apex.server.test.pivot.ApexActivePivotLicenseHelper;
import blasd.apex.server.test.registry.ApexTestRegistryHelper;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(
		classes = { ApexContentServerInFileSystemSpringConfig.class, ApexContentServerConfigComplementForTests.class })
@WebAppConfiguration
@TestPropertySource(properties = {
		ApexContentServerInFileSystemSpringConfig.KEY_H2_ROOT_DIRECTORY + "=" + "./target/content-server/" })
public class TestApexContentServerOnFileSystem {
	@BeforeClass
	public static void loadLicense() {
		ApexActivePivotLicenseHelper.ensureLicenseWithEnv();
		ApexTestRegistryHelper.ensureSecurityFacade();
	}

	@Autowired
	protected IActivePivotContentService apContentServiceConfig;

	@Test
	public void checkContentServiceWorks() {
		final IContentService rootContentService = apContentServiceConfig.getContentService().withRootPrivileges();

		Assert.assertFalse(rootContentService.getFiles("/").isEmpty());
	}
}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.spring;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.qfs.content.service.IContentService;
import com.qfs.pivot.content.IActivePivotContentService;
import com.qfs.server.cfg.impl.CxfServletConfig;
import com.qfs.store.IDatastore;
import com.quartetfs.biz.pivot.IActivePivotManager;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { ApexContentServerResourceServerConfig.class,
		ApexContentServerRestServicesConfig.class,

		// Needed by autowiring but not actually used
		CxfServletConfig.class,
		ApexFakeActivePivotConfig.class,
		TestApexAllContentServerConfig.class })
@WebAppConfiguration
public class TestApexAllContentServerConfig {

	@Bean
	IContentService contentService() {
		return Mockito.mock(IContentService.class);
	}

	@Bean
	IActivePivotManager activePivotManager() {
		// Required by ApexFakeActivePivotConfig
		return Mockito.mock(IActivePivotManager.class);
	}

	@Bean
	IDatastore datastore() {
		// Since AP5.6, required by Copper
		return Mockito.mock(IDatastore.class);
	}

	@Bean
	IActivePivotContentService activePivotContentService() {
		return Mockito.mock(IActivePivotContentService.class);
	}

	// https://www.petrikainulainen.net/programming/spring-framework/unit-testing-of-spring-mvc-controllers-configuration/
	// https://geowarin.github.io/complete-example-of-a-spring-mvc-3-2-project.html
	@Autowired
	WebApplicationContext webApplicationContext;

	protected MockMvc mockMvc;

	@Before
	public void setup() {
		mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
	}

	@Test
	public void testGetRoot() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/content"))
				.andExpect(MockMvcResultMatchers.redirectedUrl("/content/index.html"));
	}

	@Test
	public void testGetIndexHtml() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/content/index.html"))
				.andExpect(MockMvcResultMatchers.status().isOk());
	}

	// TODO We have a 404 for an unknown reason. The actual server seems OK
	@Ignore
	@Test
	public void testGetRestFilesLive() throws Exception {
		// Check calls to 'rest' are forwarded to ApexContentServerRestServicesConfig
		mockMvc.perform(MockMvcRequestBuilders.get("/content/rest/v2/files/live"))
				.andExpect(MockMvcResultMatchers.status().isOk());
	}
}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.spring;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import com.qfs.content.cfg.impl.ContentServerRestServicesConfig;

import blasd.apex.server.config.services.ISpringVersionedRestServerConfig;

/**
 * Like ContentServerRestServicesConfig. Override not to import ContentServerWebSocketServicesConfig
 * 
 * @author Benoit Lacelle
 *
 */
// ApexContentServerResourceServerConfig enables accessing the contentserver through '/content/index.html'
@Import(ApexContentServerResourceServerConfig.class)
@Configuration
public class ApexContentServerRestServicesConfig implements InitializingBean, ISpringVersionedRestServerConfig {
	private final ContentServerRestServicesConfig contentRestServicesConfig;
	private final ApplicationContext appContext;

	public ApexContentServerRestServicesConfig(ApplicationContext appContext) {
		this.appContext = appContext;
		contentRestServicesConfig = new ContentServerRestServicesConfig();
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		appContext.getAutowireCapableBeanFactory().autowireBean(contentRestServicesConfig);

		contentRestServicesConfig.afterPropertiesSet();
	}

	@Override
	public String getNamespace() {
		return contentRestServicesConfig.getNamespace();
	}

	@Override
	public String getVersion() {
		return contentRestServicesConfig.getVersion();
	}
}

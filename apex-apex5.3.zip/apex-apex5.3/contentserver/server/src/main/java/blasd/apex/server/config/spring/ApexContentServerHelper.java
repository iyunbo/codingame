/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.spring;

import com.qfs.pivot.content.IActivePivotContentService;
import com.qfs.pivot.content.impl.ActivePivotContentServiceBuilder;
import com.qfs.pivot.content.impl.ActivePivotContentServiceBuilder.ICanCache;
import com.quartetfs.biz.pivot.definitions.IActivePivotManagerDescription;

import blasd.apex.server.config.spring.security.IApexSecurityConstants;

/**
 * Helpers for IActivePivotContentService
 * 
 * @author Benoit Lacelle
 * @see IActivePivotContentService
 */
public class ApexContentServerHelper {
	protected ApexContentServerHelper() {
		// hidden
	}

	public static <T extends ActivePivotContentServiceBuilder.INeedInit> IActivePivotContentService simpleContentServer(
			ICanCache<T> withCacheForEntitlements,
			IActivePivotManagerDescription apManagerDesc) {
		// Setup directories and permissions
		return withCacheForEntitlements.withCacheForEntitlements(-1)
				.needInitialization(IApexSecurityConstants.USER_MDX_ROLE, IApexSecurityConstants.USER_KPI_ROLE)

				// https://support.quartetfs.com/jira/browse/APS-10023
				// How can we skip the push of the description, in case in refers not marshable objects in Filter
				// conditions
				// Push the manager description from DESC-INF
				.withDescription(apManagerDesc)
				// Push the context values stored in ROLE-INF
				// .withContextValues(ROLE_INF)
				.build();
	}
}

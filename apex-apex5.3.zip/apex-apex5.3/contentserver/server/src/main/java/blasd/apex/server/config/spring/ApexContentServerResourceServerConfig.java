/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.spring;

import java.util.Arrays;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.web.servlet.config.annotation.DefaultServletHandlerConfigurer;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.google.common.primitives.Ints;
import com.qfs.content.cfg.impl.ContentServerRestServicesConfig;
import com.qfs.content.cfg.impl.UseContentServerUI;

import blasd.apex.server.config.spring.security.IApexSecurityConstants;

/**
 * This enables accessing the content-server content through a Web GUI. By default, it is available through
 * '/content/index.html'
 * 
 * Like ContentServerResourceServerConfig but public. It relies on Spring MVC to prevent such bean-cycles exceptions in
 * Spring-Boot
 * 
 * @author Benoit Lacelle
 * @see http://support.quartetfs.com/jira/browse/APS-9174
 * 
 * @see ApexEmbeddedActiveUIMvcConfig
 * @see ApexContentServerResourceServerConfig
 *
 */
@Conditional({ UseContentServerUI.class })
@Configuration
@EnableWebMvc
public class ApexContentServerResourceServerConfig extends WebMvcConfigurerAdapter implements IApexSecurityConstants {

	@Autowired
	protected Environment env;

	// equivalents for <mvc:resources/> tags
	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		registry.addResourceHandler(getContentServerServlet())
				.addResourceLocations(getContentServerResources())
				.setCachePeriod(getContentServerCachePeriod());
	}

	protected Integer getContentServerCachePeriod() {
		return env.getProperty("contentserver.cacheInSeconds",
				Integer.class,
				Ints.saturatedCast(TimeUnit.SECONDS.convert(1, TimeUnit.HOURS)));
	}

	protected String[] getContentServerResources() {
		// in jar content-server-rest
		return env.getProperty("contentserver.resources", "classpath:WEB-INF/content-server/").split("\\|");
	}

	protected String getNamespace() {
		return env.getProperty("contentserver.servlet", ContentServerRestServicesConfig.NAMESPACE);
	}

	protected String[] getContentServerServlet() {
		// We can not exclude /rest: we need to include all others
		return Arrays.asList("html", "js", "css", "ico", "png")
				.stream()
				.map(s -> "/" + getNamespace() + SPRING_MATCH_ALL + "/*." + s)
				.toArray(String[]::new);
	}

	// equivalent for <mvc:default-servlet-handler/> tag
	@Override
	public void configureDefaultServletHandling(DefaultServletHandlerConfigurer configurer) {
		if (enableDefaultServletHandling()) {
			// http://stackoverflow.com/questions/8023203/how-to-use-default-servlet-handler
			// TODO: do NOT redirect to DISPATCHER_SERVLET_NAME else we would have StackOverflow as not-handled
			// requests would be exchanged indefinitely between Spring and webapp main servlet
			configurer.enable();
		}
	}

	protected boolean enableDefaultServletHandling() {
		// By default, we consider there is no resources served directly by the servlet. It appears some projects have
		// no default servlet???
		// TODO find the proper default servlet under jetty
		return false;
	}

	@Override
	public void addViewControllers(ViewControllerRegistry registry) {
		// Redirect '/content' to '/content/index.html'
		String prefix = "/" + getNamespace();
		String fullIndexHtml = prefix + "/index.html";
		registry.addRedirectViewController(prefix, fullIndexHtml);
		registry.addRedirectViewController(prefix + "/", fullIndexHtml);
	}
}

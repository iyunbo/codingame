/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.spring;

import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

import com.qfs.content.service.IContentService;
import com.qfs.pivot.content.IActivePivotContentService;
import com.qfs.pivot.content.impl.ActivePivotContentServiceBuilder;
import com.qfs.pivot.content.impl.ActivePivotContentServiceBuilder.IAPCSBuilderWithInit;
import com.qfs.pivot.content.impl.ActivePivotContentServiceBuilder.ICanCache;
import com.quartetfs.biz.pivot.definitions.IActivePivotManagerDescription;

/**
 * Helps configuring a filsystem-based content-server. It is useful in UAT environment as it will not require a BDD.
 * 
 * @author Benoit Lacelle
 *
 */
@Configuration
public class ApexContentServerInFileSystemSpringConfig {

	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexContentServerInFileSystemSpringConfig.class);

	public static final String KEY_H2_ROOT_DIRECTORY = "apex.content.h2.rootDirectory";

	@Bean
	public IContentService contentService(IActivePivotContentService activePivotContentService) {
		// Return the real content service used by the activePivotContentService instead of the wrapped one
		return activePivotContentService.getContentService().getUnderlying();
	}

	@Bean
	public IActivePivotContentService activePivotContentService(Environment env,
			IActivePivotManagerDescription apManagerDesc) {
		Properties dbProperties = new Properties();

		String h2RootDirectory = env.getProperty(KEY_H2_ROOT_DIRECTORY);

		dbProperties.put(org.hibernate.cfg.Environment.URL,
				"jdbc:h2:file:" + h2RootDirectory + "content_service;DB_CLOSE_DELAY=-1");
		dbProperties.put(org.hibernate.cfg.Environment.DRIVER, org.h2.Driver.class.getName());
		dbProperties.put(org.hibernate.cfg.Environment.DIALECT, org.hibernate.dialect.H2Dialect.class.getName());

		{
			dbProperties.put(org.hibernate.cfg.Environment.SHOW_SQL,
					env.getProperty(org.hibernate.cfg.Environment.SHOW_SQL, "false"));
			dbProperties.put(org.hibernate.cfg.Environment.FORMAT_SQL,
					env.getProperty(org.hibernate.cfg.Environment.FORMAT_SQL, "false"));
			//
			// Connection pool
			dbProperties.put(org.hibernate.cfg.Environment.C3P0_MIN_SIZE,
					env.getProperty(org.hibernate.cfg.Environment.C3P0_MIN_SIZE, "1"));
			dbProperties.put(org.hibernate.cfg.Environment.C3P0_MAX_SIZE,
					env.getProperty(org.hibernate.cfg.Environment.C3P0_MAX_SIZE, "20"));
			// When an idle connection is removed from the pool (in second)
			dbProperties.put(org.hibernate.cfg.Environment.C3P0_TIMEOUT,
					env.getProperty(org.hibernate.cfg.Environment.C3P0_TIMEOUT, "300"));
			// Number of cached prepared statements
			dbProperties.put(org.hibernate.cfg.Environment.C3P0_MAX_STATEMENTS,
					env.getProperty(org.hibernate.cfg.Environment.C3P0_MAX_STATEMENTS, "50"));

			// The following line should be removed once the table is created
			dbProperties.put(org.hibernate.cfg.Environment.HBM2DDL_AUTO,
					env.getProperty(org.hibernate.cfg.Environment.HBM2DDL_AUTO, "update"));
		}

		org.hibernate.cfg.Configuration configurtation =
				new org.hibernate.cfg.Configuration().addProperties(dbProperties);

		LOGGER.info("Using ContentService persisted in {}", h2RootDirectory);

		ICanCache<IAPCSBuilderWithInit> withAudit =
				new ActivePivotContentServiceBuilder().withPersistence(configurtation).withAudit();
		return ApexContentServerHelper.simpleContentServer(withAudit, apManagerDesc);
	}
}

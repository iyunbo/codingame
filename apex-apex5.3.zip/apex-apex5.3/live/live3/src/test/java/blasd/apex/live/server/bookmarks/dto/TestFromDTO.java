/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.live.server.bookmarks.dto;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.quartetfs.pivot.live.content.shared.IContent;
import com.quartetfs.pivot.live.core.shared.setting.impl.BooleanSetting;
import com.quartetfs.pivot.live.core.shared.widget.impl.PopupProperty;
import com.quartetfs.pivot.live.shared.content.impl.SettingContent;
import com.quartetfs.pivot.live.shared.setting.impl.PopupPropertySetting;

import blasd.apex.live.server.bookmark.dto.AContentDTO;
import blasd.apex.live.server.bookmark.dto.ContentCommonDTO;
import blasd.apex.live.server.bookmark.dto.ContentFromDTO;
import blasd.apex.live.server.bookmark.dto.ContentToDTO;
import blasd.apex.live.server.bookmark.dto.SettingContentDTO;
import blasd.apex.live.server.bookmarks.main.ApexMainBookmarksAdmin;

public class TestFromDTO {
	@BeforeClass
	public static void beforeClass() {
		ApexMainBookmarksAdmin.initRegistryForLive();
	}

	@Test
	public void testConvertSettingDTO() {
		SettingContentDTO settingDTO = new SettingContentDTO(new ContentCommonDTO(null, null, null, null, null),
				"settingKey",
				"true",
				BooleanSetting.TYPE.getKey());

		IContent content = ContentFromDTO.convertFromDTO(settingDTO);

		Assert.assertEquals(new SettingContent(new BooleanSetting("settingKey", true)), content);
	}

	@Test
	public void testConvertToSetting() {
		IContent settingContent =
				new SettingContent(new PopupPropertySetting("settingKey", new PopupProperty(1, 2, true, false, 3, 4)));

		AContentDTO contentDTO = ContentToDTO.convertToDTO(settingContent);

		SettingContentDTO settingDTO = new SettingContentDTO(new ContentCommonDTO(null, null, null, null, null),
				"settingKey",
				"1.0#2.0#true#false#3#4",
				PopupPropertySetting.TYPE.getKey());

		Assert.assertEquals(settingDTO.getClass(), contentDTO.getClass());
		Assert.assertEquals(settingDTO.getKey(), ((SettingContentDTO) contentDTO).getKey());
		Assert.assertEquals(settingDTO.getValue(), ((SettingContentDTO) contentDTO).getValue());
	}
}

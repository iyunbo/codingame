/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.live.server.bookmarks;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.UUID;

import javax.xml.bind.JAXBException;

import org.apache.commons.io.FileUtils;
import org.apache.jackrabbit.core.config.ConfigurationException;
import org.apache.jackrabbit.core.config.RepositoryConfig;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;
import org.springframework.security.authentication.TestingAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.quartetfs.pivot.live.content.impl.ContentException;
import com.quartetfs.pivot.live.content.shared.IContent;

import blasd.apex.live.server.bookmark.dto.AContentDTO;
import blasd.apex.live.server.bookmark.dto.AContentDTOHelper;
import blasd.apex.live.server.bookmark.dto.ApplicationDTO;
import blasd.apex.live.server.bookmark.dto.ContentCommonDTO;
import blasd.apex.live.server.bookmark.dto.ContentFromDTO;
import blasd.apex.live.server.bookmark.dto.FolderDTO;
import blasd.apex.live.server.bookmark.dto.MdxQueryDTO;
import blasd.apex.live.server.bookmark.dto.UsersDTO;
import blasd.apex.live.server.bookmarks.content.ApexContentMergerOnTitle;
import blasd.apex.live.server.bookmarks.content.ApexContentMergerOnUUID;
import blasd.apex.live.server.bookmarks.content.TechnicalFolderDTO;
import blasd.apex.live.server.bookmarks.main.ApexMainBookmarksAdmin;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { ApexMainBookmarksAdmin.class, TestApexContentManager.class })
@TestPropertySource(properties = ApexMainBookmarksAdmin.KEY_JCR_PATH + "=" + TestApexContentManager.TEST_JCR_FOLDER)
public class TestApexContentManager {
	public static final String TEST_JCR_FOLDER = "${java.io.tmpdir}/apex-test";

	public static final String USERNAME = "UserName";

	// Override the default bean to reset the JCR which may be corrupted
	@Bean
	public RepositoryConfig repositoryConfig(Environment environment) throws ConfigurationException, IOException {
		String repositoryPath = ApexMainBookmarksAdmin.getRepositoryFolder(environment);

		if (repositoryPath == null) {
			throw new RuntimeException("We Failed getting JCR path ");
		} else {
			FileUtils.deleteDirectory(new File(repositoryPath));
		}

		return new ApexMainBookmarksAdmin().repositoryConfig(environment);
	}

	@Autowired
	IApexContentManager apexContentManager;

	@BeforeClass
	public static void beforeClass() {
		ApexMainBookmarksAdmin.initRegistryForLive();
	}

	@Before
	public void before() throws ContentException {
		// Ensure security
		TestingAuthenticationToken authentication =
				new TestingAuthenticationToken(apexContentManager.getSystemUser().getUserName(), "ApexCredential");
		authentication.setAuthenticated(true);
		SecurityContextHolder.getContext().setAuthentication(authentication);

		for (String groupFolderUUID : apexContentManager.getGroupFolderUUIDToName().keySet()) {
			apexContentManager.delete(groupFolderUUID);
		}
		for (String groupFolderUUID : apexContentManager.getUserFolderUUIDToName().keySet()) {
			apexContentManager.delete(groupFolderUUID);
		}

		// Reset security
		SecurityContextHolder.getContext().setAuthentication(null);
	}

	@Test
	public void testImportMDXInExistingFolderExportFolderWithMDX() throws ContentException, JAXBException {
		TestingAuthenticationToken authentication = new TestingAuthenticationToken(USERNAME, "ApexCredential");
		authentication.setAuthenticated(true);
		SecurityContextHolder.getContext().setAuthentication(authentication);

		try {
			String folderTitle = "first folder";

			// First, we add a new folder
			String folderUuid;
			{
				FolderDTO folderDTO = new FolderDTO(new ContentCommonDTO(null, null, folderTitle, null, null));

				folderDTO.contentCommon.parentUUID = apexContentManager.getUserFolderUUID(USERNAME);

				IContent content = ContentFromDTO.convertFromDTO(folderDTO);
				folderUuid = apexContentManager.create(content);
			}

			String mdxTitle = "some query";
			String mdxQuery = "hardcore mdx";

			// Then we add an MDX
			MdxQueryDTO mdxQueryDTO =
					new MdxQueryDTO(new ContentCommonDTO(null, null, mdxTitle, null, null), mdxQuery, null, null);

			String asString;
			{
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				AContentDTOHelper.doMarshall(mdxQueryDTO, baos);

				asString = new String(baos.toByteArray());
			}

			int nbAdded = apexContentManager.importBookmarksAsAdmin(folderUuid, asString);
			Assert.assertEquals(1, nbAdded);

			// Check created folder
			{
				AContentDTO exportedAsDTO = apexContentManager.exportBookmarksToDTO(folderUuid);

				Assert.assertEquals(folderTitle, exportedAsDTO.contentCommon.title);

				Assert.assertTrue(exportedAsDTO.contentCommon.children.size() == 1);
				Assert.assertEquals(mdxTitle, exportedAsDTO.contentCommon.children.get(0).contentCommon.title);
			}
			// Check created folder
			{
				String exportedAsString = apexContentManager.exportBookmarks(folderUuid);
				Assert.assertTrue(exportedAsString.contains(mdxQuery));
			}
			// Check created folder parent
			{
				AContentDTO parentFolderAsDTO =
						apexContentManager.exportBookmarksToDTO(apexContentManager.get(folderUuid).getParentUUID());

				Assert.assertEquals(USERNAME, parentFolderAsDTO.contentCommon.title);

				Assert.assertTrue(parentFolderAsDTO.contentCommon.children.size() == 1);
				Assert.assertEquals(folderTitle, parentFolderAsDTO.contentCommon.children.get(0).contentCommon.title);

				Assert.assertEquals(mdxTitle,
						parentFolderAsDTO.contentCommon.children.get(0).contentCommon.children
								.get(0).contentCommon.title);
			}
		} finally {
			SecurityContextHolder.getContext().setAuthentication(null);
		}
	}

	@Test
	public void testExportImportApplication() throws ContentException, JAXBException {
		TestingAuthenticationToken authentication = new TestingAuthenticationToken(USERNAME, "ApexCredential");
		authentication.setAuthenticated(true);
		SecurityContextHolder.getContext().setAuthentication(authentication);

		try {
			// First, we add a new folder
			String folderUuid;
			{
				FolderDTO folderDTO = new FolderDTO(new ContentCommonDTO(null, null, "first folder", null, null));
				IContent content = ContentFromDTO.convertFromDTO(folderDTO);
				folderUuid = apexContentManager.create(content);
			}

			String mdxTitle = "some query";
			String mdxQuery = "hardcore mdx";

			// Then we add an MDX
			MdxQueryDTO mdxQueryDTO =
					new MdxQueryDTO(new ContentCommonDTO(null, null, mdxTitle, null, null), mdxQuery, null, null);

			String asString;
			{
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				AContentDTOHelper.doMarshall(mdxQueryDTO, baos);

				asString = new String(baos.toByteArray());
			}

			// Import MDX
			{
				int nbAdded = apexContentManager.importBookmarksAsAdmin(folderUuid, asString);
				Assert.assertEquals(1, nbAdded);
			}

			// Export application
			String exportedApplication = apexContentManager.exportBookmarks(apexContentManager.getApplicationUUID());
			Assert.assertTrue(exportedApplication.contains(mdxQuery));

			// Import back application
			{
				int nbAdded = apexContentManager.importBookmarksAsAdmin(apexContentManager.getApplicationUUID(),
						exportedApplication);

				// ApplicationNode
				// Groups
				// Users
				// Current user
				// Folder
				// MDX
				// -> Total to 6
				Assert.assertEquals(6, nbAdded);
			}
		} finally {
			SecurityContextHolder.getContext().setAuthentication(null);
		}
	}

	@Test(expected = RuntimeException.class)
	public void testImportMdxInApplicationNode() throws ContentException, JAXBException {
		TestingAuthenticationToken authentication = new TestingAuthenticationToken(USERNAME, "ApexCredential");
		authentication.setAuthenticated(true);
		SecurityContextHolder.getContext().setAuthentication(authentication);

		try {
			String mdxTitle = "some query";
			String mdxQuery = "hardcore mdx";

			// Then we add an MDX
			MdxQueryDTO mdxQueryDTO =
					new MdxQueryDTO(new ContentCommonDTO(null, null, mdxTitle, null, null), mdxQuery, null, null);

			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			AContentDTOHelper.doMarshall(mdxQueryDTO, baos);

			String asString = new String(baos.toByteArray());

			// Import MDX in applicationNode
			// We expect a failure as applicationNode does not accept directly an MDX
			apexContentManager.importBookmarksAsAdmin(apexContentManager.getApplicationUUID(), asString);
		} finally {
			SecurityContextHolder.getContext().setAuthentication(null);
		}
	}

	@Test
	public void testMakeUnknownUserNode() throws ContentException, JAXBException {
		String userName = "FakeFolderName-" + UUID.randomUUID();

		// This should create the node
		String newUuid = apexContentManager.getUserFolderUUID(userName);

		Assert.assertNotNull(newUuid);
		Assert.assertEquals(newUuid, apexContentManager.getUserFolderNameToUUID().get(userName));

		// Check we do not recreate a second user folder
		String shouldBeSameUUID = apexContentManager.getUserFolderUUID(userName);
		Assert.assertEquals(shouldBeSameUUID, newUuid);
	}

	@Test
	public void testMakeUnknownGroupNode() throws ContentException, JAXBException {
		String groupName = "FakeFolderName-" + UUID.randomUUID();

		// This should create the node
		String newUuid = apexContentManager.getGroupFolderUUID(groupName);

		Assert.assertNotNull(newUuid);
		Assert.assertEquals(newUuid, apexContentManager.getGroupFolderNameToUUID().get(groupName));

		// Check we do not recreate a second user folder
		String shouldBeSameUUID = apexContentManager.getGroupFolderUUID(groupName);
		Assert.assertEquals(shouldBeSameUUID, newUuid);
	}

	@Test
	public void testImportMdxInUnknownUserNode() throws ContentException, JAXBException {
		TestingAuthenticationToken authentication = new TestingAuthenticationToken(USERNAME, "ApexCredential");
		authentication.setAuthenticated(true);
		SecurityContextHolder.getContext().setAuthentication(authentication);

		try {
			String mdxTitle = "some query";
			String mdxQuery = "hardcore mdx";

			// Then we add an MDX
			MdxQueryDTO mdxQueryDTO =
					new MdxQueryDTO(new ContentCommonDTO(null, null, mdxTitle, null, null), mdxQuery, null, null);

			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			AContentDTOHelper.doMarshall(mdxQueryDTO, baos);

			String asString = new String(baos.toByteArray());

			// Import MDX in applicationNode
			String userFolderUUID = apexContentManager.getUserFolderUUID(authentication.getName());
			Assert.assertNotNull(userFolderUUID);

			int nbAdded = apexContentManager.importBookmarksAsAdmin(userFolderUUID, asString);
			Assert.assertEquals(1, nbAdded);

			String exportedApplication = apexContentManager.exportBookmarks(apexContentManager.getApplicationUUID());
			Assert.assertTrue(exportedApplication.contains(mdxQuery));
		} finally {
			SecurityContextHolder.getContext().setAuthentication(null);
		}
	}

	@Test
	public void testImportNodeWhenAlready2WithSameTitle() throws ContentException, JAXBException {
		TestingAuthenticationToken authentication = new TestingAuthenticationToken(USERNAME, "ApexCredential");
		authentication.setAuthenticated(true);
		SecurityContextHolder.getContext().setAuthentication(authentication);

		try {
			// First, we add a new folder
			FolderDTO folderDTO;
			{
				folderDTO = new FolderDTO(new ContentCommonDTO(null, null, "first folder", null, null));
			}

			String userNodeUUID = apexContentManager.getUserFolderUUID(USERNAME);

			// Add empty folder
			String folderUuid;
			{
				int nbAdded = apexContentManager.importBookmarksAsAdmin(userNodeUUID,
						AContentDTOHelper.doMarshallAsString(folderDTO));
				Assert.assertEquals(1, nbAdded);

				folderUuid = apexContentManager.exportBookmarksToDTO(userNodeUUID).contentCommon.children
						.get(0).contentCommon.uuid;

				// Ensure all import of the folder with match, even with UUID only
				folderDTO.contentCommon.uuid = folderUuid;
			}

			String singleTitle = "some query";

			String firstQuery = "hardcore mdx";

			// Then we add an MDX
			{
				MdxQueryDTO mdxQueryDTO = new MdxQueryDTO(new ContentCommonDTO(null, null, singleTitle, null, null),
						firstQuery,
						null,
						null);

				folderDTO.contentCommon.children.add(mdxQueryDTO);
			}

			// Add folder with 1 entry: merge folder and add MDX

			{
				int nbAdded = apexContentManager.importBookmarksAsAdmin(userNodeUUID,
						AContentDTOHelper.doMarshallAsString(folderDTO));
				Assert.assertEquals(2, nbAdded);

				AContentDTO exportedFolder = apexContentManager.exportBookmarksToDTO(folderUuid);
				Assert.assertEquals(firstQuery,
						((MdxQueryDTO) exportedFolder.contentCommon.children.get(0)).getMdxQuery());

				// MDX DTO have been inserted
				Assert.assertEquals(1, exportedFolder.contentCommon.children.size());
			}

			String secondQuery = "another mdx";
			{
				MdxQueryDTO mdxQueryDTO = new MdxQueryDTO(new ContentCommonDTO(null, null, singleTitle, null, null),
						secondQuery,
						null,
						null);

				folderDTO.contentCommon.children.clear();
				folderDTO.contentCommon.children.add(mdxQueryDTO);
			}

			// Add folder with 1 entry: merge folder and merge MDX
			{
				int nbAdded = apexContentManager.importBookmarksAsAdmin(userNodeUUID,
						AContentDTOHelper.doMarshallAsString(folderDTO));
				Assert.assertEquals(2, nbAdded);

				AContentDTO exportedFolder = apexContentManager.exportBookmarksToDTO(folderUuid);
				Assert.assertEquals(secondQuery,
						((MdxQueryDTO) exportedFolder.contentCommon.children.get(0)).getMdxQuery());

				// MDX DTO have been merged
				Assert.assertEquals(1, exportedFolder.contentCommon.children.size());
			}

			String thirdQuery = "third mdx";
			{
				MdxQueryDTO mdxQueryDTO = new MdxQueryDTO(new ContentCommonDTO(null, null, singleTitle, null, null),
						thirdQuery,
						null,
						null);

				folderDTO.contentCommon.children.clear();
				folderDTO.contentCommon.children.add(mdxQueryDTO);
			}

			// Add folder with 1 entry without merge check: we will end with 2 MDX with same title
			{
				// Import with UUID matching: the folder will match but not the MDX
				int nbAdded = apexContentManager.importBookmarks(userNodeUUID,
						AContentDTOHelper.doMarshallAsString(folderDTO),
						new ApexContentMergerOnUUID());
				Assert.assertEquals(2, nbAdded);

				// Ensure the folder have been merged correctly
				{
					Assert.assertEquals(1,
							apexContentManager.exportBookmarksToDTO(userNodeUUID).contentCommon.children.size());
				}

				AContentDTO exportedFolder = apexContentManager.exportBookmarksToDTO(folderUuid);

				// MDX DTO have been appended
				Assert.assertEquals(2, exportedFolder.contentCommon.children.size());

				Assert.assertEquals(secondQuery,
						((MdxQueryDTO) exportedFolder.contentCommon.children.get(0)).getMdxQuery());
				Assert.assertEquals(thirdQuery,
						((MdxQueryDTO) exportedFolder.contentCommon.children.get(1)).getMdxQuery());
			}

			String fourthQuery = "fourth mdx";
			{
				MdxQueryDTO mdxQueryDTO = new MdxQueryDTO(new ContentCommonDTO(null, null, singleTitle, null, null),
						fourthQuery,
						null,
						null);

				folderDTO.contentCommon.children.clear();
				folderDTO.contentCommon.children.add(mdxQueryDTO);
			}

			// Add folder with 1 entry without merge check: we will end with 2 MDX with same title
			{
				// Import with UUID or Title matching: the folder and the MDX will match, but there is already 2 MDX
				// with this title
				int nbAdded = apexContentManager.importBookmarks(userNodeUUID,
						AContentDTOHelper.doMarshallAsString(folderDTO),
						new ApexContentMergerOnTitle());
				Assert.assertEquals(2, nbAdded);

				// Ensure the folder have been merged correctly
				{
					Assert.assertEquals(1,
							apexContentManager.exportBookmarksToDTO(userNodeUUID).contentCommon.children.size());
				}

				AContentDTO exportedFolder = apexContentManager.exportBookmarksToDTO(folderUuid);

				// MDX DTO have been appended
				Assert.assertEquals(3, exportedFolder.contentCommon.children.size());

				Assert.assertEquals(secondQuery,
						((MdxQueryDTO) exportedFolder.contentCommon.children.get(0)).getMdxQuery());
				Assert.assertEquals(thirdQuery,
						((MdxQueryDTO) exportedFolder.contentCommon.children.get(1)).getMdxQuery());
				Assert.assertEquals(fourthQuery,
						((MdxQueryDTO) exportedFolder.contentCommon.children.get(2)).getMdxQuery());
			}

		} finally {
			SecurityContextHolder.getContext().setAuthentication(null);
		}
	}

	@Test
	public void testImportApplicationExportFromAnotherApp() throws ContentException, JAXBException {
		TestingAuthenticationToken authentication = new TestingAuthenticationToken(USERNAME, "ApexCredential");
		authentication.setAuthenticated(true);
		SecurityContextHolder.getContext().setAuthentication(authentication);

		try {
			String userNodeUUID = apexContentManager.getUserFolderUUID(USERNAME);

			// Add empty folder
			{
				// First, we add a MDX
				MdxQueryDTO mdxQuery;
				{
					mdxQuery = new MdxQueryDTO(new ContentCommonDTO(null, null, "Some MDX Title", null, null),
							"Some MDX QUery",
							null,
							null);
				}

				int nbAdded = apexContentManager.importBookmarksAsAdmin(userNodeUUID,
						AContentDTOHelper.doMarshallAsString(mdxQuery));
				Assert.assertEquals(1, nbAdded);
			}

			// Prepare another application export
			String otherApplicationExport;
			{
				String otherUserFolderUuid = "otherUserFolderUuid";
				String otherMdxUuid = "otherMdxUuid";
				MdxQueryDTO mdx = new MdxQueryDTO(
						new ContentCommonDTO(otherUserFolderUuid, otherMdxUuid, "Other MDX Title", null, null),
						"Other Mdx Query",
						null,
						null);

				// We guess the other application has a common user, but different UUID
				String otherUsersUuid = UUID.randomUUID().toString();
				TechnicalFolderDTO userFolder = new TechnicalFolderDTO(
						new ContentCommonDTO(otherUsersUuid, otherUserFolderUuid, USERNAME, null, Arrays.asList(mdx)));

				String otherAppUUID = UUID.randomUUID().toString();
				UsersDTO usersContent = new UsersDTO(new ContentCommonDTO(otherAppUUID,
						otherUsersUuid,
						"Other Users",
						null,
						Arrays.asList(userFolder)));

				ApplicationDTO application = new ApplicationDTO(new ContentCommonDTO(null,
						otherAppUUID,
						"otherApplicationName",
						"description",
						Arrays.asList(usersContent)));

				otherApplicationExport = AContentDTOHelper.doMarshallAsString(application);
			}

			// Import the other application without giving the target UUID
			int nbAdded = apexContentManager.importBookmarksAsAdmin(null, otherApplicationExport);
			Assert.assertEquals(4, nbAdded);

			String userUuid = apexContentManager.getUserFolderNameToUUID().get(USERNAME);
			AContentDTO userContent = apexContentManager.exportBookmarksToDTO(userUuid);
			Assert.assertEquals(2, userContent.contentCommon.children.size());

			// Check we see both the existing and the other application MDXs
			Assert.assertEquals("Some MDX Title", userContent.contentCommon.children.get(0).contentCommon.title);
			Assert.assertEquals("Other MDX Title", userContent.contentCommon.children.get(1).contentCommon.title);

		} finally {
			SecurityContextHolder.getContext().setAuthentication(null);
		}
	}
}

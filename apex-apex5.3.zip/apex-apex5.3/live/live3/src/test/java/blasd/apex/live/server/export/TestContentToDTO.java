/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.live.server.export;

import java.util.Arrays;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import blasd.apex.live.server.bookmark.dto.AContentDTO;
import blasd.apex.live.server.bookmark.dto.ContentCommonDTO;
import blasd.apex.live.server.bookmark.dto.ContentToDTO;
import blasd.apex.live.server.bookmark.dto.FolderDTO;

public class TestContentToDTO {
	@Test
	public void testRebuildTree() {
		FolderDTO top = new FolderDTO(new ContentCommonDTO(null, "top", null, null, null));
		FolderDTO children = new FolderDTO(new ContentCommonDTO("top", "child", null, null, null));
		FolderDTO grandChildren = new FolderDTO(new ContentCommonDTO("child", "grandchild", null, null, null));

		AContentDTO rebuild = ContentToDTO.rebuildTree(top, Arrays.asList(top, children, grandChildren));

		Assert.assertEquals("top", rebuild.contentCommon.uuid);
		List<AContentDTO> topChildren = rebuild.contentCommon.children;
		Assert.assertEquals(1, topChildren.size());

		Assert.assertEquals("child", topChildren.get(0).contentCommon.uuid);

		List<AContentDTO> childChildren = topChildren.get(0).contentCommon.children;
		Assert.assertEquals("grandchild", childChildren.get(0).contentCommon.uuid);
		Assert.assertEquals(0, childChildren.get(0).contentCommon.children.size());
	}
}

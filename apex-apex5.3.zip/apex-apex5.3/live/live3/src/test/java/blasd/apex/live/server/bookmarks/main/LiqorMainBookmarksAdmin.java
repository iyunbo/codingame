/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.live.server.bookmarks.main;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.xml.bind.JAXBException;

import org.joda.time.LocalDateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Configuration;

import blasd.apex.live.server.bookmark.dto.AContentDTO;
import blasd.apex.live.server.bookmark.dto.AContentDTOHelper;
import blasd.apex.live.server.bookmark.dto.ContentToDTO;
import blasd.apex.live.server.bookmark.dto.MdxSegmentQueryDTO;
import blasd.apex.live.server.bookmarks.IApexContentManager;
import blasd.apex.live.server.bookmarks.content.ApexContentMergerOnUUID;

@Configuration
public class LiqorMainBookmarksAdmin extends ApexMainBookmarksAdmin {

	protected static final Logger LOGGER = LoggerFactory.getLogger(LiqorMainBookmarksAdmin.class);

	static {
		// System.setProperty(ApexMainBookmarksAdmin.KEY_JCR_PATH, "file:/A:/Liqor/Bookmarks/20160524");
		System.setProperty(ApexMainBookmarksAdmin.KEY_JCR_PATH, "A:/Liqor/Bookmarks/20160524");
	}

	public static void main(String[] args) throws IOException, JAXBException {
		// TODO: Load some custom logback

		if (args != null && args.length >= 1) {
			// The first argument is the path to the JCR repository
			System.setProperty(ApexMainBookmarksAdmin.KEY_JCR_PATH, args[0]);
		}

		File backupFile;
		if (args != null && args.length >= 2) {
			backupFile = new File(args[1]);
		} else {
			// Change pattern to be FileSystem compatible
			backupFile = File.createTempFile("Apex-" + new LocalDateTime().toString("yyyy-MM-dd'T'HH-mm-ss.SSS") + "-",
					".xml");
		}

		initRegistryForLive();

		try (ConfigurableApplicationContext context =
				new AnnotationConfigApplicationContext(LiqorMainBookmarksAdmin.class)) {
			IApexContentManager apexContentManager = context.getBean(IApexContentManager.class);

			String applicationUUID = apexContentManager.getApplicationUUID();

			AContentDTO topDTO;
			{
				String applicationExport = apexContentManager.exportBookmarks(applicationUUID);

				topDTO = AContentDTOHelper.buildAContentDTOFromString(applicationExport);

				// Export current content
				{
					LOGGER.info("Exporting JCR={} to XML={}",
							System.getProperty(ApexMainBookmarksAdmin.KEY_JCR_PATH),
							backupFile);
					AContentDTOHelper.writeToFile(topDTO, backupFile);
				}

				// Retrieve the nodes which has to be migrated or inserted
				List<AContentDTO> addedOrUpdated = MdxSegmentQueryDTO.migrateDTMasks(topDTO);

				// Restrict the tree to these nodes
				ContentToDTO.filterAndRebuildTree(topDTO, addedOrUpdated);

				// Export migrated content
				{
					String migratedFile = backupFile + ".migrated";
					LOGGER.info("Export START JCR={} to XML={}",
							System.getProperty(ApexMainBookmarksAdmin.KEY_JCR_PATH),
							migratedFile);
					AContentDTOHelper.writeToFile(topDTO, new File(migratedFile));
					LOGGER.info("Export DONE JCR={} to XML={}",
							System.getProperty(ApexMainBookmarksAdmin.KEY_JCR_PATH),
							migratedFile);
				}

				// Skip the re-import
				if (false) {
					// As we re-import directly, we consider 2 dto to be the same if same UUID.
					apexContentManager.importBookmarks(applicationUUID, topDTO, new ApexContentMergerOnUUID());
				}
			}
		}
	}
}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.quartetfs.tech.streaming.impl;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * This implementation should automatically leave a deadlock situation after 1 minute.
 * http://support.quartetfs.com/jira/browse/APS-7115
 * 
 * To wire, override PivotRegistrationService originally defined in activepivot-live-components
 * 
 * @author Benoit Lacelle
 * 
 */
// Override the following bean
// <bean id="PivotRegistrationService"
// class="com.quartetfs.tech.streaming.impl.LeaveDeadLockLongPollingRegistrationService"
// destroy-method="stop">
// <property name="longPollingService" ref="LongPollingService" />
// <property name="listenPoolSize" value="${longpolling.listen.poolsize}" />
// <property name="publishPoolSize" value="${longpolling.publish.poolsize}" />
// <property name="reorder" value="true" />
// </bean>
public class LeaveDeadLockLongPollingRegistrationService extends LongPollingRegistrationService {
	protected final Lock lock = new ReentrantLock();

	// NOT SYNCHRONIZED
	@Override
	protected void restartListenTasks() {
		try {
			lock.tryLock(1, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			// Too long to take the lock: leave with an Exception
			throw new RuntimeException("We waited too long to acquire a lock", e);
		}

		try {
			super.restartListenTasks();
		} finally {
			lock.unlock();
		}
	}

	// NOT SYNCHRONIZED
	@Override
	protected void publishGlobalFailure() {
		try {
			lock.tryLock(1, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			// Too long to take the lock: leave with an Exception
			throw new RuntimeException("We waited too long to acquire a lock", e);
		}

		try {
			super.publishGlobalFailure();
		} finally {
			lock.unlock();
		}
	}
}

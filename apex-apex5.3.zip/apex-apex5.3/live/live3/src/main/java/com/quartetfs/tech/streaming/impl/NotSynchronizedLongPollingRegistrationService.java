/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.quartetfs.tech.streaming.impl;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Level;

/**
 * This implementation should never deadlock as restartListenTasks is not synchronized.
 * http://support.quartetfs.com/jira/browse/APS-7115
 * 
 * To wire, override PivotRegistrationService originally defined in activepivot-live-components
 * 
 * @author Benoit Lacelle
 * 
 */
// Override the following bean
// <bean id="PivotRegistrationService"
// class="com.quartetfs.tech.streaming.impl.NotSynchronizedLongPollingRegistrationService"
// destroy-method="stop">
// <property name="longPollingService" ref="LongPollingService" />
// <property name="listenPoolSize" value="${longpolling.listen.poolsize}" />
// <property name="publishPoolSize" value="${longpolling.publish.poolsize}" />
// <property name="reorder" value="true" />
// </bean>
public class NotSynchronizedLongPollingRegistrationService extends LongPollingRegistrationService {
	protected final Lock lock = new ReentrantLock();

	// NOT SYNCHRONIZED
	@Override
	protected void restartListenTasks() {
		// No big deal if we start too many Listen Tasks as they won't be
		// re-started on completion if there is too many of them (see
		// ListenTask.run)
		for (int i = 0; i < listenPoolSize; i++) {
			this.pendingTasks.incrementAndGet();
			this.listenPool.execute(new ListenTask());
		}

		logger.log(Level.INFO, "SUBMIT_LISTEN", Integer.valueOf(listenPoolSize));
	}
}

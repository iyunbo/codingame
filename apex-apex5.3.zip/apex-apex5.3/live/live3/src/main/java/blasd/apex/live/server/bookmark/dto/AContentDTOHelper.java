/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.live.server.bookmark.dto;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.io.StringReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import org.springframework.core.io.ClassPathResource;

import com.google.common.base.Charsets;
import com.google.common.collect.ImmutableSet;
import com.google.common.io.Files;
import com.quartetfs.pivot.live.content.shared.IMutableContent;
import com.quartetfs.pivot.live.content.shared.impl.GroupFolder;
import com.quartetfs.pivot.live.content.shared.impl.UserFolder;
import com.quartetfs.pivot.live.shared.content.impl.DashboardBookmark;
import com.quartetfs.pivot.live.shared.content.impl.FolderBookmark;
import com.quartetfs.pivot.live.shared.content.impl.GenericBookmark;
import com.quartetfs.pivot.live.shared.content.impl.MDXBookmark;
import com.quartetfs.pivot.live.shared.content.impl.MDXSegmentBookmark;
import com.quartetfs.pivot.live.shared.content.impl.SettingContent;

import blasd.apex.live.server.bookmarks.ApexBookmarkExporter;
import blasd.apex.live.server.bookmarks.content.ApplicationContent;
import blasd.apex.live.server.bookmarks.content.GroupsContent;
import blasd.apex.live.server.bookmarks.content.TechnicalFolderDTO;
import blasd.apex.live.server.bookmarks.content.UsersContent;

/**
 * Helps exporting a JCR repository to a file
 * 
 * @author Benoit Lacelle
 *
 */
public class AContentDTOHelper {

	public static final Set<? extends Class<? extends IMutableContent>> KNOWN_CONTENT =
			ImmutableSet.<Class<? extends IMutableContent>>builder()
					.add(ApplicationContent.class)
					.add(GroupsContent.class)
					.add(UsersContent.class)
					.add(GroupFolder.class)
					.add(UserFolder.class)
					.add(FolderBookmark.class)
					.add(GenericBookmark.class)
					.add(MDXBookmark.class)
					.add(MDXSegmentBookmark.class)
					.add(DashboardBookmark.class)
					.add(SettingContent.class)
					.build();

	public static final JAXBContext CONTEXT;

	// It is set to false as, right now, the mapping would not work as we rely
	// on Maps
	public static final boolean ADD_SENTINEL_IN_CONTEXT = false;

	static {
		try {
			List<Class<?>> contextClasses = new ArrayList<>();

			contextClasses.add(ContentCommonDTO.class);
			contextClasses.add(ApplicationDTO.class);
			contextClasses.add(UsersDTO.class);
			contextClasses.add(GroupsDTO.class);
			contextClasses.add(MdxQueryDTO.class);
			contextClasses.add(MdxSegmentQueryDTO.class);
			contextClasses.add(TechnicalFolderDTO.class);
			contextClasses.add(FolderDTO.class);
			contextClasses.add(String.class);
			contextClasses.add(DashboardDTO.class);
			contextClasses.add(GenericBookmarkDTO.class);
			contextClasses.add(SettingContentDTO.class);
			if (ADD_SENTINEL_IN_CONTEXT) {
				contextClasses.add(SentinelRuleCommonDTO.class);
				contextClasses.add(SentinelRuleDTO.class);
			}

			CONTEXT = JAXBContext.newInstance(contextClasses.toArray(new Class<?>[0]));
		} catch (JAXBException e) {
			throw new RuntimeException(e);
		}
	}

	protected AContentDTOHelper() {
		// hidden
	}

	/**
	 * Extract the MdxQueries available in a {@link AContentDTO}
	 */
	public static final void extractMDXQueries(AContentDTO topContent, List<MdxQueryDTO> queries) {
		if (queries == null || topContent == null) {
			return;
		}

		if (topContent instanceof MdxQueryDTO) {
			queries.add((MdxQueryDTO) topContent);
		}

		if (topContent.contentCommon.children != null) {
			for (AContentDTO childContent : topContent.contentCommon.children) {
				extractMDXQueries(childContent, queries);
			}
		}
	}

	/**
	 * Convert a file path to a {@link AContentDTO}
	 * 
	 * @throws IOException
	 */
	public static AContentDTO buildAContentDTOFromFile(String path) throws JAXBException, IOException {
		URL url = new ClassPathResource(path).getURL();

		if (url == null) {
			return null;
		}

		File file = new File(url.getPath());

		return buildAContentDTOFromFile(file);
	}

	/**
	 * Convert a {@link File} to a {@link AContentDTO}
	 */
	public static AContentDTO buildAContentDTOFromFile(File file) throws JAXBException {
		if (!file.isFile()) {
			return null;
		}

		Unmarshaller unmarshaller = CONTEXT.createUnmarshaller();

		Object o = unmarshaller.unmarshal(file);

		if (o instanceof AContentDTO) {
			return (AContentDTO) o;
		} else {
			throw new RuntimeException(file + " does not hold a AContentDTO");
		}
	}

	public static AContentDTO buildAContentDTOFromString(String marshalled) throws JAXBException {
		Unmarshaller unmarshaller = CONTEXT.createUnmarshaller();

		Object o = unmarshaller.unmarshal(new StringReader(marshalled));

		if (o instanceof AContentDTO) {
			return (AContentDTO) o;
		} else {
			throw new RuntimeException(marshalled + " does not hold a AContentDTO");
		}
	}

	public static void doTestMarshall(AContentDTO contentDTO, OutputStream out) throws JAXBException {
		doMarshall(contentDTO, out);
	}

	public static void doMarshall(AContentDTO contentDTO, OutputStream out) throws JAXBException {
		Marshaller marshaller = CONTEXT.createMarshaller();
		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);

		marshaller.marshal(contentDTO, out);
	}

	public static String doMarshallAsString(AContentDTO contentDTO) throws JAXBException {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		AContentDTOHelper.doMarshall(contentDTO, baos);

		return new String(baos.toByteArray());
	}

	public static void writeToFile(AContentDTO dtoTree, File tmpFile) throws IOException, JAXBException {
		Files.write(new ApexBookmarkExporter().exportBookmarks(dtoTree), tmpFile, Charsets.UTF_8);
	}
}

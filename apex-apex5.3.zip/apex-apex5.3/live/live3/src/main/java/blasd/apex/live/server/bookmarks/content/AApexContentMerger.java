/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.live.server.bookmarks.content;

import com.quartetfs.pivot.live.content.shared.IContent;
import com.quartetfs.pivot.live.content.shared.impl.GroupFolder;
import com.quartetfs.pivot.live.content.shared.impl.UserFolder;

import blasd.apex.live.server.bookmark.dto.AContentDTO;
import blasd.apex.live.server.bookmark.dto.ApplicationDTO;
import blasd.apex.live.server.bookmark.dto.GroupsDTO;
import blasd.apex.live.server.bookmark.dto.UsersDTO;

/**
 * Enable matching between IContent and AContentDTO
 * 
 * @author Benoit Lacelle
 *
 */
public abstract class AApexContentMerger implements IContentMerger {

	@Override
	public boolean sameNode(IContent rootContent, AContentDTO rootDTO) {
		if (rootContent instanceof ApplicationContent && rootDTO instanceof ApplicationDTO) {
			// Both are application top node
			return true;
		} else if (rootContent instanceof UsersContent && rootDTO instanceof UsersDTO) {
			// Both are application top node
			return true;
		} else if (rootContent instanceof GroupsContent && rootDTO instanceof GroupsDTO) {
			// Both are application top node
			return true;
		} else if (rootContent instanceof UserFolder && rootDTO instanceof TechnicalFolderDTO
				&& rootContent.getTitle().equals(rootDTO.contentCommon.title)) {
			// Both are same user node
			return true;
		} else if (rootContent instanceof GroupFolder && rootDTO instanceof TechnicalFolderDTO
				&& rootContent.getTitle().equals(rootDTO.contentCommon.title)) {
			// Both are same user node
			return true;
		} else {
			return false;
		}
	}
}

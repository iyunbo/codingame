/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.live.server.bookmark.dto;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.LinkedBlockingQueue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Iterables;
import com.quartetfs.fwk.Registry;
import com.quartetfs.pivot.live.content.shared.IContent;
import com.quartetfs.pivot.live.content.shared.impl.GroupFolder;
import com.quartetfs.pivot.live.content.shared.impl.UserFolder;
import com.quartetfs.pivot.live.core.server.setting.ISettingSerializer;
import com.quartetfs.pivot.live.core.shared.setting.ISetting;
import com.quartetfs.pivot.live.shared.content.impl.DashboardBookmark;
import com.quartetfs.pivot.live.shared.content.impl.FolderBookmark;
import com.quartetfs.pivot.live.shared.content.impl.GenericBookmark;
import com.quartetfs.pivot.live.shared.content.impl.MDXBookmark;
import com.quartetfs.pivot.live.shared.content.impl.MDXSegmentBookmark;
import com.quartetfs.pivot.live.shared.content.impl.SettingContent;
import com.quartetfs.pivot.live.shared.contextvalues.IFlatContextValue;

import blasd.apex.live.server.bookmarks.content.ApplicationContent;
import blasd.apex.live.server.bookmarks.content.GroupsContent;
import blasd.apex.live.server.bookmarks.content.TechnicalFolderDTO;
import blasd.apex.live.server.bookmarks.content.UsersContent;

/**
 * Enable marshalling of JCR elements
 * 
 * @author Benoit Lacelle
 *
 */
public final class ContentToDTO {
	protected static final Logger LOGGER = LoggerFactory.getLogger(ContentToDTO.class);

	protected ContentToDTO() {
		// hidden
	}

	public static List<AContentDTO> convertToDTO(Collection<? extends IContent> contents) {

		List<AContentDTO> result = new ArrayList<>();

		for (IContent c : contents) {
			AContentDTO content = convertToDTO(c);
			if (content != null) {
				result.add(content);
			}

		}

		return result;
	}

	public static AContentDTO convertToDTO(IContent l) {
		ContentCommonDTO common = new ContentCommonDTO(l);

		if (l instanceof ApplicationContent) {
			// AApexContentMerge needs a specific DTO for application in order to merge easily 2 applications
			return new ApplicationDTO(common);
		} else if (l instanceof UsersContent) {
			return new UsersDTO(common);
		} else if (l instanceof GroupsContent) {
			return new GroupsDTO(common);
		} else if (l instanceof GroupFolder || l instanceof UserFolder) {
			return new TechnicalFolderDTO(common);
		} else if (l instanceof FolderBookmark) {
			return new FolderDTO(common);
		} else if (l instanceof GenericBookmark) {
			return new GenericBookmarkDTO(common, ((GenericBookmark) l).getKey(), ((GenericBookmark) l).getContent());
		} else if (l instanceof MDXBookmark) {

			Map<String, String> contextValues = new HashMap<>();

			for (IFlatContextValue fcv : ((MDXBookmark) l).getContextValues()) {
				contextValues.put(fcv.getName(), fcv.getValue());
			}

			return new MdxQueryDTO(common,
					((MDXBookmark) l).getMdxQuery(),
					((MDXBookmark) l).getDisplayType(),
					contextValues);
		} else if (l instanceof MDXSegmentBookmark) {
			return new MdxSegmentQueryDTO(common,
					((MDXSegmentBookmark) l).getMdx(),
					((MDXSegmentBookmark) l).getCube(),
					((MDXSegmentBookmark) l).getSegmentType().toString());
		} else if (l instanceof DashboardBookmark) {
			return new DashboardDTO(common,
					((DashboardBookmark) l).getKey(),
					((DashboardBookmark) l).getParameters(),
					String.valueOf(((DashboardBookmark) l).getSize()),
					Arrays.asList(((DashboardBookmark) l).getWidgetParamsForSerialization()));
		} else if (l instanceof SettingContent) {
			ISetting<?> setting = ((SettingContent) l).getSetting();

			@SuppressWarnings("rawtypes")
			ISettingSerializer serializer =
					Registry.getPlugin(ISettingSerializer.class).valueOf(setting.getType().getKey());

			if (serializer == null) {
				LOGGER.warn("There is no {} for {}", ISettingSerializer.class, setting.getType().getKey());
				return null;
			}

			@SuppressWarnings("unchecked")
			String value = serializer.serializeValue(setting.getValue());

			return new SettingContentDTO(common, setting.getKey(), value, String.valueOf(setting.getType()));
		} // else

		throw new IllegalArgumentException("Unhandled LiveContent " + l.getClass() + " : " + l);
	}

	// Rebuild the tree given the parent UUID
	// TODO: infinite loop (A -> B -> A)
	public static AContentDTO rebuildTree(AContentDTO top, Iterable<? extends AContentDTO> convertToDTO) {
		if (top == null || top.contentCommon.uuid == null || convertToDTO == null) {
			return null;
		} // else

		List<AContentDTO> children = new ArrayList<>();

		String currentUuid = top.contentCommon.uuid;
		for (AContentDTO dto : convertToDTO) {
			if (currentUuid.equals(dto.contentCommon.parentUUID)) {
				children.add(dto);
				rebuildTree(dto, convertToDTO);
			}
		}

		top.contentCommon.children.clear();
		top.contentCommon.children.addAll(children);

		return top;
	}

	public static void filterAndRebuildTree(AContentDTO topDTO, List<AContentDTO> addedOrUpdated) {
		Map<String, AContentDTO> uuidToDTO = new HashMap<>();
		{
			// Iterate through the tree to convert each node
			Queue<AContentDTO> leftToProcess = new LinkedBlockingQueue<>();
			leftToProcess.add(topDTO);
			while (!leftToProcess.isEmpty()) {
				AContentDTO next = leftToProcess.poll();
				uuidToDTO.put(next.contentCommon.uuid, next);
				leftToProcess.addAll(next.contentCommon.children);
			}
		}

		// use a Map as an ancestor could be encountered several times
		Map<String, AContentDTO> ancestors = new HashMap<>();
		List<AContentDTO> newItems = new ArrayList<>();

		for (AContentDTO oneAddedOrUpdated : addedOrUpdated) {
			// Add current element
			String uuidToAdd = oneAddedOrUpdated.contentCommon.uuid;

			if (uuidToAdd == null) {
				newItems.add(oneAddedOrUpdated);
			} else {
				while (uuidToAdd != null) {
					AContentDTO current = uuidToDTO.get(uuidToAdd);
					if (current == null) {
						// This may be the root
						LOGGER.warn("We did not found content for {}", uuidToAdd);
					} else {
						ancestors.put(uuidToAdd, current);

						if (uuidToAdd.equals(topDTO.contentCommon.uuid)) {
							// We have no interest in ancestors above the top node
							break;
						} else {
							// Iterate through ancestors
							uuidToAdd = current.contentCommon.parentUUID;
						}
					}
				}
			}
		}

		// Rebuild the tree of the migrated nodes
		ContentToDTO.rebuildTree(topDTO, Iterables.concat(ancestors.values(), newItems));
	}
}

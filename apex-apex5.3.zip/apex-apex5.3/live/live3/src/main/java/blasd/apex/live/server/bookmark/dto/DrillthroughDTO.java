/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.live.server.bookmark.dto;

import javax.xml.bind.JAXBException;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Enable marshalling of JCR elements
 * 
 * @author Benoit Lacelle
 *
 */
@XmlRootElement(name = "drillthrough")
public class DrillthroughDTO extends AContentDTO {

	/**
	 * Cube name
	 */
	@XmlElement
	protected String cubeName;

	/**
	 * Location dimensions
	 * <p>
	 * It contains the dimensions associated with the locations
	 */
	@XmlElement
	protected String[] locationDimensions;

	/**
	 * Locations - The locations following the pattern of locationDimensions.
	 * <p>
	 * ex:<br>
	 * locationDimension = ["Book", "Currency"];<br>
	 * locations = [ "AllMember\BookA|AllMember\EUR", "|AllMember\USD" ];
	 */
	@XmlElement
	protected String[] locations;

	/**
	 * Filter dimensions
	 * <p>
	 * It contains the dimensions associated with the filter multi-values
	 */
	@XmlElement
	protected String[] filterDimensions;

	/**
	 * Filter multi-values - It contains paths for the filters.<br>
	 * ex:<br>
	 * filterDimensions = ["Book", "Desk"];<br>
	 * filterPaths = ["AllMember\BookA|AllMember\BookB", "AllMember\DeskA"]
	 */
	@XmlElement
	protected String[] filterPaths;

	protected DrillthroughDTO() {
		// Serialization
	}

	public DrillthroughDTO(ContentCommonDTO common,
			String cubeName,
			String[] locationDimensions,
			String[] locations,
			String[] filterDimensions,
			String[] filterPaths) {
		super(common);
		this.cubeName = cubeName;
		this.locationDimensions = locationDimensions;
		this.locations = locations;
		this.filterDimensions = filterDimensions;
		this.filterPaths = filterPaths;

	}

	public String getCubeName() {
		return cubeName;
	}

	public String[] getLocationDimensions() {
		return locationDimensions;
	}

	public String[] getLocations() {
		return locations;
	}

	public String[] getFilterDimensions() {
		return filterDimensions;
	}

	public String[] getFilterPaths() {
		return filterPaths;
	}

	@Override
	public String toString() {
		return "DrillthroughDTO [toString()=" + super.toString()
				+ "; cubeName: "
				+ cubeName
				+ "; locations: "
				+ locations
				+ "; locationDimensions: "
				+ locationDimensions
				+ "; filterDimensions: "
				+ filterDimensions
				+ "; filterPaths: "
				+ filterPaths;
	}

	public static void main(String[] args) throws JAXBException {
		String[] locations = { "locations" };
		String[] locationDimensions = { "locationDimension" };
		String[] filterDimensions = { "filterDimensions" };
		String[] filterPaths = { "filterPaths" };
		DrillthroughDTO drillthrough =
				new DrillthroughDTO(new ContentCommonDTO("parentUUID", "uuid", "title", "description", null),
						"cube",
						locations,
						locationDimensions,
						filterDimensions,
						filterPaths);

		AContentDTOHelper.doTestMarshall(drillthrough, System.out);

	}

}

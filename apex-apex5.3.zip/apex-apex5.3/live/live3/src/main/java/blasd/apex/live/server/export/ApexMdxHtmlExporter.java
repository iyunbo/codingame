/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.live.server.export;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Collection;
import java.util.List;

import com.google.common.base.Charsets;
import com.quartetfs.pivot.live.content.IContentManager;
import com.quartetfs.pivot.live.server.IDiscoveryService;
import com.quartetfs.pivot.live.server.export.impl.AFeedExporter;
import com.quartetfs.pivot.live.server.export.impl.AMdxFeedExporter;
import com.quartetfs.pivot.live.server.export.impl.AMdxFeedExporterSpy;
import com.quartetfs.pivot.live.server.export.impl.MdxHtmlExporter;
import com.quartetfs.pivot.live.shared.contextvalues.IFlatContextValue;
import com.quartetfs.pivot.live.shared.mdx.IFilterData;
import com.quartetfs.pivot.live.shared.mdx.IMdxModel;
import com.quartetfs.pivot.live.shared.mdx.filter.cell.impl.PivotFilterConstructor;
import com.quartetfs.pivot.live.shared.mdx.grid.cell.impl.PivotGridConstructor;
import com.quartetfs.pivot.live.shared.mdx.grid.render.html.IContentCellRenderer;
import com.quartetfs.pivot.live.shared.mdx.grid.render.html.impl.PivotGridHtmlMatrixBuilder;
import com.quartetfs.pivot.live.shared.mdx.grid.render.impl.LayeredStringBuilder;

import blasd.apex.core.io.GZipStringBuilder;

/**
 * Softer transient memory usage by using {@link GZipStringBuilder}
 * 
 * @author Benoit Lacelle
 * 
 */
public class ApexMdxHtmlExporter extends MdxHtmlExporter {

	public ApexMdxHtmlExporter(final IDiscoveryService discoveryService, final IContentManager contentManager) {
		super(discoveryService, contentManager);
	}

	@Override
	protected void doExportImpl(final OutputStream out,
			final IMdxModel mdxModel,
			final Collection<IFlatContextValue> ctxValues) {
		Collection<IFlatContextValue> actualCtxValues;
		if (addCtxValue) {
			actualCtxValues = ctxValues;
		} else {
			actualCtxValues = null;
		}

		doExportImpl(out, mdxModel, actualCtxValues, contentCellRenderer, gridConstructor, filterConstructor, this);
	}

	protected static void doExportImpl(final OutputStream out,
			final IMdxModel mdxModel,
			final Collection<IFlatContextValue> ctxValues,
			IContentCellRenderer contentCellRenderer,
			PivotGridConstructor<PivotGridHtmlMatrixBuilder> gridConstructor,
			PivotFilterConstructor<LayeredStringBuilder> filterConstructor,
			AMdxFeedExporter mdxFeedExporter) {
		try {
			contentCellRenderer.updateMdxModel(mdxModel);
			final List<IFilterData> filterDataList = mdxModel.getFilterData();
			final boolean hasFilter = filterDataList != null && !filterDataList.isEmpty()
					&& AMdxFeedExporterSpy.filterDataListHasAtLeastOneElementVisibleWithNotNullCaption(mdxFeedExporter,
							filterDataList);
			final ApexPivotGridHtmlMatrixBuilder ptBuilder = new ApexPivotGridHtmlMatrixBuilder(null);
			final LayeredStringBuilder filterBuilder = new LayeredStringBuilder();
			gridConstructor.construct(mdxModel, ptBuilder);
			if (hasFilter) {
				filterConstructor.construct(mdxModel, filterBuilder);
			}
			final GZipStringBuilder reportBuilder = new GZipStringBuilder();
			reportBuilder.append(
					"<html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"></head><body>");
			if (ctxValues != null && !ctxValues.isEmpty()) {
				final StringBuilder headerRow = new StringBuilder();
				final StringBuilder valueRow = new StringBuilder();
				for (final IFlatContextValue ctx : AFeedExporter.sortContextValuesForExport(ctxValues)) {
					headerRow.append("<th>").append(ctx.getName()).append("</th>");
					valueRow.append("<td>").append(ctx.getValue()).append("</td>");
				}
				reportBuilder.append("Context Values:<br/><table border =\"1\">");
				reportBuilder.append("<tr>").append(headerRow).append("</tr>");
				reportBuilder.append("<tr>").append(valueRow).append("</tr>");
				reportBuilder.append("</table>");
				reportBuilder.append("<br/>");
			}
			if (hasFilter) {
				reportBuilder.append(filterBuilder.build());
				reportBuilder.append("<br/>");
			}
			ptBuilder.build(reportBuilder);
			reportBuilder.append("</body></html>");

			reportBuilder.writeTo(out, Charsets.UTF_8);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
}

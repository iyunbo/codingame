/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.live.server.bookmarks;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.jcr.ItemNotFoundException;
import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.query.Query;
import javax.jcr.query.QueryResult;
import javax.jcr.query.qom.QueryObjectModelFactory;
import javax.xml.bind.JAXBException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;

import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Strings;
import com.google.common.collect.ImmutableBiMap;
import com.quartetfs.fwk.AgentException;
import com.quartetfs.pivot.live.content.auth.IGroup;
import com.quartetfs.pivot.live.content.impl.AContentManager;
import com.quartetfs.pivot.live.content.impl.ContentException;
import com.quartetfs.pivot.live.content.jcr.IJCRContentFactory;
import com.quartetfs.pivot.live.content.jcr.impl.AJCRContentManager;
import com.quartetfs.pivot.live.content.shared.IContent;
import com.quartetfs.pivot.live.content.shared.IMutableContent;
import com.quartetfs.pivot.live.content.shared.impl.GroupFolder;
import com.quartetfs.pivot.live.content.shared.impl.UserFolder;
import com.quartetfs.pivot.live.core.server.security.IUser;
import com.quartetfs.pivot.live.server.content.impl.ContentManager;

import blasd.apex.core.jmx.PepperJMXHelper;
import blasd.apex.live.server.bookmark.dto.AContentDTO;
import blasd.apex.live.server.bookmark.dto.AContentDTOHelper;
import blasd.apex.live.server.bookmarks.content.ApexContentMergerOnTitle;
import blasd.apex.live.server.bookmarks.content.IContentMerger;

/**
 * Override the bean with id ContentManager in Custom.xml, originally defined in activepivot-live-content.jar in
 * /ContentManager.xml
 * 
 * @author Benoit Lacelle
 * 
 */
// <!-- Override ContentManager in /ContentManager.xml -->
// <bean id="ContentManager"
// class="blasd.apex.live.server.bookmarks.ApexContentManager"
// init-method="init" destroy-method="stop">
// <property name="applicationName" value="PivotLive" />
// <property name="repository" ref="jcrRepository" />
// <property name="nodeDefinitions">
// <list>
// <value>classpath:QFSJCRDefinitions.cnd</value>
// <value>classpath:APLJCRDefinitions.cnd</value>
// </list>
// </property>
// <property name="userService" ref="UserService" />
// <property name="groupService" ref="ContentGroupService" />
// </bean>
@ManagedResource
public class ApexContentManager extends ContentManager
		implements IApexContentManager, InitializingBean, DisposableBean {

	private static final long serialVersionUID = 1L;

	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexContentManager.class);

	public static final String ADMIN_ROLE = "ROLE_CONTENT_ADMIN";
	public static final String USERS_NODE_KEY = "users";
	public static final String GROUPS_NODE_KEY = "groups";

	protected final transient IApexBookmarkExporter apexBookmarkExporter;

	// For debug purposes, enable full bookmark visiblity to everybody when true
	@VisibleForTesting
	protected boolean allUsersAreAdmin = false;

	/**
	 * Ability to be someone else, e.g. enforce ourself to be the system user
	 */
	protected static final ThreadLocal<IUser> CURRENT_FORCED_USER = new ThreadLocal<IUser>();

	public ApexContentManager(IApexBookmarkExporter apexBookmarkExporter, boolean allUsersAreAdmin) {
		this.apexBookmarkExporter = apexBookmarkExporter;
		this.allUsersAreAdmin = allUsersAreAdmin;
	}

	@ManagedAttribute
	public void setAllUsersAreAdmin(boolean allUsersAreAdmin) {
		this.allUsersAreAdmin = allUsersAreAdmin;
	}

	@ManagedAttribute
	public boolean getAllUsersAreAdmin() {
		return allUsersAreAdmin;
	}

	@ManagedOperation
	@Override
	public Map<String, String> getGroupFolderUUIDToName() {
		Map<String, String> uuidToName = new HashMap<>();

		try {
			for (GroupFolder groupFolder : getGroupFolders(getSystemUser())) {
				uuidToName.put(groupFolder.getUUID(), groupFolder.getGroupName());
			}
		} catch (ContentException e) {
			// JMX: ContentException are not known by JConsole
			LOGGER.warn("Issue with UUID", e);
			throw new RuntimeException(e.getMessage());
		}

		return uuidToName;
	}

	@ManagedOperation
	@Override
	public Map<String, String> getGroupFolderNameToUUID() {
		try {
			return PepperJMXHelper.convertToJMXMap(ImmutableBiMap.copyOf(getGroupFolderUUIDToName()).inverse());
		} catch (RuntimeException e) {
			throw new RuntimeException("It seems one userName is associated to several UUIDs");
		}
	}

	@ManagedOperation
	@Override
	public Map<String, String> getUserFolderUUIDToName() {
		Map<String, String> uuidToName = new HashMap<>();

		try {
			for (UserFolder groupFolder : getUserFoldersAsSystem()) {
				uuidToName.put(groupFolder.getUUID(), groupFolder.getUserName());
			}
		} catch (ContentException e) {
			// JMX: ContentException are not known by JConsole
			LOGGER.warn("Issue with UUID", e);
			throw new RuntimeException(e.getMessage());
		}

		return uuidToName;
	}

	@ManagedOperation
	@Override
	public Map<String, String> getUserFolderNameToUUID() {
		try {
			return PepperJMXHelper.convertToJMXMap(ImmutableBiMap.copyOf(getUserFolderUUIDToName()).inverse());
		} catch (RuntimeException e) {
			throw new RuntimeException("It seems one userName is associated to several UUIDs");
		}
	}

	/**
	 * 
	 * @return the JCR root node
	 */
	@ManagedAttribute
	public String getRootUUID() {
		try {
			return getRootNode().getIdentifier();
		} catch (RepositoryException e) {
			// JMX: ContentException are not known by JConsole
			LOGGER.warn("Issue with UUID", e);
			throw new RuntimeException(e.getMessage());
		}
	}

	/**
	 * 
	 * @return the APLive instance root node
	 */
	@ManagedAttribute
	@Override
	public String getApplicationUUID() {
		try {
			// the applicationName node is hardcoded in
			// AJCRContentManager._init(Properties)
			return getRootNode().getNode(this.applicationName).getIdentifier();
		} catch (RepositoryException e) {
			// JMX: ContentException are not known by JConsole
			LOGGER.warn("Issue with UUID", e);
			throw new RuntimeException(e.getMessage());
		}
	}

	protected List<UserFolder> getUserFoldersAsSystem() throws ContentException {
		// "users" is hardcoded in AJCRContentManager._init(Properties)
		return getContentAsUser(getSystemUser(), USERS_NODE_KEY, UserFolder.class);
	}

	protected List<GroupFolder> getGroupFolders(final IUser user) throws ContentException {
		// "groups" is hardcoded in AJCRContentManager._init(Properties)
		return getContentAsUser(user, GROUPS_NODE_KEY, GroupFolder.class);
	}

	@ManagedOperation
	public String getUUIDContentAsAdmin(String uuid) {
		try {
			IUser systemUser = getSystemUser();

			try {
				if (CURRENT_FORCED_USER.get() != null) {
					throw new RuntimeException("Can not force user=" + systemUser
							+ " as user is already set to"
							+ CURRENT_FORCED_USER.get());
				}
				CURRENT_FORCED_USER.set(systemUser);

				uuid = cleanUUIDFromJMX(uuid);

				{
					IContent content = get(uuid);

					// MDXBookmark will hold the MDX in its .toString
					return String.valueOf(content);
				}
			} finally {
				CURRENT_FORCED_USER.remove();
			}
		} catch (ContentException e) {
			LOGGER.warn("Issue with UUID", e);
			throw new RuntimeException("Issue with UUID=" + uuid + " - " + e.getMessage());
		}
	}

	@ManagedOperation
	@Override
	public String exportBookmarks(String uuid) throws JAXBException {
		try {
			uuid = cleanUUIDFromJMX(uuid);

			AContentDTO tree = exportBookmarksToDTO(uuid);
			return apexBookmarkExporter.exportBookmarks(tree);
		} catch (ContentException e) {
			LOGGER.warn("Issue when exporting", e);
			// JMX: ContentException are not known by JConsole
			throw new RuntimeException(e.getMessage());
		}
	}

	@Override
	public AContentDTO exportBookmarksToDTO(String uuid) throws JAXBException, ContentException {
		Collection<? extends IMutableContent> flatTree =
				getTreeAsUser(uuid, getSystemUser(), AContentDTOHelper.KNOWN_CONTENT);

		return apexBookmarkExporter.exportBookmarks(uuid, flatTree);
	}

	protected String cleanUUIDFromJMX(String uuid) {
		uuid = PepperJMXHelper.convertToString(uuid);
		if (Strings.isNullOrEmpty(uuid)) {
			uuid = getApplicationUUID();
			LOGGER.info("Import Node not specified: we guess we are importing to the application node: {}", uuid);
		}

		return uuid;
	}

	@ManagedOperation
	@Override
	public int importBookmarksAsAdmin(String targetParentUUID, String xml) throws JAXBException {
		// Clean the JMX targetParentUUID
		{
			targetParentUUID = cleanUUIDFromJMX(targetParentUUID);
		}

		// Clean the JMX imported XML
		{
			xml = PepperJMXHelper.convertToString(xml);
			if (Strings.isNullOrEmpty(xml)) {
				throw new RuntimeException("Can not import an empty XML");
			}
		}

		return importBookmarks(targetParentUUID, xml, makeDefaultApexContentMerger());
	}

	protected IContentMerger makeDefaultApexContentMerger() {
		return new ApexContentMergerOnTitle();
	}

	@Override
	public int importBookmarks(String targetParentUUID, String xml, IContentMerger contentMerger) throws JAXBException {
		AContentDTO rootDTO = AContentDTOHelper.buildAContentDTOFromString(xml);

		return importBookmarks(targetParentUUID, rootDTO, contentMerger);
	}

	@Override
	public IUser getCurrentUser() throws ContentException {
		IUser forcedUser = CURRENT_FORCED_USER.get();
		if (forcedUser != null) {
			return forcedUser;
		} else {
			return super.getCurrentUser();
		}
	}

	@Override
	protected synchronized void lazyLoadUser(IUser user) throws ContentException {
		if (user instanceof SystemUser) {
			// When importing an XML, we add nodes as the system user: we should not treat this user as an actual user
			LOGGER.debug("Skip user folder creation for {}", user);
		} else {
			super.lazyLoadUser(user);
		}
	}

	@Override
	public int importBookmarks(String targetParentUUID, AContentDTO contentDTO, IContentMerger contentMerger)
			throws JAXBException {
		try {
			// This call is typically done through RMI: no user is registered. However, update/insert of nodes has to be
			// done as a user
			IUser systemUser = getSystemUser();

			// TODO: it is a bad design to require having both in memory the whole imported tree and the whole existing
			// tree
			Collection<? extends IMutableContent> flatTree =
					getTreeAsUser(targetParentUUID, systemUser, AContentDTOHelper.KNOWN_CONTENT);

			try {
				if (CURRENT_FORCED_USER.get() != null) {
					throw new RuntimeException("Can not force user=" + systemUser
							+ " as user is already set to"
							+ CURRENT_FORCED_USER.get());
				}
				CURRENT_FORCED_USER.set(systemUser);
				return apexBookmarkExporter.importBookmarks(targetParentUUID,
						contentDTO,
						flatTree,
						this,
						contentMerger);
			} finally {
				CURRENT_FORCED_USER.remove();
			}

		} catch (ContentException e) {
			LOGGER.warn("Issue when importing", e);
			// JMX: ContentException are not known by JConsole
			throw new RuntimeException(e.getMessage());
		}
	}

	/**
	 * 
	 * @return an {@link IUser} which has access to the whole repository
	 */
	@Override
	public IUser getSystemUser() {
		// com.quartetfs.pivot.live.content.jcr.impl.JCRAccessManager.isGranted(Path, int)
		return new AContentManager.SystemUser();
	}

	/**
	 * 
	 * @return all {@link UserFolder} visible by current {@link IUser}. Which are either the {@link UserFolder} owned by
	 *         current {@link IUser}, or all {@link UserFolder} if current {@link IUser} is a Content admin
	 * @throws ContentException
	 */
	@Override
	public List<UserFolder> getUserFolders() throws ContentException {
		final IUser user = getCurrentUser();
		lazyLoadUser(user);

		if (allUsersAreAdmin || ADMIN_ROLE.equals(user.getUserName())) {
			return getUserFoldersAsSystem();
		} else {
			// Not an admin: can see only current user UserFolder
			return Collections.singletonList(getUserFolder());
		}
	}

	protected <T extends IMutableContent> List<T> getContentAsUser(final IUser user,
			final String nodeKey,
			final Class<T> contentClass) throws ContentException {
		final List<T> contentItems = new ArrayList<>();

		// Requests all Users as the System user
		executeSession(user, new AContentManager.SessionModificationCommand<Session>() {
			@Override
			public void execute(Session session) throws RepositoryException, ContentException {
				Set<Class<? extends T>> filter = Collections.<Class<? extends T>>singleton(contentClass);

				try {
					Node applicationNode = session.getNodeByIdentifier(ApexContentManager.this.applicationNodeUUID);
					NodeIterator usersNodeIt = applicationNode.getNode(nodeKey).getNodes();

					// For each user
					while (usersNodeIt.hasNext()) {
						Node contentNode = usersNodeIt.nextNode();

						appendContent(session, user, contentNode, contentItems, filter);
					}
				} catch (RepositoryException e) {
					throw new ContentException(e.getMessage(), e.getCause());
				}
			}
		});

		return contentItems;
	}

	/**
	 * 
	 * @param rootUUID
	 * @param contentTypeFilters
	 * @return the tree of {@link IContent} under a rootUUID without restriction to current user visibility
	 * @throws ContentException
	 */
	@Override
	public Collection<? extends IMutableContent> getTreeAsUser(final String rootUUID,
			final IUser user,
			final Set<? extends Class<? extends IMutableContent>> contentTypeFilters) throws ContentException {
		if (null == rootUUID) {
			throw new ContentException("GET_CHILDREN: Cannot execute: UUID is null");
		}
		final List<IMutableContent> treeContents = new ArrayList<>();

		executeSession(user, new AContentManager.SessionModificationCommand<Session>() {
			@Override
			public void execute(Session session) throws RepositoryException, ContentException {
				final Node rootNode;
				try {
					rootNode = session.getNodeByIdentifier(rootUUID);
				} catch (ItemNotFoundException e) {
					LOGGER.info("UUID_DOES_NOT_EXIST: " + rootUUID, e);
					return;
				}
				if (null == rootNode) {
					LOGGER.info("UUID_DOES_NOT_EXIST: " + rootUUID);
				} else {
					QueryObjectModelFactory qomFactory = session.getWorkspace().getQueryManager().getQOMFactory();
					Query q = qomFactory.createQuery(qomFactory.selector("qfs:Content", "s"),
							qomFactory.descendantNode("s", rootNode.getPath()),
							null,
							null);

					QueryResult result = q.execute();
					NodeIterator nit = result.getNodes();

					while (nit.hasNext()) {
						Node cNode = nit.nextNode();

						appendContent(session, user, cNode, treeContents, contentTypeFilters);
					}
					appendContent(session, user, rootNode, treeContents, contentTypeFilters);
				}
			}
		});
		return treeContents;
	}

	@SuppressWarnings("unchecked")
	protected <T extends IMutableContent> void appendContent(Session session,
			IUser user,
			Node node,
			List<T> treeContents,
			Set<? extends Class<? extends T>> contentTypeFilters) throws RepositoryException {

		if (node == null) {
			return;
		}

		try {
			IJCRContentFactory cContentFactory = getContentFactoryByNodeType(node.getPrimaryNodeType().getName());
			if (null == cContentFactory) {
				LOGGER.debug("Skip content of type {}", node.getPrimaryNodeType().getName());
			} else {
				IMutableContent cContent = null;
				try {
					cContent = cContentFactory.translateFromNode(session, node);
				} catch (Exception e) {
					LOGGER.warn("Failed to translate node " + node.toString() + " with " + cContentFactory, e);
				}

				if (null == cContent) {
					LOGGER.debug("Skip content of type {}", node.getPrimaryNodeType().getName());
				} else {
					if (user instanceof SystemUser) {
						cContent.setIsWritable(true);
					} else {
						IGroup nodeGroup = getNodeGroup(node);
						IUser nodeUser = getNodeUser(node);
						cContent.setIsWritable(isWritable(cContent, user, nodeGroup, nodeUser));
					}
					if (null == contentTypeFilters || contentTypeFilters.contains(cContent.getClass())) {
						treeContents.add((T) cContent);
					} else {
						LOGGER.debug("Filtered out content of type {}", node.getPrimaryNodeType().getName());
					}
				}
			}
		} catch (Exception e) {
			LOGGER.warn("Failed to create content factory which node type is " + node.getPrimaryNodeType().getName());
		}
	}

	@Override
	public void destroy() throws AgentException {
		stop();
	}

	@Override
	public void afterPropertiesSet() throws AgentException {
		init();
		start();
	}

	@Override
	public String getUserFolderUUID(String userName) throws ContentException {
		String uuid = getUserFolderNameToUUID().get(userName);

		if (uuid == null) {
			LOGGER.info("Creating the user folder for {}", userName);

			ensureUserNodeExists(userName);

			uuid = getUserFolderNameToUUID().get(userName);

			if (uuid == null) {
				throw new RuntimeException("For some reason, we failed creating a folder for " + userName);
			}
		}

		return uuid;
	}

	@Override
	public String getGroupFolderUUID(String groupName) throws ContentException {
		String uuid = getGroupFolderNameToUUID().get(groupName);

		if (uuid == null) {
			LOGGER.info("Creating the group folder for {}", groupName);

			ensureGroupNodeExists(groupName);

			uuid = getGroupFolderNameToUUID().get(groupName);

			if (uuid == null) {
				throw new RuntimeException("For some reason, we failed creating a folder for " + groupName);
			}
		}

		return uuid;
	}

	/**
	 * @see AJCRContentManager#lazyLoaduser
	 */
	private synchronized void ensureUserNodeExists(String userName) throws ContentException {
		try {
			Node applicationNode = this.systemSession.getNodeByIdentifier(this.applicationNodeUUID);
			Node usersNode = applicationNode.getNode(USERS_NODE_KEY);
			if (!usersNode.hasNode(userName)) {
				Node u = usersNode.addNode(userName, "qfs:UserNode");
				u.setProperty("title", userName);
				u.setProperty("creationDate", Calendar.getInstance());
			}
			this.systemSession.save();
		} catch (RepositoryException e) {
			throw new ContentException(e.getMessage(), e.getCause());
		} catch (Exception e) {
			throw new ContentException("Failed to load user node from Content Manager", e);
		}
	}

	/**
	 * @see AJCRContentManager#lazyLoaduser
	 */
	private synchronized void ensureGroupNodeExists(String groupName) throws ContentException {
		try {
			Node applicationNode = this.systemSession.getNodeByIdentifier(this.applicationNodeUUID);
			Node groupsNode = applicationNode.getNode(GROUPS_NODE_KEY);
			if (!groupsNode.hasNode(groupName)) {
				Node g = groupsNode.addNode(groupName, "qfs:GroupNode");
				g.setProperty("title", groupName);
				g.setProperty("creationDate", Calendar.getInstance());
			}
			this.systemSession.save();
		} catch (RepositoryException e) {
			throw new ContentException(e.getMessage(), e.getCause());
		} catch (Exception e) {
			throw new ContentException("Failed to load user node from Content Manager", e);
		}
	}

}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.live.server.export;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Collection;
import java.util.List;

import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.sax.SAXResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.fop.apps.FOPException;
import org.apache.fop.apps.FOUserAgent;
import org.apache.fop.apps.Fop;
import org.apache.fop.apps.FopFactory;

import com.quartetfs.pivot.live.content.IContentManager;
import com.quartetfs.pivot.live.server.IDiscoveryService;
import com.quartetfs.pivot.live.server.export.impl.AFeedExporter;
import com.quartetfs.pivot.live.server.export.impl.MdxPdfExporter;
import com.quartetfs.pivot.live.shared.contextvalues.IFlatContextValue;
import com.quartetfs.pivot.live.shared.mdx.IFilterData;
import com.quartetfs.pivot.live.shared.mdx.IMdxModel;
import com.quartetfs.pivot.live.shared.mdx.grid.render.impl.LayeredStringBuilder;
import com.quartetfs.pivot.live.shared.utils.SharedUtils;

import blasd.apex.core.io.GZipStringBuilder;

/**
 * Softer transient memory usage by using {@link GZipStringBuilder}
 * 
 * @author Benoit Lacelle
 * 
 */
public class ApexMdxPdfExporter extends MdxPdfExporter {

	public ApexMdxPdfExporter(final IDiscoveryService discoveryService, final IContentManager contentManager) {
		super(discoveryService, contentManager);
	}

	@Override
	protected void doExportImpl(final OutputStream out,
			final IMdxModel mdxModel,
			final Collection<IFlatContextValue> ctxValues) {
		final List<IFilterData> filterDataList = mdxModel.getFilterData();
		final boolean hasFilter = filterDataList != null && !filterDataList.isEmpty()
				&& this.filterDataListHasAtLeastOneElementVisibleWithNotNullCaption(filterDataList);
		final ApexPivotGridXslLayeredBuilder ptXslBuilder = new ApexPivotGridXslLayeredBuilder();
		final LayeredStringBuilder filterXslBuilder = new LayeredStringBuilder();
		this.gridConstructor.construct(mdxModel, ptXslBuilder);
		if (hasFilter) {
			this.filterConstructor.construct(mdxModel, filterXslBuilder);
		}
		final GZipStringBuilder xslBuilder = new GZipStringBuilder();
		try {
			Collection<IFlatContextValue> actualCtxValues;
			if (this.addCtxValue) {
				actualCtxValues = ctxValues;
			} else {
				actualCtxValues = null;
			}
			buildFO(xslBuilder,
					this.exportTitle,
					this.exportDescription,
					actualCtxValues,
					filterXslBuilder,
					ptXslBuilder);

			final TransformerFactory transFactory = TransformerFactory.newInstance();
			final FopFactory fopFactory = FopFactory.newInstance();
			final FOUserAgent foUserAgent = fopFactory.newFOUserAgent();
			final Fop fop = fopFactory.newFop("application/pdf", foUserAgent, out);
			final Transformer transformer = transFactory.newTransformer();
			final Source src = new StreamSource(xslBuilder.toInputStream());
			final Result res = new SAXResult(fop.getDefaultHandler());
			transformer.transform(src, res);
			out.flush();
		} catch (TransformerException | FOPException | IOException e) {
			throw new RuntimeException(e);
		}
	}

	public static void buildFO(final Appendable xslBuilder,
			final String exportTitle,
			final String exportDescription,
			final Collection<IFlatContextValue> ctxValues,
			final LayeredStringBuilder filterXslBuilder,
			final ApexPivotGridXslLayeredBuilder ptXslBuilder) throws IOException {
		xslBuilder.append("<?xml version=\"1.0\"?>");
		xslBuilder.append("<fo:root xmlns:fo=\"http://www.w3.org/1999/XSL/Format\">");
		xslBuilder.append("<fo:layout-master-set>");
		xslBuilder.append("<fo:simple-page-master master-name=\"content\" page-width=\"297mm\" page-height=\"210mm\">");
		xslBuilder.append("<fo:region-body />");
		xslBuilder.append("</fo:simple-page-master>");
		xslBuilder.append("</fo:layout-master-set>");
		xslBuilder.append("<fo:page-sequence master-reference=\"content\">");
		xslBuilder.append("<fo:flow flow-name=\"xsl-region-body\" font-size=\"8pt\" font-family=\"sans-serif\">");
		xslBuilder.append(
				"<fo:table block-progression-dimension=\"auto\" table-layout=\"fixed\" width=\"100%\" height=\"100%\">");
		xslBuilder.append("<fo:table-column column-width=\"proportional-column-width(1)\" />");
		xslBuilder.append("<fo:table-column column-width=\"260mm\" />");
		xslBuilder.append("<fo:table-column column-width=\"proportional-column-width(1)\" />");
		xslBuilder.append("<fo:table-body height=\"100%\">");
		xslBuilder.append("<fo:table-row height=\"210mm\">");
		xslBuilder.append("<fo:table-cell column-number=\"2\" display-align=\"center\">");
		if (exportTitle != null && !exportTitle.isEmpty()) {
			xslBuilder.append("<fo:block space-before=\"5mm\" text-align=\"center\">");
			xslBuilder.append(SharedUtils.escapeXml(exportTitle));
			xslBuilder.append("</fo:block>");
		}
		if (exportDescription != null && !exportDescription.isEmpty()) {
			xslBuilder.append("<fo:block space-before=\"5mm\">");
			xslBuilder.append(SharedUtils.escapeXml(exportDescription));
			xslBuilder.append("</fo:block>");
		}
		if (ctxValues != null && !ctxValues.isEmpty()) {
			xslBuilder.append("<fo:block space-before=\"5mm\">Context Values:</fo:block>");
			xslBuilder.append("<fo:block>");
			xslBuilder.append("<fo:table border-style=\"solid\"><fo:table-body>");
			final StringBuilder firstRow = new StringBuilder("<fo:table-row>");
			final StringBuilder secondRow = new StringBuilder("<fo:table-row>");
			for (final IFlatContextValue cv : AFeedExporter.sortContextValuesForExport(ctxValues)) {
				firstRow.append("<fo:table-cell border-style=\"solid\" text-align=\"center\"><fo:block>")
						.append(cv.getName())
						.append("</fo:block></fo:table-cell>");
				secondRow.append("<fo:table-cell border-style=\"solid\" text-align=\"center\"><fo:block>")
						.append(cv.getValue())
						.append("</fo:block></fo:table-cell>");
			}
			firstRow.append("</fo:table-row>");
			secondRow.append("</fo:table-row>");
			xslBuilder.append(firstRow.toString()).append(secondRow.toString());
			xslBuilder.append("</fo:table-body></fo:table>");
			xslBuilder.append("</fo:block>");
		}
		final String filter = filterXslBuilder.build();
		if (filter != null && !filter.isEmpty()) {
			xslBuilder.append("<fo:block space-before=\"5mm\">Filters:</fo:block>");
			xslBuilder.append("<fo:block>");
			xslBuilder.append(filter);
			xslBuilder.append("</fo:block>");
		}
		xslBuilder.append("<fo:block space-before=\"5mm\">");
		ptXslBuilder.build(xslBuilder);
		xslBuilder.append("</fo:block>");
		xslBuilder.append("</fo:table-cell>");
		xslBuilder.append("</fo:table-row>");
		xslBuilder.append("</fo:table-body>");
		xslBuilder.append("</fo:table>");
		xslBuilder.append("</fo:flow>");
		xslBuilder.append("</fo:page-sequence>");
		xslBuilder.append("</fo:root>");
	}
}

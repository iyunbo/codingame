/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.live.server.bookmarks;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.LinkedBlockingQueue;

import javax.xml.bind.JAXBException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Optional;
import com.google.common.base.Strings;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.ListMultimap;
import com.google.common.collect.MultimapBuilder;
import com.quartetfs.pivot.live.content.IContentManager;
import com.quartetfs.pivot.live.content.impl.ContentException;
import com.quartetfs.pivot.live.content.shared.IContent;
import com.quartetfs.pivot.live.content.shared.IMutableContent;
import com.quartetfs.pivot.live.content.shared.impl.GroupFolder;
import com.quartetfs.pivot.live.content.shared.impl.UserFolder;

import blasd.apex.live.server.bookmark.dto.AContentDTO;
import blasd.apex.live.server.bookmark.dto.AContentDTOHelper;
import blasd.apex.live.server.bookmark.dto.ContentCommonDTO;
import blasd.apex.live.server.bookmark.dto.ContentFromDTO;
import blasd.apex.live.server.bookmark.dto.ContentToDTO;
import blasd.apex.live.server.bookmark.dto.FolderDTO;
import blasd.apex.live.server.bookmarks.content.ApplicationContent;
import blasd.apex.live.server.bookmarks.content.GroupsContent;
import blasd.apex.live.server.bookmarks.content.IContentMerger;
import blasd.apex.live.server.bookmarks.content.UsersContent;

/**
 * Default implementation for {@link IApexBookmarkExporter}
 * 
 * @author Benoit Lacelle
 *
 */
public class ApexBookmarkExporter implements IApexBookmarkExporter {
	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexBookmarkExporter.class);

	protected static final Set<? extends Class<? extends IMutableContent>> NOT_UPDATABLE = ImmutableSet
			.of(ApplicationContent.class, GroupsContent.class, UsersContent.class, UserFolder.class, GroupFolder.class);

	@Override
	public String exportBookmarks(AContentDTO dtoTree) throws JAXBException {
		ByteArrayOutputStream os = new ByteArrayOutputStream();

		AContentDTOHelper.doMarshall(dtoTree, os);

		return new String(os.toByteArray());
	}

	@Override
	public AContentDTO exportBookmarks(String uuid, Collection<? extends IContent> flatTree) throws JAXBException {
		ListMultimap<String, IContent> parentUUIDToContents = MultimapBuilder.hashKeys().arrayListValues().build();
		IContent rootContent = null;

		for (IContent content : flatTree) {
			parentUUIDToContents.put(content.getParentUUID(), content);

			if (content.getUUID().equals(uuid)) {
				if (rootContent != null) {
					LOGGER.warn("We matched several IContent with the same rootUUID");
				}
				rootContent = content;
			}
		}
		if (rootContent == null) {
			throw new RuntimeException("We found no content with UUID=" + uuid);
		} else {
			LOGGER.info("We export the node {} which has {} descendants", rootContent, flatTree.size() - 1);
		}

		AContentDTO rootDTO = ContentToDTO.convertToDTO(rootContent);

		Queue<AContentDTO> contentToConsider = new LinkedBlockingQueue<>();
		contentToConsider.add(rootDTO);

		while (!contentToConsider.isEmpty()) {
			AContentDTO next = contentToConsider.poll();

			// Add the children and prevent this UUID to be considered later
			List<IContent> children = parentUUIDToContents.removeAll(next.contentCommon.uuid);

			if (children != null && !children.isEmpty()) {
				List<AContentDTO> childrenDTO = ContentToDTO.convertToDTO(children);
				// Set these nodes as children
				next.contentCommon.children.addAll(childrenDTO);
				// COnsider these nodes for there own children later
				contentToConsider.addAll(childrenDTO);
			}
		}

		return rootDTO;
	}

	@Override
	public int importBookmarks(String targetParentUUID,
			AContentDTO dtoTreeToImport,
			Collection<? extends IMutableContent> flatTree,
			IContentManager contentManager,
			IContentMerger contentMerger) throws JAXBException, ContentException {
		// Several mode:
		// 1) Delete the node content before inserting
		// 2) Add the node in any case
		// 3) Add the node only if there is not a sibling with same title/uuid
		// 4) Add the node and remove existing siblings with same title/uuid

		ListMultimap<String, IMutableContent> existingParentUUIDToContents =
				MultimapBuilder.hashKeys().arrayListValues().build();
		IContent rootContent = null;

		for (IMutableContent content : flatTree) {
			existingParentUUIDToContents.put(content.getParentUUID(), content);

			if (content.getUUID().equals(targetParentUUID)) {
				rootContent = content;
			}
		}

		final boolean rerooted;
		if (rootContent == null) {
			throw new RuntimeException("There is no content with UUID=" + targetParentUUID);
		} else if (!contentMerger.sameNode(rootContent, dtoTreeToImport)) {
			// We are importing a content which root is different for the
			// targeted root: wrap the imported content in a matching
			// content.
			// It typically happens when importing an MDX in a folder: the clean way is to import a folder with same
			// name as existing folder, the imported folder holding the imported MDX
			AContentDTO newRootDTO = new FolderDTO(new ContentCommonDTO(rootContent));
			newRootDTO.contentCommon.children.add(dtoTreeToImport);

			LOGGER.info("We re-rooted as imported root is {} while target UUID was {}", dtoTreeToImport, rootContent);

			dtoTreeToImport = newRootDTO;
			rerooted = true;
		} else {
			rerooted = false;
		}

		// Hold the children still to process inthis process
		Queue<ContentAndDTOPair> toConsider = new LinkedBlockingQueue<>();

		toConsider.add(new ContentAndDTOPair(rootContent, dtoTreeToImport));

		int nbAdded = 0;
		if (rerooted) {
			// The parent folder is not an actually added node
			nbAdded = -1;
		}

		// We loop on each node of the tree to import, starting from parents to children
		while (!toConsider.isEmpty()) {
			nbAdded++;

			// Get next node to process
			ContentAndDTOPair pairToConsider = toConsider.poll();

			// Process current node
			Collection<? extends ContentAndDTOPair> childrenToConsider =
					addPairAndReturnChildrenPairs(pairToConsider.content,
							pairToConsider.dto,
							existingParentUUIDToContents,
							contentManager,
							contentMerger);

			// Add children as nodes to process
			toConsider.addAll(childrenToConsider);
		}

		return nbAdded;
	}

	protected Collection<? extends ContentAndDTOPair> addPairAndReturnChildrenPairs(IContent parentExistingNode,
			AContentDTO parentImportedNode,
			ListMultimap<String, IMutableContent> existingParentUUIDToContents,
			IContentManager contentManager,
			IContentMerger contentMerger) throws ContentException {

		if (contentMerger.sameNode(parentExistingNode, parentImportedNode)) {
			LOGGER.debug("We merge {} in {}", parentImportedNode, parentExistingNode);

			// We retrieve the children of the existing node
			// It is necessary to merge correctly the imported children in the existing children
			List<IMutableContent> existingChildren = existingParentUUIDToContents.get(parentExistingNode.getUUID());
			// {
			// existingChildren = ;
			// Map<String, IContent> uuidToChildren = new HashMap<>();
			// for (IContent child : existingChildren) {
			// uuidToChildren.put(child.getUUID(), child);
			// }
			// }

			List<ContentAndDTOPair> childrenToConsider = new ArrayList<>();

			for (AContentDTO importedChild : parentImportedNode.contentCommon.children) {
				// Find the existing children which are considered as the same as the imported child
				List<IMutableContent> repositoryChildren = new ArrayList<>();
				for (IMutableContent existingChild : existingChildren) {
					if (contentMerger.sameNode(existingChild, importedChild)) {
						repositoryChildren.add(existingChild);
					}
				}

				LOGGER.info("We consider the child {} which has as siblings in the repository: {}",
						importedChild,
						repositoryChildren);

				// Update parent UUID with the actual value in the repository
				importedChild.contentCommon.parentUUID = parentExistingNode.getUUID();

				final Optional<IMutableContent> dtoInRepository;
				if (repositoryChildren.isEmpty()) {
					LOGGER.debug("{} has no siblings as child of {}",
							importedChild,
							repositoryChildren.size(),
							parentExistingNode);

					dtoInRepository = appendChildren(contentManager, importedChild, parentExistingNode);
				} else if (repositoryChildren.size() == 1) {
					// There is a single existing sibling
					IMutableContent existingSibling = repositoryChildren.get(0);

					LOGGER.debug("{} has a single sibling ({}) as child of {}",
							importedChild,
							existingSibling,
							parentExistingNode);

					dtoInRepository = updateChildren(contentManager, importedChild, existingSibling);
				} else {
					// There is already several siblings: just add another
					// siblings
					LOGGER.debug("{} has {} siblings as child of {}",
							importedChild,
							repositoryChildren.size(),
							parentExistingNode);
					dtoInRepository = appendChildren(contentManager, importedChild, parentExistingNode);
				}

				if (dtoInRepository.isPresent()) {
					childrenToConsider.add(new ContentAndDTOPair(dtoInRepository.get(), importedChild));
				} else {
					LOGGER.warn("Do not consider children for {}", importedChild);
				}
			}

			return childrenToConsider;
		} else {
			throw new RuntimeException("The top elements must have the same title: " + parentExistingNode.getTitle()
					+ " and "
					+ parentImportedNode.contentCommon.title);
		}
	}

	protected Optional<IMutableContent> updateChildren(IContentManager contentManager,
			AContentDTO importedChild,
			IMutableContent existingSibling) {
		// Set the UUID of the existing node
		importedChild.contentCommon.uuid = existingSibling.getUUID();

		if (!Strings.isNullOrEmpty(importedChild.contentCommon.description)) {
			// The imported node has no description: read the one from the existing node
			importedChild.contentCommon.description = existingSibling.getDescription();
		}

		if (NOT_UPDATABLE.contains(existingSibling.getClass())) {
			LOGGER.debug("Skip a not-updatable content: {} {}", existingSibling.getClass(), existingSibling);
			return Optional.of(existingSibling);
		} else {
			// Update the existing node
			IMutableContent dtoInRepository =
					ContentFromDTO.convertFromDTO(importedChild, Optional.of(existingSibling.getParentUUID()));

			if (dtoInRepository == null) {
				LOGGER.debug("Skip updating {}", importedChild);
				return Optional.absent();
			} else {
				try {
					contentManager.update(dtoInRepository);
				} catch (ContentException | RuntimeException e) {
					throw new RuntimeException("Failed merging " + importedChild
							+ " to "
							+ existingSibling
							+ " as child of "
							+ existingSibling.getParentUUID(), e);
				}

				LOGGER.debug("We updated {} from {} to {}",
						importedChild.contentCommon.uuid,
						existingSibling,
						dtoInRepository);
			}
			return Optional.of(dtoInRepository);
		}
	}

	protected Optional<IMutableContent> appendChildren(IContentManager contentManager,
			AContentDTO importedChild,
			IContent parentExistingNode) {

		// There is no equivalent node: add the imported node
		IMutableContent dtoInRepository =
				ContentFromDTO.convertFromDTO(importedChild, Optional.of(parentExistingNode.getUUID()));

		if (dtoInRepository == null) {
			return Optional.absent();
		} else if (NOT_UPDATABLE.contains(dtoInRepository.getClass())) {
			LOGGER.debug("Skip a not-updatable content: {} {}", dtoInRepository.getClass(), dtoInRepository);
			return Optional.of(dtoInRepository);
		} else {
			// Remove the UUID which might be present in the XML, as the ContentManager has to set it itself
			dtoInRepository.setUUID(null);

			String newUUID;
			try {
				newUUID = contentManager.create(dtoInRepository);
			} catch (ContentException | RuntimeException e) {
				throw new RuntimeException("Failed adding " + dtoInRepository + " to " + parentExistingNode, e);
			}

			// Copy back the UUID to the imported node
			dtoInRepository.setUUID(newUUID);

			// Update with the actual value in the repository
			importedChild.contentCommon.uuid = newUUID;

			LOGGER.debug("We appended ({}) {} to {}",
					dtoInRepository.getTitle(),
					newUUID,
					parentExistingNode.getUUID());

			return Optional.of(dtoInRepository);
		}
	}
}

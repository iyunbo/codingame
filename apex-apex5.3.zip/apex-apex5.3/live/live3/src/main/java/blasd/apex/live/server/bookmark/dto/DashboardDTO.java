/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.live.server.bookmark.dto;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Enable marshalling of JCR elements
 * 
 * @author Benoit Lacelle
 *
 */
@XmlRootElement(name = "dashboard")
public class DashboardDTO extends AContentDTO {

	@XmlElement
	protected String key;

	/**
	 * Store as a string a set of parameters that characterize this template
	 */
	@XmlElement
	protected String parameters;

	/**
	 * The number of slots provided by this template
	 */
	@XmlElement
	protected String size;

	/**
	 * List of bookmark's uuid & params contained into this dashboard, null if no widget inserted in a certain slot
	 */
	@XmlElement
	protected List<String> widgetParams;

	public DashboardDTO() {
		// Serialization
	}

	public DashboardDTO(ContentCommonDTO common,
			String key,
			String parameters,
			String size,
			List<String> widgetParams) {
		super(common);
		this.key = key;
		this.parameters = parameters;
		this.size = size;
		this.widgetParams = widgetParams;
	}

	public String getKey() {
		return key;
	}

	public String getParameters() {
		return parameters;
	}

	public String getSize() {
		return size;
	}

	public List<String> getWidgetParams() {
		return widgetParams;
	}

	@Override
	public String toString() {
		return "DashboardDTO [key=" + key
				+ ", parameters="
				+ parameters
				+ ", size="
				+ size
				+ ", widgetParams="
				+ widgetParams
				+ "]";
	}
}

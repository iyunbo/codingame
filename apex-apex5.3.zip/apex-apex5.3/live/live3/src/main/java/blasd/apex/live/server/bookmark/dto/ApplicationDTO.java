/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.live.server.bookmark.dto;

import java.util.Arrays;

import javax.xml.bind.JAXBException;
import javax.xml.bind.annotation.XmlRootElement;

import blasd.apex.live.server.bookmarks.content.TechnicalFolderDTO;

/**
 * Enable marshalling of JCR elements
 * 
 * @author Benoit Lacelle
 *
 */
@XmlRootElement(name = "application")
public class ApplicationDTO extends AContentDTO {

	protected ApplicationDTO() {
		// Serialization
	}

	public ApplicationDTO(ContentCommonDTO common) {
		super(common);
	}

	// A minimal interesting application: we have a user with an MDX
	public static void main(String[] args) throws JAXBException {
		MdxQueryDTO mdx =
				new MdxQueryDTO(new ContentCommonDTO("userFolderUuid", "mdxUuid", "Some MDX Title", null, null),
						"mdxQuery",
						null,
						null);

		TechnicalFolderDTO userFolder = new TechnicalFolderDTO(
				new ContentCommonDTO("usersContentUuid", "userFolderUuid", "Other User", null, Arrays.asList(mdx)));

		UsersDTO usersContent = new UsersDTO(
				new ContentCommonDTO("appUuid", "usersContentUuid", "Some MDX Title", null, Arrays.asList(userFolder)));

		ApplicationDTO application = new ApplicationDTO(new ContentCommonDTO("rootUuid",
				"appUuid",
				"applicationName",
				"description",
				Arrays.asList(usersContent)));

		AContentDTOHelper.doTestMarshall(application, System.out);
	}
}

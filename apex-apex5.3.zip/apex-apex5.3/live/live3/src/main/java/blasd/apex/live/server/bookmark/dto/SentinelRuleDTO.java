/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.live.server.bookmark.dto;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBException;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Enable marshalling of JCR elements
 * 
 * @author Benoit Lacelle
 *
 */
@XmlRootElement(name = "sentinelRule")
public class SentinelRuleDTO extends ASentinelRuleDTO {

	/** This rule's conditions */
	@XmlElement
	protected List<String> conditions;

	protected SentinelRuleDTO() {
		// Serialization
	}

	public SentinelRuleDTO(ContentCommonDTO common,
			SentinelRuleCommonDTO sentinelCommon,
			String mdxQuery,
			boolean autoStart,
			String pivotId,
			String state,
			List<String> conditions) {
		super(common, sentinelCommon, mdxQuery, autoStart, pivotId, state);
		this.conditions = conditions;
	}

	public List<String> getConditions() {
		return conditions;
	}

	public static void main(String[] args) throws JAXBException {
		Map<String, String> properties = new HashMap<>();
		properties.put("Properties", "property");
		Map<String, String[]> details = new HashMap<>();
		String[] detail = { "detail" };
		details.put("Details", detail);
		List<String> conditions = new ArrayList<>();
		conditions.add("conditions");

		SentinelRuleDTO rule =
				new SentinelRuleDTO(new ContentCommonDTO("parentUUID", "uuid", "title", "description", null),
						new SentinelRuleCommonDTO("liveServerUrl", "ownerName", properties, details),
						"mdxQuery",
						false,
						"pivotId",
						"state",
						conditions);

		AContentDTOHelper.doTestMarshall(rule, System.out);
	}
}

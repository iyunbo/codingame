/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.live.server.bookmarks;

import javax.xml.bind.JAXBException;

import com.quartetfs.pivot.live.content.impl.ContentException;

import blasd.apex.live.server.bookmark.dto.AContentDTO;
import blasd.apex.live.server.bookmarks.content.IContentMerger;

/**
 * Enable exporting of a JCR repository
 * 
 * @author Benoit Lacelle
 *
 */
public interface IApexContentExporter {
	String getApplicationUUID();

	String exportBookmarks(String uuid) throws JAXBException;

	AContentDTO exportBookmarksToDTO(String uuid) throws JAXBException, ContentException;

	int importBookmarksAsAdmin(String uuid, String xml) throws JAXBException;

	int importBookmarks(String targetParentUUID, String xml, IContentMerger contentMerger) throws JAXBException;

	int importBookmarks(String targetParentUUID, AContentDTO contentDTO, IContentMerger contentMerger)
			throws JAXBException;
}

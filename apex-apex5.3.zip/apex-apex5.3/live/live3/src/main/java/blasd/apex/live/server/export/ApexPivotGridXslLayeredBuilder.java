/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.live.server.export;

import java.io.IOException;

import com.quartetfs.pivot.live.shared.mdx.grid.render.xsl.impl.PivotGridXslLayeredBuilder;

/**
 * Enable building to any {@link Appendable}
 * 
 * @author Benoit Lacelle
 * 
 */
public class ApexPivotGridXslLayeredBuilder extends PivotGridXslLayeredBuilder {

	@Override
	public StringBuilder getBodyLayer() {
		return bodyLayer;
	}

	/**
	 * Build first row of table header
	 */
	@Override
	public StringBuilder getPrefixLayer() {
		return prefixLayer;
	}

	@Override
	public String build() {
		try {
			return build(new StringBuilder()).toString();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	public <T extends Appendable> T build(T sb) throws IOException {
		sb.append(headLayer);

		boolean headerStarted = false;
		for (int i = 0; i < maxLayer + 1; i++) {
			if (null != layers.get(i) && layers.get(i).length() > 0) {
				if (!headerStarted) {
					sb.append("<fo:table-header>");

					if (prefixLayer.length() > 0) {
						sb.append("<fo:table-row>\n");
						sb.append(prefixLayer);
						sb.append("</fo:table-row>\n");
					}

					headerStarted = true;
				}

				sb.append("<fo:table-row>\n");
				StringBuilder bodyRowBuilder = layers.get(i);

				// table row must have children
				if (bodyRowBuilder.length() == 0) {
					bodyRowBuilder.append("<fo:table-cell><fo:block></fo:block></fo:table-cell>");
				}

				sb.append(bodyRowBuilder);
				sb.append("</fo:table-row>\n");
			}
		}

		if (headerStarted) {
			sb.append("</fo:table-header>\n");
		}

		sb.append("<fo:table-body>\n<fo:table-row>");
		StringBuilder bodyRowBuilder = bodyLayer;

		// table row must have children
		if (bodyRowBuilder.length() == 0) {
			bodyRowBuilder.append("<fo:table-cell><fo:block></fo:block></fo:table-cell>");
		}

		sb.append(bodyRowBuilder);
		sb.append("</fo:table-row>\n</fo:table-body>");
		sb.append(bottomLayer);

		return sb;
	}

	@Override
	public StringBuilder getNewBuilder() {
		return new StringBuilder();
	}
}

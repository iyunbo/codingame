/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.live.client.rightlick;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.logging.Logger;

import com.google.common.collect.HashBasedTable;
import com.google.common.collect.Table;
import com.quartetfs.biz.pivot.cube.dimension.IDimension;
import com.quartetfs.pivot.live.client.mdx.table.IPivotCell;
import com.quartetfs.pivot.live.client.mdx.table.IPivotDataCell;
import com.quartetfs.pivot.live.client.mdx.table.IPivotHeaderCell;
import com.quartetfs.pivot.live.shared.HierarchyWrapper;
import com.quartetfs.pivot.live.shared.mdx.IFilterData;
import com.quartetfs.pivot.live.shared.mdx.IMdxModel;
import com.quartetfs.pivot.live.shared.mdx.grid.impl.GridUtils;
import com.quartetfs.pivot.live.shared.model.IMdxIdentifier;
import com.quartetfs.pivot.live.shared.model.IMdxMemberExpression;
import com.quartetfs.pivot.live.shared.model.executor.impl.MultiselectExecutor;
import com.quartetfs.pivot.live.shared.model.visitor.IMdxVisitorContext;
import com.quartetfs.pivot.live.shared.model.visitor.impl.DefaultMdxVisitorContext;
import com.quartetfs.pivot.live.shared.olap.impl.Cube;
import com.quartetfs.pivot.live.shared.olap.impl.Dimension;
import com.quartetfs.pivot.live.shared.olap.impl.Hierarchy;
import com.quartetfs.pivot.live.shared.olap.impl.Level;

/**
 * Helpers to convert a pivot cell to a Map of coordinates
 * 
 * @author Benoit Lacelle
 *
 */
public class ApexPivotCellHelper {

	protected static final Logger LOGGER = Logger.getLogger(ApexPivotCellHelper.class.getName());

	protected ApexPivotCellHelper() {
		// hidden
	}

	/**
	 * 
	 * @param pivotCell
	 * @return a {@link Map} from a {@link Dimension} to a {@link Hierarchy} to a {@link Level} ordinal to its
	 *         coordinate
	 */
	public static Map<String, Map<String, Map<Integer, String>>> extractCoordinates(IPivotCell pivotCell) {
		if (pivotCell == null) {
			return Collections.emptyMap();
		} else {
			Map<String, Map<String, Map<Integer, String>>> coordinates =
					new HashMap<String, Map<String, Map<Integer, String>>>();

			if (pivotCell instanceof IPivotDataCell) {
				fillCoordinates(coordinates, ((IPivotDataCell) pivotCell).getColumnHeaderCell());
				fillCoordinates(coordinates, ((IPivotDataCell) pivotCell).getRowHeaderCell());
			} else if (pivotCell instanceof IPivotHeaderCell) {
				fillCoordinates(coordinates, (IPivotHeaderCell) pivotCell);
			} else {
				// TODO ???
				// For instance, we don't consider IPivotFilterCell
				LOGGER.info("Class not handlded: " + pivotCell.getClass());
			}

			return coordinates;
		}
	}

	public static void fillCoordinates(Map<String, Map<String, Map<Integer, String>>> coordinates,
			IPivotHeaderCell pivotHeaderCell) {
		for (Entry<HierarchyWrapper, String[]> entry : pivotHeaderCell.extractAllFilterPathes().entrySet()) {
			fillCoordinates(coordinates, entry.getKey(), entry.getValue());
		}
	}

	/**
	 * Add the coordinate for each {@link Level} of this {@link Hierarchy}
	 * 
	 * @param coordinates
	 *            a {@link Map} where to register the coordinates
	 * @param key
	 * @param value
	 */
	public static void fillCoordinates(Map<String, Map<String, Map<Integer, String>>> coordinates,
			HierarchyWrapper key,
			String[] value) {
		if (!coordinates.containsKey(key.getDimension())) {
			coordinates.put(key.getDimension(), new HashMap<String, Map<Integer, String>>());
		}
		if (!coordinates.get(key.getDimension()).containsKey(key.getHierarchy())) {
			coordinates.get(key.getDimension()).put(key.getHierarchy(), new HashMap<Integer, String>());
		}

		for (int i = 0; i < value.length; i++) {
			coordinates.get(key.getDimension()).get(key.getHierarchy()).put(i, value[i]);
		}
	}

	// { d name => { h name => { value }}}
	// for measure : IDimension.MEASURES, IDimension.MEASURES
	// TODO : Pair<Measure, ...>
	public static Table<String, String, List<String>> extractExpressedLevels(IMdxModel mdxModel, IPivotCell cell) {
		Table<String, String, List<String>> result = HashBasedTable.create();

		if (mdxModel != null) {

			MultiselectExecutor multiselectExecutor = new MultiselectExecutor();

			Collection<IFilterData> filterData = mdxModel.getFilterData();

			if (filterData != null) {

				IMdxVisitorContext context = new DefaultMdxVisitorContext(mdxModel.getMdxSelect(), mdxModel.getCube());

				for (IFilterData fd : filterData) {
					for (IMdxMemberExpression member : multiselectExecutor.getMembers(context, fd.getExpression())) {
						mergeResult(result, member.getParts());
					}
				}
			}

			if (cell != null) {

				if (cell instanceof IPivotDataCell) {
					if (((IPivotDataCell) cell).getColumnHeaderCell() != null) {

						for (IMdxMemberExpression member : GridUtils.positionFromHeader(mdxModel.getCube(),
								((IPivotDataCell) cell).getColumnHeaderCell().extractAllFilterPathes())) {
							mergeResult(result, member.getParts());
						}
					}
					if (((IPivotDataCell) cell).getRowHeaderCell() != null) {

						for (IMdxMemberExpression member : GridUtils.positionFromHeader(mdxModel.getCube(),
								((IPivotDataCell) cell).getRowHeaderCell().extractAllFilterPathes())) {
							mergeResult(result, member.getParts());
						}
					}
				} else if (cell instanceof IPivotHeaderCell) {
					for (IMdxMemberExpression member : GridUtils.positionFromHeader(mdxModel.getCube(),
							((IPivotHeaderCell) cell).extractAllFilterPathes())) {
						mergeResult(result, member.getParts());
					}
				} else {
					throw new RuntimeException(cell.getClass().getName());
				}
			}
		}

		return result;
	}

	public static String extractExpressedLevelValue(IMdxModel mdxModel,
			IPivotCell cell,
			String dimensionName,
			String hierarchyName,
			int levelOrdinal) {
		Table<String, String, List<String>> expressedD = extractExpressedLevels(mdxModel, cell);

		Map<String, List<String>> expressedH = expressedD.row(dimensionName);

		if (expressedH == null) {
			return null;
		}

		List<String> hMembers = expressedH.get(hierarchyName);

		if (hMembers == null) {
			return null;
		}

		if (levelOrdinal < hMembers.size()) {
			return hMembers.get(levelOrdinal);
		}

		return null;
	}

	public static final int MEMBER_INDEX = 3;

	protected static void mergeResult(Table<String, String, List<String>> dResult, IMdxIdentifier[] parts) {
		if (parts[0].getValue().equals(IDimension.MEASURES)) {
			dResult.put(IDimension.MEASURES, IDimension.MEASURES, Collections.singletonList(parts[1].getValue()));
		} else {
			List<String> members = new ArrayList<>();
			for (int i = MEMBER_INDEX; i < parts.length; i++) {
				members.add(parts[i].getValue());
			}

			dResult.put(parts[0].getValue(), parts[1].getValue(), members);
		}
	}

	/**
	 * Check this is an easy Mdx Expression, for which most assumptions are true
	 * 
	 * @param cube
	 * @param position
	 * @return
	 */
	public static boolean isNiceExpression(Cube cube, IMdxMemberExpression position) {
		// Consider: SharedUtils.parseUniqueName:

		if (IDimension.MEASURES.equals(position.getHierarchy())) {
			// Calculated measures may return null for:
			// cube.getHierarchiesPerName().get(position.getHierarchy())
			if (position.getParts().length == 2) {
				return true;
			} else {
				return false;
			}
		} else {
			// Check the rootLevel is the second part of the expression: we have
			// a full path
			// TODO: migration
			throw new UnsupportedOperationException("TODO migration");
			// return
			// cube.getDimensionsPerName().get(position.getHierarchy()).getRootLevelName().equals(position.getLevel());
		}
	}
}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.live.server.export;

import java.io.IOException;

import com.quartetfs.pivot.live.shared.mdx.IColorProvider;
import com.quartetfs.pivot.live.shared.mdx.grid.render.html.impl.PivotGridHtmlMatrixBuilder;
import com.quartetfs.pivot.live.shared.mdx.grid.render.impl.LayeredBuilder;

/**
 * Enable building to any {@link Appendable}
 * 
 * @author Benoit Lacelle
 * 
 */
public class ApexPivotGridHtmlMatrixBuilder extends PivotGridHtmlMatrixBuilder {

	public ApexPivotGridHtmlMatrixBuilder(final IColorProvider colorProvider) {
		super(colorProvider);
	}

	@Override
	public String build() {
		try {
			return build(new StringBuilder()).toString();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	public <T extends Appendable> T build(T sb) throws IOException {
		final LayeredBuilder<StringBuilder> topLeft = this.getTopLeftLayer();
		final LayeredBuilder<StringBuilder> colHead = this.getColHeaderLayer();
		final LayeredBuilder<StringBuilder> rowHead = this.getRowHeaderLayer();
		final LayeredBuilder<StringBuilder> bodyCenter = this.getBodyCenterLayer();
		sb.append(this.headLayer.toString());
		sb.append("<thead>");
		sb.append(topLeft.getHeadLayer().toString()).append(colHead.getHeadLayer().toString());
		final int topLeftNb = topLeft.getLayerNb();
		final int colHeadNb = colHead.getLayerNb();
		for (int maxHeadLayer = Math.max(topLeftNb, colHeadNb), i = 0; i < maxHeadLayer + 1; ++i) {
			sb.append("<tr>\n");
			sb.append(topLeft.getLayer(i).toString()).append(colHead.getLayer(i).toString());
			sb.append("</tr>\n");
		}
		sb.append(topLeft.getBottomLayer().toString()).append(colHead.getBottomLayer().toString());
		sb.append("</thead>\n");
		sb.append("<tbody>\n");
		sb.append(rowHead.getHeadLayer().toString()).append(bodyCenter.getHeadLayer().toString());
		final int rowHeadNb = rowHead.getLayerNb();
		final int bodyCenterNb = bodyCenter.getLayerNb();
		for (int maxBodyLayer = Math.max(rowHeadNb, bodyCenterNb), j = 0; j < maxBodyLayer + 1; ++j) {
			sb.append("<tr>\n");
			sb.append(rowHead.getLayer(j).toString()).append(bodyCenter.getLayer(j).toString());
			sb.append("</tr>\n");
		}
		sb.append(rowHead.getBottomLayer().toString()).append(bodyCenter.getBottomLayer().toString());
		sb.append("\n</tbody>");
		sb.append(this.bottomLayer.toString());
		return sb;
	}
}

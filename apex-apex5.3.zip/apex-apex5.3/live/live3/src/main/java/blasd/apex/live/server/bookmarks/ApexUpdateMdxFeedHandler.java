/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.live.server.bookmarks;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import com.google.common.util.concurrent.AtomicLongMap;
import com.quartetfs.pivot.live.content.impl.ContentException;
import com.quartetfs.pivot.live.content.shared.IContent;
import com.quartetfs.pivot.live.core.server.cmd.IActionContext;
import com.quartetfs.pivot.live.core.shared.cmd.ActionException;
import com.quartetfs.pivot.live.core.shared.cmd.impl.VoidResult;
import com.quartetfs.pivot.live.server.mdx.impl.UpdateMdxFeedHandler;
import com.quartetfs.pivot.live.shared.mdx.impl.UpdateMdxFeedAction;
import com.quartetfs.pivot.live.shared.mdx.impl.UpdateMdxFeedAction.MdxDescription;

import blasd.apex.core.jmx.PepperJMXHelper;

/**
 * Enables the logging of bookmark usage by users.
 * 
 * Override the bean with id UpdateMdxFeedHandler in Custom.xml, originally defined in activepivot-live-components.jar
 * in /Command.components.xml
 * 
 * @author Benoit Lacelle
 * 
 */
// <!-- Override UpdateMdxFeedHandler in /Command.components.xml -->
// <bean id="UpdateMdxFeedHandler"
// class="blasd.apex.live.server.bookmarks.ApexUpdateMdxFeedHandler">
// <property name="pivotIdGenerator" ref="IdGenerator" />
// <property name="PivotRegistrationService" ref="PivotRegistrationService" />
// <property name="contentManager" ref="ContentManager" />
// </bean>
@ManagedResource
public class ApexUpdateMdxFeedHandler extends UpdateMdxFeedHandler {
	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexUpdateMdxFeedHandler.class);

	protected final AtomicLongMap<String> uuidToUsage = AtomicLongMap.create();

	@ManagedAttribute
	public Map<String, Long> getUuidToUsage() {
		return PepperJMXHelper.convertToJMXValueOrderedMap(uuidToUsage.asMap(), true);
	}

	@Override
	public VoidResult executeSession(UpdateMdxFeedAction action, IActionContext context) throws ActionException {
		logBookmarkUsage(action.getMdxDescription());

		return super.executeSession(action, context);
	}

	protected void logBookmarkUsage(MdxDescription mdxDescription) {
		if (mdxDescription instanceof UpdateMdxFeedAction.MdxBookmarkDescription) {
			String uuid = ((UpdateMdxFeedAction.MdxBookmarkDescription) mdxDescription).getBookmarkId();

			String userName = getUserName();

			IContent content;
			try {
				content = contentManager.get(uuid);
			} catch (ContentException e) {
				LOGGER.warn("Issue while user {} requested bookmark {}", userName, uuid);
				return;
			}

			if (content == null) {
				LOGGER.debug("User {} tried to open a non-existing bookmark: ", userName, uuid);
			} else {
				// AtomicLongMap is not ThreadSafe
				uuidToUsage.incrementAndGet(uuid);

				onUserOpenBookmark(userName, content);
			}
		}
	}

	protected void onUserOpenBookmark(String userName, IContent content) {
		LOGGER.info("User {} open bookmark {} (title='{}')",
				new Object[] { userName, content.getUUID(), content.getTitle() });
	}

	protected String getUserName() {
		SecurityContext securityContext = SecurityContextHolder.getContext();
		if (securityContext == null) {
			return "NO_AUTH";
		} else {
			Authentication auth = securityContext.getAuthentication();
			if (auth == null) {
				return "NO_AUTH";
			} else {
				return auth.getName();
			}
		}
	}
}

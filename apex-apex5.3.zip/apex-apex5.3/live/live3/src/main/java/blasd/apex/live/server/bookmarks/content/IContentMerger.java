/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.live.server.bookmarks.content;

import com.quartetfs.pivot.live.content.shared.IContent;

import blasd.apex.live.server.bookmark.dto.AContentDTO;

/**
 * This interface is used when importing nodes to an existing repository: we have to define the logic telling if 2 nodes
 * should be merged or appended one next to the user. We may always want to add (e.g. we are adding crafted bookmarks),
 * or merge if same title even if different UUID (e.g. importing from UAT to PROD: UUIDs are different but titles define
 * a kind of unicity), or merge only if same UUID (e.g. importing back an export after applying regex to the MDX)
 * 
 * @author Benoit Lacelle
 *
 */
public interface IContentMerger {

	boolean sameNode(IContent rootContent, AContentDTO rootDTO);

}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.live.server.export;

import java.io.OutputStream;
import java.util.Collection;

import com.quartetfs.pivot.live.content.IContentManager;
import com.quartetfs.pivot.live.server.IDiscoveryService;
import com.quartetfs.pivot.live.server.export.impl.MdxXlsExporter;
import com.quartetfs.pivot.live.shared.contextvalues.IFlatContextValue;
import com.quartetfs.pivot.live.shared.mdx.IMdxModel;

import blasd.apex.core.io.GZipStringBuilder;

/**
 * Softer transient memory usage by using {@link GZipStringBuilder}
 * 
 * @author Benoit Lacelle
 * 
 */
public class ApexMdxXlsExporter extends MdxXlsExporter {
	public ApexMdxXlsExporter(final IDiscoveryService discoveryService, final IContentManager contentManager) {
		super(discoveryService, contentManager);
	}

	/**
	 * It appears the logic in MdxXlsExporter is strictly the same than in MdxCsvExporter
	 */
	@Override
	protected void doExportImpl(final OutputStream out,
			final IMdxModel mdxModel,
			final Collection<IFlatContextValue> ctxValues) {
		Collection<IFlatContextValue> actualCtxValues;
		if (addCtxValue) {
			actualCtxValues = ctxValues;
		} else {
			actualCtxValues = null;
		}

		ApexMdxHtmlExporter.doExportImpl(out,
				mdxModel,
				actualCtxValues,
				contentCellRenderer,
				gridConstructor,
				filterConstructor,
				this);
	}
}

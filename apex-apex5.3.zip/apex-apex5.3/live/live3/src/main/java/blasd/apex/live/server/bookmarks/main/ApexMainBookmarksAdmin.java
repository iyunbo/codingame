/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.live.server.bookmarks.main;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.xml.bind.JAXBException;

import org.apache.jackrabbit.core.TransientRepository;
import org.apache.jackrabbit.core.config.ConfigurationException;
import org.apache.jackrabbit.core.config.RepositoryConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.jmx.export.annotation.AnnotationMBeanExporter;

import com.quartetfs.fwk.Registry;
import com.quartetfs.fwk.contributions.impl.AnnotationContributionProvider;
import com.quartetfs.pivot.live.content.auth.IGroupService;
import com.quartetfs.pivot.live.content.auth.impl.StaticGroupService;
import com.quartetfs.pivot.live.content.jcr.impl.GroupFolderFactory;
import com.quartetfs.pivot.live.content.jcr.impl.UserFolderFactory;
import com.quartetfs.pivot.live.core.server.security.IUserService;
import com.quartetfs.pivot.live.core.server.security.impl.UserService;
import com.quartetfs.pivot.live.server.content.jcr.impl.DashboardBookmarkFactory;
import com.quartetfs.pivot.live.server.content.jcr.impl.DrillthroughBookmarkFactory;
import com.quartetfs.pivot.live.server.content.jcr.impl.FolderBookmarkFactory;
import com.quartetfs.pivot.live.server.content.jcr.impl.GenericBookmarkFactory;
import com.quartetfs.pivot.live.server.content.jcr.impl.MDXBookmarkFactory;
import com.quartetfs.pivot.live.server.content.jcr.impl.MDXSegmentBookmarkFactory;
import com.quartetfs.pivot.live.server.content.jcr.impl.SettingContentFactory;
import com.quartetfs.pivot.live.server.setting.impl.DockPanelPropertySettingSerializer;
import com.quartetfs.pivot.live.server.setting.impl.PopupPropertySettingSerializer;

import blasd.apex.core.spring.LoggingMethodCallAnnotationMBeanExporter;
import blasd.apex.live.server.bookmarks.ApexBookmarkExporter;
import blasd.apex.live.server.bookmarks.ApexContentManager;
import blasd.apex.live.server.bookmarks.IApexBookmarkExporter;
import blasd.apex.live.server.bookmarks.IApexContentManager;
import blasd.apex.live.server.bookmarks.content.ApplicationContentFactory;
import blasd.apex.live.server.bookmarks.content.GroupsCategoryContentFactory;
import blasd.apex.live.server.bookmarks.content.UsersCategoryContentFactory;

/**
 * Wraps together the bean for JCR import/export
 * 
 * @author Benoit Lacelle
 *
 */
@Configuration
@PropertySource(value = "classpath:activepivotlive.content.properties", ignoreResourceNotFound = true)
public class ApexMainBookmarksAdmin {

	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexMainBookmarksAdmin.class);

	public static final String KEY_JCR_PATH = "jcr.repository.path";

	public static final Resource DEFAULT_JCR_CONFIG = new ClassPathResource("jackrabbit-repository.xml");

	public static final boolean WAIT_BEFORE_CLOSING = true;
	public static final int MINUTES_TO_WAIT = 3600;

	@Bean
	public IGroupService groupService() {
		return new StaticGroupService();
	}

	@Bean
	public IUserService userService() {
		return new UserService();
	}

	public static String getRepositoryFolder(Environment environment) {
		return environment.getProperty(KEY_JCR_PATH, "${java.io.tmpdir}/dev/jcrrepo-3.3.0");
	}

	@Bean
	public RepositoryConfig repositoryConfig(Environment environment) throws ConfigurationException, IOException {
		String repositoryPath = getRepositoryFolder(environment);

		if (repositoryPath == null) {
			throw new RuntimeException("We are missing the property " + KEY_JCR_PATH);
		} else {
			// Path is resolved by
			// RepositoryConfigurationParser.parseRepositoryConfig(InputSource)
			LOGGER.info("Loading JCR from {}", new File(repositoryPath).getAbsolutePath());
		}

		return RepositoryConfig.create(DEFAULT_JCR_CONFIG.getInputStream(), new File(repositoryPath).getAbsolutePath());
	}

	/**
	 * Add a Bean which will register beans to the JConsole
	 */
	@Bean
	public AnnotationMBeanExporter annotationMBeanExporter() {
		return new LoggingMethodCallAnnotationMBeanExporter();
	}

	@Bean
	public IApexBookmarkExporter apexBookmarkExporter() {
		return new ApexBookmarkExporter();
	}

	@Bean
	public IApexContentManager contentManager(IGroupService groupService,
			IUserService userService,
			RepositoryConfig repositoryConfig,
			IApexBookmarkExporter apexBookmarkExporter,
			Environment env) {
		ApexContentManager contentManager = new ApexContentManager(apexBookmarkExporter, false);

		// AJCRContentManager defin PivotLive as default application name
		contentManager.setApplicationName(env.getProperty("activepivotlive.applicationname", "PivotLive"));

		contentManager.setGroupService(groupService);
		contentManager.setUserService(userService);
		contentManager.setNodeDefinitions(new Resource[] { new ClassPathResource("QFSJCRDefinitions.cnd"),
				new ClassPathResource("APLJCRDefinitions.cnd") });

		contentManager.setRepository(new TransientRepository(repositoryConfig));

		return contentManager;
	}

	public static void initRegistryForLive() {
		List<Class<?>> classForQFSRegistry = new ArrayList<>();

		classForQFSRegistry.add(ApplicationContentFactory.class);
		classForQFSRegistry.add(UsersCategoryContentFactory.class);
		classForQFSRegistry.add(GroupsCategoryContentFactory.class);
		classForQFSRegistry.add(DrillthroughBookmarkFactory.class);
		classForQFSRegistry.add(MDXBookmarkFactory.class);
		classForQFSRegistry.add(DashboardBookmarkFactory.class);
		classForQFSRegistry.add(FolderBookmarkFactory.class);
		classForQFSRegistry.add(GenericBookmarkFactory.class);
		classForQFSRegistry.add(GroupFolderFactory.class);
		classForQFSRegistry.add(UserFolderFactory.class);
		classForQFSRegistry.add(MDXSegmentBookmarkFactory.class);
		classForQFSRegistry.add(SettingContentFactory.class);

		// Enable reading from JCR
		classForQFSRegistry.add(PopupPropertySettingSerializer.class);
		classForQFSRegistry.add(DockPanelPropertySettingSerializer.class);

		Registry.setContributionProvider(
				new AnnotationContributionProvider(classForQFSRegistry.toArray(new Class<?>[0])));
	}

	public static void main(String[] args) throws IOException, JAXBException, InterruptedException {
		// TODO: Load some custom logback

		initRegistryForLive();

		try (ConfigurableApplicationContext context =
				new AnnotationConfigApplicationContext(ApexMainBookmarksAdmin.class)) {
			IApexContentManager apexContentManager = context.getBean(IApexContentManager.class);

			String applicationUUID = apexContentManager.getApplicationUUID();

			String applicationExport = apexContentManager.exportBookmarks(applicationUUID);

			System.out.println(applicationExport);

			if (WAIT_BEFORE_CLOSING) {
				// Wait, to enable connecting through MBean for instance
				Thread.sleep(TimeUnit.MILLISECONDS.convert(MINUTES_TO_WAIT, TimeUnit.MINUTES));
			}
		}
	}
}

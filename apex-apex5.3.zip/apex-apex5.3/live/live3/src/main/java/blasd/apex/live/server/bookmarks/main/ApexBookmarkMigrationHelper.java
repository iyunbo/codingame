/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.live.server.bookmarks.main;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.google.common.base.Function;
import com.google.common.base.Joiner;
import com.google.common.collect.Iterables;
import com.quartetfs.pivot.live.core.server.setting.impl.StringMapSettingSerializer;

import blasd.apex.live.server.bookmark.dto.AContentDTO;
import blasd.apex.live.server.bookmark.dto.ContentCommonDTO;
import blasd.apex.live.server.bookmark.dto.MdxSegmentQueryDTO;
import blasd.apex.live.server.bookmark.dto.SettingContentDTO;

/**
 * Helps converting an APLive 3.X JCR repository
 * 
 * @author Benoit Lacelle
 *
 */
public class ApexBookmarkMigrationHelper {
	protected ApexBookmarkMigrationHelper() {
		// hidden
	}

	public static List<? extends MdxSegmentQueryDTO> convertToMdxSegment(String valueAsString) {
		List<MdxSegmentQueryDTO> segments = new ArrayList<>();

		Map<String, String> asMap = new StringMapSettingSerializer().deserializeValue(valueAsString);

		for (Entry<String, String> entry : asMap.entrySet()) {
			String[] details = entry.getValue().split("#");
			String title = details[0];
			String cubeName = details[1];
			String[] columns = details[2].split(",");

			// System.lineSeparator would be encoded
			String columnsAsMdx = Joiner.on(","
			// + System.lineSeparator()
			).join(Iterables.transform(Arrays.asList(columns), new Function<String, String>() {

				@Override
				public String apply(String input) {
					return "[" + input + "]";
				}
			}));
			segments.add(new MdxSegmentQueryDTO(new ContentCommonDTO(null, null, title, title, null),
					columnsAsMdx,
					cubeName,
					"DRILLTHROUGH_COLUMN_SET"));
		}

		return segments;
	}

	public static List<? extends MdxSegmentQueryDTO> convertDTMaskSettingToContent(SettingContentDTO setting,
			String userUUID) {
		// <title>Setting-drillthrough.masks</title>
		// <key>drillthrough.masks</key>
		// <value>{test demo 21=test demo 21#Basyliq
		// Metrics#AdditionalDwgCollatAmount,BalanceCode,ContractId, mask extract=mask extract#Liquidity
		// Aggregates#AggregateAmount,AggregateAmountCurrency,AggregateId,CashflowAmount,IndAssetLiability,SourceType}</value>

		// <value>{Rejected Aggregates=#Rejected
		// Aggregates#AffectedColumn,AggregateId,IdfTrtSit,InventoryDate,Motif,MotifRejectFilename,RejectABLFilename,SourceType,
		// Queries=#Queries#CellsNumber,Client,Cube,ExecutionDuration(ms),ExecutionMonth,ExecutionTime,FilterRefresh,Finished,Request,Type,UserName,
		// Liquidity Aggregates=#Liquidity Aggregates#AggregateId,TradeId}</value>

		if ("drillthrough.masks".equals(setting.getKey())) {
			List<? extends MdxSegmentQueryDTO> migrated =
					ApexBookmarkMigrationHelper.convertToMdxSegment(setting.getValue());

			// The setting is a child of parentOfAllSettings
			// The migrated content as MdxSegmentDTO: we move them under the userNode
			for (AContentDTO segment : migrated) {
				segment.contentCommon.parentUUID = userUUID;
			}

			return migrated;
		} else {
			return Collections.emptyList();
		}
	}
}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.live.server.bookmark.dto;

import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.JAXBException;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Enable marshalling of JCR elements
 * 
 * @author Benoit Lacelle
 *
 */
@XmlRootElement(name = "mdx")
public class MdxQueryDTO extends AContentDTO {

	@XmlElement
	protected String mdxQuery;

	@XmlElement
	protected String displayType;

	@XmlElement
	protected Map<String, String> contextValues;

	protected MdxQueryDTO() {
		// Serialization
	}

	public MdxQueryDTO(ContentCommonDTO common,
			String mdxQuery,
			String displayType,
			Map<String, String> contextValues) {
		super(common);
		this.mdxQuery = mdxQuery;
		this.displayType = displayType;
		this.contextValues = contextValues;
	}

	public String getMdxQuery() {
		return this.mdxQuery;
	}

	public String getDisplayType() {
		return this.displayType;
	}

	public Map<String, String> getContextValues() {
		return contextValues;
	}

	@Override
	public String toString() {
		return "MdxQueryDTO [mdxQuery=" + mdxQuery
				+ ", displayType="
				+ displayType
				+ ", contextValues="
				+ contextValues
				+ "]";
	}

	public static void main(String[] args) throws JAXBException {
		Map<String, String> contextValues = new HashMap<>();
		MdxQueryDTO mdx = new MdxQueryDTO(new ContentCommonDTO("parentUUID", "uuid", "title", "description", null),
				"mdxQuery",
				"displayType",
				contextValues);

		AContentDTOHelper.doTestMarshall(mdx, System.out);
	}

}

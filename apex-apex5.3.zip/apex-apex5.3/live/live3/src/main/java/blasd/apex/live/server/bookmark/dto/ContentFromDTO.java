/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.live.server.bookmark.dto;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Optional;
import com.google.common.collect.ClassToInstanceMap;
import com.google.common.collect.MutableClassToInstanceMap;
import com.quartetfs.fwk.Registry;
import com.quartetfs.pivot.live.content.shared.IContent;
import com.quartetfs.pivot.live.content.shared.IMutableContent;
import com.quartetfs.pivot.live.content.shared.impl.AContent;
import com.quartetfs.pivot.live.core.server.setting.ISettingSerializer;
import com.quartetfs.pivot.live.core.shared.setting.ISetting;
import com.quartetfs.pivot.live.core.shared.setting.impl.BooleanSetting;
import com.quartetfs.pivot.live.core.shared.setting.impl.StringSetting;
import com.quartetfs.pivot.live.shared.content.impl.DashboardBookmark;
import com.quartetfs.pivot.live.shared.content.impl.FolderBookmark;
import com.quartetfs.pivot.live.shared.content.impl.GenericBookmark;
import com.quartetfs.pivot.live.shared.content.impl.MDXBookmark;
import com.quartetfs.pivot.live.shared.content.impl.MDXSegmentBookmark;
import com.quartetfs.pivot.live.shared.content.impl.MDXSegmentBookmark.SegmentType;
import com.quartetfs.pivot.live.shared.content.impl.SettingContent;
import com.quartetfs.pivot.live.shared.contextvalues.IFlatContextValue;
import com.quartetfs.pivot.live.shared.contextvalues.impl.FlatContextValue;

import blasd.apex.live.server.bookmarks.content.ApplicationContent;
import blasd.apex.live.server.bookmarks.content.GroupsContent;
import blasd.apex.live.server.bookmarks.content.TechnicalFolderDTO;
import blasd.apex.live.server.bookmarks.content.UsersContent;

/**
 * Enable marshalling of JCR elements
 * 
 * @author Benoit Lacelle
 *
 */
public final class ContentFromDTO {
	protected static final Logger LOGGER = LoggerFactory.getLogger(ContentFromDTO.class);

	protected ContentFromDTO() {
		// hidden
	}

	public static IMutableContent convertFromDTO(AContentDTO content) {
		return convertFromDTO(content, Optional.<String>absent());
	}

	/**
	 * Convert an exported AContentDTO back to a JCR IMutableContent
	 * 
	 * @param dto
	 *            the AContentDTO to convert to a JCR IMutableContent
	 * @param forcedParentUUID
	 *            if provided, the parentUUID to set, expected to match a node existing in the JCR repository
	 * @return
	 */
	public static IMutableContent convertFromDTO(AContentDTO dto, Optional<? extends String> forcedParentUUID) {
		ClassToInstanceMap<? extends AContentDTO> dtoClassToLogic = MutableClassToInstanceMap.create();

		if (dtoClassToLogic == null) {
			dtoClassToLogic = null;
		}

		String parentUuid;
		if (forcedParentUUID.isPresent()) {
			parentUuid = forcedParentUUID.get();
		} else {
			parentUuid = dto.contentCommon.parentUUID;
		}

		final AContent aacontent;

		// TODO : Ugly, use a map, ...
		if (dto instanceof ApplicationDTO) {
			aacontent = new ApplicationContent();
		} else if (dto instanceof UsersDTO) {
			aacontent = new UsersContent();
		} else if (dto instanceof GroupsDTO) {
			aacontent = new GroupsContent();
		} else if (dto instanceof TechnicalFolderDTO) {
			aacontent = new FolderBookmark();
		} else if (dto instanceof FolderDTO) {
			aacontent = new FolderBookmark();
		} else if (dto instanceof GenericBookmarkDTO) {
			GenericBookmark bkm = new GenericBookmark();
			bkm.setKey(((GenericBookmarkDTO) dto).getKey());
			bkm.setContent(((GenericBookmarkDTO) dto).getContent());

			aacontent = bkm;
		} else if (dto instanceof MdxQueryDTO) {
			MdxQueryDTO mdxQueryDTO = (MdxQueryDTO) dto;

			MDXBookmark mdxQuery = new MDXBookmark();

			mdxQuery.setMdxQuery(mdxQueryDTO.getMdxQuery());
			mdxQuery.setDisplayType(mdxQueryDTO.getDisplayType());
			Collection<IFlatContextValue> contextValues = new ArrayList<>();

			if (mdxQueryDTO.getContextValues() != null) {
				for (Map.Entry<String, String> entry : mdxQueryDTO.getContextValues().entrySet()) {
					contextValues.add(new FlatContextValue(entry.getKey(), entry.getValue()));
				}
			}
			mdxQuery.setContextValues(contextValues);

			aacontent = mdxQuery;
		} else if (dto instanceof MdxSegmentQueryDTO) {
			MdxSegmentQueryDTO mdxSegmentQueryDTO = (MdxSegmentQueryDTO) dto;

			MDXSegmentBookmark mdxSegmentBookmark = new MDXSegmentBookmark();

			mdxSegmentBookmark.setMdx(mdxSegmentQueryDTO.mdxSegmentQuery);
			mdxSegmentBookmark.setSegmentType(SegmentType.valueOf(mdxSegmentQueryDTO.segmentType));
			mdxSegmentBookmark.setCube(mdxSegmentQueryDTO.cube);

			aacontent = mdxSegmentBookmark;
		} else if (dto instanceof DashboardDTO) {
			DashboardBookmark dashboard = new DashboardBookmark();

			dashboard.setKey(((DashboardDTO) dto).getKey());
			dashboard.setParameters(((DashboardDTO) dto).getParameters());
			dashboard.setSize(Integer.parseInt(((DashboardDTO) dto).getSize()));
			List<String> list = ((DashboardDTO) dto).getWidgetParams();
			dashboard.setWidgetParamsFromSerialization(list.toArray(new String[list.size()]));

			aacontent = dashboard;
		} else if (dto instanceof SettingContentDTO) {
			// TODO we skip that type of setting
			SettingContentDTO settingDTO = (SettingContentDTO) dto;

			String settingType = settingDTO.getType();
			ISettingSerializer<?> serializer = Registry.getPlugin(ISettingSerializer.class).valueOf(settingType);

			if (serializer == null) {
				LOGGER.warn("There is no {} for {}", ISettingSerializer.class, settingType);
				return null;
			}

			Object value = serializer.deserializeValue(settingDTO.value);

			ISetting<?> setting;
			if (StringSetting.TYPE.getKey().equals(settingType)) {
				setting = new StringSetting(settingDTO.getKey(), (String) value);
			} else if (BooleanSetting.TYPE.getKey().equals(settingType)) {
				setting = new BooleanSetting(settingDTO.getKey(), (Boolean) value);
			} else {
				LOGGER.warn("We do not handle {}", settingType);
				return null;
			}
			SettingContent settingContent = new SettingContent(setting);
			aacontent = settingContent;
		} else {
			throw new IllegalArgumentException("Unkown object" + dto);
		}

		aacontent.setParentUUID(parentUuid);
		aacontent.setTitle(dto.contentCommon.title);
		aacontent.setDescription(dto.contentCommon.description);

		// Ensure the UUID is set, as we might not set it as it is
		// forbidden to create a node with a specified UUID
		// dtoInRepository.setUUID(equivalentChildren.get(0).getUUID());
		aacontent.setUUID(dto.contentCommon.uuid);

		return aacontent;
	}

	/**
	 * Some IContent needs to be updated given their imported children
	 * 
	 * @param content
	 * @param childrenIIds
	 */
	public static void onChildren(IContent content, List<String> childrenIIds) {
		if (content instanceof DashboardBookmark) {
			String[] params = new String[childrenIIds.size()];
			for (int i = 0; i < params.length; i++) {
				params[i] = DashboardBookmark.ID + "=" + childrenIIds.get(i);
			}
			((DashboardBookmark) content).setWidgetParamsFromSerialization(params);
		}
	}
}

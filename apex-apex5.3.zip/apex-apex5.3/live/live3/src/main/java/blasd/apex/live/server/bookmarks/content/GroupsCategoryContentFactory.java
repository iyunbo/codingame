/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.live.server.bookmarks.content;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;

import com.quartetfs.fwk.QuartetPluginValue;
import com.quartetfs.pivot.live.content.impl.ContentException;
import com.quartetfs.pivot.live.content.jcr.IJCRContentFactory;
import com.quartetfs.pivot.live.content.jcr.impl.AJCRContentFactory;

/**
 * Enable creating GroupsNode
 * 
 * @author Benoit Lacelle
 *
 */
@QuartetPluginValue(intf = IJCRContentFactory.class)
public class GroupsCategoryContentFactory extends AJCRContentFactory<GroupsContent> {
	private static final long serialVersionUID = -545131728916959492L;

	@Override
	public String getNodePrimaryType() {
		return "qfs:GroupsCategory";
	}

	public GroupsCategoryContentFactory() {
		super(GroupsContent.class);
	}

	@Override
	protected void updateNodeFromType(Session session, GroupsContent content, Node targetNode)
			throws ContentException, RepositoryException {
		throw new ContentException("GroupsContent should not be created");
	}

	@Override
	protected GroupsContent createTypeFromNode(Session session, Node node)
			throws ContentException, RepositoryException {
		GroupsContent applicationContent = new GroupsContent();
		return applicationContent;
	}

}

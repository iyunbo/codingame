/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.live.server.bookmarks.content;

import com.quartetfs.pivot.live.content.shared.IContent;

import blasd.apex.live.server.bookmark.dto.AContentDTO;

/**
 * This merger enables importing content without any merge or rejection
 * 
 * @author Benoit Lacelle
 *
 */
public class ApexContentMergerOnUUID extends AApexContentMerger {

	@Override
	public boolean sameNode(IContent rootContent, AContentDTO rootToImport) {
		boolean superSameNode = super.sameNode(rootContent, rootToImport);

		if (superSameNode) {
			// e.g. application node may have different UUID and different title for various AP versions
			return true;
		}

		// jcr.content.duplicate.allow=false
		return rootContent.getUUID().equals(rootToImport.contentCommon.uuid);
	}
}

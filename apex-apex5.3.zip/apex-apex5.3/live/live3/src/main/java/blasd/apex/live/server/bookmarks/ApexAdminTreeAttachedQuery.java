/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.live.server.bookmarks;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.quartetfs.fwk.QuartetExtendedPluginValue;
import com.quartetfs.fwk.query.IAttachedQuery;
import com.quartetfs.fwk.query.IQuery;
import com.quartetfs.fwk.query.QueryException;
import com.quartetfs.pivot.live.content.IContentManager;
import com.quartetfs.pivot.live.content.IContentManagerSession;
import com.quartetfs.pivot.live.content.impl.ContentException;
import com.quartetfs.pivot.live.content.query.impl.UUIDTreeAttachedQuery;
import com.quartetfs.pivot.live.content.shared.IContent;
import com.quartetfs.pivot.live.content.shared.IMutableContent;
import com.quartetfs.pivot.live.content.shared.impl.GroupFolder;
import com.quartetfs.pivot.live.content.shared.impl.UserFolder;

/**
 * To use this component, Add the package <value>blasd.apex.live</value> as FIRST entry in RegistryInitializer.xml
 * 
 * It enables the use of {@link ApexContentManager}
 * 
 * @author Benoit Lacelle
 * 
 */
@QuartetExtendedPluginValue(intf = IAttachedQuery.class, key = "UUID_TREE")
public class ApexAdminTreeAttachedQuery extends UUIDTreeAttachedQuery {
	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexAdminTreeAttachedQuery.class);

	private static final long serialVersionUID = 1L;

	public ApexAdminTreeAttachedQuery(IQuery<List<IContent>> originatingQuery, IContentManagerSession session) {
		super(originatingQuery, session);
	}

	@Override
	public List<IContent> execute() throws QueryException {
		IContentManager manager = this.session.getContentManager();

		List<IContent> result = new ArrayList<>();
		try {
			Set<Class<? extends IContent>> contentTypeFilters = this.UUIDTreeQuery.getContentTypeFilters();

			if (null != this.UUIDTreeQuery.getRootUUID()) {
				result.addAll(manager.getTree(this.UUIDTreeQuery.getRootUUID(), contentTypeFilters));
			} else {
				if (manager instanceof IApexContentManager) {
					IApexContentManager apexManager = (IApexContentManager) manager;

					Set<? extends Class<? extends IMutableContent>> mutableFilters =
							contentTypeFilters.stream().map(input -> {
								if (IMutableContent.class.isAssignableFrom(input)) {
									return (Class<? extends IMutableContent>) input;
								} else {
									LOGGER.warn("{} does not extends IMutableContent", input);
									return null;
								}
							}).distinct().filter(Objects::nonNull).collect(Collectors.toSet());

					// Add each UserFolder as current user could be an admin
					for (UserFolder userFolder : apexManager.getUserFolders()) {
						result.addAll(apexManager.getTreeAsUser(userFolder.getUUID(),
								apexManager.getSystemUser(),
								mutableFilters));
					}
				} else {
					// Add only current User userFolder
					result.addAll(manager.getTree(manager.getUserFolder().getUUID(), contentTypeFilters));
				}

				// Add Each GroupFolder
				for (GroupFolder g : manager.getGroupFolders()) {
					result.addAll(manager.getTree(g.getUUID(), contentTypeFilters));
				}
			}
		} catch (

		ContentException e) {
			LOGGER.warn("Failed to exexute query type " + this.UUIDTreeQuery.getType(), e);
			throw new QueryException(this.UUIDTreeQuery, e.getMessage(), e.getCause());
		}
		return result;
	}
}

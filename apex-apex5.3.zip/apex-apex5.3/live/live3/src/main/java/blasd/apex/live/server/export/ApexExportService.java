/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.live.server.export;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.web.HttpRequestHandler;

import com.google.common.base.Charsets;
import com.google.common.net.HttpHeaders;
import com.google.gwt.regexp.shared.RegExp;
import com.quartetfs.fwk.AgentException;
import com.quartetfs.fwk.QuartetException;
import com.quartetfs.pivot.live.content.IContentManager;
import com.quartetfs.pivot.live.content.impl.ContentException;
import com.quartetfs.pivot.live.core.server.event.IFeed;
import com.quartetfs.pivot.live.core.server.security.IUser;
import com.quartetfs.pivot.live.core.server.security.IUserService;
import com.quartetfs.pivot.live.core.server.service.IServiceRegistry;
import com.quartetfs.pivot.live.core.server.session.IInstanceSession;
import com.quartetfs.pivot.live.core.server.session.ISessionManager;
import com.quartetfs.pivot.live.core.server.setting.ISettingService;
import com.quartetfs.pivot.live.core.shared.SessionId;
import com.quartetfs.pivot.live.core.shared.event.IRemoteEvent;
import com.quartetfs.pivot.live.core.shared.event.IRemoteEventListener;
import com.quartetfs.pivot.live.core.shared.event.impl.ConditionRemoteEventListener;
import com.quartetfs.pivot.live.server.IDiscoveryService;
import com.quartetfs.pivot.live.server.contextvalues.IContextValueService;
import com.quartetfs.pivot.live.server.drillthrough.IDrillthroughFeed;
import com.quartetfs.pivot.live.server.drillthrough.impl.DTBookmarkFeedDecorator;
import com.quartetfs.pivot.live.server.drillthrough.impl.DrillthroughFeed;
import com.quartetfs.pivot.live.server.export.IFeedExporter;
import com.quartetfs.pivot.live.server.export.impl.DrillthroughCsvExporter;
import com.quartetfs.pivot.live.server.export.impl.DrillthroughHtmlExporter;
import com.quartetfs.pivot.live.server.export.impl.DrillthroughXlsExporter;
import com.quartetfs.pivot.live.server.export.impl.ExportService;
import com.quartetfs.pivot.live.server.export.impl.FeedRemoteEventTriggerListener;
import com.quartetfs.pivot.live.server.export.impl.MdxCsvExporter;
import com.quartetfs.pivot.live.server.export.impl.MdxHtmlExporter;
import com.quartetfs.pivot.live.server.export.impl.MdxPdfExporter;
import com.quartetfs.pivot.live.server.export.impl.MdxXlsExporter;
import com.quartetfs.pivot.live.server.export.repository.impl.ExportFileInfo;
import com.quartetfs.pivot.live.server.export.repository.impl.ExportRepository;
import com.quartetfs.pivot.live.server.mdx.IMdxBookmarkFeed;
import com.quartetfs.pivot.live.server.mdx.IMdxFeed;
import com.quartetfs.pivot.live.server.mdx.impl.AMdxFeed;
import com.quartetfs.pivot.live.server.mdx.impl.MdxBookmarkFeedDecorator;
import com.quartetfs.pivot.live.server.mdx.impl.MdxFeed;
import com.quartetfs.pivot.live.server.parsing.IMdxParserService;
import com.quartetfs.pivot.live.shared.content.impl.DrillthroughBookmark;
import com.quartetfs.pivot.live.shared.content.impl.MDXBookmark;
import com.quartetfs.pivot.live.shared.drillthrough.impl.DrillthroughRemoteEvent;
import com.quartetfs.pivot.live.shared.export.ExportConstants;
import com.quartetfs.pivot.live.shared.export.ExportConstants.ExportType;
import com.quartetfs.pivot.live.shared.export.ExportConstants.FeedType;
import com.quartetfs.pivot.live.shared.mdx.CellSetRemoteEvent;
import com.quartetfs.tech.streaming.IIdGenerator;
import com.quartetfs.tech.streaming.IRegistrationService;
import com.quartetfs.tech.streaming.IStreamingService;

import blasd.apex.core.logging.PepperLogHelper;

/**
 * This alternative to {@link ExportService} will consume much less transient memory
 * 
 * @author Benoit Lacelle
 * 
 */
// <servlet>
// <servlet-name>ExportService</servlet-name>
// <servlet-class>org.springframework.web.context.support.HttpRequestHandlerServlet</servlet-class>
// </servlet>
// <bean id="ExportService"
// class="blasd.apex.live.server.export.ApexExportService">
// <property name="sessionManager" ref="SessionManager" />
// <property name="userService" ref="UserService" />
// <property name="serviceRegistry" ref="ServiceRegistry" />
// <property name="pivotIdGenerator" ref="IdGenerator" />
// <property name="pivotRegistrationService" ref="PivotRegistrationService" />
// <property name="contentManager" ref="ContentManager" />
// <property name="exportRepository" ref="ExportRepository" />
// </bean>
@ManagedResource
public class ApexExportService extends HttpServlet implements HttpRequestHandler {
	private static final long serialVersionUID = 5365958696588245377L;

	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexExportService.class);

	protected static final RegExp REGEXP_IE8 = RegExp.compile("msie 8.0", "i");
	protected static final String ATTACHMENT = "attachment";
	protected static final String CONTENT_DISPOSITION = HttpHeaders.CONTENT_DISPOSITION;
	public static final int EXPORT_TIMEOUT = 5;

	protected final ISessionManager sessionManager;
	protected final IUserService userService;
	protected final IServiceRegistry serviceRegistry;
	protected final IIdGenerator pivotIdGenerator;
	protected final IRegistrationService pivotRegistrationService;
	protected final IContentManager contentManager;
	protected final ExportRepository exportRepository;

	protected final AtomicInteger id;

	public static final int DEFAULT_EXPORT_TIMEOUT_MINUTES = 5;
	protected final AtomicInteger exportTimeOutInMInutes = new AtomicInteger(DEFAULT_EXPORT_TIMEOUT_MINUTES);

	protected abstract static class AsyncRemoteEventListener implements IRemoteEventListener {
		protected RuntimeException storedException;

		protected AsyncRemoteEventListener() {
			this.storedException = null;
		}

		public RuntimeException getStoredException() {
			return this.storedException;
		}
	}

	public ApexExportService(ISessionManager sessionManager,
			IUserService userService,
			IServiceRegistry serviceRegistry,
			IIdGenerator pivotIdGenerator,
			IRegistrationService pivotRegistrationService,
			IContentManager contentManager,
			ExportRepository exportRepository) {
		this.sessionManager = sessionManager;
		this.userService = userService;
		this.serviceRegistry = serviceRegistry;
		this.pivotIdGenerator = pivotIdGenerator;
		this.pivotRegistrationService = pivotRegistrationService;
		this.contentManager = contentManager;
		this.exportRepository = exportRepository;

		this.id = new AtomicInteger(0);
	}

	@ManagedAttribute
	public int getExportTimeOutInMInutes() {
		return exportTimeOutInMInutes.get();
	}

	@ManagedAttribute
	public void setExportTimeOutInMInutes(int exportTimeOutInMInutes) {
		this.exportTimeOutInMInutes.set(exportTimeOutInMInutes);
	}

	@Override
	public final void doPost(final HttpServletRequest request, final HttpServletResponse response) {
		try {
			this.handleGetOrPost(request, response);
		} catch (Exception e) {
			fail(response, e);
		}
	}

	@Override
	public final void doGet(final HttpServletRequest request, final HttpServletResponse response) {
		try {
			this.handleGetOrPost(request, response);
		} catch (Exception e) {
			fail(response, e);
		}
	}

	protected IInstanceSession getSessionId(final HttpServletRequest request, final HttpServletResponse response)
			throws Exception {
		final IUser user = this.userService.getCurrentUser();
		if (user == null) {
			throw new Exception("Could not authenticate user with Security Context");
		}
		final String userId = user.getUserName();
		final String pageSessionIdAsString = request.getParameter("pageSessionId");
		if (pageSessionIdAsString == null) {
			throw new Exception("Missing parameter 'pageSessionId'");
		}
		final long pageSessionId = Long.parseLong(pageSessionIdAsString);
		final SessionId session = new SessionId(userId, request.getSession().getId(), pageSessionId);
		final IInstanceSession instanceSession = this.sessionManager.getSession(session);
		return instanceSession;
	}

	public <T> T getSessionService(final IInstanceSession instanceSession, final Class<T> service)
			throws QuartetException {
		return (T) instanceSession.getSessionService(service, this.serviceRegistry.getFactory(service));
	}

	@Override
	public void handleRequest(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		handleGetOrPost(request, response);
	}

	/**
	 * Not named 'do*' to prevent sonar to cry because throwing exceptiond in a 'do*' method in a servlet
	 */
	protected void handleGetOrPost(final HttpServletRequest request, final HttpServletResponse response)
			throws ServletException, IOException {
		final IInstanceSession instanceSession;
		try {
			instanceSession = this.getSessionId(request, response);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		if (instanceSession == null) {
			throw new RuntimeException("Fail to retrieve session");
		}

		final String exportUniqueId = request.getParameter("uid");
		if (exportUniqueId != null) {
			returnPreparedExport(request, response, instanceSession, exportUniqueId);
		} else {
			final String strExportType = request.getParameter("type");
			if (strExportType == null) {
				throw new RuntimeException("Missing parameter 'type'");
			}
			final ExportConstants.ExportType exportType;
			try {
				exportType = ExportConstants.ExportType.valueOf(strExportType);
			} catch (Exception e) {
				throw new RuntimeException("Unsupported export type: " + strExportType, e);
			}
			LOGGER.info("Received request for {} exportType: {}", instanceSession.getId().getUserId(), exportType);
			final String feedId = request.getParameter("feedId");
			final ExportConstants.FeedType feedType;
			IFeed feed = null;
			if (feedId != null) {
				feed = instanceSession.getFeed(feedId);
				if (feed instanceof IMdxFeed) {
					feedType = ExportConstants.FeedType.MDX;
				} else if (feed instanceof IDrillthroughFeed) {
					feedType = ExportConstants.FeedType.DT;
				} else {
					if (feed == null) {
						throw new RuntimeException("Can't determine feed type: feed is null");
					} else {
						throw new RuntimeException("Can't determine feed type " + feed.getClass());
					}
				}
			} else {
				final String strFeedType = request.getParameter("feedType");
				if (strFeedType == null) {
					throw new RuntimeException("Can't determine feed type");
				}
				try {
					feedType = ExportConstants.FeedType.valueOf(strFeedType);
				} catch (Exception e2) {
					throw new RuntimeException("Unsupported feed type: " + strFeedType, e2);
				}
			}
			final CountDownLatch exportFinished = new CountDownLatch(1);
			final AsyncRemoteEventListener onRemoteEventsReceived = new AsyncRemoteEventListener() {
				@Override
				public void onRemoteEvents(final List<IRemoteEvent> remoteEventsToExport) {
					try {
						exportRemoteEvents(request,
								response,
								instanceSession,
								feedType,
								exportType,
								remoteEventsToExport);
					} catch (RuntimeException e) {
						this.storedException = e;
					} catch (Exception e) {
						this.storedException = new RuntimeException(e);
					} catch (Throwable e) {
						// Log as this is very severe and we might have issues
						// logging later
						LOGGER.error("Error while exporting", e);
						this.storedException = new RuntimeException(e);
					} finally {
						exportFinished.countDown();
					}
				}
			};
			final String bkUuid = request.getParameter("uuid");

			Runnable cleanFeed;
			try {
				cleanFeed = startExportFeed(bkUuid, instanceSession, feedType, feed, onRemoteEventsReceived);
			} catch (QuartetException e) {
				throw new RuntimeException(e);
			}

			try {
				if (!exportFinished.await(exportTimeOutInMInutes.get(), TimeUnit.MINUTES)) {
					throw new RuntimeException("It took too long to run the export");
				}
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
				throw new RuntimeException(e);
			} finally {
				cleanFeed.run();
			}
		}
	}

	protected void returnPreparedExport(HttpServletRequest request,
			HttpServletResponse response,
			IInstanceSession instanceSession,
			String exportUniqueId) throws UnsupportedEncodingException {

		// Synchronized to ensure the export is put back in case of failure, without having a second thread/try arriving
		// in the meantime
		// Typically, in happened in Liqor/Firefox: we get 2 threads calling the export at the same time, while the
		// response outputstream for one of them is always broken
		synchronized (this) {
			final ExportFileInfo fileInfo = this.exportRepository.getExportInfo(exportUniqueId);
			if (fileInfo == null) {
				throw new RuntimeException("Unknown export ID " + exportUniqueId);
			}

			try {
				final ByteArrayOutputStream output = fileInfo.getStream();
				response.setContentLength(output.size());

				LOGGER.info("Exporting to stream for {} ExportID {} of size={}",
						instanceSession.getId().getUserId(),
						exportUniqueId,
						PepperLogHelper.getNiceMemory(output.size()));

				response.setContentType(fileInfo.getContentType());
				response.setStatus(HttpServletResponse.SC_OK);
				final String currentFileExtension = fileInfo.getFileExtension();
				String fileRootName = fileInfo.getFileName();
				fileRootName = URLEncoder.encode(fileRootName, Charsets.UTF_8.name());
				final String userAgent = request.getHeader(HttpHeaders.USER_AGENT);

				response.setHeader(CONTENT_DISPOSITION,
						computeContentDisposition(userAgent, fileRootName, currentFileExtension));
				response.setHeader(HttpHeaders.CACHE_CONTROL, "no-store");
				response.getOutputStream().write(output.toByteArray());
			} catch (IOException | RuntimeException e) {
				// Put back the export for a later try
				this.exportRepository.putExportInfo(exportUniqueId, fileInfo);

				throw new RuntimeException(e);
			}
		}
	}

	/**
	 * Export MDX or Drillthrough query result
	 */
	protected Runnable startExportFeed(String bkUuid,
			IInstanceSession instanceSession,
			FeedType feedType,
			IFeed feed,
			final AsyncRemoteEventListener onRemoteEventsReceived) throws QuartetException {
		final IContextValueService contextValueService =
				this.getSessionService(instanceSession, IContextValueService.class);
		final IMdxParserService mdxParserService = this.getSessionService(instanceSession, IMdxParserService.class);
		final IStreamingService streamingService = this.getSessionService(instanceSession, IStreamingService.class);
		final ISettingService settingService = this.getSessionService(instanceSession, ISettingService.class);
		final IDiscoveryService discoveryService = this.getSessionService(instanceSession, IDiscoveryService.class);

		final IFeed createdFeed;
		final IRemoteEventListener feedListener;
		switch (feedType) {
		case MDX: {
			final AMdxFeed rootFeed = new MdxFeed(streamingService,
					this.pivotRegistrationService,
					this.pivotIdGenerator,
					mdxParserService,
					settingService,
					contextValueService,
					discoveryService,
					UUID.randomUUID().toString());
			final IMdxBookmarkFeed mdxFeed = new MdxBookmarkFeedDecorator(this.contentManager, rootFeed);
			mdxFeed.setUseSizeLimit(false);
			mdxFeed.init(null);
			mdxFeed.startPaused();
			final ConditionRemoteEventListener mdxReStore = new FeedRemoteEventTriggerListener(
					Arrays.<Class<? extends IRemoteEvent>>asList(CellSetRemoteEvent.class));
			mdxFeed.addListener(mdxReStore, false);
			mdxReStore.addListener(onRemoteEventsReceived);
			if (bkUuid != null) {
				final MDXBookmark mdxbk = new MDXBookmark();
				mdxbk.setUUID(bkUuid);

				try {
					String mdx = contentManager.get(bkUuid).getTitle();
					LOGGER.info("Exporting for {} MDX={}", instanceSession.getId().getUserId(), mdx);
				} catch (ContentException e) {
					LOGGER.warn("Issue when trying to fetch the Content for UUID=" + bkUuid, e);
				}

				mdxFeed.updateBookmarkFeed(mdxbk, false);
			} else {
				if (feed == null || !(feed instanceof IMdxFeed)) {
					throw new RuntimeException("Missing required parameter 'feedId' or 'uuid'");
				}
				final IMdxFeed mdxF = (IMdxFeed) feed;
				String mdxQuery = mdxF.getRequestedMDXQuery();

				LOGGER.info("Exporting for {} MDX={}", instanceSession.getId().getUserId(), mdxQuery);

				mdxFeed.update(mdxQuery, mdxF.getFlatContextValues(), true);
			}
			createdFeed = mdxFeed;
			feedListener = mdxReStore;
			break;
		}
		case DT: {
			final DrillthroughFeed feedToDecorate = new DrillthroughFeed(streamingService,
					this.pivotRegistrationService,
					this.pivotIdGenerator,
					discoveryService,
					settingService,
					contextValueService,
					UUID.randomUUID().toString());
			final DTBookmarkFeedDecorator dtFeed = new DTBookmarkFeedDecorator(this.contentManager, feedToDecorate);
			dtFeed.setUseSizeLimit(false);
			dtFeed.init(null);
			dtFeed.startPaused();
			final ConditionRemoteEventListener dtReStore = new FeedRemoteEventTriggerListener(
					Arrays.<Class<? extends IRemoteEvent>>asList(DrillthroughRemoteEvent.class));
			dtFeed.addListener(dtReStore, false);
			dtReStore.addListener(onRemoteEventsReceived);
			if (bkUuid != null) {
				final DrillthroughBookmark dtBk = new DrillthroughBookmark();
				dtBk.setUUID(bkUuid);
				dtFeed.updateBookmarkFeed(dtBk, false);
			} else {
				if (feed == null) {
					throw new RuntimeException("Missing required parameter 'feedId' or 'uuid'");
				}
				final IDrillthroughFeed dtF = (IDrillthroughFeed) feed;
				dtFeed.update(dtF.getDescription(), dtF.getFlatContextValues(), true);
			}
			createdFeed = dtFeed;
			feedListener = dtReStore;
			break;
		}

		default: {
			throw new RuntimeException("Unexpected feedType: " + feedType);
		}
		}

		return new Runnable() {

			@Override
			public void run() {
				if (feedListener != null) {
					createdFeed.removeListener(feedListener);
				}
				try {
					createdFeed.stopIfNotStopped();
				} catch (AgentException e) {
					throw new RuntimeException(e);
				}
				if (onRemoteEventsReceived.getStoredException() != null) {
					// Propagate the stack
					throw new RuntimeException(onRemoteEventsReceived.getStoredException());
				}
			}

		};
	}

	protected String computeContentDisposition(String userAgent, String fileRootName, String currentFileExtension) {
		String contentDisposition = ATTACHMENT;

		if (ApexExportService.REGEXP_IE8.test(userAgent)) {
			contentDisposition += "; filename=";
		} else {
			contentDisposition += "; filename*=UTF-8''";
		}

		return contentDisposition + fileRootName + currentFileExtension;
	}

	/**
	 * Enable exporting to file of Events from server
	 */
	protected void exportRemoteEvents(HttpServletRequest request,
			HttpServletResponse response,
			IInstanceSession instanceSession,
			FeedType finalFeedType,
			ExportType exportType,
			List<IRemoteEvent> remoteEventsToExport) throws QuartetException, IOException {
		final String separator;

		if (request.getParameter("sep") != null) {
			separator = request.getParameter("sep");
		} else {
			separator = ",";
		}
		final String exportTitle = request.getParameter("title");
		final String exportDescription = request.getParameter("description");
		boolean addCtxValue = false;
		try {
			addCtxValue = request.getParameter("ctx") != null && Boolean.parseBoolean(request.getParameter("ctx"));
		} catch (Exception e) {
			LOGGER.trace("Minor issue with ctx: " + request.getParameter("ctx"), e);
		}
		boolean addDescription = false;
		try {
			addDescription =
					request.getParameter("location") != null && Boolean.parseBoolean(request.getParameter("location"));
		} catch (Exception e) {
			LOGGER.trace("Minor issue with location: " + request.getParameter("location"));
		}
		boolean printRawValue = false;
		try {
			printRawValue = request.getParameter("raw") != null && Boolean.parseBoolean(request.getParameter("raw"));
		} catch (Exception e) {
			LOGGER.trace("Minor issue with raw: " + request.getParameter("raw"));
		}
		final String fileName = request.getParameter("name");
		IFeedExporter feedExporter = null;
		// String contentType = null;
		{
			switch (finalFeedType) {
			case MDX: {
				final IDiscoveryService discoveryService = getSessionService(instanceSession, IDiscoveryService.class);
				feedExporter = exportMdx(exportType,
						discoveryService,
						printRawValue,
						addCtxValue,
						exportTitle,
						exportDescription,
						separator);
				break;
			}
			case DT: {
				feedExporter = exportDT(exportType, addDescription, addCtxValue, separator);
				break;
			}
			default: {
				throw new RuntimeException("Unexpected feedType: " + finalFeedType);
			}
			}
		}
		if (feedExporter != null) {
			// final ByteArrayOutputStream output = new ByteArrayOutputStream();
			LOGGER.debug("Start exporting");
			// Apex customization: we prefer to export the result directly to outputstream
			// http://stackoverflow.com/questions/8797035/servlet-response-setcontentlength-slows-download-down
			// response.setContentLength(output.size());
			{
				switch (exportType) {
				case CSV_TYPE: {
					response.setContentType("text/csv; charset=utf-8");
					break;
				}
				case HTML_TYPE: {
					response.setContentType("text/html; charset=utf-8");
					break;
				}
				case XLS_TYPE: {
					response.setContentType("application/vnd.ms-excel; charset=utf-8");
					break;
				}
				case PDF_TYPE: {
					response.setContentType("application/pdf; charset=utf-8");
					break;
				}

				default: {
					throw new RuntimeException("Unexpected exportType: " + exportType);
				}
				}
			}
			response.setStatus(HttpServletResponse.SC_OK);
			final String currentFileExtension = "." + feedExporter.getExtension();
			String fileRootName;
			if (fileName == null) {
				fileRootName = feedExporter.getDefaultFileName() + "_" + id.incrementAndGet();
			} else {
				fileRootName = fileName.replace(" ", "_");
				fileRootName = URLEncoder.encode(fileRootName, Charsets.UTF_8.name());
				if (fileRootName.endsWith(currentFileExtension)) {
					fileRootName = fileRootName.substring(0, fileRootName.length() - currentFileExtension.length());
				}
			}
			final String userAgent = request.getHeader(HttpHeaders.USER_AGENT);
			String contentDisposition = computeContentDisposition(userAgent, fileRootName, currentFileExtension);
			response.setHeader(CONTENT_DISPOSITION, contentDisposition);
			response.setHeader(HttpHeaders.CACHE_CONTROL, "no-store");

			// DoExport after having written all headers
			LOGGER.debug("Start actual export type={}", exportType);
			feedExporter.doExport(remoteEventsToExport, response.getOutputStream());
			LOGGER.info("Start actual export type={}", exportType);
		}
	}

	protected IFeedExporter exportDT(ExportType exportType,
			boolean addDescription,
			boolean addCtxValue,
			String separator) {
		switch (exportType) {
		case CSV_TYPE: {
			return new DrillthroughCsvExporter(separator);
		}
		case HTML_TYPE: {
			return new DrillthroughHtmlExporter(addDescription, addCtxValue);
		}
		case XLS_TYPE: {
			return new DrillthroughXlsExporter(addDescription, addCtxValue);
		}
		default: {
			throw new RuntimeException("Unsupported drillthrough export type: " + exportType);
		}
		}
	}

	protected IFeedExporter exportMdx(ExportType exportType,
			IDiscoveryService discoveryService,
			boolean printRawValue,
			boolean addCtxValue,
			String exportTitle,
			String exportDescription,
			String separator) {
		switch (exportType) {
		case HTML_TYPE: {
			final MdxHtmlExporter htmlExp = makeMdxHtmlExporter(discoveryService);
			htmlExp.init(printRawValue, addCtxValue);
			return htmlExp;
		}
		case XLS_TYPE: {
			final MdxXlsExporter xlsExp = makeMdxXlsExporter(discoveryService);
			xlsExp.init(printRawValue, addCtxValue);
			return xlsExp;
		}
		case CSV_TYPE: {
			final MdxCsvExporter csvExp = makeMdxCsvExporter(discoveryService);
			csvExp.init(printRawValue, separator);
			return csvExp;
		}
		case PDF_TYPE: {
			final MdxPdfExporter pdfExp = makeMdxPdfExporter(discoveryService);
			pdfExp.init(printRawValue, exportTitle, exportDescription, addCtxValue);
			return pdfExp;
		}
		default: {
			throw new RuntimeException("Unsupported mdx export type: " + exportType);
		}
		}
	}

	protected MdxHtmlExporter makeMdxHtmlExporter(IDiscoveryService discoveryService) {
		return new ApexMdxHtmlExporter(discoveryService, contentManager);
	}

	protected MdxXlsExporter makeMdxXlsExporter(IDiscoveryService discoveryService) {
		return new ApexMdxXlsExporter(discoveryService, contentManager);
	}

	protected MdxCsvExporter makeMdxCsvExporter(IDiscoveryService discoveryService) {
		return new ApexMdxCsvExporter(discoveryService, contentManager);
	}

	protected MdxPdfExporter makeMdxPdfExporter(IDiscoveryService discoveryService) {
		return new ApexMdxPdfExporter(discoveryService, contentManager);
	}

	public static void fail(final HttpServletResponse response, final Throwable failure) {
		LOGGER.warn("Exception while handling export request", failure);
		try {
			response.setContentType("text/plain; charset=utf-8");
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			final String message = "Failed to do export because :\n" + failure.getMessage();
			try {
				response.getOutputStream().write(message.getBytes(Charsets.UTF_8));
			} catch (IllegalStateException e) {
				response.getWriter().write(message);
			}
		} catch (IOException ex) {
			LOGGER.warn("ExportService failed while sending the previous failure to the client", ex);
		}
	}
}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.live.server.bookmark.dto;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.LinkedBlockingQueue;

import javax.xml.bind.JAXBException;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import blasd.apex.live.server.bookmarks.main.ApexBookmarkMigrationHelper;

/**
 * Enable marshalling of JCR elements
 * 
 * @author Benoit Lacelle
 *
 */
@XmlRootElement(name = "mdxSegmentQuery")
public class MdxSegmentQueryDTO extends AContentDTO {

	public static final Logger LOGGER = LoggerFactory.getLogger(MdxSegmentQueryDTO.class);

	// public enum SegmentType {FILTER, CALCULATED_MEASURE};
	@XmlElement
	public String mdxSegmentQuery;

	@XmlElement
	public String cube;

	@XmlElement
	public String segmentType;

	protected MdxSegmentQueryDTO() {
		// Serialization
	}

	public MdxSegmentQueryDTO(ContentCommonDTO common, String mdxSegmentQuery, String cube, String segmentType) {
		super(common);
		this.mdxSegmentQuery = mdxSegmentQuery;
		this.cube = cube;
		this.segmentType = segmentType;

	}

	@Override
	public String toString() {
		return "MdxQueryDTO [toString()=" + super.toString()
				+ "; SegmentType: "
				+ segmentType
				+ "; MDX: "
				+ mdxSegmentQuery
				+ "; Cube: "
				+ cube;
	}

	public static void main(String[] args) throws JAXBException {
		MdxSegmentQueryDTO mdxSegment = new MdxSegmentQueryDTO(
				new ContentCommonDTO("parentUUID", "uuid", "title", "description", null), "mdxQuery", "cube", "Type");

		AContentDTOHelper.doTestMarshall(mdxSegment, System.out);
	}

	// Migrate from SettingContent to MdxSegmentQueryDTO
	public static List<AContentDTO> migrateDTMasks(AContentDTO topDTO) {
		// Keep a mapping uuidToparentUUID to map DT masks (APLive 5.2 to APLive5.3?) to DTMdxSegment the
		// userNode
		Map<String, AContentDTO> uuidToParentUUID = new HashMap<>();

		List<AContentDTO> addedOrUpdated = new ArrayList<>();

		// Iterate through the tree to convert each node
		Queue<AContentDTO> leftToProcess = new LinkedBlockingQueue<>();
		leftToProcess.add(topDTO);
		while (!leftToProcess.isEmpty()) {
			AContentDTO next = leftToProcess.poll();

			// Register the mapping UUID to parent
			for (AContentDTO children : next.contentCommon.children) {
				uuidToParentUUID.put(children.contentCommon.uuid, next);
			}

			// Check if it is a Setting to migrate
			if (next instanceof SettingContentDTO) {
				SettingContentDTO setting = (SettingContentDTO) next;

				String parentOfAllSettingUUID = setting.contentCommon.parentUUID;
				AContentDTO userNodeUUID = uuidToParentUUID.get(parentOfAllSettingUUID);

				List<? extends MdxSegmentQueryDTO> migrated = ApexBookmarkMigrationHelper
						.convertDTMaskSettingToContent(setting, userNodeUUID.contentCommon.uuid);

				if (!migrated.isEmpty()) {
					// Get ride of settings already migrated
					{
						// Use an Iterator to remove while iterating
						Iterator<? extends MdxSegmentQueryDTO> it = migrated.iterator();
						while (it.hasNext()) {
							MdxSegmentQueryDTO oneMigrated = it.next();

							for (AContentDTO userChildren : userNodeUUID.contentCommon.children) {
								if (userChildren instanceof MdxSegmentQueryDTO) {
									MdxSegmentQueryDTO mdxSegmentUserChildren = (MdxSegmentQueryDTO) userChildren;
									if (mdxSegmentUserChildren.cube.equals(oneMigrated.cube)
											&& mdxSegmentUserChildren.mdxSegmentQuery
													.equals(oneMigrated.mdxSegmentQuery)
											&& mdxSegmentUserChildren.segmentType.equals(oneMigrated.segmentType)
											&& mdxSegmentUserChildren.contentCommon.title
													.equals(oneMigrated.contentCommon.title)) {
										LOGGER.info("The migrated setting {} already exists");
										it.remove();
										break;
									}
								}
							}
						}
					}

					LOGGER.info("We migrated {} to {} masks", setting, migrated.size());

					addedOrUpdated.add(userNodeUUID);
					addedOrUpdated.addAll(migrated);

					// Add the migrated MDX fragment as node under the usernode
					userNodeUUID.contentCommon.children.addAll(migrated);
				}
			}

			leftToProcess.addAll(next.contentCommon.children);
		}

		return addedOrUpdated;
	}
}

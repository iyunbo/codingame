/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.live.server.bookmark.dto;

import javax.xml.bind.JAXBException;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Enable marshalling of JCR elements
 * 
 * @author Benoit Lacelle
 *
 */
@XmlRootElement(name = "setting")
public class SettingContentDTO extends AContentDTO {

	@XmlElement
	protected String key;

	@XmlElement
	protected String value;

	@XmlElement
	protected String type;

	public SettingContentDTO() {
	}

	public SettingContentDTO(ContentCommonDTO common, String key, String value, String type) {
		super(common);
		this.key = key;
		this.value = value;
		this.type = type;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return "SettingContentDTO [key=" + key + ", value=" + value + ", type=" + type + "]";
	}

	public static void main(String[] args) throws JAXBException {
		SettingContentDTO mdx =
				new SettingContentDTO(new ContentCommonDTO("parentUUID", "uuid", "title", "description", null),
						"settingKey",
						"settingValue",
						"settingType");

		AContentDTOHelper.doTestMarshall(mdx, System.out);
	}
}

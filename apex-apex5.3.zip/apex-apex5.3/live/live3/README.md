[![Build Status](https://travis-ci.com/blasd/apex.svg?token=ghVoZrM9LWCSNPczn97T&branch=master)](https://travis-ci.com/blasd/apex)

# apex
## Live
### Live3
We provide tools for Live3 server-side only: there is no GWT code (i.e. Java code translated to Javascript) in there


#### Bookmark exports
It is sometimes useful to import/export bookmarks in a batch way. It is typically done to massively update HierarchyNames, remove all MDXs matching some pattern, or clearing all user preferences (e.g. the RealTime=on parameter)
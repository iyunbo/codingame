/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.live.datastore.client.datastore;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeSet;
import java.util.logging.Level;
import java.util.logging.Logger;

import blasd.apex.live.datastore.client.action.GetStoreColumnsAction;
import blasd.apex.live.datastore.client.action.GetStoreKeysAction;
import blasd.apex.live.datastore.client.action.GetStoreNamesAction;
import blasd.apex.live.datastore.client.action.SearchStoreAction;
import blasd.apex.live.datastore.client.action.UpdateStoreAction;
import blasd.apex.live.datastore.client.popup.ApexPopupUtil;
import blasd.apex.live.datastore.client.result.ListMapStringStringResult;
import blasd.apex.live.datastore.client.result.SetStringResult;

import com.google.gwt.cell.client.CheckboxCell;
import com.google.gwt.cell.client.EditTextCell;
import com.google.gwt.cell.client.FieldUpdater;
import com.google.gwt.cell.client.ValueUpdater;
import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.Document;
import com.google.gwt.dom.client.Element;
import com.google.gwt.dom.client.NativeEvent;
import com.google.gwt.event.dom.client.ChangeEvent;
import com.google.gwt.event.dom.client.ChangeHandler;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.dom.client.ContextMenuEvent;
import com.google.gwt.event.dom.client.ContextMenuHandler;
import com.google.gwt.event.dom.client.DomEvent;
import com.google.gwt.user.cellview.client.Column;
import com.google.gwt.user.cellview.client.DataGrid;
import com.google.gwt.user.cellview.client.SimplePager;
import com.google.gwt.user.cellview.client.SimplePager.TextLocation;
import com.google.gwt.user.cellview.client.TextHeader;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.HeaderPanel;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.Panel;
import com.google.gwt.user.client.ui.PopupPanel;
import com.google.gwt.view.client.CellPreviewEvent;
import com.google.gwt.view.client.ListDataProvider;
import com.google.gwt.view.client.NoSelectionModel;
import com.google.inject.Inject;
import com.qfs.store.IDatastore;
import com.quartetfs.pivot.live.client.mdx.IMdxModelSwitch;
import com.quartetfs.pivot.live.core.client.cmd.ICommandExecutorAsync;
import com.quartetfs.pivot.live.core.client.event.FailureType;
import com.quartetfs.pivot.live.core.client.event.IEventBus;
import com.quartetfs.pivot.live.core.client.event.Main;
import com.quartetfs.pivot.live.core.client.impl.DefaultAsyncCallback;
import com.quartetfs.pivot.live.core.shared.cmd.IAction;
import com.quartetfs.pivot.live.core.shared.cmd.IResult;
import com.quartetfs.pivot.live.core.shared.cmd.impl.CompoundAction;
import com.quartetfs.pivot.live.core.shared.cmd.impl.CompoundResult;

/**
 * A {@link Panel} enabling the browsing and update of an {@link IDatastore}
 * 
 * @author Benoit Lacelle
 * 
 */
public class DatastoreViewerPanel extends HeaderPanel {
	/**
	 * If the Map representing a row to update holds this key, it means the user
	 * requested to delete this row
	 */
	public static final String TAG_DELETE_ROW = "TAG_DELETE_ROW";

	protected static final Logger LOGGER = Logger.getLogger(DatastoreViewerPanel.class.getName());

	protected final HorizontalPanel headerHorizontalPanel = new HorizontalPanel();

	protected final Button doSearch = new Button();
	protected final Button applyChanges = new Button();
	protected final ListBox storesListBox = new ListBox();

	/**
	 * The store columns which are not present in the datagrid, but can be added
	 * by the user
	 */
	protected final ListBox availableColumns = new ListBox();

	/**
	 * This Map holds the filters requested by a user.
	 */
	protected final Map<String, String> template = new HashMap<String, String>();

	protected final Map<String, Set<String>> storeToKeys = new HashMap<String, Set<String>>();

	/**
	 * Register the update not yet-submitted, to handle modifying several pages
	 * before submitting
	 */
	protected final Map<Map<String, String>, Map<String, String>> pendingUpdate = new HashMap<Map<String, String>, Map<String, String>>();

	protected static final int DEFAULT_PAGE_SIZE = 10;
	protected final DataGrid<Map<String, String>> mainDatagrid = new DataGrid<Map<String, String>>(DEFAULT_PAGE_SIZE);

	protected final SimplePager.Resources pagerResources = GWT.create(SimplePager.Resources.class);
	protected final SimplePager pager = new SimplePager(TextLocation.CENTER, pagerResources, true, 100, true);

	public static final int DEFAULT_NB_COLUMNS_BY_DEFAULT = 5;

	/**
	 * Initially, the datagrid holds this number of columns, the other columns
	 * are available in a ListBox
	 */
	protected int nbColumnsByDefault = DEFAULT_NB_COLUMNS_BY_DEFAULT;

	protected final ListDataProvider<Map<String, String>> dataProvider = new ListDataProvider<Map<String, String>>();

	/**
	 * The Popup holding this panel
	 */
	protected PopupPanel mainPopup;

	/**
	 * Keep a reference to waitPopup, to close-it when the action finished
	 */
	protected PopupPanel waitPopup;

	protected final IEventBus eventBus;
	protected final ICommandExecutorAsync commandExecutor;
	protected final IMdxModelSwitch mdxModelSwitch;

	@Inject
	public DatastoreViewerPanel(@Main IEventBus eventBus, ICommandExecutorAsync commandExecutorAsync, IMdxModelSwitch mdxModelSwitch) {
		this.eventBus = eventBus;
		this.commandExecutor = commandExecutorAsync;
		this.mdxModelSwitch = mdxModelSwitch;
	}

	public void initWidget() {
		// The header holds the actions buttons
		this.setHeaderWidget(headerHorizontalPanel);

		// 1) The user selects a store
		headerHorizontalPanel.add(storesListBox);
		headerHorizontalPanel.add(availableColumns);

		// 2 & 3 ) The user can search and apply updates
		{
			doSearch.setText("Search");
			headerHorizontalPanel.add(doSearch);

			applyChanges.setText("Apply");
			headerHorizontalPanel.add(applyChanges);
		}

		// 4 ) The user can skip pages
		{
			pager.setDisplay(mainDatagrid);
			dataProvider.addDataDisplay(mainDatagrid);

			headerHorizontalPanel.add(pager);

			this.add(mainDatagrid);

			// !!! We HAVE TO set sizes manually, else the dataGrid might not
			// render itself. Moreover, beware of keeping a chain of Panel
			// implementing ProvideResize
			// http://stackoverflow.com/questions/17469284/datagrid-inside-flowpanel-is-not-visible-gwt
			// http://stackoverflow.com/questions/12173108/gwt-datagrid-does-not-show-data-but-contains-it
			this.setHeight("480px");
			this.setWidth("640px");

			mainDatagrid.setHeight("100%");
			mainDatagrid.setWidth("100%");

			mainDatagrid.setSelectionModel(new NoSelectionModel<Map<String, String>>(), new CellPreviewEvent.Handler<Map<String, String>>() {

				@Override
				public void onCellPreview(CellPreviewEvent<Map<String, String>> event) {
					Map<String, String> eventValue = event.getValue();

					// TODO: what do we want to do with that?
					eventValue.size();
				}
			});
		}

		registerEvents();

		queryStores();
	}

	public static class MyWidget extends Composite implements ContextMenuHandler {

		// just an example, use a meaningful Widget here...
		// private Widget base;

		private PopupPanel contextMenu;

		public MyWidget() {
			// initialize base widget, etc...

			this.contextMenu = new PopupPanel(true);
			this.contextMenu.add(new HTML("My Context menu!"));
			this.contextMenu.hide();

			initWidget(this.contextMenu);

			// of course it would be better if base would implement
			// HasContextMenuHandlers, but the effect is the same
			addDomHandler(this, ContextMenuEvent.getType());
		}

		public void onContextMenu(ContextMenuEvent event) {
			// stop the browser from opening the context menu
			event.preventDefault();
			event.stopPropagation();

			this.contextMenu.setPopupPosition(event.getNativeEvent().getClientX(), event.getNativeEvent().getClientY());
			this.contextMenu.show();
		}

	}

	protected String getSelectedStore() {
		int selectedIndex = storesListBox.getSelectedIndex();

		if (selectedIndex < 0) {
			return null;
		} else {
			return storesListBox.getItemText(selectedIndex);
		}
	}

	protected void registerEvents() {
		// If a user selects a store
		storesListBox.addChangeHandler(new ChangeHandler() {

			@SuppressWarnings("unchecked")
			@Override
			public void onChange(ChangeEvent event) {

				final String selectedStore = getSelectedStore();

				if (selectedStore != null) {
					// Request the list of keys and columns
					commandExecutor.execute(new CompoundAction(new GetStoreColumnsAction(selectedStore), new GetStoreKeysAction(selectedStore)),
							new DefaultAsyncCallback<CompoundResult>(eventBus, "Error while initializing " + this.getClass(), FailureType.MAJOR) {
								@Override
								public void onSuccess(final CompoundResult result) {
									if (mainPopup == null) {
										mainPopup = ApexPopupUtil.showFormPopup("Datastore Viewer", DatastoreViewerPanel.this);
									}

									result.evaluate(0, new DefaultAsyncCallback<IResult>(eventBus, "Error while initializing " + this.getClass(),
											FailureType.MAJOR) {
										@Override
										public void onSuccess(final IResult columnResultRaw) {

											result.evaluate(1,
													new DefaultAsyncCallback<IResult>(eventBus, "Error while initializing " + this.getClass(),
															FailureType.MAJOR) {
														@Override
														public void onSuccess(IResult keysResultRaw) {
															SetStringResult columnResult = (SetStringResult) columnResultRaw;
															SetStringResult keysResult = (SetStringResult) keysResultRaw;

															// We can process
															// the store as we
															// received its keys
															// and columns
															onStoreSelected(selectedStore, columnResult.getResult(), keysResult.getResult());
														}

													});
										}

									});

								}
							});
				}
			}
		});

		availableColumns.addChangeHandler(new ChangeHandler() {

			@Override
			public void onChange(ChangeEvent event) {
				int selectedIndex = availableColumns.getSelectedIndex();

				// If the user selected a columnName
				if (selectedIndex >= 1) {
					// Add the column
					addColumnInDatagrid(availableColumns.getItemText(selectedIndex), false);

					// Remove from the list
					availableColumns.removeItem(selectedIndex);

					updateAvailableColumnsVisibility();
				}

			}
		});

		doSearch.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				doSearch();
			}
		});

		applyChanges.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				applyChanges();
			}
		});
	}

	protected void applyChanges() {
		Map<Map<String, String>, Map<String, String>> toSend = new HashMap<Map<String, String>, Map<String, String>>(pendingUpdate);
		pendingUpdate.clear();

		List<IAction<? extends IResult>> updates = new ArrayList<IAction<? extends IResult>>();

		for (Entry<Map<String, String>, Map<String, String>> entry : toSend.entrySet()) {
			updates.add(new UpdateStoreAction(getSelectedStore(), entry.getKey(), entry.getValue()));
		}

		// TODO: wait popup with number of updates requested

		commandExecutor.execute(new CompoundAction(updates),
				new DefaultAsyncCallback<CompoundResult>(eventBus, "Error while initializing " + this.getClass(), FailureType.MAJOR) {
					@Override
					public void onSuccess(final CompoundResult result) {
						// TODO: close pop

					}
				});
	}

	protected void doSearch() {
		// Hide the search button while doing the search
		doSearch.setVisible(false);

		// Clead the pending updates which has not been commited
		// TODO: warn the user?
		pendingUpdate.clear();

		final String selectedStore = getSelectedStore();

		if (selectedStore != null) {
			// Retrieve the name of the visible columns from the Header
			Set<String> visibleColumns = new HashSet<String>();
			for (int i = 0; i < mainDatagrid.getColumnCount(); i++) {
				visibleColumns.add(((TextHeader) mainDatagrid.getHeader(i)).getValue());
			}

			commandExecutor.execute(new SearchStoreAction(selectedStore, template, null, Integer.MAX_VALUE, 0),
					new DefaultAsyncCallback<ListMapStringStringResult>(eventBus, "Error while initializing " + this.getClass(), FailureType.MAJOR) {
						@Override
						public void onSuccess(final ListMapStringStringResult result) {
							if (mainPopup == null) {
								mainPopup = ApexPopupUtil.showFormPopup("Datastore Viewer", DatastoreViewerPanel.this);
							}

							// Make the search button visible, as the user may
							// want to search again the same filter, knowing the
							// store has been updated in the meantime
							doSearch.setVisible(true);

							if (selectedStore.equals(getSelectedStore())) {
								onSearchResult(selectedStore, result.getProperties());
							} else {
								// Another store has been selected in the
								// meantime
								LOGGER.log(Level.INFO, "Another store (" + getSelectedStore() + ") than " + selectedStore
										+ "has been selected in the mean time");
							}

						}
					});
		}
	}

	protected void onSearchResult(String selectedStore, List<? extends Map<String, String>> properties) {
		// Remove all existing rows
		dataProvider.getList().clear();

		// Before showing the received result
		dataProvider.getList().addAll(properties); // mainDatagrid.getRowCount()

		// ??? Try to force the rendering, seems useless
		dataProvider.refresh();
	}

	/**
	 * The user selected a stores and we received its keys and columns
	 * 
	 * @param selectedStore
	 * @param selectedStoreColumns
	 * @param keys
	 */
	protected void onStoreSelected(String selectedStore, Set<String> selectedStoreColumns, Set<String> keys) {
		storeToKeys.put(selectedStore, keys);

		// Clear the found rows
		dataProvider.getList().clear();

		// Remove all rows
		while (mainDatagrid.getColumnCount() > 0) {
			mainDatagrid.removeColumn(0);
		}

		// Clean the list of available columns as we will rebuild it
		availableColumns.clear();

		// Add an item not representing any column
		availableColumns.addItem("-");

		// Add a first column to select rows for deletion
		{
			final String columnName = "X";

			Column<Map<String, String>, Boolean> column = new Column<Map<String, String>, Boolean>(new CheckboxCell()) {

				@Override
				public Boolean getValue(Map<String, String> object) {
					return object.containsKey(TAG_DELETE_ROW);
				}

			};

			column.setFieldUpdater(new FieldUpdater<Map<String, String>, Boolean>() {

				@Override
				public void update(int index, Map<String, String> object, Boolean value) {
					Map<String, String> key = buildCurrentRowKey(object);

					// Initialiye the row for update if necessary
					if (!pendingUpdate.containsKey(key)) {
						pendingUpdate.put(key, new HashMap<String, String>());
					}

					// Register the requested modification. We prefer doing this
					// instead of submitting the whole updated object, to
					// minimize
					// the transferred data, and improve concurrency (as another
					// process may change other columns)
					pendingUpdate.get(key).put(TAG_DELETE_ROW, TAG_DELETE_ROW);
				}
			});

			// TODO: add a select all button in the footer
			mainDatagrid.addColumn(column, new TextHeader(columnName), new TextHeader(columnName));
		}

		// Then add ALL key columns
		for (final String columnName : new TreeSet<String>(keys)) {
			addColumnInDatagrid(columnName, true);
		}

		// Remove from the template the keys which are invalid for the newly
		// selected store
		template.keySet().retainAll(keys);

		// Then add more columns up to a limit
		for (final String columnName : new TreeSet<String>(selectedStoreColumns)) {
			if (!keys.contains(columnName)) {
				// Key columns have already been added
				if (mainDatagrid.getColumnCount() < nbColumnsByDefault) {
					addColumnInDatagrid(columnName, false);
				} else {
					availableColumns.addItem(columnName);
				}
			}
		}

		updateAvailableColumnsVisibility();

		doSearch.setVisible(true);
	}

	protected void updateAvailableColumnsVisibility() {
		// Hide the listBox if it does not hold any column
		// 1 as there is always the "-" item
		if (availableColumns.getItemCount() > 1) {
			availableColumns.setVisible(true);
		} else {
			availableColumns.setVisible(false);
		}
	}

	protected void addColumnInDatagrid(final String columnName, boolean isKeyColumn) {
		SearchTerm searchTerm = new SearchTerm();

		// Put the template associate to this column name, even if it has been
		// initially filled for another store
		searchTerm.setSearchedValue(template.get(columnName));

		ValueUpdater<SearchTerm> searchUpdater = new ValueUpdater<SearchTerm>() {

			@Override
			public void update(SearchTerm value) {
				// The template has been changed: update the template
				template.put(columnName, value.getSearchedValue());

				// TODO: we don't do the search as it would remove the focus
				// And redo the search with the new template
				// doSearch();
				doSearch.setVisible(true);
			}
		};

		// TODO: bold header if isKeyColumn=true
		Column<Map<String, String>, String> column = new Column<Map<String, String>, String>(new EditTextCell()) {
			@Override
			public String getValue(Map<String, String> object) {
				return object.get(columnName);
			}
		};
		column.setFieldUpdater(new FieldUpdater<Map<String, String>, String>() {

			@Override
			public void update(int index, Map<String, String> object, String value) {
				Map<String, String> key = buildCurrentRowKey(object);

				// Initialiye the row for update if necessary
				if (!pendingUpdate.containsKey(key)) {
					pendingUpdate.put(key, new HashMap<String, String>());
				}

				// Register the requested modification. We prefer doing this
				// instead of submitting the whole updated object, to minimize
				// the transferred data, and improve concurrency (as another
				// process may change other columns)
				pendingUpdate.get(key).put(columnName, value);
			}
		});

		// It is much simpler to add a '*' char, than making the header in bold
		// http://stackoverflow.com/questions/11993154/how-to-set-gwt-cell-background-color
		String headerText;
		if (isKeyColumn) {
			headerText = columnName + "*";
		} else {
			headerText = columnName;
		}

		mainDatagrid.addColumn(column, new TextHeader(headerText), new SearchHeader(new SearchCell() {
			@Override
			protected void onEnterKeyDown(com.google.gwt.cell.client.Cell.Context context, Element parent, SearchTerm value, NativeEvent event,
					ValueUpdater<SearchTerm> valueUpdater) {
				super.onEnterKeyDown(context, parent, value, event, valueUpdater);

				doSearch();
			}
		}, searchTerm, searchUpdater));
	}

	protected Map<String, String> buildCurrentRowKey(Map<String, String> object) {
		Set<String> keys = storeToKeys.get(getSelectedStore());

		if (keys == null || keys.isEmpty()) {
			// Either unexpected case, or called too soon, or append-only store
			setThisAsReadOnly();

			throw new RuntimeException("Is this store append-only?");
		} else {
			Map<String, String> key = new HashMap<String, String>();
			for (String keyColumn : keys) {
				key.put(keyColumn, object.get(keyColumn));
			}

			return key;
		}

	}

	protected void setThisAsReadOnly() {
		// TODO: For some reason, we decided to stop modifying this store
		// anymore
	}

	/**
	 * Query for the available stores
	 */
	protected void queryStores() {
		waitPopup = ApexPopupUtil.showWaitPopup("Loading Datastore Viewer...");

		commandExecutor.execute(new GetStoreNamesAction(),
				new DefaultAsyncCallback<SetStringResult>(eventBus, "Error while initializing " + this.getClass(), FailureType.MAJOR) {
					@Override
					public void onSuccess(final SetStringResult result) {
						if (waitPopup != null) {
							waitPopup.hide();
						}

						if (mainPopup == null) {
							mainPopup = ApexPopupUtil.showFormPopup("Datastore Viewer", DatastoreViewerPanel.this);
						}

						onStoresReceived(result.getResult());
					}
				});
	}

	/**
	 * Process the list of available stores
	 * 
	 * @param stores
	 */
	protected void onStoresReceived(Collection<String> stores) {
		storesListBox.clear();

		// Add the stores in the lexicographic order
		for (String storeName : new TreeSet<String>(stores)) {
			storesListBox.addItem(storeName, storeName);
		}

		// Simulate a user selecting the first store
		NativeEvent event = Document.get().createChangeEvent();
		DomEvent.fireNativeEvent(event, storesListBox);
	}
}

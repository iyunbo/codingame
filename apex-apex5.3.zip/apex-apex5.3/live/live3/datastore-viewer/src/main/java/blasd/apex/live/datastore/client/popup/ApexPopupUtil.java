/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.live.datastore.client.popup;

import com.google.gwt.user.client.ui.PopupPanel;
import com.google.gwt.user.client.ui.Widget;
import com.quartetfs.pivot.live.core.client.widget.impl.LiveDialogBox;
import com.quartetfs.pivot.live.core.client.widget.impl.PopupServices;

public class ApexPopupUtil {
	protected ApexPopupUtil() {
		// hidden
	}

	/**
	 * Something went wrong: .isClosable()
	 */
	public static LiveDialogBox showErrorMessagePopup(String header, String message) {
		return PopupServices.create().setTitle(header).setContent(message).isClosable().center();
	}

	/**
	 * Something went wrong: .isClosable() with header as message
	 */
	public static LiveDialogBox showErrorMessagePopup(String header) {
		return showErrorMessagePopup(header, header);
	}

	/**
	 * Wait for an asynchronous call: .isClosable().isAutoHide() with header as
	 * message
	 */
	public static PopupPanel showWaitPopup(String header) {
		return PopupServices.create().setTitle(header).setContent(header).isClosable().isAutoHide().center();
	}

	/**
	 * Show a form: .isClosable()
	 */
	public static LiveDialogBox showFormPopup(String header, Widget widget) {
		return PopupServices.create().setTitle(header).setContent(widget).isClosable().center();
	}

	public static LiveDialogBox showSuccessMessagePopup(String header, String message) {
		return PopupServices.create().setTitle(header).setContent(message).isClosable().isAutoHide().center();
	}
}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.live.datastore.client.datastore;

import com.google.gwt.user.client.Command;
import com.google.inject.Inject;
import com.quartetfs.pivot.live.client.mdx.IMdxModelSwitch;
import com.quartetfs.pivot.live.core.client.cmd.ICommandExecutorAsync;
import com.quartetfs.pivot.live.core.client.event.IEventBus;
import com.quartetfs.pivot.live.core.client.event.Main;

public class DatastoreViewerCommand implements Command {

	protected final IEventBus eventBus;
	protected final ICommandExecutorAsync commandExecutor;
	protected final IMdxModelSwitch mdxModelSwitch;

	@Inject
	public DatastoreViewerCommand(@Main IEventBus eventBus, ICommandExecutorAsync commandExecutor, IMdxModelSwitch mdxModelSwitch) {
		this.eventBus = eventBus;
		this.commandExecutor = commandExecutor;
		this.mdxModelSwitch = mdxModelSwitch;
	}

	@Override
	public void execute() {
		DatastoreViewerPanel panel = new DatastoreViewerPanel(eventBus, commandExecutor, mdxModelSwitch);
		panel.initWidget();
	}

}

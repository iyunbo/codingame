/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.live.datastore.client.datastore;

import com.google.gwt.cell.client.AbstractCell;
import com.google.gwt.cell.client.ValueUpdater;
import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.Element;
import com.google.gwt.dom.client.InputElement;
import com.google.gwt.dom.client.NativeEvent;
import com.google.gwt.safehtml.client.SafeHtmlTemplates;
import com.google.gwt.safehtml.shared.SafeHtml;
import com.google.gwt.safehtml.shared.SafeHtmlBuilder;

public class SearchCell extends AbstractCell<SearchTerm> {

	interface Template extends SafeHtmlTemplates {
		@Template("<div style=\"\">{0}</div>")
		SafeHtml header(String columnName);

		@Template("<div style=\"\"><input type=\"text\" value=\"{0}\"/></div>")
		SafeHtml input(String value);
	}

	private static Template template;

	// private boolean isChanged = false;

	public SearchCell() {
		super("keydown", "keyup", "change", "blur");
		if (template == null) {
			template = GWT.create(Template.class);
		}
	}

	@Override
	public void render(com.google.gwt.cell.client.Cell.Context context, SearchTerm value, SafeHtmlBuilder sb) {
		sb.append(template.header(value.getSearchedValue()));
		sb.append(template.input(value.getSearchedValue()));
	}

	@Override
	public void onBrowserEvent(Context context, Element parent, SearchTerm value, NativeEvent event, ValueUpdater<SearchTerm> valueUpdater) {
		if (value == null) {
			return;
		}
		super.onBrowserEvent(context, parent, value, event, valueUpdater);
		if ("keyup".equals(event.getType())) {
			// isChanged = true;
			InputElement elem = getInputElement(parent);
			value.setSearchedValue(elem.getValue());
			if (valueUpdater != null) {
				valueUpdater.update(value);
			}
		}
		// else if ("blur".equals(event.getType())) {
		// isChanged = false;
		// }
	}

	protected InputElement getInputElement(Element parent) {
		Element elem = parent.getElementsByTagName("input").getItem(0);
		return elem.cast();
	}
}
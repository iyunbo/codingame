/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.live.datastore.server.handler;

import blasd.apex.live.datastore.client.action.GetStoreKeysAction;
import blasd.apex.live.datastore.client.result.SetStringResult;
import blasd.apex.shared.datastore.IApexDatastoreService;

import com.quartetfs.pivot.live.core.server.cmd.IActionContext;
import com.quartetfs.pivot.live.core.server.utils.impl.ASessionHandler;
import com.quartetfs.pivot.live.core.shared.cmd.ActionException;

/**
 * @see IApexDatastoreService#storeKeys(String)
 * @author Benoit Lacelle
 * 
 */
public class GetStoreKeysHandler extends ASessionHandler<GetStoreKeysAction, SetStringResult> {

	@Override
	protected SetStringResult executeSession(GetStoreKeysAction arg0, IActionContext arg1) throws ActionException {
		return new SetStringResult(this.getSessionService(IApexDatastoreService.class).storeKeys(arg0.getStoreName()));
	}
}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.live.datastore.client.popup;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.quartetfs.pivot.live.client.mdx.table.IPivotHeaderCell;
import com.quartetfs.pivot.live.shared.mdx.grid.impl.GridUtils;
import com.quartetfs.pivot.live.shared.model.IMdxMemberExpression;
import com.quartetfs.pivot.live.shared.olap.impl.Cube;

public class ApexCellUtil {

	protected ApexCellUtil() {
		// hidden
	}

	/**
	 * 
	 * @param cube
	 * @param pivotCell
	 * @return a Map from a String describing an ILevel to a member unique name
	 */
	public static Map<String, Map<String, Map<Integer, String>>> extractExpressedLevels(Cube cube, IPivotHeaderCell pivotCell) {
		final Map<String, Map<String, Map<Integer, String>>> dimToHieToLevToUniqueName = new HashMap<String, Map<String, Map<Integer, String>>>();

		if (pivotCell != null) {
			List<IMdxMemberExpression> positions = GridUtils.positionFromHeader(cube, pivotCell.extractAllFilterPathes());

			// For all expressions
			for (IMdxMemberExpression position : positions) {
				// Check we have a full path
				if (isNiceExpression(cube, position)) {
					int i = 1;
					i = i * 2;
					// TODO
					// if (!dimToHieToLevToUniqueName.containsKey(key))

					// For all values: 0 is dimensionName, 1 is levelName
					// for (int index = 2; index < position.getParts().length;
					// index++) {
					// IMdxIdentifier part = position.getParts()[index];
					//
					// expressed.put(new SimpleLevel(position.getHierarchy(),
					// index - 2), part.getValue());
					// }
				}

			}
		}

		return dimToHieToLevToUniqueName;
	}

	/**
	 * Check this is an easy Mdx Expression, for which most assumptions are true
	 * 
	 * @param cube
	 * @param position
	 * @return
	 */
	public static boolean isNiceExpression(Cube cube, IMdxMemberExpression position) {
		if ("Measures".equals(position.getHierarchy())) {
			// Calculated measures may return null for:
			// cube.getHierarchiesPerName().get(position.getHierarchy())
			if (position.getParts().length == 2) {
				return true;
			} else {
				return false;
			}
		} else {
			// Check the rootLevel is the second part of the expression: we have
			// a full path
			// TODO: migration
			throw new UnsupportedOperationException("TODO migration");
			// return
			// cube.getDimensionsPerName().get(position.getHierarchy()).getRootLevelName().equals(position.getLevel());
		}
	}
}

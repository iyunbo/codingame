package blasd.apex.live.jcr;

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import java.io.ByteArrayInputStream;
import java.io.DataInput;
import java.io.DataInputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.derby.catalog.TypeDescriptor;
import org.apache.derby.iapi.services.crypto.CipherFactory;
import org.apache.derby.iapi.services.crypto.CipherProvider;
import org.apache.derby.iapi.services.io.ArrayInputStream;
import org.apache.derby.iapi.services.io.CompressedNumber;
import org.apache.derby.iapi.services.io.FormatIdUtil;
import org.apache.derby.iapi.services.io.FormatableBitSet;
import org.apache.derby.iapi.services.io.StoredFormatIds;
import org.apache.derby.iapi.types.DataTypeDescriptor;
import org.apache.derby.iapi.types.DataValueDescriptor;
import org.apache.derby.impl.services.jce.JCECipherFactory;
import org.apache.derby.impl.store.raw.data.StoredFieldHeader;
import org.apache.derby.impl.store.raw.data.StoredRecordHeader;

/**
 * Utility to read a data file in the seg0 directory of a Derby database. This
 * is based on the 10.8 version of data records.
 */
public class DataFileReader {
	// //////////////////////////////////////////////////////////////////////
	//
	// CONSTANTS
	//
	// //////////////////////////////////////////////////////////////////////

	private static final String USAGE = "Usage:\n"
			+ "\n"
			+ "    java DataFileReader $dataFileName [ -v ] [ -d $D ] [ -p $P ] [ -n $N ] [ -e $encryptionAttributes $serviceProperties ]\n"
			+ "\n"
			+ "    -v   Verbose. Print out records and slot tables. Field data appears as byte arrays. If you do not set this flag, the tool just decodes the page headers.\n"
			+ "    -d   Data signature. This makes a verbose printout turn the field data into objects. $D is a row signature, e.g., \"( a int, b varchar( 30 ) )\"\n"
			+ "    -p   Starting page. $P is a number which must be at least 1, the first page to read after the header. Page 0 (the header) is always read.\n"
			+ "    -n   Number of pages to read. $N is a positive number. Defaults to all subsequent pages.\n"
			+ "    -e   If the database is encrypted, you must supply the encryption attributes and the location of service.properties.\n"
			+ "\n"
			+ "  For example, the following command deserializes all of the records in the SYSCONGLOMERATES file:\n"
			+ "\n"
			+ "    java DataFileReader db/seg0/c20.dat -v -d \"( a char(36), b char(36), c bigint, d varchar( 128), e boolean, f serializable, g boolean, h char( 36 )  )\"\n"
			+ "\n"
			+ "  Note the special 'serializable' type in the preceding example. Use 'serializable' for user-defined types and for the system columns which are objects.\n";

	private static final long READ_ALL_PAGES = -1L;

	// page status
	public static final byte VALID_PAGE = 1;
	public static final byte INVALID_PAGE = 2;

	// container status
	public static final int FILE_DROPPED = 0x1;
	public static final int FILE_COMMITTED_DROP = 0x2;
	public static final int FILE_REUSABLE_RECORDID = 0x8;

	// extent status
	public static final int HAS_DEALLOCATED = 0x1;
	public static final int HAS_FREE = 0x2;
	public static final int ALL_FREE = 0x4;
	public static final int HAS_UNFILLED_PAGES = 0x10;
	public static final int KEEP_UNFILLED_PAGES = 0x10000000;
	public static final int NO_DEALLOC_PAGE_MAP = 0x20000000;
	public static final int RETIRED = 0x8;

	public static final int CHECKSUM_SIZE = 8;
	public static final int SMALL_SLOT_SIZE = 2;
	public static final int LARGE_SLOT_SIZE = 4;

	// size of read buffer. this is 2 times the max size of a Derby page
	public static final int BUFFER_SIZE = 65536;

	// record status
	public static final byte RECORD_DELETED = 0x01;
	public static final byte RECORD_OVERFLOW = 0x02;
	public static final byte RECORD_HAS_FIRST_FIELD = 0x04;
	public static final byte RECORD_VALID_MASK = 0x0f;

	// field status
	public static final int FIELD_INITIAL = 0x00;
	public static final int FIELD_NULL = 0x01;
	public static final int FIELD_OVERFLOW = 0x02;
	public static final int FIELD_NOT_NULLABLE = 0x04;
	public static final int FIELD_EXTENSIBLE = 0x08;
	public static final int FIELD_TAGGED = 0x10;
	public static final int FIELD_FIXED = 0x20;

	// //////////////////////////////////////////////////////////////////////
	//
	// STATE
	//
	// //////////////////////////////////////////////////////////////////////

	//
	// Args.
	//
	private static String _dataFileName;
	private static boolean _verbose = false;
	private static long _maxPageCount = READ_ALL_PAGES;
	private static long _firstPage = 1L;
	private static DataTypeDescriptor[] _rowSignature;
	private static CipherProvider _decryptionEngine;

	public static final DevNull devNull = new DevNull();

	// //////////////////////////////////////////////////////////////////////
	//
	// ENTRY POINT
	//
	// //////////////////////////////////////////////////////////////////////

	protected static List<String> found = new ArrayList<>();

	public static void main(String... args) throws Exception {
		if (!parseArgs(args)) {
			usage();
		}

		DataFile dataFile = new DataFile(new File(_dataFileName), _verbose, _maxPageCount, _firstPage, _rowSignature, _decryptionEngine);

		dataFile.printMe(System.out);

		List<String> mxExtracted = new ArrayList<>();

		for (String oneFound : found) {
			if (!oneFound.contains("http://www.quartetfs.com")) {
				// Skip unknown data
			} else if (oneFound.contains("http://www.quartetfs.com/ActivePivotSetting")) {
				// Skip Settings which are not a big lost
			} else if (oneFound.contains("http://www.quartetfs.com/ActivePivotMDXSegment")) {
				System.out.println(oneFound.replace('\r', ' ').replace('\n', ' '));
			} else if (oneFound.contains("http://www.quartetfs.com/ActivePivotMDX")) {
				String actualTitle = "";
				{
					int indexPosition = oneFound.indexOf("title");

					String title = oneFound.substring(indexPosition);

					int afterTitle = "title".length() + 3;
					int titleSize = title.getBytes()[afterTitle - 1];
					actualTitle = title.substring(afterTitle, afterTitle + titleSize);
				}

				String actualMdx = "";
				{
					int mdxPosition = oneFound.indexOf("mdx");
					int cvPosition = oneFound.indexOf("contextValues", mdxPosition);

					if (cvPosition >= 0) {
						actualMdx = oneFound.substring(mdxPosition + "mdx".length() + 4, cvPosition - 1);
					} else {
						actualMdx = oneFound.substring(mdxPosition + "mdx".length() + 4);
					}

					// String mdx = oneFound.substring(mdxPosition);
					//
					// int afterTitle = "mdx".length() + 4;
					// int titleSize = mdx.getBytes()[afterTitle - 1];
					// actualMdx = mdx.substring(afterTitle, afterTitle +
					// titleSize);
					//
					// mdx.substring(mdx.indexOf("Liquidity Aggregates")).getBytes()[21]

					// -65, -67, 1
					// new ByteArrayInputStream( new byte[]{-67, 1});
					// int j = (-67 & 0xFF) << 8 | 3 & 0xFF;
				}

				String actualCV = "";
				{
					int cvPosition = oneFound.indexOf("contextValues");

					int open = oneFound.indexOf('{', cvPosition);
					int close = oneFound.indexOf('}', open);

					if (close >= 0) {
						actualCV = oneFound.substring(open, close + 1);
					} else {
						actualCV = oneFound.substring(open);
					}

					// String cv = oneFound.substring(cvPosition);
					//
					// int afterTitle = "contextValues".length() + 3;
					// int titleSize = cv.getBytes()[afterTitle - 1];
					// actualCV = cv.substring(afterTitle, afterTitle +
					// titleSize);
				}

				mxExtracted.add(actualTitle + ";" + actualMdx + ";" + actualCV + ";");

				// Print what has not been extracted
				System.out.println(oneFound.replace(actualTitle, "").replace(actualMdx, "").replace(actualCV, "").replace('\r', ' ')
						.replace('\n', ' '));
			} else if (oneFound.contains("http://www.quartetfs.com/UserNode")) {
				System.out.println(oneFound.replace('\r', ' ').replace('\n', ' '));
			} else {
				System.out.println(oneFound.replace('\r', ' ').replace('\n', ' '));
			}
		}

		for (String mdx : mxExtracted) {
			System.out.println(mdx.replace('\r', ' ').replace('\n', ' '));
		}
	}

	private static boolean parseArgs(String... args) {
		if ((args == null) || (args.length < 1)) {
			return false;
		}

		int argCount = args.length;
		int idx = 0;

		_dataFileName = args[idx++];

		// optional args
		while (idx < argCount) {
			String arg = args[idx++];

			if ("-v".equals(arg)) {
				_verbose = true;
			} else if ("-p".equals(arg)) {
				if (idx >= argCount) {
					return false;
				}
				try {
					_firstPage = Long.parseLong(args[idx++]);
					if (_firstPage < 1L) {
						return false;
					}
				} catch (Exception e) {
					return false;
				}
			} else if ("-n".equals(arg)) {
				if (idx >= argCount) {
					return false;
				}
				try {
					_maxPageCount = Long.parseLong(args[idx++]);
					if (_maxPageCount < 1L) {
						return false;
					}
				} catch (Exception e) {
					return false;
				}
			} else if ("-d".equals(arg)) {
				if (idx >= argCount) {
					return false;
				}
				try {
					String tableSignature = args[idx++];
					_rowSignature = getTypeSignature(tableSignature);

					if (_rowSignature == null) {
						return false;
					}
				} catch (Exception e) {
					e.printStackTrace();
					return false;
				}
			} else if ("-e".equals(arg)) {
				if (idx + 1 >= argCount) {
					return false;
				}

				String encryptionAttributes = args[idx++];
				File serviceProperties = new File(args[idx++]);
				try {
					_decryptionEngine = makeDecryptionEngine(encryptionAttributes, serviceProperties);
				} catch (Exception e) {
					System.out.println(e.getMessage());
					return false;
				}
			} else {
				return false;
			}
		}

		return true;
	}

	private static DataTypeDescriptor[] getTypeSignature(String tableSignature) throws Exception {
		//
		// Boot an in-memory database so that we can parse a table signature.
		//
		Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
		Connection conn = DriverManager.getConnection("jdbc:derby:memory:db;create=true");

		String createTable = "create table dummyTable " + tableSignature;

		try {
			conn.prepareStatement("create type serializable external name 'java.io.Serializable' language java").execute();
			conn.prepareStatement(createTable).execute();
		} catch (SQLException se) {
			System.out.println("Badly formed type signature: " + tableSignature);
			System.out.println(se.getMessage());
			return null;
		}

		String select = "select c.columndatatype, c.columnnumber\n" + "from sys.syscolumns c, sys.systables t\n"
				+ "where c.referenceid = t.tableid\n" + "and t.tablename = 'DUMMYTABLE'\n" + "order by c.columnnumber";
		ResultSet rs = conn.prepareStatement(select).executeQuery();

		ArrayList<DataTypeDescriptor> list = new ArrayList<DataTypeDescriptor>();

		while (rs.next()) {
			list.add(DataTypeDescriptor.getType((TypeDescriptor) rs.getObject(1)));
		}

		rs.close();

		DataTypeDescriptor[] result = new DataTypeDescriptor[list.size()];
		list.toArray(result);

		return result;
	}

	private static DataValueDescriptor[] getRow(TypeDescriptor[] typeSignature) throws Exception {
		int count = typeSignature.length;
		DataValueDescriptor[] result = new DataValueDescriptor[count];

		for (int i = 0; i < count; i++) {
			result[i] = DataTypeDescriptor.getType(typeSignature[i]).getNull();
		}

		return result;
	}

	private static CipherProvider makeDecryptionEngine(String encryptionAttributes, File serviceProperties) throws Exception {
		Properties properties = unpackEncryptionProperties(encryptionAttributes);
		properties.load(new FileInputStream(serviceProperties));

		JCECipherFactory cipherFactory = new JCECipherFactory(false, properties, false);

		return cipherFactory.createNewCipher(CipherFactory.DECRYPT);
	}

	private static Properties unpackEncryptionProperties(String encryptionAttributes) {
		Properties retval = new Properties();
		String[] items = encryptionAttributes.split(";");

		for (String item : items) {
			int equalsSignIdx = item.indexOf("=");
			if (equalsSignIdx > 0) {
				String key = item.substring(0, equalsSignIdx);
				String value = item.substring(equalsSignIdx + 1, item.length());

				retval.setProperty(key, value);
			}
		}

		return retval;
	}

	private static void usage() {
		System.out.println(USAGE);
		System.exit(1);
	}

	private static void skipBytes(DataInputStream dais, int bytesToSkip) throws IOException {
		int actualBytesSkipped = dais.skipBytes(bytesToSkip);

		if (actualBytesSkipped != bytesToSkip) {
			throw new IOException("Expected to skip " + bytesToSkip + " bytes but only skipped " + actualBytesSkipped + " bytes.");
		}
	}

	// //////////////////////////////////////////////////////////////////////
	//
	// NESTED CLASSES
	//
	// //////////////////////////////////////////////////////////////////////

	// //////////////////////////////////////////////
	//
	// THIS IS THE WORKHORSE FOR THIS PROGRAM
	//
	// //////////////////////////////////////////////

	public static final class DataFile {
		// constructor args

		private File _file;
		private boolean _verbose;
		private long _maxPageCount;
		private long _firstPage;
		private DataTypeDescriptor[] _rowSignature;
		private CipherProvider _decryptionEngine;

		// control info

		private long _pageCount;
		private long _pageNumber;
		private byte[] _pageData;
		private int _pageSize;
		private int _slotTableOffsetToFirstEntry;
		private int _slotTableOffsetToFirstRecordLengthField;
		private int _slotTableOffsetToFirstReservedSpaceField;
		private int _slotFieldSize;
		private int _slotEntrySize;
		private ArrayList<String> _errors = new ArrayList<String>();

		public DataFile(File file, boolean verbose, long maxPageCount, long firstPage, DataTypeDescriptor[] rowSignature,
				CipherProvider decryptionEngine) {
			_file = file;
			_verbose = verbose;
			_maxPageCount = maxPageCount;
			_firstPage = firstPage;
			_rowSignature = rowSignature;
			_decryptionEngine = decryptionEngine;
		}

		public void printMe(PrintStream printStream) throws Exception {
			_pageCount = 0L;

			XMLWriter ps = new XMLWriter(printStream);

			ps.println("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>");

			ps.beginTag("dataFile");
			{
				FileInputStream fis = new FileInputStream(_file);
				WrapperInputStream wis = new WrapperInputStream(fis);

				readFile(ps, wis);

				if (_errors != null) {
					formatErrors(ps);
				}

				wis.close();
				fis.close();
			}
			ps.endTag(); // dataFile
		}

		private void readFile(XMLWriter ps, WrapperInputStream wis) {
			try {
				readFileHeader(ps, wis);
				positionOnFirstPage(wis);

				DataInputStream dais = new DataInputStream(wis);

				boolean readMore = true;
				while (readMore) {
					if ((_maxPageCount != READ_ALL_PAGES) && (_pageCount >= _maxPageCount)) {
						break;
					}

					readMore = readPageBytes(ps, dais);
				}

				createTextElement(ps, "pageCount", Long.toString(_pageCount));

			} catch (Throwable t) {
				_errors.add("Error reading page: " + getPageCoordinates() + ": " + formatThrowable(t));
			}
		}

		/** Returns false if at EOF */
		private boolean readPageBytes(XMLWriter ps, DataInputStream dais) throws Exception {
			try {
				_pageData = new byte[_pageSize];
				dais.readFully(_pageData);
				readNonHeaderPage(ps);

				return true;
			} catch (EOFException eof) {
				return false;
			}
		}

		private void positionOnFirstPage(WrapperInputStream wis) throws Exception {
			skipToPageEnd(wis);

			if (_firstPage <= 1L) {
				return;
			}

			long bytesToSkip = (_firstPage - 1L) * _pageSize;

			DataInputStream dais = new DataInputStream(wis);

			while (true) {
				if (bytesToSkip <= Integer.MAX_VALUE) {
					skipBytes(dais, (int) bytesToSkip);
					break;
				} else {
					skipBytes(dais, Integer.MAX_VALUE);
					bytesToSkip -= Integer.MAX_VALUE;
				}
			}

			_pageNumber = _firstPage;
		}

		private void readFileHeader(XMLWriter ps, WrapperInputStream wis) throws Exception {
			DataInputStream dais = new DataInputStream(wis);

			ps.beginTag("fileHeader");
			{
				readAllocPage(ps, wis, readPageFormatableID(dais));
			}
			ps.endTag(); // fileHeader

			_pageCount++;
			_pageNumber++;
		}

		private void readNonHeaderPage(XMLWriter ps) throws Exception {
			// readFile() positioned us at the start of a page

			if (_decryptionEngine != null) {
				decryptPage();
			}

			WrapperInputStream wis = new WrapperInputStream(new ByteArrayInputStream(_pageData));
			int pageFormatableID = readPageFormatableID(new DataInputStream(wis));

			switch (pageFormatableID) {
			case StoredFormatIds.RAW_STORE_ALLOC_PAGE:
				readAllocPage(ps, wis, pageFormatableID);
				break;
			case StoredFormatIds.RAW_STORE_STORED_PAGE:
				readStoredPage(ps, wis, pageFormatableID);
				break;
			default:
				throw new IOException("Unknown page formatable ID: " + pageFormatableID);
			}

			_pageCount++;
			_pageNumber++;
		}

		private void skipToPageEnd(WrapperInputStream wis) throws Exception {
			int remainingBytesOnPage = getRemainingBytesOnPage(wis);

			DataInputStream dais = new DataInputStream(wis);
			if (remainingBytesOnPage != 0) {
				skipBytes(dais, remainingBytesOnPage);
			}
		}

		private int getRemainingBytesOnPage(WrapperInputStream wis) {
			long offsetIntoCurrentPage = currentOffsetIntoPage(wis);

			int remainingBytes = (offsetIntoCurrentPage == 0L) ? 0 : (int) (_pageSize - offsetIntoCurrentPage);

			return remainingBytes;
		}

		private int currentOffsetIntoPage(WrapperInputStream wis) {
			return (int) (wis.getBytesRead() % (long) _pageSize);
		}

		private int readPageFormatableID(DataInputStream dais) throws Exception {
			int formatableID = FormatIdUtil.readFormatIdInteger(dais);

			// Even though the formatableID only takes up the leading two bytes
			// of
			// the AllocPage header, 4 bytes are allocated to it. Flush the next
			// 2 bytes.
			skipBytes(dais, 2);

			return formatableID;
		}

		// See FileContainer.decryptPage()
		private void decryptPage() throws Exception {
			byte[] cipherText = _pageData;
			byte[] clearText = new byte[_pageSize];

			int len = _decryptionEngine.decrypt(cipherText, 0, _pageSize, clearText, 0);

			if (len != _pageSize) {
				throw new IOException("Expected to decrypt " + _pageSize + " bytes but actually decrypted " + len + " bytes.");
			}

			// need to put the checksum where it belongs
			System.arraycopy(clearText, 8, cipherText, 0, _pageSize - 8);
			System.arraycopy(clearText, 0, cipherText, _pageSize - 8, 8);

			_pageData = cipherText;
		}

		private void readStoredPage(XMLWriter ps, WrapperInputStream wis, int formatableID) throws Exception {
			DataInputStream dais = new DataInputStream(wis);

			if (formatableID != StoredFormatIds.RAW_STORE_STORED_PAGE) {
				throw new IOException("Page header should start with formatable id " + StoredFormatIds.RAW_STORE_STORED_PAGE
						+ " but instead starts with formatable id " + formatableID);
			}

			String attributes = "number=" + doubleQuote(Long.toString(_pageNumber));

			ps.beginTag("storedPage", attributes);
			{
				createIntElement(ps, "formatableID", formatableID);

				PageHeader ph = readPageHeader(ps, dais);

				if (_verbose) {
					formatRecords(ps, ph);
				}
				readChecksum(ps);
			}
			ps.endTag(); // storedPage
		}

		private void formatRecords(XMLWriter ps, PageHeader ph) throws Exception {
			ArrayInputStream ais = new ArrayInputStream(_pageData);

			int recordCount = ph.getSlotsInUse();

			// largely cribbed from StoredPage.recordToString()
			ps.beginTag("records");
			{
				for (int slot = 0; slot < recordCount; slot++) {
					// we need this in order to look at the
					// RECORD_HAS_FIRST_FIELD status,
					// which is not exposed by StoredRecordHeader
					byte recordStatusByte = _pageData[getRecordOffset(slot)];
					StoredRecordHeader recordHeader = getRecordHeader(slot);
					int offset = getRecordOffset(slot);

					String attributes = "slot=" + doubleQuote(Integer.toString(slot)) + " offset=" + doubleQuote(Integer.toString(offset))
							+ " recordLength=" + doubleQuote(Integer.toString(getTotalSpace(ais, slot))) + " recordPortionLength="
							+ doubleQuote(Integer.toString(getRecordPortionLength(ais, slot))) + " reservedCount="
							+ doubleQuote(Integer.toString(getRecordPortionLength(ais, slot)));

					int fieldCount = recordHeader.getNumberFields();

					ps.beginTag("record", attributes);
					{
						ps.beginTag("recordHeader");
						{
							createIntElement(ps, "recordID", recordHeader.getId());

							if (recordHeader.hasOverflow()) {
								createLongElement(ps, "overflowPage", recordHeader.getOverflowPage());
								createIntElement(ps, "overflowID", recordHeader.getOverflowId());
							}

							createIntElement(ps, "firstField", recordHeader.getFirstField());

							createIntElement(ps, "fieldCount", fieldCount);
						}
						ps.endTag(); // recordHeader

						// move offset past record header to begin of first
						// field.
						offset += recordHeader.size();
						ais.setPosition(offset);

						if (fieldCount > 0) {
							// field layout is described in
							// StoredFieldHeader.write()
							ps.beginTag("fields");
							{
								for (int fieldIdx = 0; fieldIdx < fieldCount; fieldIdx++) {
									int fieldStatus = StoredFieldHeader.readStatus(ais);
									int fieldDataLength = StoredFieldHeader.readFieldDataLength(ais, fieldStatus, _slotFieldSize);
									int fieldDataOffset = ais.getPosition();

									String fieldAttributes = "number=" + doubleQuote(Integer.toString(fieldIdx));

									ps.beginTag("field", fieldAttributes);
									{
										formatFieldStatus(ps, fieldStatus);
										if (fieldDataLength < 0) {
											createTextElement(ps, "fieldOffset", "null");
										} else {
											createIntElement(ps, "fieldOffset", offset);
										}
										createIntElement(ps, "fieldDataLength", fieldDataLength);

										if (fieldDataLength >= 0) // not null?
										{
											if (StoredFieldHeader.isOverflow(fieldStatus)) {
												long overflowPage;
												int overflowId;

												// not likely to be a real
												// pointer, this is most
												// likely an old column chain
												// where the first field
												// is set to overflow even
												// though the second field
												// is the overflow pointer
												if (fieldIdx == 0 && fieldDataLength != 3) {
													// figure out where we
													// should go next
													offset = ais.getPosition() + fieldDataLength;
													overflowPage = CompressedNumber.readLong((DataInput) ais);
													overflowId = CompressedNumber.readInt((DataInput) ais);

													createTextElement(ps, "warning", "questionable long column");

													ais.setPosition(offset);
												} else {
													// print the overflow
													// pointer
													overflowPage = CompressedNumber.readLong((DataInput) ais);
													overflowId = CompressedNumber.readInt((DataInput) ais);
												}

												createLongElement(ps, "overflowPage", overflowPage);
												createIntElement(ps, "overflowID", overflowId);
											} // end if overflow
											else // not overflow
											{
												if (fieldDataLength > 0) {
													//
													// Can't deserialize the
													// data if the user hasn't
													// told us what the
													// datatypes
													// are.
													//
													// In addition, if the
													// RECORD_HAS_FIRST_FIELD
													// bit is set, the contents
													// might not be easy to
													// deserialize either.
													//
													if ((_rowSignature == null)
															|| (recordHasFirstField(recordStatusByte) && ((fieldCount == 1) || (fieldCount != _rowSignature.length)))) {
														createTextElement(ps, "byteData", stringifyFieldData(fieldDataOffset, fieldDataLength));
													} else {
														createTextElement(
																ps,
																"data",
																stringifyFieldData(slot, fieldIdx, fieldDataOffset, fieldDataLength,
																		_rowSignature[fieldIdx]));
													}
												}

												// go to next field
												offset = ais.getPosition() + fieldDataLength;
												ais.setPosition(offset);
											} // end if not overflow
										} // end if not null

									}
									ps.endTag(); // field
								} // end loop through fields
							}
							ps.endTag(); // fields
						} // end if there are fields

					}
					ps.endTag(); // record

				} // end of loop through records
			}
			ps.endTag(); // records
		}

		// copied from StoredPage
		private int calculateSlotFieldSize(int pageSize) {
			if (pageSize < 65536) {
				// slots are 2 bytes (unsigned short data type) for pages <64KB
				return SMALL_SLOT_SIZE;
			} else {
				// slots are 4 bytes (int data type) for pages >=64KB
				return LARGE_SLOT_SIZE;
			}
		}

		/** Get a record header */
		private StoredRecordHeader getRecordHeader(int slot) {
			return new StoredRecordHeader(_pageData, getRecordOffset(slot));
		}

		// copied from StoredPage
		private int getRecordOffset(int slot) {
			byte[] data = _pageData;
			int offset = _slotTableOffsetToFirstEntry - (slot * _slotEntrySize);

			// offset on the page of the record is stored in the first 2 or 4
			// bytes
			// of the slot table entry. Code has been inlined for performance
			// critical low level routine.
			//
			// return(
			// (slotFieldSize == SMALL_SLOT_SIZE) ?
			// readUnsignedShort() : readInt());

			return ((_slotFieldSize == SMALL_SLOT_SIZE) ?

			((data[offset++] & 0xff) << 8) | (data[offset] & 0xff) :

			(((data[offset++] & 0xff) << 24) | ((data[offset++] & 0xff) << 16) | ((data[offset++] & 0xff) << 8) | ((data[offset] & 0xff))));
		}

		// copied from StoredPage
		private int getTotalSpace(ArrayInputStream ais, int slot) throws Exception {
			// A slot entry looks like the following:
			// 1st field: offset of the record on the page
			// 2nd field: length of the record on the page
			// 3rd field: amount of space reserved for the record to grow.

			// position the read at the beginning of the 2nd field.
			ais.setPosition(getSlotOffset(slot) + _slotFieldSize);

			// return the size of the record + size of the reserved space.
			// the size of the fields to read is determined by slotFieldSize.

			return (((_slotFieldSize == SMALL_SLOT_SIZE) ? (ais.readUnsignedShort() + ais.readUnsignedShort()) : (ais.readInt() + ais.readInt())));
		}

		// copied from StoredPage
		private int getSlotOffset(int slot) {
			// slot table grows backward from the spot at the end of the page
			// just
			// before the checksum which is located in the last 8 bytes of the
			// page.

			return (_slotTableOffsetToFirstEntry - (slot * _slotEntrySize));
		}

		// copied from StoredPage
		private int getRecordPortionLength(ArrayInputStream ais, int slot) throws IOException {
			ais.setPosition(_slotTableOffsetToFirstRecordLengthField - (slot * _slotEntrySize));

			return ((_slotFieldSize == SMALL_SLOT_SIZE) ? ais.readUnsignedShort() : ais.readInt());
		}

		// copied from StoredPage
		private int getReservedCount(ArrayInputStream ais, int slot) throws IOException {
			ais.setPosition(_slotTableOffsetToFirstReservedSpaceField - (slot * _slotEntrySize));

			return ((_slotFieldSize == SMALL_SLOT_SIZE) ? ais.readUnsignedShort() : ais.readInt());
		}

		private void readChecksum(XMLWriter ps) throws Exception {
			int checksumLength = 8;

			String checksum = stringifyFieldData(_pageSize - checksumLength, checksumLength);
			createTextElement(ps, "checksum", checksum);
		}

		/**
		 * Search the data byte array for the first occurrence of the byte array
		 * pattern within given boundaries.
		 * 
		 * @param data
		 * @param start
		 *            First index in data
		 * @param stop
		 *            Last index in data so that stop-start = length
		 * @param pattern
		 *            What is being searched. '*' can be used as wildcard for
		 *            "ANY character"
		 * @return
		 */
		public static int indexOf(byte[] data, int start, int stop, byte[] pattern) {
			if (data == null || pattern == null)
				return -1;

			int[] failure = computeFailure(pattern);

			int j = 0;

			for (int i = start; i < stop; i++) {
				while (j > 0 && (pattern[j] != '*' && pattern[j] != data[i])) {
					j = failure[j - 1];
				}
				if (pattern[j] == '*' || pattern[j] == data[i]) {
					j++;
				}
				if (j == pattern.length) {
					return i - pattern.length + 1;
				}
			}
			return -1;
		}

		/**
		 * Computes the failure function using a boot-strapping process, where
		 * the pattern is matched against itself.
		 */
		private static int[] computeFailure(byte[] pattern) {
			int[] failure = new int[pattern.length];

			int j = 0;
			for (int i = 1; i < pattern.length; i++) {
				while (j > 0 && pattern[j] != pattern[i]) {
					j = failure[j - 1];
				}
				if (pattern[j] == pattern[i]) {
					j++;
				}
				failure[i] = j;
			}

			return failure;
		}

		private String stringifyFieldData(int offset, int length) throws Exception {
			StringBuilder buffer = new StringBuilder();

			for (int i = 0; i < length; i++) {
				if (i > 0) {
					buffer.append(" ");
				}
				buffer.append(Integer.toHexString(_pageData[offset + i]));
			}

			found.add(new String(_pageData, offset, length));
			if (new String(_pageData, offset, length).contains("SELECT")) {
				int indexOfMdx = indexOf(_pageData, offset, offset + length, "mdx".getBytes());
				// This index could be used in case we need to keep the original
				// byte array, and to search the MDX from there. However, we
				// don't know how to compute the size of the MDX given the byte
				// between 'mdx' and SELECT
			}
			return buffer.toString();
		}

		private String stringifyFieldData(int recordNumber, int fieldNumber, int offset, int length, DataTypeDescriptor dtd) throws Exception {
			try {
				byte[] bytes = new byte[length];
				System.arraycopy(_pageData, offset, bytes, 0, length);
				ArrayInputStream ais = new ArrayInputStream(bytes);

				DataValueDescriptor dvd = dtd.getNull();
				dvd.readExternalFromArray(ais);

				return dvd.toString();
			} catch (Exception e) {
				String errorMessage = "Error reading field data. Offset = " + offset + ", length = " + length + ", datatype = " + dtd.getSQLstring()
						+ ": " + getFieldCoordinates(recordNumber, fieldNumber) + ": " + formatThrowable(e);

				_errors.add(errorMessage);
				return errorMessage;
			}
		}

		/** Coordinates of field which confused us */
		private String getFieldCoordinates(int recordNumber, int fieldNumber) {
			return "Field " + fieldNumber + " in record " + recordNumber + " on page " + _pageNumber + getPageCoordinates();
		}

		/** Coordinates of page which confused us */
		private String getPageCoordinates() {
			return " on page " + _pageNumber + " in file " + _file.getName();
		}

		/** Format an error for printing */
		private String formatThrowable(Throwable e) {
			// e.printStackTrace();
			return e.getClass().getName() + ": " + e.getMessage();
		}

		private boolean isOverflowField(int fieldStatus) {
			return ((fieldStatus & FIELD_OVERFLOW) == FIELD_OVERFLOW);
		}

		private boolean isFieldNull(int fieldStatus) {
			return ((fieldStatus & FIELD_NULL) == FIELD_NULL);
		}

		private boolean hasOverflow(byte recordStatus) {
			return ((recordStatus & RECORD_OVERFLOW) == RECORD_OVERFLOW);
		}

		private boolean hasFirstField(byte recordStatus) {
			return ((recordStatus & RECORD_HAS_FIRST_FIELD) == RECORD_HAS_FIRST_FIELD);
		}

		private boolean isDeleted(byte recordStatus) {
			return ((recordStatus & RECORD_DELETED) == RECORD_DELETED);
		}

		private void formatFieldStatus(XMLWriter ps, int status) throws Exception {
			ps.beginTag("fieldStatus", "hexvalue=" + doubleQuote(Integer.toHexString(0xFF & status)));
			{
				String flag = "flag";

				int flagCount = 0;
				if (StoredFieldHeader.isNull(status)) {
					createTextElement(ps, flag, "FIELD_NULL");
					flagCount++;
				}
				if (StoredFieldHeader.isOverflow(status)) {
					createTextElement(ps, flag, "FIELD_OVERFLOW");
					flagCount++;
				}
				if (StoredFieldHeader.isNonexistent(status)) {
					createTextElement(ps, flag, "FIELD_NONEXISTENT");
					flagCount++;
				}
				if (StoredFieldHeader.isNullable(status)) {
					createTextElement(ps, flag, "FIELD_NULLABLE");
					flagCount++;
				}
				if (StoredFieldHeader.isExtensible(status)) {
					createTextElement(ps, flag, "FIELD_EXTENSIBLE");
					flagCount++;
				}
				if (StoredFieldHeader.isTagged(status)) {
					createTextElement(ps, flag, "FIELD_TAGGED");
					flagCount++;
				}
				if (StoredFieldHeader.isFixed(status)) {
					createTextElement(ps, flag, "FIELD_FIXED");
					flagCount++;
				}
				if (flagCount == 0) {
					createTextElement(ps, flag, "FIELD_INITIAL");
				}
			}
			ps.endTag(); // recordStatus
		}

		private void formatRecordStatus(XMLWriter ps, byte status) throws Exception {
			ps.beginTag("recordStatus", "hexvalue=" + doubleQuote(Integer.toHexString(0xFF & ((int) status))));
			{
				String flag = "flag";

				if ((status & RECORD_DELETED) != 0) {
					createTextElement(ps, flag, "RECORD_DELETED");
				}
				if ((status & RECORD_OVERFLOW) != 0) {
					createTextElement(ps, flag, "RECORD_OVERFLOW");
				}
				if ((status & RECORD_HAS_FIRST_FIELD) != 0) {
					createTextElement(ps, flag, "RECORD_HAS_FIRST_FIELD");
				}
				if ((status & ~RECORD_VALID_MASK) != 0) {
					createTextElement(ps, flag, "RECORD_INVALID");
				}
			}
			ps.endTag(); // recordStatus
		}

		private boolean recordHasFirstField(byte recordStatus) {
			return ((recordStatus & RECORD_HAS_FIRST_FIELD) != 0);
		}

		private void readAllocPage(XMLWriter ps, WrapperInputStream wis, int formatableID) throws Exception {
			DataInputStream dais = new DataInputStream(wis);
			if (formatableID != StoredFormatIds.RAW_STORE_ALLOC_PAGE) {
				throw new IOException("File header should start with formatable id " + StoredFormatIds.RAW_STORE_ALLOC_PAGE
						+ " but instead starts with formatable id " + formatableID);
			}

			String attributes = "number=" + doubleQuote(Long.toString(_pageNumber));

			ps.beginTag("allocPage", attributes);
			{
				createIntElement(ps, "formatableID", formatableID);
				readPageHeader(ps, dais);

				// documented in AllocPage.readAllocPageHeader()
				createLongElement(ps, "nextAllocPageNumber", dais.readLong());
				createLongElement(ps, "nextAllocPageOffset", dais.readLong());

				skipBytes(dais, 8 + 8 + 8 + 8);

				byte containerInfoLength = dais.readByte();

				createByteElement(ps, "containerInfoLength", containerInfoLength);
				if (containerInfoLength > (byte) 0) {
					readContainerInfo(ps, dais, containerInfoLength);
				}
				readAllocationExtent(ps, dais);
			}
			ps.endTag(); // allocPage
		}

		// for format, see AllocExtent.writeExternal()
		private void readAllocationExtent(XMLWriter ps, DataInputStream dais) throws Exception {
			ps.beginTag("allocationExtent");
			{
				createLongElement(ps, "extentOffset", dais.readLong());
				createLongElement(ps, "extentStart", dais.readLong());
				createLongElement(ps, "extentEnd", dais.readLong());

				int extentLength = dais.readInt();

				createIntElement(ps, "extentLength", extentLength);
				formatExtentStatus(ps, dais.readInt());
				createIntElement(ps, "preAllocLength", dais.readInt());
				createIntElement(ps, "reserved1", dais.readInt());
				createLongElement(ps, "reserved2", dais.readLong());
				createLongElement(ps, "reserved3", dais.readLong());

				FormatableBitSet freePages = readBitSet(dais);
				FormatableBitSet unFilledPages = readBitSet(dais);

				formatBitSet(ps, "freePages", freePages);
				formatBitSet(ps, "unFilledPages", unFilledPages);
			}
			ps.endTag(); // allocationExtent
		}

		private FormatableBitSet readBitSet(DataInputStream dais) throws Exception {
			int lenInBits = dais.readInt();
			int lenInBytes = (lenInBits + 7) >> 3;

			byte[] value = new byte[lenInBytes];

			dais.readFully(value);

			return new FormatableBitSet(value);
		}

		// see FileContainer.writeHeaderToArray() for the format of the
		// container descriptor
		private void readContainerInfo(XMLWriter ps, DataInputStream dais, byte containerInfoLength) throws Exception {
			int formatableID = dais.readInt();
			if (formatableID != StoredFormatIds.RAW_STORE_SINGLE_CONTAINER_FILE) {
				throw new IOException("Container info should start with formatable id " + StoredFormatIds.RAW_STORE_SINGLE_CONTAINER_FILE
						+ " but instead starts with formatable id " + formatableID);

			}

			ps.beginTag("containerInfo");
			{
				createIntElement(ps, "formatableID", formatableID);
				formatContainerStatus(ps, dais.readInt());

				_pageSize = dais.readInt();

				_slotFieldSize = calculateSlotFieldSize(_pageSize);
				_slotEntrySize = 3 * _slotFieldSize;
				_slotTableOffsetToFirstEntry = _pageSize - CHECKSUM_SIZE - _slotEntrySize;
				_slotTableOffsetToFirstRecordLengthField = _slotTableOffsetToFirstEntry + _slotFieldSize;
				_slotTableOffsetToFirstReservedSpaceField = _slotTableOffsetToFirstEntry + (2 * _slotFieldSize);

				createIntElement(ps, "pageSize", _pageSize);
				createIntElement(ps, "spareSpace", dais.readInt());
				createIntElement(ps, "minimumRecordSize", dais.readInt());
				createShortElement(ps, "initialPages", dais.readShort());
				createShortElement(ps, "preAllocSize", dais.readShort());
				createLongElement(ps, "firstAllocPageNumber", dais.readLong());
				createLongElement(ps, "firstAllocPageOffset", dais.readLong());
				createLongElement(ps, "containerVersion", dais.readLong());
				createLongElement(ps, "estimatedRowCount", dais.readLong());
				createLongElement(ps, "reusableRecordIdSequenceNumber", dais.readLong());
				createLongElement(ps, "spare", dais.readLong());
				createLongElement(ps, "checksum", dais.readLong());
			}
			ps.endTag(); // containerInfo
		}

		// format is documented in StoredPage.readPageHeader()
		private PageHeader readPageHeader(XMLWriter ps, DataInputStream dais) throws Exception {
			PageHeader ph = new PageHeader(dais);

			ps.beginTag("pageHeader");
			{
				createBooleanElement(ps, "isOverFlowPage", ph.isOverFlowPage());
				formatPageStatus(ps, ph.getPageStatus());
				createLongElement(ps, "pageVersion", ph.getPageVersion());
				createIntElement(ps, "slotsInUse", ph.getSlotsInUse());
				createIntElement(ps, "nextRecordID", ph.getNextRecordID());
				createIntElement(ps, "pageGeneration", ph.getPageGeneration());
				createIntElement(ps, "previousGeneration", ph.getPreviousGeneration());
				createLongElement(ps, "beforeImagePageLocation", ph.getBeforeImagePageLocation());
				createIntElement(ps, "deletedRowCount", ph.getDeletedRowCount());
			}
			ps.endTag(); // pageHeader

			return ph;
		}

		private void formatBitSet(XMLWriter ps, String tag, FormatableBitSet bitSet) throws Exception {
			int totalLength = bitSet.getLength();

			int bitsThatAreSet = 0;
			for (int i = 0; i < totalLength; i++) {
				if (bitSet.isSet(i)) {
					bitsThatAreSet++;
				}
			}

			String attributes = "totalLength=" + doubleQuote(Integer.toString(totalLength)) + " bitsThatAreSet="
					+ doubleQuote(Integer.toString(bitsThatAreSet));
			ps.writeEmptyTag(tag, attributes);
		}

		private void formatExtentStatus(XMLWriter ps, int status) throws Exception {
			ps.beginTag("extentStatus", "hexvalue=" + doubleQuote(Integer.toHexString(status)));
			{
				String flag = "flag";

				if ((status & HAS_DEALLOCATED) != 0) {
					createTextElement(ps, flag, "HAS_DEALLOCATED");
				}
				if ((status & HAS_FREE) != 0) {
					createTextElement(ps, flag, "HAS_FREE");
				}
				if ((status & ALL_FREE) != 0) {
					createTextElement(ps, flag, "ALL_FREE");
				}
				if ((status & HAS_UNFILLED_PAGES) != 0) {
					createTextElement(ps, flag, "HAS_UNFILLED_PAGES");
				}
				if ((status & KEEP_UNFILLED_PAGES) != 0) {
					createTextElement(ps, flag, "KEEP_UNFILLED_PAGES");
				}
				if ((status & NO_DEALLOC_PAGE_MAP) != 0) {
					createTextElement(ps, flag, "NO_DEALLOC_PAGE_MAP");
				}
				if ((status & RETIRED) != 0) {
					createTextElement(ps, flag, "RETIRED");
				}
			}
			ps.endTag(); // extentStatus
		}

		private void formatContainerStatus(XMLWriter ps, int status) throws Exception {
			ps.beginTag("containerStatus", "hexvalue=" + doubleQuote(Integer.toHexString(status)));
			{
				String flag = "flag";

				if ((status & FILE_DROPPED) != 0) {
					createTextElement(ps, flag, "FILE_DROPPED");
				}
				if ((status & FILE_COMMITTED_DROP) != 0) {
					createTextElement(ps, flag, "FILE_COMMITTED_DROP");
				}
				if ((status & FILE_REUSABLE_RECORDID) != 0) {
					createTextElement(ps, flag, "FILE_REUSABLE_RECORDID");
				}
			}
			ps.endTag(); // containerStatus
		}

		private void formatPageStatus(XMLWriter ps, byte status) throws Exception {
			ps.beginTag("status", "hexvalue=" + doubleQuote(Integer.toHexString(0xFF & ((int) status))));
			{
				String flag = "flag";

				if ((status & VALID_PAGE) != 0) {
					createTextElement(ps, flag, "VALID_PAGE");
				}
				if ((status & INVALID_PAGE) != 0) {
					createTextElement(ps, flag, "INVALID_PAGE");
				}
			}
			ps.endTag(); // status
		}

		private void formatErrors(XMLWriter ps) throws Exception {
			if (_errors.size() == 0) {
				return;
			}

			StringBuilder buffer = new StringBuilder();

			for (String error : _errors) {
				buffer.append(error + "\n");
			}

			createTextElement(ps, "errors", buffer.toString());
		}

		private void createBooleanElement(XMLWriter ps, String tag, boolean value) throws Exception {
			createTextElement(ps, tag, Boolean.toString(value));
		}

		private void createLongElement(XMLWriter ps, String tag, long value) throws Exception {
			createTextElement(ps, tag, Long.toString(value));
		}

		private void createIntElement(XMLWriter ps, String tag, int value) throws Exception {
			createTextElement(ps, tag, Integer.toString(value));
		}

		private void createShortElement(XMLWriter ps, String tag, short value) throws Exception {
			createTextElement(ps, tag, Short.toString(value));
		}

		private void createByteElement(XMLWriter ps, String tag, byte value) throws Exception {
			createTextElement(ps, tag, Byte.toString(value));
		}

		private void createTextElement(XMLWriter ps, String tag, String text) throws Exception {
			ps.writeTextElement(tag, text);
		}

		private String doubleQuote(String text) {
			return "\"" + text + "\"";
		}

	}

	// //////////////////////////////////////////////////////////////////////
	//
	// PAGE HEADER
	//
	// //////////////////////////////////////////////////////////////////////

	public static final class PageHeader {
		private boolean _isOverFlowPage;
		private byte _pageStatus;
		private long _pageVersion;
		private int _slotsInUse;
		private int _nextRecordID;
		private int _pageGeneration;
		private int _previousGeneration;
		private long _beforeImagePageLocation;
		private int _deletedRowCount;

		public PageHeader(DataInputStream dais) throws Exception {
			_isOverFlowPage = dais.readBoolean();
			_pageStatus = dais.readByte();
			_pageVersion = dais.readLong();
			_slotsInUse = dais.readUnsignedShort();
			_nextRecordID = dais.readInt();
			_pageGeneration = dais.readInt();
			_previousGeneration = dais.readInt();
			_beforeImagePageLocation = dais.readLong();
			_deletedRowCount = dais.readUnsignedShort();

			skipBytes(dais, 2 + 4 + 8 + 8);
		}

		public boolean isOverFlowPage() {
			return _isOverFlowPage;
		}

		public byte getPageStatus() {
			return _pageStatus;
		}

		public long getPageVersion() {
			return _pageVersion;
		}

		public int getSlotsInUse() {
			return _slotsInUse;
		}

		public int getNextRecordID() {
			return _nextRecordID;
		}

		public int getPageGeneration() {
			return _pageGeneration;
		}

		public int getPreviousGeneration() {
			return _previousGeneration;
		}

		public long getBeforeImagePageLocation() {
			return _beforeImagePageLocation;
		}

		public int getDeletedRowCount() {
			return _deletedRowCount;
		}
	}

	// //////////////////////////////////////////////////////////////////////
	//
	// ENTRY IN THE SLOT TABLE
	//
	// //////////////////////////////////////////////////////////////////////

	public static final class Slot {
		private int _slotNumber;
		private int _offset;
		private int _length;
		private int _reservedBytes;

		public Slot(int slotNumber, int offset, int length, int reservedBytes) {
			_slotNumber = slotNumber;
			_offset = offset;
			_length = length;
			_reservedBytes = reservedBytes;
		}

		public int getSlotNumber() {
			return _slotNumber;
		}

		public int getOffset() {
			return _offset;
		}

		public int getLength() {
			return _length;
		}

		public int getReservedBytes() {
			return _reservedBytes;
		}
	}

	// //////////////////////////////////////////////////////////////////////
	//
	// MACHINE FOR STREAMING XML TO SYSTEM OUT
	//
	// //////////////////////////////////////////////////////////////////////

	/**
	 * <p>
	 * XML-writing wrapper around a PrintStream.
	 * </p>
	 */
	public static final class XMLWriter {
		private static final String TAB_STOP = "    ";

		// If this boolean is set, then all operations are NOPs.
		private boolean _vacuous;

		private PrintStream _pw;
		private ArrayList<String> _tagStack;

		/**
		 * <p>
		 * Special constructor for making a vacuous writer which doesn't do
		 * anything. This allows us to write easy-to-read dita-generating code
		 * that is not cluttered with "if ( documented )" conditionals.
		 * </p>
		 */
		public XMLWriter() {
			_vacuous = true;
		}

		/**
		 * <p>
		 * Create a productive writer which actually flushes text to a
		 * PrintStream.
		 * </p>
		 */
		public XMLWriter(PrintStream printStream) throws IOException {
			_vacuous = false;
			_pw = printStream;
			_tagStack = new ArrayList<String>();
		}

		public void flush() throws IOException {
			if (_vacuous) {
				return;
			}

			_pw.flush();
		}

		public void close() throws IOException {
		}

		/**
		 * <p>
		 * Indent and write an empty tag.
		 * </p>
		 */
		public void writeEmptyTag(String tag) throws IOException {
			if (_vacuous) {
				return;
			}

			writeEmptyTag(tag, "");
		}

		/**
		 * <p>
		 * Indent and write an empty tag with attributes.
		 * </p>
		 */
		public void writeEmptyTag(String tag, String attributes) throws IOException {
			if (_vacuous) {
				return;
			}

			indent();
			if (attributes.length() > 0)
				_pw.println("<" + tag + " " + attributes + "/>");
			else
				_pw.println("<" + tag + "/>");
		}

		/**
		 * <p>
		 * Indent and write an opening tag.
		 * </p>
		 */
		public void beginTag(String tag) throws IOException {
			if (_vacuous) {
				return;
			}

			beginTag(tag, "");
		}

		/**
		 * <p>
		 * Indent and write an opening tag.
		 * </p>
		 */
		public void beginTag(String tag, String attributes) throws IOException {
			if (_vacuous) {
				return;
			}

			indent();
			if (attributes.length() > 0)
				_pw.println("<" + tag + " " + attributes + ">");
			else
				_pw.println("<" + tag + ">");

			_tagStack.add(tag);
		}

		/**
		 * <p>
		 * Indent and write a closing tag.
		 * </p>
		 */
		public void endTag() throws IOException {
			if (_vacuous) {
				return;
			}

			String tag = _tagStack.remove(_tagStack.size() - 1);

			indent();

			_pw.println("</" + tag + ">");
		}

		/**
		 * <p>
		 * Indent and write a whole element
		 * </p>
		 */
		public void writeTextElement(String tag, String text) throws IOException {
			if (_vacuous) {
				return;
			}

			writeTextElement(tag, "", text);
		}

		/**
		 * <p>
		 * Indent and write a whole element
		 * </p>
		 */
		public void writeTextElement(String tag, String attributes, String text) throws IOException {
			if (_vacuous) {
				return;
			}

			indent();
			if (attributes.length() > 0)
				_pw.print("<" + tag + " " + attributes + ">");
			else
				_pw.print("<" + tag + ">");
			_pw.print(text);
			_pw.println("</" + tag + ">");
		}

		/**
		 * <p>
		 * Indent based on the depth of our tag nesting level.
		 * </p>
		 */
		public void indent() throws IOException {
			if (_vacuous) {
				return;
			}

			int tabCount = _tagStack.size();

			for (int i = 0; i < tabCount; i++) {
				_pw.print(TAB_STOP);
			}
		}

		/**
		 * <p>
		 * Print text.
		 * </p>
		 */
		public void println(String text) throws IOException {
			if (_vacuous) {
				return;
			}

			_pw.println(text);
		}

	}

	// //////////////////////////////////////////////////////////////////////
	//
	// Other helper classes.
	//
	// //////////////////////////////////////////////////////////////////////

	//
	// Used to keep track of where we are in the input stream.
	//
	public static final class WrapperInputStream extends InputStream {
		private InputStream _wrapped;
		private long _bytesRead;

		public WrapperInputStream(InputStream is) {
			_wrapped = is;
			_bytesRead = 0L;
		}

		public int read() throws IOException {
			int retval = _wrapped.read();

			if (retval >= 0) {
				_bytesRead++;
			}

			return retval;
		}

		public long getBytesRead() {
			return _bytesRead;
		}
	}

	//
	// Used to get some protected constants out of a class.
	//
	public static final class AllocPagePeeker extends org.apache.derby.impl.store.raw.data.AllocPage {
		public static int getBorrowedSpaceOffset() {
			return BORROWED_SPACE_OFFSET;
		}

		public static int getPageHeaderOffset() {
			return PAGE_HEADER_OFFSET;
		}
	}

	// //////////////////////////////////////////////////////////////////////
	//
	// /dev/null
	//
	// //////////////////////////////////////////////////////////////////////

	public static final class DevNull extends OutputStream {
		public void write(int b) {
		}
	}
}

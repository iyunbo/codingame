/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.live.datastore.client.datastore;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.junit.Ignore;
import org.junit.Test;
import org.mockito.Mockito;

import blasd.apex.live.datastore.client.datastore.DatastoreViewerPanel;

import com.google.gwt.junit.client.GWTTestCase;
import com.quartetfs.pivot.live.client.mdx.IMdxModelSwitch;
import com.quartetfs.pivot.live.core.client.cmd.ICommandExecutorAsync;
import com.quartetfs.pivot.live.core.client.event.IEventBus;

@Ignore
public class TestDatastoreViewerPanel extends GWTTestCase {
	@Test
	public void testPanel() {
		IEventBus eventBus = Mockito.mock(IEventBus.class);
		ICommandExecutorAsync commandExecutorAsync = Mockito.mock(ICommandExecutorAsync.class);
		IMdxModelSwitch mdxModelSwitch = Mockito.mock(IMdxModelSwitch.class);

		DatastoreViewerPanel panel = new DatastoreViewerPanel(eventBus, commandExecutorAsync, mdxModelSwitch);

		Set<String> selectedColumns = new HashSet<String>(Arrays.asList("c1", "c2", "c3"));
		Set<String> keyColumns = new HashSet<String>(Arrays.asList("c2", "c3"));

		panel.onStoreSelected("selectedStore", selectedColumns, keyColumns);
	}

	@Override
	public String getModuleName() {
		return "blasd.apex.live.datastore.DatastoreViewer";
	}
}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.live.client.rightlick;

import com.quartetfs.pivot.live.core.shared.setting.ISetting;
import com.quartetfs.pivot.live.core.shared.setting.InitialSetting;

/**
 * As there is some issues with {@link InitialSetting} delayed loading, it seems
 * better to systematically load them at startup
 * 
 * @author Benoit Lacelle
 * 
 */
public interface IApexInitialSettings {
	/**
	 * The {@link ISetting} key defining if a user has access to admin tools or
	 * not
	 */
	@InitialSetting
	String SETTING_APE_ADMIN = "role.apex.admin";
}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.live.client.rightlick;

import java.util.ArrayList;
import java.util.List;

import blasd.apex.live.datastore.client.datastore.DatastoreViewerCommand;

import com.google.inject.Inject;
import com.google.inject.Provider;
import com.quartetfs.pivot.live.client.desktop.dashboard.mdx.impl.StorableMdxWidgetSelectorPresenter;
import com.quartetfs.pivot.live.client.desktop.dashboard.widget.pivot.impl.PivotViewPluginAddinProvider;
import com.quartetfs.pivot.live.client.realtime.IRealtimeConstants;
import com.quartetfs.pivot.live.client.realtime.IRealtimeResources;
import com.quartetfs.pivot.live.core.client.cmd.ICommandExecutorAsync;
import com.quartetfs.pivot.live.core.client.event.IEventBus;
import com.quartetfs.pivot.live.core.client.event.Main;
import com.quartetfs.pivot.live.core.client.settting.ISettingProvider;
import com.quartetfs.pivot.live.core.client.widget.addin.IAddinPresenter;
import com.quartetfs.pivot.live.core.client.widget.addin.IAddinView;
import com.quartetfs.pivot.live.core.client.widget.addin.impl.CommandAddinPresenter;
import com.quartetfs.pivot.live.core.shared.setting.ISetting;
import com.quartetfs.pivot.live.core.shared.setting.impl.BooleanSetting;

public class ApexShowcasePivotViewPluginProvider extends PivotViewPluginAddinProvider {

	protected final Provider<DatastoreViewerCommand> datastoreViewerCommandProvider;

	protected final boolean isAdmin;

	@Inject
	public ApexShowcasePivotViewPluginProvider(@Main IEventBus eventBus, ICommandExecutorAsync cmdExecutor, ISettingProvider settingProvider,
			IRealtimeResources realtimeResources, IRealtimeConstants realtimeConstants,
			Provider<DatastoreViewerCommand> datastoreViewerCommandProvider) {
		super(eventBus, cmdExecutor, settingProvider, realtimeResources, realtimeConstants);

		this.datastoreViewerCommandProvider = datastoreViewerCommandProvider;

		ISetting<Boolean> isAdminSetting = settingProvider.instantValue(BooleanSetting.TYPE, IApexInitialSettings.SETTING_APE_ADMIN);

		if (isAdminSetting != null && Boolean.TRUE.equals(isAdminSetting.getValue())) {
			isAdmin = true;
		} else {
			isAdmin = false;
		}
	}

	@Override
	public List<IAddinPresenter<? extends IAddinView>> createAddins(StorableMdxWidgetSelectorPresenter presenter) {
		List<IAddinPresenter<? extends IAddinView>> addins = new ArrayList<IAddinPresenter<? extends IAddinView>>();

		if (isAdmin) {
			addins.add(new CommandAddinPresenter("Datastore Viewer", datastoreViewerCommandProvider.get()));
		}

		// keep the addins defined in the core product
		addins.addAll(super.createAddins(presenter));

		return addins;
	};

}
[![Build Status](https://travis-ci.com/blasd/apex.svg?token=ghVoZrM9LWCSNPczn97T&branch=master)](https://travis-ci.com/blasd/apex)

# apex
## Live
### ActiveUI
We provide barely no logic for ActiveUI.

This package is helpful if want want to integrate a vanila ActiveUI at barely no-cost. ActiveUI is then available through /ui/index.html

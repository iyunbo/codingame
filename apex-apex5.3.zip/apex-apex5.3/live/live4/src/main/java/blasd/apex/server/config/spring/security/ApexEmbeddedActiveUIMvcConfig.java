/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.spring.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.web.servlet.config.annotation.DefaultServletHandlerConfigurer;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.google.common.base.Joiner;

/**
 * Single configuratin fo enable Active UI as static ressources available through any server, including a full-fledged
 * ActivePivot
 * 
 * @author Benoit Lacelle
 *
 */
// http://stackoverflow.com/questions/14299149/how-to-use-spring-mvcs-mvcresources-tag-in-a-java-application-context/17013442#17013442
@Configuration
@EnableWebMvc
public class ApexEmbeddedActiveUIMvcConfig implements WebMvcConfigurer, IApexSecurityConstants {

	// Update pom.xml with this value
	private static final String VERSION_REACT = "16.3.2";

	@Autowired
	protected Environment env;

	// equivalents for <mvc:resources/> tags
	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		registry.addResourceHandler(getLiveServlet())
				.addResourceLocations(getLiveResources())
				.setCachePeriod(getLiveCachePeriod());
	}

	protected Integer getLiveCachePeriod() {
		return env.getProperty("apex.live.cacheInSeconds", Integer.class, DEFAULT_MVC_CACHE_SECONDS);
	}

	protected String[] getLiveResources() {
		// https://support.activeviam.com/documentation/activeui/4.2.0/dev/setup/maven-integration.html
		// ActiveUI SDK UMD scripts and supporting assets
		return env
				.getProperty("apex.live.resources",
						Joiner.on('|')
								.join("classpath:/static/activeui/",
										"classpath:META-INF/resources/activeui/",
										"classpath:META-INF/resources/activeviam/activeui-sdk/",
										"classpath:META-INF/resources/webjars/react/" + VERSION_REACT + "/umd/",
										"classpath:META-INF/resources/webjars/react-dom/" + VERSION_REACT + "/umd/"))
				.split("\\|");
	}

	protected String getLiveNamespace() {
		return env.getProperty("apex.live.servlet", ApexEmbeddedActiveUISecurityConfig.ACTIVEUI_SERVLET_FOLDER);
	}

	protected String getLiveServlet() {
		return "/" + getLiveNamespace() + SPRING_MATCH_ALL;
	}

	// equivalent for <mvc:default-servlet-handler/> tag
	@Override
	public void configureDefaultServletHandling(DefaultServletHandlerConfigurer configurer) {
		if (enableDefaultServletHandling()) {
			// http://stackoverflow.com/questions/8023203/how-to-use-default-servlet-handler
			// TODO: do NOT redirect to DISPATCHER_SERVLET_NAME else we would have StackOverflow as not-handled
			// requests would be exchanged indefinitely between Spring and webapp main servlet
			configurer.enable();
		}
	}

	protected boolean enableDefaultServletHandling() {
		// By default, we consider there is no resources served directly by the servlet. It appears some projects have
		// no default servlet???
		// TODO find the proper default servlet under jetty
		return false;
	}

	@Override
	public void addViewControllers(ViewControllerRegistry registry) {
		String prefix = "/" + getLiveNamespace();
		String fullIndexHtml = prefix + "/index.html";
		registry.addRedirectViewController(prefix, fullIndexHtml);
		registry.addRedirectViewController(prefix + "/", fullIndexHtml);
	}
}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.spring.security;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

/**
 * Embedded Live requires an additional filter: JwtFilter
 * 
 * @author Benoit Lacelle
 *
 */
@Profile(IApexSecurityConstants.SPRING_PROFILE_NOT_DISCONNECTED)
@Configuration
@EnableWebSecurity
@Order(IApexSecurityConstants.EMBEDDED_LIVE_FILTER_ORDER)
public class ApexEmbeddedActiveUISecurityConfig extends WebSecurityConfigurerAdapter implements IApexSecurityConstants {
	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexEmbeddedActiveUISecurityConfig.class);

	public static final String USER_GUEST = "apexGuest";

	// Follow sandbox servlet name
	// https://support.activeviam.com/confluence/pages/viewpage.action?pageId=27859978
	public static final String ACTIVEUI_SERVLET_FOLDER = "ui";

	@Override
	public void configure(HttpSecurity http) throws Exception {
		ApexWebSecurityHelper.noCsrfWithCorsWithJwtWithLogout(getApplicationContext(), http, false);

		final String url = ApexWebSecurityHelper.matchNamespace(ACTIVEUI_SERVLET_FOLDER);

		// These static resources are fully available
		http.mvcMatcher(url).authorizeRequests().anyRequest().permitAll();

		// Authorizing pages to be embedded in iframes to have ActivePivot Live in Sentinel UI or monitoring HTML
		http.headers().frameOptions().disable();
	}
}

[![Build Status](https://travis-ci.com/blasd/apex.svg?token=ghVoZrM9LWCSNPczn97T&branch=master)](https://travis-ci.com/blasd/apex)

# apex

## Live
Holds a package for Live3 (based on GWT http://www.gwtproject.org/) and Live4 (based on React https://facebook.github.io/react/)


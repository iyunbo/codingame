[![Build Status](https://travis-ci.com/blasd/apex.svg?token=ghVoZrM9LWCSNPczn97T&branch=master)](https://travis-ci.com/blasd/apex)
[![Quality Gate](https://sonarqube.com/api/badges/gate?key=com.github.blasd.apex:apex)](https://sonarqube.com/dashboard/index/com.github.blasd.apex:apex)
[![Technical debt ratio](https://sonarqube.com/api/badges/measure?key=com.github.blasd.apex:apex&metric=sqale_debt_ratio)](https://sonarqube.com/dashboard/index/com.github.blasd.apex:apex)

# apex

Extentions for ActiveViam ActivePivot

## Apex release process:
	
    mvn clean install -Pfull
    mvn release:clean release:prepare release:perform -Darguments="-DskipTests"
## Deploy ActivePivot jars through maven

After having downloaded ActivePivot maven repository as a .zip one, unzip it locally open a Git bash (if you are udner Windows, else any Linux shell would work):

    cd metadata/script/deploy
    ./deploy_to_<entity>.sh /root/folder/maven-repository-5.X.Y/
    
The script will check for the existence of the pom/jar in your Nexus|Artifactory|... repository before trying to deploy it.
    
## Server
### Post-Processor
#### ManyToMany
If you need one fact to contribute to several members (e.g. France to contribute in the members G8 and Europe), you should use the [RebucketingPostProcessor](server/query/src/main/java/blasd/apex/server/query/postprocessor/bucket/RebucketingPostProcessor.java) and [AManyToManyRebucketingPostProcessor](server/query/src/main/java/blasd/apex/server/query/postprocessor/bucket/AManyToManyRebucketingPostProcessor.java) (see [DatastoreManyToManyPostProcessor](server/query/src/main/java/blasd/apex/server/query/postprocessor/bucket/DatastoreManyToManyPostProcessor.java) for a concrete example).

#### Analysis Dimension
If one configure your cubes programmatically, you can add a static analysis hierarchy (i.e. an analysis hierarchy with a predefined set of coordinates) in a single row:

		IActivePivotDescription activePivotDescription = ...;
		IApexCubeBuilder cubeBuilder = ApexCubeBuilder.editDescriptionactivePivotDescription();
        
		ApexStaticAnalysisHierarchyBuilder staticAnalysisHierarchy = ApexStaticAnalysisHierarchy
				.addStaticAnalysisHierarchy(cubeBuilder, "Scenarios");
		staticAnalysisHierarchy.withAllMember();

		IntStream.range(0, 250).forEach(scenarioIndex -> staticAnalysisHierarchy
				.addPath(Arrays.asList("ScenarioName_" + scenarioIndex, scenarioIndex)));
                
It is also straightforward to build an analysis hierarchy following some datastore content:

		ApexDatastoreAnalysisHierarchyBuilder countryGroupHierarchy = ApexDatastoreAnalysisHierarchy
			.addDatastoreAnalysisHierarchy(cubeBuilder, "anyCube");
		countryGroupHierarchy.withAllMember();

		countryGroupHierarchy.setStoreName("countryGroupsStore");
		countryGroupHierarchy.setColumnNames("country", "countryGroup");
		countryGroupHierarchy.setSearchTemplate(ImmutableMap.of("groupType", "Official"));

It may be preferable rely on the core mechanism to build the analysis hierarchy as a factless hierarchy over any store (e.g. even a store not joined with the base store), especially if you do not use ApexDatastoreAnalysisHierarchyBuilder.setSearchTemplate to filter the pathes reported in the analysis hierarchy.


## Monitoring
One can easily track any queries running into ActivePivot by activating ApexActivePivotQueryExecutor. Then, all queries will be reported into ApexMetricsTowerControl (which is available as a MBean) which will log automatically long-running queries.
[One-shot query Monitoring](server/monitoring/src/main/java/blasd/apex/server/monitoring/query/ApexActivePivotQueryExecutor.java)

    ActivePivotDescription.setQueryExecutor(new PluginDefinition(ApexActivePivotQueryExecutor.PLUGIN_KEY))

Custom code is able to hook into the underlying EventBus in order to be called-back on query events. Here is an example to log any MDX queries to a file:

	@Bean
	public ApexMdxLogWriter apexMdxWriter(EventBus eventBus) throws IOException {
		ApexMdxLogWriter fileWriter = new ApexMdxLogWriter(Files.createTempFile("apex.mdx.", ".csv"));

		eventBus.register(fileWriter);

		return fileWriter;
	}


[ApexMdxLogWriter](server/monitoring/src/main/java/blasd/apex/server/monitoring/query/mdx/ApexMdxLogWriter.java)

    public class ApexMdxLogWriter  {
    
        @Subscribe
        @AllowConcurrentEvents
        public void onMdxQuery(EndMetricEvent endEvent) {
            if (endEvent.source instanceof IMDXQuery) {
                IMDXQuery mdxQuery = (IMDXQuery) endEvent.source;

                final Object entryPoint = endEvent.startEvent.getDetail(StartMetricEvent.KEY_CLIENT);

                if (entryPoint != null) {
                    final Object pivotId = endEvent.startEvent.getDetail(StartMetricEvent.KEY_PIVOT_ID);
                    final String mdx = getMdx(mdxQuery);
                    final Object userName = endEvent.startEvent.getDetail(StartMetricEvent.KEY_USERNAME);
                    final long startTime = endEvent.startEvent.startTime;
                    final long durationInMs = endEvent.durationInMs();
                    final Object resultSize = endEvent.startEvent.getDetail(EndMetricEvent.KEY_RESULT_SIZE);

                    appendToFile(pivotId, mdx, userName, entryPoint, startTime, durationInMs, resultSize);
                }
            }
        }

    }

Memory footprint analysis:

ApexActivePivotMemoryTowerControl enables through the JConsole an overview of which data-structure consumes memory.


[Transaction Monitoring](server/monitoring/src/main/java/blasd/apex/server/monitoring/loading/MonitorableTransactionManager.java) (see [Transaction ApexDatastoreConfig](server/config/src/main/java/blasd/apex/server/config/spring/ApexDatastoreConfig.java) for wiring).

[QueryTowerControl](server/monitoring/src/main/java/blasd/apex/server/monitoring/query/QueryTowerControl.java) Insights about compute time per measures, queries falling out of any Partial

## ActiveUI
Apex does not propose any features for ActiveUI. We just provide drop-in SpringConfiguration to enable ActiveUI without any configuration:

    @Configuration
    @Import(value = {
		// Add Live as static resource
		ApexEmbeddedActiveUIMvcConfig.class,
		ApexEmbeddedActiveUISecurityConfig.class })
    public class CustomActiveUI {

    }



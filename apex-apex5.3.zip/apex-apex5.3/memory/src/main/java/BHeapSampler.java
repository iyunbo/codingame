/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
// Warning: No line numbers available in class file

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.zip.GZIPInputStream;

public class BHeapSampler {
   private static String[] a = new String[]{"", "string", "load_class", "unload_class", "stack_frame", "stack_trace", "alloc_sites", "heap_summary", "", "", "start_thread", "end_thread", "heap_dump", "cpu_samples", "control_settings", "", "", "", "", "", "", "", "", "", "", "", "", "", "heap_dump_segment", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "heap_dump_end", "", "", ""};
   private static String[] b = new String[]{"ROOT UNKNOWN", "ROOT JNI GLOBAL", "ROOT JNI LOCAL", "ROOT JAVA FRAME", "ROOT NATIVE STACK", "ROOT STICKY CLASS", "ROOT THREAD BLOCK", "ROOT MONITOR USED", "ROOT THREAD OBJECT", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "CLASS DUMP", "INSTANCE-DUMP", "OBJECT_ARRAY-DUMP", "PRIMITIVE_ARRAY-DUMP"};
   private static long[] c;
   private static long[] d;
   private static HashMap e;
   private static HashMap f;
   private static HashMap g;
   private static b h;
   private static DataInputStream i;
   private static long j;
   private static int k;
   private static int l;
   private static boolean m;
   private static double n;
   private static boolean o;
   private static boolean p;
   private static boolean q;

   public static void main(String[] arg) {
      System.out.println("BHeapSampler 1.3 / 2012 / Dr. Arndt Brenschede");
      if(arg.length >= 1 && arg.length <= 5) {
         String arg0 = arg[0];
         String arg1;
         if(arg.length > 1) {
            arg1 = arg[1].toUpperCase();
            if("SHORT".equals(arg1)) {
               o = false;
            } else {
               if(!"RANDOM".equals(arg1)) {
                  throw new IllegalArgumentException("invalid path-selection: " + arg1);
               }

               o = true;
            }
         }

         if(arg.length > 2) {
            arg1 = arg[2].toUpperCase();
            if("NONE".equals(arg1)) {
               p = false;
               q = false;
            } else if("INSTANCE".equals(arg1)) {
               p = true;
               q = false;
            } else {
               if(!"CLASS".equals(arg1)) {
                  throw new IllegalArgumentException("invalid path-unification: " + arg1);
               }

               p = true;
               q = true;
            }
         }

         if(arg.length > 3) {
            n = Double.parseDouble(arg[3]);
         }

         if(arg.length > 4) {
            g.a = Integer.parseInt(arg[4]);
         }

         if(arg0.endsWith(".txt")) {
            a(arg0);
         } else {
            c();

            for(l = 0; l < 3; ++l) {
               if(l == 1) {
                  a();
               }

               if(l == 2) {
                  d();
               }

               a(arg0);
            }

            if(n == 0.0D) {
               double[] arg8 = new double[]{1000.0D, 500.0D, 200.0D, 100.0D, 50.0D, 20.0D, 10.0D, 5.0D, 2.0D, 1.0D, 0.5D, 0.2D, 0.1D, 0.05D, 0.02D, 0.01D};

               for(int arg2 = 0; arg2 < arg8.length; ++arg2) {
                  n = arg8[arg2];
                  if((double)(524288L + f.c) * n / 1048576.0D < 1000.0D) {
                     break;
                  }
               }
            }

            int arg9 = (int)((double)(524288L + f.c) * n / 1048576.0D);
            List arg10 = g.a(arg9, o, p, q);
            g.a(arg10);
            f.e();
            a(arg0);
            System.out.println("calculating edge exclusiveness.. ");
            ArrayList arg3 = new ArrayList();

            for(int arg4 = 0; arg4 < arg10.size(); ++arg4) {
               arg3.add(g.a((e)arg10.get(arg4), arg4, arg10.size()));
            }

            System.out.println("writing memory-path-file: memory_paths.txt");
            PrintWriter arg11 = new PrintWriter(new FileOutputStream("memory_paths.txt"));

            for(int arg5 = 0; arg5 < arg10.size(); ++arg5) {
               List arg6 = g.a((e)arg10.get(arg5), (boolean[])arg3.get(arg5));
               arg11.println("memory-path," + (long)(1048576.0D / n));

               for(int arg7 = 0; arg7 < arg6.size(); ++arg7) {
                  arg11.println("    " + (String)arg6.get(arg7));
               }

               arg11.println();
            }

            arg11.close();
            f.c();
            g.a();
            i.a("memory_paths.txt");
         }
      } else {
         System.out.println("to sample heap-paths in an HPROF-Binary-Heapdump");
         System.out.println("usage: java BHeapSampler <heapfile> [<path-selection> [<path-unification> [<oversampling> [max-path-length]]]]");
         System.out.println("   path-selection = SHORT | RANDOM, default = SHORT");
         System.out.println("   path-unification = NONE | INSTANCE | CLASS, default = INSTANCE");
         System.out.println("   oversampling = paths/MB");
         System.out.println("   max-path-length = linked-list-cutoff, default = 100");
         System.out.println("");
         System.out.println("additional properties (as VM-arg with -D - prefix):");
         System.out.println("- treatClassesAsRoot (true/false, default true)");
         System.out.println("    treat static instances as roots, set to false to look at classloader issues");
         System.out.println("- skipObjectExclusiveness (true/false, default false)");
         System.out.println("    skip calculation of object exclusiveness (set to true for speed)");
         System.out.println("- avoidClassList (;-separated list of ,-sep. subgroups of classname-substrings)");
         System.out.println("    sorted list of classes to avoid in pathfinding, default avoid dynamic roots");
         System.out.println("- avoidGhostList (;-separated list of ,-sep. subgroups of classname-substrings)");
         System.out.println("    sorted list of classes to avoid in pathfinding and ignore in");
         System.out.println("    exlusivess-detection, default avoids Weak-/Softrefs and Finalizers");
         System.out.println("- randomSeed (default = system time)");
         System.out.println("    random seed for object-choosing and path-finding (used in regression-test)");
      }
   }

   public static void a(String arg) {
      System.out.println("* Parsing from: " + arg + " in pass " + l);
      if(arg.endsWith(".gz")) {
         i = new DataInputStream(new BufferedInputStream(new GZIPInputStream(new FileInputStream(arg))));
      } else {
         i = new DataInputStream(new BufferedInputStream(new FileInputStream(arg)));
      }

      j = 0L;
      String arg0 = i();
      k = f();
      long arg1 = g();
      if(l == 0) {
         System.out.println("version = " + arg0 + " id-size=" + k + " date=" + new Date(arg1));
      }

      m = "JAVA PROFILE 1.0.3".equals(arg0);
      boolean arg3 = true;

      try {
         while(true) {
            while(true) {
               arg3 = true;
               byte arg13 = d();
               arg3 = false;
               int arg14 = f();
               long arg6 = (long)f();
               if(l == 0 && arg13 >= 0 && arg13 < c.length) {
                  ++c[arg13];
               }

               String arg8 = arg13 >= 0 && arg13 < c.length?a[arg13]:"unkown_" + arg13;
               if(!arg8.equals("string") && !arg8.equals("load_class") && !arg8.equals("stack_trace") && !arg8.equals("stack_frame") && !arg8.equals("heap_dump_segment") && l == 0) {
                  System.out.println("tag = " + arg8 + " size=" + arg6 + " date=" + new Date(arg1 + (long)arg14));
               }

               if(l == 0 && arg8.equals("string")) {
                  long arg9 = h();
                  String arg11 = b((int)arg6 - k);
                  e.put(new Long(arg9), arg11);
               } else if(l == 0 && arg8.equals("load_class")) {
                  a();
               } else if(l == 0 && arg8.equals("stack_frame")) {
                  b();
               } else if(l == 0 && arg8.equals("stack_trace")) {
                  c();
               } else if(!arg8.equals("heap_dump") && !arg8.equals("heap_dump_segment")) {
                  a((int)arg6);
               } else {
                  a(arg6);
               }
            }
         }
      } catch (EOFException arg12) {
         if(l == 0 && !arg3) {
            System.out.println("**** WARNING : end-of file at position:" + j);
            System.out.println("**** WARNING : dump is truncated or corrupt, processing anyhow");
            System.out.println("**** WARNING : analysis results may be wrong or misleading");
         }

         i.close();
         if(l == 0) {
            int arg4;
            String arg5;
            for(arg4 = 0; arg4 < c.length; ++arg4) {
               arg5 = a[arg4];
               if(arg5.length() > 0) {
                  System.out.println("tag: " + a[arg4] + " count=" + c[arg4]);
               }
            }

            for(arg4 = 0; arg4 < d.length; ++arg4) {
               arg5 = b[arg4];
               if(arg5.length() > 0) {
                  System.out.println("subtag: " + b[arg4] + " count=" + d[arg4]);
               }
            }
         } else if(l == 1) {
            System.out.println("nobjects: " + f.a);
         } else if(l == 2) {
            System.out.println("totalRefererCount: " + f.e);
            System.out.println("nullReferenceCount: " + f.h);
         } else if(l == 3) {
            System.out.println("totalEdgeCheckCount: " + f.g);
         }

         System.out.println("* Parsing in pass " + l + " finished.");
      }
   }

   private static void a() {
      int arg = f();
      long arg0 = h();
      int arg2 = f();
      long arg3 = h();
      h.a(arg0, arg3);
   }

   private static void b() {
      long arg = h();
      long arg1 = h();
      long arg3 = h();
      long arg5 = h();
      int arg7 = f();
      int arg8 = f();
      String arg9 = b(arg1) + "(" + b(arg5) + ":" + arg8 + ")";
      f.put(new Long(arg), arg9);
   }

   private static void c() {
      f();
      int arg = f();
      int arg0 = f();
      long[] arg1 = new long[arg0];
      System.out.println("Thread-ID:" + arg);

      for(int arg2 = 0; arg2 < arg0; ++arg2) {
         arg1[arg2] = h();
         String arg3 = (String)f.get(new Long(arg1[arg2]));
         System.out.println("   " + arg3);
      }

      System.out.println();
      g.put(new Integer(arg), arg1);
   }

   private static String a(int arg, int arg0) {
      long[] arg1 = (long[])g.get(new Integer(arg));
      if(arg1 != null && arg0 >= 0 && arg0 < arg1.length) {
         long arg2 = arg1[arg0];
         return (String)f.get(new Long(arg2));
      } else {
         return "thread_" + arg;
      }
   }

   private static void a(long arg) {
      long arg1 = j;

      while(j - arg1 < arg) {
         byte arg3 = d();
         if(m && (arg3 == -119 || arg3 == -118 || arg3 == -117 || arg3 == -116 || arg3 == -115 || arg3 == -112)) {
            arg3 = -1;
         }

         if(l == 0 && arg3 >= -1 && arg3 < d.length) {
            ++d[arg3 == -1?0:arg3];
         }

         long arg4 = h();
         boolean arg6 = true;
         String arg7 = null;
         if(arg3 != -1 && arg3 != 5 && arg3 != 7) {
            if(arg3 == 1) {
               long arg8 = h();
            } else {
               int arg9;
               int arg30;
               if(arg3 != 2 && arg3 != 3) {
                  if(arg3 != 4 && arg3 != 6) {
                     if(arg3 == 8) {
                        arg30 = f();
                        arg9 = f();
                        arg7 = "ID=" + arg30;
                     } else {
                        arg6 = false;
                        boolean arg31 = false;
                        long arg10;
                        if(arg3 == 32) {
                           arg9 = f();
                           arg10 = h();
                           long arg12 = h();
                           String arg14 = b(h.a(arg4));
                           long arg15 = h();
                           long arg17 = h();
                           long arg19 = h();
                           long arg21 = h();
                           int arg23 = f();
                           short arg24 = e();

                           short arg26;
                           for(int arg25 = 0; arg25 < arg24; ++arg25) {
                              arg26 = e();
                              byte arg27 = d();
                              if(arg27 == 2) {
                                 throw new RuntimeException("unexpected objectId in constant-pool!");
                              }

                              a(a(arg27));
                           }

                           short arg35 = e();

                           for(int arg36 = 0; arg36 < arg35; ++arg36) {
                              long arg37 = h();
                              byte arg29 = d();
                              if(l < 2) {
                                 a(a(arg29));
                              } else {
                                 a(arg4, arg29, arg37);
                              }
                           }

                           arg26 = e();
                           byte[] arg38 = new byte[arg26];
                           long[] arg28 = new long[arg26];

                           for(int arg39 = 0; arg39 < arg26; ++arg39) {
                              arg28[arg39] = h();
                              arg38[arg39] = d();
                           }

                           if(l == 0) {
                              a.a(arg4, arg10, arg14, arg38, arg28);
                              f.a(arg4, arg4, 100, true, false, false);
                           }
                        } else {
                           int arg34;
                           if(arg3 == 33) {
                              arg9 = f();
                              arg10 = h();
                              arg34 = f();
                              if(l == 1) {
                                 f.a(arg4, arg10, arg34, false, false, false);
                              }

                              if(l < 2) {
                                 a(arg34);
                              } else {
                                 a(arg4, arg10, arg34);
                              }
                           } else {
                              int arg32;
                              if(arg3 == 34) {
                                 arg9 = f();
                                 arg32 = f();
                                 long arg11 = h();
                                 int arg13 = arg32 * k;
                                 if(l == 1) {
                                    f.a(arg4, arg11, arg13, false, false, false);
                                 }

                                 if(l == 2) {
                                    a(arg4, arg32);
                                 } else {
                                    a(arg13);
                                 }
                              } else if(arg3 == 35) {
                                 arg9 = f();
                                 arg32 = f();
                                 byte arg33 = d();
                                 arg34 = a(arg33) * arg32;
                                 if(l == 1) {
                                    f.a(arg4, (long)arg33, arg34, false, false, true);
                                 }

                                 a(arg34);
                              } else {
                                 if(!m || arg3 != -2) {
                                    throw new RuntimeException("unknown subtag:" + arg3 + " at position " + j);
                                 }

                                 f();
                              }
                           }
                        }
                     }
                  } else {
                     arg30 = f();
                  }
               } else {
                  arg30 = f();
                  arg9 = f();
                  arg7 = a(arg30, arg9);
               }
            }
         }

         if(l == 2 && arg6) {
            f.a(arg4, arg3, arg7);
         }
      }

      if(j - arg1 > arg) {
         throw new RuntimeException("heapdump tag read to much: size=" + arg + " read=" + (j - arg1));
      }
   }

   private static void a(long arg, byte arg1, long arg2) {
      int arg4 = a(arg1);
      if(arg1 == 2) {
         long arg5 = h();
         if(l == 2) {
            f.a(arg5, arg);
         } else if(l == 3) {
            int arg7 = f.c(arg5, arg);
            if(arg7 >= 0) {
               String arg8 = b(arg2);
               f.a(arg7, arg8);
            }
         }
      } else {
         a(arg4);
      }

   }

   private static void a(long arg, int arg1) {
      int arg2 = -1;

      for(int arg3 = 0; arg3 < arg1; ++arg3) {
         long arg4 = h();
         if(l == 2) {
            if(arg2 == -1) {
               arg2 = f.a(arg);
            }

            f.a(arg4, arg2);
         }
      }

   }

   private static void a(long arg, long arg1, int arg3) {
      int arg4 = 0;
      int arg5 = a.a(arg1);

      for(int arg6 = -1; arg5 != -1; arg5 = a.a(arg5)) {
         byte[] arg7 = a.d(arg5);
         long[] arg8 = a.e(arg5);
         int arg9 = 0;

         for(int arg10 = 0; arg10 < arg7.length; ++arg10) {
            byte arg11 = arg7[arg10];
            int arg12 = a(arg11);
            arg9 += arg12;
            if(arg11 == 2) {
               long arg13 = h();
               if(arg13 != arg) {
                  if(arg6 == -1) {
                     arg6 = f.a(arg);
                  }

                  if(l == 2) {
                     f.a(arg13, arg6);
                  } else if(l == 3) {
                     int arg15 = f.b(arg13, arg6);
                     if(arg15 >= 0) {
                        String arg16 = b(arg8[arg10]);
                        f.a(arg15, arg16);
                     }
                  }
               }
            } else {
               a(arg12);
            }
         }

         arg4 += arg9;
      }

      if(arg4 != arg3) {
         throw new RuntimeException("size-missmatch: " + arg4);
      }
   }

   private static byte d() {
      ++j;
      return i.readByte();
   }

   private static short e() {
      j += 2L;
      return i.readShort();
   }

   private static int f() {
      j += 4L;
      return i.readInt();
   }

   private static long g() {
      j += 8L;
      return i.readLong();
   }

   private static long h() {
      j += (long)k;
      return k == 4?(long)i.readInt():i.readLong();
   }

   private static void a(int arg) {
      j += (long)arg;
      i.skipBytes(arg);
   }

   private static int a(byte arg) {
      switch(arg) {
      case 2:
         return k;
      case 3:
      default:
         throw new RuntimeException("unknown entry type: " + arg);
      case 4:
         return 1;
      case 5:
         return 2;
      case 6:
         return 4;
      case 7:
         return 8;
      case 8:
         return 1;
      case 9:
         return 2;
      case 10:
         return 4;
      case 11:
         return 8;
      }
   }

   private static String i() {
      ByteArrayOutputStream arg = new ByteArrayOutputStream();

      while(true) {
         byte arg0 = d();
         if(arg0 == 0) {
            return new String(arg.toByteArray());
         }

         arg.write(arg0);
      }
   }

   private static String b(int arg) {
      byte[] arg0 = new byte[arg];
      i.readFully(arg0);
      j += (long)arg;
      return new String(arg0, 0, arg0.length);
   }

   private static String b(long arg) {
      return (String)e.get(new Long(arg));
   }

   static {
      c = new long[a.length];
      d = new long[b.length];
      e = new HashMap();
      f = new HashMap();
      g = new HashMap();
      h = new b();
      m = false;
      n = 0.0D;
      o = false;
      p = true;
      q = false;
   }
}
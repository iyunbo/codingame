/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
// Warning: No line numbers available in class file

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.zip.GZIPInputStream;

public class a
{
  private static String[] a = { "", "string", "load_class", "unload_class", "stack_frame", "stack_trace", "alloc_sites", "heap_summary", "", "", "start_thread", "end_thread", "heap_dump", "cpu_samples", "control_settings", "", "", "", "", "", "", "", "", "", "", "", "", "", "heap_dump_segment", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "heap_dump_end", "", "", "" };
  private static String[] b = { "ROOT UNKNOWN", "ROOT JNI GLOBAL", "ROOT JNI LOCAL", "ROOT JAVA FRAME", "ROOT NATIVE STACK", "ROOT STICKY CLASS", "ROOT THREAD BLOCK", "ROOT MONITOR USED", "ROOT THREAD OBJECT", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "CLASS DUMP", "INSTANCE-DUMP", "OBJECT_ARRAY-DUMP", "PRIMITIVE_ARRAY-DUMP" };
  private static long[] c = new long[a.length];
  private static long[] d = new long[b.length];
//  private static HashMap e = new HashMap();
//  private static HashMap f = new HashMap();
//  private static HashMap g = new HashMap();
  private static b h = new b();
//  private static DataInputStream i;
  private static long j;
  private static int k;
  private static int l;
  private static boolean m = false;
  private static double n = 0.0D;
  private static boolean o = false;
  private static boolean p = true;
  private static boolean q = false;

  public static void main(String[] paramArrayOfString)
  {
    System.out.println("BHeapSampler 1.3 / 2012 / Dr. Arndt Brenschede");
    if ((paramArrayOfString.length < 1) || (paramArrayOfString.length > 5))
    {
      System.out.println("to sample heap-paths in an HPROF-Binary-Heapdump");
      System.out.println("usage: java BHeapSampler <heapfile> [<path-selection> [<path-unification> [<oversampling> [max-path-length]]]]");
      System.out.println("   path-selection = SHORT | RANDOM, default = SHORT");
      System.out.println("   path-unification = NONE | INSTANCE | CLASS, default = INSTANCE");
      System.out.println("   oversampling = paths/MB");
      System.out.println("   max-path-length = linked-list-cutoff, default = 100");
      System.out.println("");
      System.out.println("additional properties (as VM-arg with -D - prefix):");
      System.out.println("- treatClassesAsRoot (true/false, default true)");
      System.out.println("    treat static instances as roots, set to false to look at classloader issues");
      System.out.println("- skipObjectExclusiveness (true/false, default false)");
      System.out.println("    skip calculation of object exclusiveness (set to true for speed)");
      System.out.println("- avoidClassList (;-separated list of ,-sep. subgroups of classname-substrings)");
      System.out.println("    sorted list of classes to avoid in pathfinding, default avoid dynamic roots");
      System.out.println("- avoidGhostList (;-separated list of ,-sep. subgroups of classname-substrings)");
      System.out.println("    sorted list of classes to avoid in pathfinding and ignore in");
      System.out.println("    exlusivess-detection, default avoids Weak-/Softrefs and Finalizers");
      System.out.println("- randomSeed (default = system time)");
      System.out.println("    random seed for object-choosing and path-finding (used in regression-test)");
      return;
    }
    String str = paramArrayOfString[0];
    Object localObject;
    if (paramArrayOfString.length > 1)
    {
      localObject = paramArrayOfString[1].toUpperCase();
      if ("SHORT".equals(localObject))
        o = false;
      else if ("RANDOM".equals(localObject))
        o = true;
      else
        throw new IllegalArgumentException("invalid path-selection: " + ((String)localObject));
    }
    if (paramArrayOfString.length > 2)
    {
      localObject = paramArrayOfString[2].toUpperCase();
      if ("NONE".equals(localObject))
      {
        p = false;
        q = false;
      }
      else if ("INSTANCE".equals(localObject))
      {
        p = true;
        q = false;
      }
      else if ("CLASS".equals(localObject))
      {
        p = true;
        q = true;
      }
      else
      {
        throw new IllegalArgumentException("invalid path-unification: " + ((String)localObject));
      }
    }
    if (paramArrayOfString.length > 3)
      n = Double.parseDouble(paramArrayOfString[3]);
    if (paramArrayOfString.length > 4)
      g.a = Integer.parseInt(paramArrayOfString[4]);
    if (str.endsWith(".txt"))
    {
      i.a(str);
      return;
    }
    f.c();
    l = 0;
    while (l < 3)
    {
      if (l == 1)
        a();
      if (l == 2)
        d();
      a(str);
      l += 1;
    }
    if (n == 0.0D)
    {
    	double[] localObject = new double[] { 1000.0D, 500.0D, 200.0D, 100.0D, 50.0D, 20.0D, 10.0D, 5.0D, 2.0D, 1.0D, 0.5D, 0.2D, 0.1D, 0.05D, 0.02D, 0.01D };
      for (int i2 = 0; i2 < localObject.length; ++i2)
      {
        n = localObject[i2];
        if ((524288L + f.c) * n / 1048576.0D < 1000.0D)
          break;
      }
    }
    int i1 = (int)((524288L + f.c) * n / 1048576.0D);
    List localList1 = g.a(i1, o, p, q);
    g.a(localList1);
    f.e();
    a(str);
    System.out.println("calculating edge exclusiveness.. ");
    ArrayList localArrayList = new ArrayList();
    for (int i3 = 0; i3 < localList1.size(); ++i3)
      localArrayList.add(g.a((e)localList1.get(i3), i3, localList1.size()));
    System.out.println("writing memory-path-file: memory_paths.txt");
    PrintWriter localPrintWriter = new PrintWriter(new FileOutputStream("memory_paths.txt"));
    for (int i4 = 0; i4 < localList1.size(); ++i4)
    {
      List localList2 = g.a((e)localList1.get(i4), (boolean[])localArrayList.get(i4));
      localPrintWriter.println("memory-path," + (1048576.0D / n));
      for (int i5 = 0; i5 < localList2.size(); ++i5)
        localPrintWriter.println("    " + ((String)localList2.get(i5)));
      localPrintWriter.println();
    }
    localPrintWriter.close();
    f.c();
    g.a();
    i.a("memory_paths.txt");
  }

  public static void a(String paramString)
  {
    System.out.println("* Parsing from: " + paramString + " in pass " + l);
    if (paramString.endsWith(".gz"))
      i = new DataInputStream(new BufferedInputStream(new GZIPInputStream(new FileInputStream(paramString))));
    else
      i = new DataInputStream(new BufferedInputStream(new FileInputStream(paramString)));
    j = 0L;
    String str1 = i();
    k = f();
    long l1 = g();
    if (l == 0)
      System.out.println("version = " + str1 + " id-size=" + k + " date=" + new Date(l1));
    m = "JAVA PROFILE 1.0.3".equals(str1);
    int i1 = 1;
    while (true)
      try
      {
        i1 = 1;
        int i2 = d();
        i1 = 0;
        int i4 = f();
        long l2 = f();
        if ((l == 0) && (i2 >= 0) && (i2 < c.length))
          c[i2] += 1L;
        String str3 = "unkown_" + i2;
        if ((!(str3.equals("string"))) && (!(str3.equals("load_class"))) && (!(str3.equals("stack_trace"))) && (!(str3.equals("stack_frame"))) && (!(str3.equals("heap_dump_segment"))) && (l == 0))
          System.out.println("tag = " + str3 + " size=" + l2 + " date=" + new Date(l1 + i4));
        if ((l == 0) && (str3.equals("string")))
        {
          long l3 = h();
          String str4 = b((int)l2 - k);
          e.put(new Long(l3), str4);
        }
        else if ((l == 0) && (str3.equals("load_class")))
        {
          a();
        }
        else if ((l == 0) && (str3.equals("stack_frame")))
        {
          b();
        }
        else if ((l == 0) && (str3.equals("stack_trace")))
        {
          c();
        }
        else if ((str3.equals("heap_dump")) || (str3.equals("heap_dump_segment")))
        {
          a(l2);
        }
        else
        {
          a((int)l2);
        }
      }
      catch (EOFException e)
      {
        if ((l == 0) && (i1 == 0))
        {
          System.out.println("**** WARNING : end-of file at position:" + j);
          System.out.println("**** WARNING : dump is truncated or corrupt, processing anyhow");
          System.out.println("**** WARNING : analysis results may be wrong or misleading");
        }
        i.close();
        if (l == 0)
        {
          String str2;
          for (int i3 = 0; i3 < c.length; ++i3)
          {
            str2 = a[i3];
            if (str2.length() <= 0)
              continue;
            System.out.println("tag: " + a[i3] + " count=" + c[i3]);
          }
          for (i3 = 0; i3 < d.length; ++i3)
          {
            str2 = b[i3];
            if (str2.length() <= 0)
              continue;
            System.out.println("subtag: " + b[i3] + " count=" + d[i3]);
          }
        }
        else if (l == 1)
        {
          System.out.println("nobjects: " + f.a);
        }
        else if (l == 2)
        {
          System.out.println("totalRefererCount: " + f.e);
          System.out.println("nullReferenceCount: " + f.h);
        }
        else if (l == 3)
        {
          System.out.println("totalEdgeCheckCount: " + f.g);
        }
        System.out.println("* Parsing in pass " + l + " finished.");
      }
  }

  private static void a()
  {
    int i1 = f();
    long l1 = h();
    int i2 = f();
    long l2 = h();
    h.a(l1, l2);
  }

  private static void b()
  {
    long l1 = h();
    long l2 = h();
    long l3 = h();
    long l4 = h();
    int i1 = f();
    int i2 = f();
    String str = b(l2) + "(" + b(l4) + ":" + i2 + ")";
    f.put(new Long(l1), str);
  }

  private static void c()
  {
    f();
    int i1 = f();
    int i2 = f();
    long[] arrayOfLong = new long[i2];
    System.out.println("Thread-ID:" + i1);
    for (int i3 = 0; i3 < i2; ++i3)
    {
      arrayOfLong[i3] = h();
      String str = (String)f.get(new Long(arrayOfLong[i3]));
      System.out.println("   " + str);
    }
    System.out.println();
    g.put(new Integer(i1), arrayOfLong);
  }

  private static String a(int paramInt1, int paramInt2)
  {
    long[] arrayOfLong = (long[])g.get(new Integer(paramInt1));
    if ((arrayOfLong == null) || (paramInt2 < 0) || (paramInt2 >= arrayOfLong.length))
      return "thread_" + paramInt1;
    long l1 = arrayOfLong[paramInt2];
    return ((String)f.get(new Long(l1)));
  }

  private static void a(long paramLong)
  {
    long l1 = j;
    while (j - l1 < paramLong)
    {
      int i1 = d();
      if ((m) && (((i1 == -119) || (i1 == -118) || (i1 == -117) || (i1 == -116) || (i1 == -115) || (i1 == -112))))
        i1 = -1;
      if ((l == 0) && (i1 >= -1) && (i1 < d.length))
        d[((i1 == -1) ? 0 : i1)] += 1L;
      long l2 = h();
      int i2 = 1;
      String str1 = null;
      if ((i1 != -1) && (i1 != 5))
        if (i1 != 7)
          if (i1 == 1)
          {
            long l3 = h();
          }
          else
          {
            int i3;
            int i4;
            if ((i1 == 2) || (i1 == 3))
            {
              i3 = f();
              i4 = f();
              str1 = a(i3, i4);
            }
            else if ((i1 == 4) || (i1 == 6))
            {
              i3 = f();
            }
            else if (i1 == 8)
            {
              i3 = f();
              i4 = f();
              str1 = "ID=" + i3;
            }
            else
            {
              i2 = 0;
              i3 = 0;
              long l4;
              if (i1 == 32)
              {
                i4 = f();
                l4 = h();
                long l6 = h();
                String str2 = b(h.a(l2));
                long l7 = h();
                long l8 = h();
                long l9 = h();
                long l10 = h();
                int i9 = f();
                int i10 = e();
                for (int i11 = 0; i11 < i10; ++i11)
                {
                  i12 = e();
                  byte b1 = d();
                  if (b1 == 2)
                    throw new RuntimeException("unexpected objectId in constant-pool!");
                  a(a(b1));
                }
                i11 = e();
                for (int i12 = 0; i12 < i11; ++i12)
                {
                  long l11 = h();
                  i13 = d();
                  if (l < 2)
                    a(a(i13));
                  else
                    a(l2, i13, l11);
                }
                i12 = e();
                byte[] arrayOfByte = new byte[i12];
                long[] arrayOfLong = new long[i12];
                for (int i13 = 0; i13 < i12; ++i13)
                {
                  arrayOfLong[i13] = h();
                  arrayOfByte[i13] = d();
                }
                if (l == 0)
                {
                  a.a(l2, l4, str2, arrayOfByte, arrayOfLong);
                  f.a(l2, l2, 100, true, false, false);
                }
              }
              else
              {
                int i7;
                if (i1 == 33)
                {
                  i4 = f();
                  l4 = h();
                  i7 = f();
                  if (l == 1)
                    f.a(l2, l4, i7, false, false, false);
                  if (l < 2)
                    a(i7);
                  else
                    a(l2, l4, i7);
                }
                else
                {
                  int i5;
                  if (i1 == 34)
                  {
                    i4 = f();
                    i5 = f();
                    long l5 = h();
                    int i8 = i5 * k;
                    if (l == 1)
                      f.a(l2, l5, i8, false, false, false);
                    if (l == 2)
                      a(l2, i5);
                    else
                      a(i8);
                  }
                  else if (i1 == 35)
                  {
                    i4 = f();
                    i5 = f();
                    int i6 = d();
                    i7 = a(i6) * i5;
                    if (l == 1)
                      f.a(l2, i6, i7, false, false, true);
                    a(i7);
                  }
                  else if ((m) && (i1 == -2))
                  {
                    f();
                  }
                  else
                  {
                    throw new RuntimeException("unknown subtag:" + i1 + " at position " + j);
                  }
                }
              }
            }
          }
      if ((l == 2) && (i2 != 0))
        f.a(l2, i1, str1);
    }
    if (j - l1 <= paramLong)
      return;
    throw new RuntimeException("heapdump tag read to much: size=" + paramLong + " read=" + (j - l1));
  }

  private static void a(long paramLong1, byte paramByte, long paramLong2)
  {
    int i1 = a(paramByte);
    if (paramByte == 2)
    {
      long l1 = h();
      if (l == 2)
      {
        f.a(l1, paramLong1);
      }
      else if (l == 3)
      {
        int i2 = f.c(l1, paramLong1);
        if (i2 >= 0)
        {
          String str = b(paramLong2);
          f.a(i2, str);
        }
      }
    }
    else
    {
      a(i1);
    }
  }

  private static void a(long paramLong, int paramInt)
  {
    int i1 = -1;
    for (int i2 = 0; i2 < paramInt; ++i2)
    {
      long l1 = h();
      if (l != 2)
        continue;
      if (i1 == -1)
        i1 = f.a(paramLong);
      f.a(l1, i1);
    }
  }

  private static void a(long paramLong1, long paramLong2, int paramInt)
  {
    int i1 = 0;
    int i2 = a.a(paramLong2);
    int i3 = -1;
    while (i2 != -1)
    {
      byte[] arrayOfByte = a.d(i2);
      long[] arrayOfLong = a.e(i2);
      int i4 = 0;
      for (int i5 = 0; i5 < arrayOfByte.length; ++i5)
      {
        byte b1 = arrayOfByte[i5];
        int i6 = a(b1);
        i4 += i6;
        if (b1 == 2)
        {
          long l1 = h();
          if (l1 != paramLong1)
          {
            if (i3 == -1)
              i3 = f.a(paramLong1);
            if (l == 2)
            {
              f.a(l1, i3);
            }
            else if (l == 3)
            {
              int i7 = f.b(l1, i3);
              if (i7 >= 0)
              {
                String str = b(arrayOfLong[i5]);
                f.a(i7, str);
              }
            }
          }
        }
        else
        {
          a(i6);
        }
      }
      i1 += i4;
      i2 = a.a(i2);
    }
    if (i1 == paramInt)
      return;
    throw new RuntimeException("size-missmatch: " + i1);
  }

  private static byte d()
  {
    j += 1L;
    return i.readByte();
  }

  private static short e()
  {
    j += 2L;
    return i.readShort();
  }

  private static int f()
  {
    j += 4L;
    return i.readInt();
  }

  private static long g()
  {
    j += 8L;
    return i.readLong();
  }

  private static long h()
  {
    j += k;
    if (k == 4)
      return i.readInt();
    return i.readLong();
  }

  private static void a(int paramInt)
  {
    j += paramInt;
    i.skipBytes(paramInt);
  }

  private static int a(byte paramByte)
  {
    switch (paramByte)
    {
    case 2:
      return k;
    case 4:
      return 1;
    case 5:
      return 2;
    case 6:
      return 4;
    case 7:
      return 8;
    case 8:
      return 1;
    case 9:
      return 2;
    case 10:
      return 4;
    case 11:
      return 8;
    case 3:
    }
    throw new RuntimeException("unknown entry type: " + paramByte);
  }

  private static String i()
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    while (true)
    {
      int i1 = d();
      if (i1 == 0)
        break;
      localByteArrayOutputStream.write(i1);
    }
    return new String(localByteArrayOutputStream.toByteArray());
  }

  private static String b(int paramInt)
  {
    byte[] arrayOfByte = new byte[paramInt];
    i.readFully(arrayOfByte);
    j += paramInt;
    return new String(arrayOfByte, 0, arrayOfByte.length);
  }

  private static String b(long paramLong)
  {
    return ((String)e.get(new Long(paramLong)));
  }
}

/*
	DECOMPILATION REPORT

	Decompiled from: /Users/blasd/.m2/repository/amazon/bheapsampler/1/bheapsampler-1.jar
	Total time: 9 ms
	Location:           /var/folders/f_/tw0zbc7d4y90b2p47j6v02k80000gn/T/BHeapSampler1488906245458.jar
	Qualified Name:     BHeapSampler.BHeapSampler
	Java Class Version: 5 (49.0)
	JD-Core Version:    0.5.3
	
*/
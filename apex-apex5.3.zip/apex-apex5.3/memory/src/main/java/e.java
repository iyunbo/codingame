/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
// Warning: No line numbers available in class file

public final class e {
   private int[] a;
   private int b;

   public e(int[] arg0, int arg1) {
      if(arg0 == null) {
         throw new IllegalArgumentException("cannot construct MemoryPath with null argument");
      } else {
         this.a = arg0;
         this.b = arg1;
      }
   }

   public int a(int arg0) {
      return this.a[arg0];
   }

   public int a() {
      return this.a.length;
   }

   public int b() {
      return this.b;
   }

   public int b(int arg0) {
      int arg1 = this.a.length;

      do {
         --arg1;
      } while(this.a[arg1] != arg0);

      return arg1 < this.a.length - 1?this.a[arg1 + 1]:0;
   }
}
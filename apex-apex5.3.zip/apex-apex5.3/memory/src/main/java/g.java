/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
// Warning: No line numbers available in class file

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class g {
//   public static int a = 100;
   private static Random b;
   private static int c;
   private static ArrayList d = new ArrayList();
   private static d e = null;
//   private static d f = null;
   private static int[] g = null;
   private static int h = -1;
   private static d i = null;
   private static boolean j = true;
   private static boolean k = false;
   private static long l = 0L;

   public static void a() {
      e = null;
//      f = null;
      g = null;
      i = null;
   }

   public static List a(int arg, boolean arg0, boolean arg1, boolean arg2) {
      k = arg1;
      if(System.getProperty("treatClassesAsRoot") != null) {
         j = Boolean.getBoolean("treatClassesAsRoot");
         System.out.println("treatClassesAsRoot=" + j);
      }

      long arg3 = System.currentTimeMillis();
      String arg5 = System.getProperty("randomSeed");
      if(arg5 != null) {
         arg3 = Long.parseLong(arg5);
      }

      b = new Random(arg3);
      System.out.println("findPaths: randomSeed=" + arg3);
      System.out.println("findPaths: randomWalk=" + arg0 + " unifyOnInstanceLevel=" + arg1 + " unifyOnClassLevel=" + arg2);
      c = f.a(0L, 0L, 0, false, true, false);
      e = arg1?new d():null;
      f = null;
      boolean arg6 = false;
      int[] arg7 = new int[arg];

      int arg8;
      for(arg8 = 0; arg8 < arg; ++arg8) {
         arg7[arg8] = f.a(b);
      }

      f.b();

      for(arg8 = 0; arg8 < arg; ++arg8) {
         int arg9 = arg7[arg8];
         e arg10 = null;
         int arg11;
         int arg12;
         if(!arg2) {
            arg10 = a(arg9, arg0);
         } else {
            arg11 = 0;

            for(arg12 = 0; arg12 < 16; ++arg12) {
               e arg13 = a(arg9, arg0);
               int arg14 = a(arg13);
               if(arg10 == null || arg14 > arg11) {
                  arg10 = arg13;
                  arg11 = arg14;
               }
            }
         }

         arg11 = arg10.a(arg10.a() - 1);
         if(arg1 && arg11 != c) {
            for(arg12 = 0; arg12 < arg10.a(); ++arg12) {
               if(f.a(arg10.a(arg12), Integer.MIN_VALUE)) {
                  e.b((long)arg10.a(arg12), arg8);
               }
            }
         }

         d.add(arg10);
         if(arg8 == 0 || arg8 + 1 == arg || System.currentTimeMillis() - l > 100L) {
            l = System.currentTimeMillis();
            System.out.println("findPaths: " + (arg8 + 1) + " of " + arg + " done");
         }
      }

      return d;
   }

   public static List a(e arg, boolean[] arg0) {
      ArrayList arg1 = new ArrayList();

      for(int arg2 = 0; arg2 < arg.a(); ++arg2) {
         int arg3 = arg.a(arg2);
         int arg4 = f.b(arg3);
         String arg5 = arg2 == 0?"":f.b((long)arg.a(arg2 - 1), (long)arg3);
         if(arg2 > 0 && !arg0[arg2 - 1]) {
            arg5 = "-" + arg5;
         }

         String arg6 = a.c(arg4);
         int arg7 = a.f(arg4);
         String arg8 = arg7 < 0?"":"<" + arg7 + ">";
         arg1.add(arg6 + arg8 + "(" + arg3 + ":" + arg5 + ")");
      }

      return arg1;
   }

   public static void a(List arg) {
      for(int arg0 = 0; arg0 < arg.size(); ++arg0) {
         e arg1 = (e)arg.get(arg0);

         for(int arg2 = 1; arg2 < arg1.a(); ++arg2) {
            f.a(arg1.a(arg2 - 1), arg1.a(arg2), "");
         }
      }

   }

   private static e a(int arg, boolean arg0) {
      for(int arg1 = a.b(); arg1 >= 0; --arg1) {
         int[] arg2 = a(arg, arg0, arg1);
         if(arg2 != null) {
            return new e(arg2, arg1);
         }
      }

      return null;
   }

   private static int[] a(int arg, boolean arg0, int arg1) {
      f.a();
      if(g == null) {
         g = new int[f.a + 1];
      }

      int[] arg2 = g;
      h arg3 = new h();
      arg3.a(arg, 0);
      if(f.a(arg, 0)) {
         arg2[arg] = 0;
      }

      int[] arg4 = new int[32];

      label87:
      while(arg3.a() > 0) {
         int[] arg5 = arg0?arg3.b():arg3.c();
         int arg6 = arg5[0];
         int arg7 = arg5[1];
         int arg8 = f.b(arg6);
         boolean arg9 = j?(arg8 & -1073741824) != 0:(arg8 & 1073741824) != 0;
         if(arg9 || !arg0 && arg7 > a) {
            return a(arg2, arg6, arg2[arg6]);
         }

         int arg10 = a(arg6);
         if(arg10 == 0) {
            arg4[0] = 0;
            if(!arg0 || arg7 < a) {
               arg4 = f.a(arg4, arg6);
            }
         } else {
            arg4[0] = 1;
            arg4[1] = arg10;
         }

         int arg11 = arg4[0];

         while(true) {
            int arg13;
            int arg14;
            do {
               if(arg11 <= 0) {
                  continue label87;
               }

               int arg12 = 1 + (arg11 > 1?b.nextInt(arg11):0);
               arg13 = arg4[arg12];
               if(arg12 < arg11) {
                  arg4[arg12] = arg4[arg11];
               }

               --arg11;
               arg14 = a.b(f.b(arg13));
            } while(arg14 != 0 && arg14 <= arg1);

            if(f.a(arg13, 0)) {
               arg2[arg13] = arg6;
               arg3.a(arg13, arg7 + 1);
            }
         }
      }

      return arg1 == 0?a(arg2, c, arg):null;
   }

   private static boolean a(int arg, int arg0, int arg1, boolean arg2) {
      if(!arg2) {
         f.a();
      }

      h arg3 = new h();
      arg3.a(arg, 0);
      f.a(arg, 0);
      f.a(arg0, 0);
      int[] arg4 = new int[32];

      label55:
      while(arg3.a() > 0) {
         int[] arg5 = arg3.c();
         int arg6 = arg5[0];
         int arg7 = arg5[1];
         int arg8 = f.b(arg6);
         boolean arg9 = j?(arg8 & -1073741824) != 0:(arg8 & 1073741824) != 0;
         if(arg9 || arg7 > a) {
            return true;
         }

         arg4[0] = 0;
         arg4 = f.a(arg4, arg6);
         int arg10 = arg4[0];

         while(true) {
            int arg11;
            int arg12;
            do {
               if(arg10 <= 0) {
                  continue label55;
               }

               arg11 = arg4[arg10--];
               arg12 = a.b(f.b(arg11));
            } while(arg12 != 0 && arg12 <= arg1);

            if(f.a(arg11, 0)) {
               if(g[arg11] == h) {
                  return true;
               }

               arg3.a(arg11, arg7 + 1);
            }
         }
      }

      return false;
   }

   private static int a(int arg) {
      if(e != null && f.b(arg, Integer.MIN_VALUE)) {
         e arg0 = (e)d.get(e.b((long)arg));
         return arg0.b(arg);
      } else {
         return 0;
      }
   }

   private static int[] a(int[] arg, int arg0, int arg1) {
      int arg2 = a(arg, arg0, arg1, (int[])null);
      int[] arg3 = new int[arg2];
      a(arg, arg0, arg1, arg3);
      return arg3;
   }

   private static int a(int[] arg, int arg0, int arg1, int[] arg2) {
      int arg3 = 0;

      while(true) {
         if(arg2 != null) {
            arg2[arg2.length - arg3 - 1] = arg0;
         }

         ++arg3;
         if(arg1 == 0) {
            return arg3;
         }

         arg0 = arg1;
         arg1 = arg[arg1];
      }
   }

   private static int a(e arg) {
      boolean[] arg0 = new boolean[d.size()];
      int arg1 = 0;
      int arg2 = arg.a();

      while(arg2 > 1 && arg1 < d.size()) {
         --arg2;
         int arg3 = f.b(arg.a(arg2));

         for(int arg4 = 0; arg4 < d.size(); ++arg4) {
            if(!arg0[arg4]) {
               e arg5 = (e)d.get(arg4);
               int arg6 = arg2 + (arg5.a() - arg.a());
               if(arg6 < 1 || arg3 != f.b(arg5.a(arg6))) {
                  arg0[arg4] = true;
                  ++arg1;
               }
            }
         }
      }

      return arg.a() - arg2 + 1;
   }

   public static boolean[] a(e arg, int arg0, int arg1) {
      e = null;
      boolean[] arg2 = new boolean[arg.a()];
      int arg3;
      if(Boolean.getBoolean("skipObjectExclusiveness")) {
         for(arg3 = 0; arg3 < arg.a(); ++arg3) {
            arg2[arg3] = true;
         }

         return arg2;
      } else {
         if(i == null) {
            i = new d();
         }

         b();

         for(arg3 = 0; arg3 < arg.a(); ++arg3) {
            g[arg.a(arg3)] = h;
         }

         boolean arg7 = false;

         for(int arg4 = 0; arg4 < arg.a() - 1; ++arg4) {
            g[arg.a(arg4)] = 0;
            boolean arg5;
            if(!f.b(arg.a(arg4), 1073741824)) {
               int arg6 = arg.b();
               if(arg6 >= a.c()) {
                  arg6 = a.c();
               }

               arg5 = a(arg.a(arg4), arg.a(arg4 + 1), arg6, arg7);
               if(k && f.a(arg.a(arg4), 1073741824)) {
                  i.b((long)arg.a(arg4), arg5?0:1);
               }

               arg7 = !arg5;
            } else {
               arg5 = i.b((long)arg.a(arg4)) == 0;
            }

            arg2[arg4] = !arg5;
         }

         arg2[arg.a() - 1] = true;
         if(arg0 == 0 || arg0 + 1 == arg1 || System.currentTimeMillis() - l > 100L) {
            l = System.currentTimeMillis();
            System.out.println("calculating edge exclusiveness: " + (arg0 + 1) + " of " + arg1 + " done");
         }

         return arg2;
      }
   }

   public static void b() {
      ++h;
      if(h == 0) {
         g = null;
         g = new int[f.a + 1];
         h = 1;
      }

   }
}
/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
// Warning: No line numbers available in class file

public class c
{
  private long[][] a = new long[31][];
  private int[] b = new int[31];
  private int c = 0;
  private long[][] d;

  public c()
  {
    this.a[0] = new long[1];
    a();
    a(0, 1);
  }

  protected void a()
  {
    this.d = new long[31][];
  }

  protected void a(int paramInt1, int paramInt2)
  {
    this.d[paramInt1] = new long[paramInt2];
  }

  protected void a(int paramInt)
  {
    this.d[paramInt] = null;
  }

  protected void a(Object paramObject, int paramInt1, int paramInt2)
  {
    ((long[])(long[])paramObject)[0] = this.d[paramInt1][paramInt2];
  }

  protected void a(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    this.d[paramInt3][paramInt4] = this.d[paramInt1][paramInt2];
  }

  public void a(long paramLong1, long paramLong2)
  {
    this.d[0][0] = paramLong2;
    b(paramLong1);
  }

  public long a(long paramLong)
  {
    long[] arrayOfLong = new long[1];
    if (a(paramLong, arrayOfLong))
      return arrayOfLong[0];
    throw new IllegalArgumentException("unknown key: " + paramLong);
  }

  protected void b(long paramLong)
  {
    if (c(paramLong))
      throw new IllegalArgumentException("cannot put on existing key");
    d(paramLong);
  }

  private boolean d(long paramLong)
  {
    if (this.c == 2147483647)
      throw new IllegalArgumentException("cannot grow beyond size Integer.MAX_VALUE");
    this.a[0][0] = paramLong;
    int i = this.c++;
    int j = 1;
    int k = 1;
    this.b[0] = 1;
    this.b[1] = 1;
    while ((i & 0x1) == 1)
    {
      i >>= 1;
      this.b[(j++)] = k;
      k <<= 1;
    }
    if (this.a[j] == null)
    {
      this.a[j] = new long[k];
      a(j, k);
    }
    while (k > 0)
    {
      long l1 = 0L;
      int l = -1;
      for (int i1 = 0; i1 < j; ++i1)
      {
        int i2 = this.b[i1];
        if (i2 <= 0)
          continue;
        long l2 = this.a[i1][(i2 - 1)];
        if ((l >= 0) && (l2 <= l1))
          continue;
        l = i1;
        l1 = l2;
      }
      this.a[j][(--k)] = l1;
      a(l, this.b[l] - 1, j, k);
      this.b[l] -= 1;
    }
    while (j-- > 14)
    {
      this.a[j] = null;
      a(j);
    }
    return false;
  }

  public boolean c(long paramLong)
  {
    return a(paramLong, null);
  }

  protected boolean a(long paramLong, Object paramObject)
  {
    int i = this.c;
    int j = 1;
    while (i != 0)
    {
      if (((i & 0x1) == 1) && (a(j, paramLong, paramObject)))
        return true;
      ++j;
      i >>= 1;
    }
    return false;
  }

  private boolean a(int paramInt, long paramLong, Object paramObject)
  {
    long[] arrayOfLong = this.a[paramInt];
    int i = arrayOfLong.length;
    int k;
    for (int j = 0; i >>= 1 > 0; j = k)
    {
      k = j + i;
      if (arrayOfLong[k] > paramLong);
    }
    if (arrayOfLong[j] == paramLong)
    {
      if (paramObject != null)
        a(paramObject, paramInt, j);
      return true;
    }
    return false;
  }
}

/*
	DECOMPILATION REPORT

	Decompiled from: /Users/blasd/.m2/repository/amazon/bheapsampler/1/bheapsampler-1.jar
	Total time: 3 ms
	Location:           /var/folders/f_/tw0zbc7d4y90b2p47j6v02k80000gn/T/b1488906245477.jar
	Qualified Name:     b.b
	Java Class Version: 5 (49.0)
	JD-Core Version:    0.5.3
	
*/
/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
// Warning: No line numbers available in class file

public class b {
   private long[][] a = new long[31][];
   private int[] b = new int[31];
   private int c = 0;
   private long[][] d;

   public b() {
      this.a[0] = new long[1];
      this.a();
      this.a(0, 1);
   }

   protected void a() {
      this.d = new long[31][];
   }

   protected void a(int arg0, int arg1) {
      this.d[arg0] = new long[arg1];
   }

   protected void a(int arg0) {
      this.d[arg0] = null;
   }

   protected void a(Object arg0, int arg1, int arg2) {
      ((long[])((long[])arg0))[0] = this.d[arg1][arg2];
   }

   protected void a(int arg0, int arg1, int arg2, int arg3) {
      this.d[arg2][arg3] = this.d[arg0][arg1];
   }

   public void a(long arg0, long arg2) {
      this.d[0][0] = arg2;
      this.b(arg0);
   }

   public long a(long arg0) {
      long[] arg2 = new long[1];
      if(this.a(arg0, arg2)) {
         return arg2[0];
      } else {
         throw new IllegalArgumentException("unknown key: " + arg0);
      }
   }

   protected void b(long arg0) {
      if(this.c(arg0)) {
         throw new IllegalArgumentException("cannot put on existing key");
      } else {
         this.d(arg0);
      }
   }

   private boolean d(long arg0) {
      if(this.c == Integer.MAX_VALUE) {
         throw new IllegalArgumentException("cannot grow beyond size Integer.MAX_VALUE");
      } else {
         this.a[0][0] = arg0;
         int arg2 = this.c++;
         int arg3 = 1;
         int arg4 = 1;
         this.b[0] = 1;

         for(this.b[1] = 1; (arg2 & 1) == 1; arg4 <<= 1) {
            arg2 >>= 1;
            this.b[arg3++] = arg4;
         }

         if(this.a[arg3] == null) {
            this.a[arg3] = new long[arg4];
            this.a(arg3, arg4);
         }

         while(arg4 > 0) {
            long arg5 = 0L;
            int arg7 = -1;

            for(int arg8 = 0; arg8 < arg3; ++arg8) {
               int arg9 = this.b[arg8];
               if(arg9 > 0) {
                  long arg10 = this.a[arg8][arg9 - 1];
                  if(arg7 < 0 || arg10 > arg5) {
                     arg7 = arg8;
                     arg5 = arg10;
                  }
               }
            }

            --arg4;
            this.a[arg3][arg4] = arg5;
            this.a(arg7, this.b[arg7] - 1, arg3, arg4);
            --this.b[arg7];
         }

         while(arg3-- > 14) {
            this.a[arg3] = null;
            this.a(arg3);
         }

         return false;
      }
   }

   public boolean c(long arg0) {
      return this.a(arg0, (Object)null);
   }

   protected boolean a(long arg0, Object arg2) {
      int arg3 = this.c;

      for(int arg4 = 1; arg3 != 0; arg3 >>= 1) {
         if((arg3 & 1) == 1 && this.a(arg4, arg0, arg2)) {
            return true;
         }

         ++arg4;
      }

      return false;
   }

   private boolean a(int arg0, long arg1, Object arg3) {
      long[] arg4 = this.a[arg0];
      int arg5 = arg4.length;
      int arg6 = 0;

      while((arg5 >>= 1) > 0) {
         int arg7 = arg6 + arg5;
         if(arg4[arg7] <= arg1) {
            arg6 = arg7;
         }
      }

      if(arg4[arg6] == arg1) {
         if(arg3 != null) {
            this.a(arg3, arg0, arg6);
         }

         return true;
      } else {
         return false;
      }
   }
}
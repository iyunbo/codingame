/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
// Warning: No line numbers available in class file

import java.util.ArrayList;
import java.util.Random;

public class f {
   private static int i = 1024;
   private static int j = 1024;
   private static ArrayList k;
   private static ArrayList l;
   private static int[] m;
   private static int[] n;
   private static ArrayList o;
   private static d p;
   private static d q;
   private static ArrayList r;
   private static int s;
   public static int a;
   public static int b;
   public static long c;
   private static int t = 0;
   public static int d = 0;
   public static int e;
   public static int f;
   public static int g;
   public static int h;

   public static void a() {
      ++t;
      d = 0;
      int arg = -1073741824;
      if((t & arg) != 0) {
         c(arg);
         t = 1;
      }

   }

   private static void c(int arg) {
      for(int arg0 = 1; arg0 <= a; ++arg0) {
         int arg1 = arg0 / i;
         int arg2 = arg0 % i * 2 + 1;
         int[] arg3 = (int[])l.get(arg1);
         arg3[arg2] &= arg;
      }

   }

   public static boolean a(int arg, int arg0) {
      int arg1 = arg / i;
      int arg2 = arg % i * 2 + 1;
      int[] arg3 = (int[])l.get(arg1);
      if(arg0 == 0) {
         int arg4 = arg3[arg2] & 1073741823;
         if(arg4 == t) {
            return false;
         } else {
            arg3[arg2] = arg3[arg2] & -1073741824 | t;
            ++d;
            return true;
         }
      } else if((arg3[arg2] & arg0) != 0) {
         return false;
      } else {
         arg3[arg2] |= arg0;
         return true;
      }
   }

   public static boolean b(int arg, int arg0) {
      int arg1 = arg / i;
      int arg2 = arg % i * 2 + 1;
      int[] arg3 = (int[])l.get(arg1);
      if(arg0 == 0) {
         int arg4 = arg3[arg2] & 1073741823;
         return arg4 == t;
      } else {
         return (arg3[arg2] & arg0) != 0;
      }
   }

   public static void b() {
      c(0);
      k = null;
   }

   public static void c() {
      k = new ArrayList();
      l = new ArrayList();
      o = new ArrayList();
      m = null;
      n = null;
      p = new d(31);
      q = new d();
      r = new ArrayList();
      s = 0;
      a = 0;
      b = 0;
      c = 0L;
      e = 0;
      f = 0;
      g = 0;
      h = 0;
   }

   public static int a(long arg, long arg1, int arg3, boolean arg4, boolean arg5, boolean arg6) {
      arg3 += 16;
      int arg7 = ++a;
      if(arg != 0L) {
         p.b(arg, arg7);
      }

      int arg8 = arg7 / i;
      int arg9 = arg7 % i;
      int[] arg10;
      if(arg8 < l.size()) {
         arg10 = (int[])l.get(arg8);
      } else {
         arg10 = new int[2 * i];
         l.add(arg10);
         long[] arg11 = new long[]{c};
         k.add(arg11);
      }

      int arg12;
      if(arg6) {
         arg12 = 536870912 + (byte)((int)arg1);
      } else if(arg5) {
         arg12 = 1073741824 + (byte)((int)arg1);
      } else {
         arg12 = a(arg1);
         if(arg4) {
            arg12 |= Integer.MIN_VALUE;
         } else {
            a(arg12, arg3);
         }
      }

      c += (long)arg3;
      arg10[2 * arg9] = arg12;
      arg10[2 * arg9 + 1] = arg3;
      if(a % 1000000 == 0) {
         System.out.println("nobjects so far =" + a);
      }

      return arg7;
   }

   public static void d() {
      p = new c(p);
      m = new int[a + 1];
      n = new int[a + 1];
   }

   public static void e() {
      q = new c(q);
   }

   public static void a(long arg, byte arg1, String arg2) {
      int arg3 = a(0L, arg1 == -1?0L:(long)arg1, 0, false, true, false);
      int arg4 = a(arg, arg3);
      if(arg2 != null && arg4 != 0) {
         a(arg4, arg3, arg2);
      }

   }

   public static int a(long arg) {
      return p.b(arg);
   }

   public static void a(long arg, long arg1) {
      if(arg != arg1) {
         int arg3 = p.b(arg1);
         a(arg, arg3);
      }
   }

   public static int a(long arg, int arg1) {
      if(arg == 0L) {
         ++h;
         return 0;
      } else {
         int arg2;
         try {
            arg2 = p.b(arg);
         } catch (IllegalArgumentException arg6) {
            ++f;
            return 0;
         }

         if(++e % 1000000 == 0) {
            System.out.println("refererCount so far =" + e + " badRefererCount=" + f);
         }

         int arg3 = m[arg2];
         int arg4 = n[arg2];
         if(arg4 == 0) {
            (arg3 == 0?m:n)[arg2] = arg1;
         } else if((arg4 & Integer.MIN_VALUE) == 0) {
            int arg5 = c(arg3, arg4);
            m[arg2] = arg5;
            n[arg2] = d(arg5, arg1);
         } else {
            n[arg2] = d(arg4, arg1);
         }

         return arg2;
      }
   }

   public static int c(int arg, int arg0) {
      int arg1 = b++;
      int arg2 = arg1 / j;
      int arg3 = arg1 % j;
      int[] arg4;
      if(arg2 < o.size()) {
         arg4 = (int[])o.get(arg2);
      } else {
         arg4 = new int[2 * j];
         o.add(arg4);
      }

      arg4[2 * arg3] = arg;
      arg4[2 * arg3 + 1] = arg0;
      return arg1 | Integer.MIN_VALUE;
   }

   private static int d(int arg, int arg0) {
      arg &= Integer.MAX_VALUE;
      int arg1 = arg / j;
      int arg2 = arg % j;
      int[] arg3 = (int[])o.get(arg1);
      int arg4 = c(arg3[2 * arg2 + 1], arg0);
      arg3[2 * arg2 + 1] = arg4;
      return arg4;
   }

   public static int[] a(int[] arg, int arg0) {
      int arg1 = m[arg0];
      int arg2 = n[arg0];
      if((arg2 & Integer.MIN_VALUE) == 0) {
         if(arg1 != 0) {
            arg = b(arg, arg1);
         }

         if(arg2 != 0) {
            arg = b(arg, arg2);
         }
      } else {
         while(true) {
            if((arg1 & Integer.MIN_VALUE) == 0) {
               arg = b(arg, arg1);
               break;
            }

            int arg3 = arg1 & Integer.MAX_VALUE;
            int arg4 = arg3 / j;
            int arg5 = arg3 % j;
            int[] arg6 = (int[])o.get(arg4);
            int arg7 = arg6[2 * arg5];
            int arg8 = arg6[2 * arg5 + 1];
            arg = b(arg, arg7);
            arg1 = arg8;
         }
      }

      return arg;
   }

   private static int[] b(int[] arg, int arg0) {
      int arg1 = arg[0] + 1;
      if(arg1 == arg.length) {
         int[] arg2 = new int[2 * arg.length];
         System.arraycopy(arg, 0, arg2, 0, arg.length);
         arg = arg2;
      }

      arg[arg1] = arg0;
      arg[0] = arg1;
      return arg;
   }

   public static int a(Random arg) {
      long arg0 = c;

      long arg2;
      for(arg2 = 0L; arg0 != 0L; arg0 >>= 1) {
         arg2 = arg2 << 1 | 1L;
      }

      long arg4;
      do {
         arg4 = arg.nextLong() & arg2;
      } while(arg4 > c);

      int arg6 = 0;
      long arg7 = 0L;

      int arg9;
      for(arg9 = 0; arg6 < k.size() && ((long[])k.get(arg6))[0] < arg4; ++arg6) {
         arg7 = ((long[])k.get(arg6))[0];
         arg9 = arg6 * i;
      }

      while(arg9 < a) {
         int arg10 = a(arg9);
         if(arg7 + (long)arg10 >= arg4) {
            break;
         }

         arg7 += (long)arg10;
         ++arg9;
      }

      return arg9;
   }

   public static int a(int arg) {
      int arg0 = arg / i;
      int arg1 = arg % i;
      int[] arg2 = (int[])l.get(arg0);
      return arg2[2 * arg1 + 1];
   }

   public static int b(int arg) {
      int arg0 = arg / i;
      int arg1 = arg % i;
      int[] arg2 = (int[])l.get(arg0);
      return arg2[2 * arg1];
   }

   public static void a(int arg, int arg0, String arg1) {
      long arg2 = (long)arg << 32 | (long)arg0;
      if(!q.a(arg2)) {
         q.a(arg2, s);
         r.add(arg1 == null?"":arg1);
         ++s;
      }

   }

   public static String b(long arg, long arg1) {
      long arg3 = arg << 32 | arg1;
      int[] arg5 = new int[1];
      return q.a(arg3, arg5)?(String)r.get(arg5[0]):null;
   }

   public static int c(long arg, long arg1) {
      int arg3 = p.b(arg1);
      return b(arg, arg3);
   }

   public static int b(long arg, int arg1) {
      if(arg == 0L) {
         return -1;
      } else {
         int arg2;
         try {
            arg2 = p.b(arg);
         } catch (IllegalArgumentException arg6) {
            return -1;
         }

         long arg3 = (long)arg2 << 32 | (long)arg1;
         if(++g % 1000000 == 0) {
            System.out.println("edgeCheckCount so far =" + g);
         }

         int[] arg5 = new int[1];
         return q.a(arg3, arg5)?arg5[0]:-1;
      }
   }

   public static void a(int arg, String arg0) {
      String arg1 = (String)r.get(arg);
      r.set(arg, arg1.length() > 0?arg1 + "," + arg0:arg0);
   }
}
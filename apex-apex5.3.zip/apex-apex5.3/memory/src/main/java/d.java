/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
// Warning: No line numbers available in class file

public class d {
   private long[][] a;
   private int[] b;
   private int c;
   private int d;
   private static boolean e;
   private int[][] f;

   public d() {
      this(14);
   }

   public d(int arg0) {
      this.c = 0;
      this.d = arg0;
      this.b = new int[31];
      this.a = new long[31][];
      this.a[0] = new long[1];
      this.f = new int[31][];
      this.f[0] = new int[1];
      e = Boolean.getBoolean("earlyDuplicateCheck");
   }

   protected void a(int[] arg0, int arg1, int arg2) {
      arg0[0] = this.f[arg1][arg2];
      if(arg0.length == 2) {
         this.f[arg1][arg2] = arg0[1];
      }

   }

   public boolean a(long arg0, int arg2) {
      int[] arg3 = new int[]{0, arg2};
      if(this.a(arg0, arg3)) {
         return true;
      } else {
         this.f[0][0] = arg2;
         this.c(arg0);
         return false;
      }
   }

   public void b(long arg0, int arg2) {
      if(e && this.a(arg0, (int[])null)) {
         throw new IllegalArgumentException("duplicate key found in early check: " + arg0);
      } else {
         this.f[0][0] = arg2;
         this.c(arg0);
      }
   }

   public int b(long arg0) {
      int[] arg2 = new int[1];
      if(this.a(arg0, arg2)) {
         return arg2[0];
      } else {
         throw new IllegalArgumentException("unknown key: " + arg0);
      }
   }

   public int a() {
      return this.c;
   }

   private boolean c(long arg0) {
      if(this.c == Integer.MAX_VALUE) {
         throw new IllegalArgumentException("cannot grow beyond size Integer.MAX_VALUE");
      } else {
         this.a[0][0] = arg0;
         int arg2 = this.c++;
         int arg3 = 1;
         int arg4 = 1;
         this.b[0] = 1;

         for(this.b[1] = 1; (arg2 & 1) == 1; arg4 <<= 1) {
            arg2 >>= 1;
            this.b[arg3++] = arg4;
         }

         if(this.a[arg3] == null) {
            this.a[arg3] = new long[arg4];
            this.f[arg3] = new int[arg4];
         }

         while(arg4 > 0) {
            long arg5 = 0L;
            int arg7 = -1;

            for(int arg8 = 0; arg8 < arg3; ++arg8) {
               int arg9 = this.b[arg8];
               if(arg9 > 0) {
                  long arg10 = this.a[arg8][arg9 - 1];
                  if(arg7 < 0 || arg10 > arg5) {
                     arg7 = arg8;
                     arg5 = arg10;
                  }
               }
            }

            if(arg4 < this.a[arg3].length && arg5 == this.a[arg3][arg4]) {
               throw new IllegalArgumentException("duplicate key found in late check: " + arg5);
            }

            --arg4;
            this.a[arg3][arg4] = arg5;
            this.f[arg3][arg4] = this.f[arg7][this.b[arg7] - 1];
            --this.b[arg7];
         }

         while(arg3-- > this.d) {
            this.a[arg3] = null;
            this.f[arg3] = null;
         }

         return false;
      }
   }

   public boolean a(long arg0) {
      return this.a(arg0, (int[])null);
   }

   public boolean a(long arg0, int[] arg2) {
      int arg3 = this.c;

      for(int arg4 = 1; arg3 != 0; arg3 >>= 1) {
         if((arg3 & 1) == 1 && this.a(arg4, arg0, arg2)) {
            return true;
         }

         ++arg4;
      }

      return false;
   }

   private boolean a(int arg0, long arg1, int[] arg3) {
      long[] arg4 = this.a[arg0];
      int arg5 = arg4.length;
      int arg6 = 0;

      while((arg5 >>= 1) > 0) {
         int arg7 = arg6 + arg5;
         if(arg4[arg7] <= arg1) {
            arg6 = arg7;
         }
      }

      if(arg4[arg6] == arg1) {
         if(arg3 != null) {
            this.a(arg3, arg0, arg6);
         }

         return true;
      } else {
         return false;
      }
   }

   protected void a(long[] arg0, int[] arg1) {
      int arg2;
      for(arg2 = 1; arg2 < 31; ++arg2) {
         this.b[arg2] = 0;
      }

      for(arg2 = 0; arg2 < this.c; ++arg2) {
         int arg3 = this.c;
         int arg4 = -1;
         long arg5 = 0L;

         for(int arg7 = 1; arg3 != 0; arg3 >>= 1) {
            if((arg3 & 1) == 1) {
               int arg8 = this.b[arg7];
               if(arg8 < this.a[arg7].length) {
                  long arg9 = this.a[arg7][arg8];
                  if(arg4 < 0 || arg9 < arg5) {
                     arg4 = arg7;
                     arg5 = arg9;
                  }
               }
            }

            ++arg7;
         }

         arg0[arg2] = arg5;
         arg1[arg2] = this.f[arg4][this.b[arg4]];
         ++this.b[arg4];
         if(arg2 > 0 && arg0[arg2 - 1] == arg5) {
            throw new IllegalArgumentException("duplicate key found in late check: " + arg5);
         }
      }

      this.a = (long[][])null;
      this.f = (int[][])null;
   }
}
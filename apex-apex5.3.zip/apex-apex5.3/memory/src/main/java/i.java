/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
// Warning: No line numbers available in class file

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

public class i {
	private static File a;
	private static File b;
	private static int c;
	private static String d;
	private static int e;
	private static double f = 1.0D;
	private static int g = 0;
	private static List h;
	private static Map i;
	private static List j;
	private static Map k;
	private static int l;
	private static Map m = new TreeMap();
	private static Map n = new TreeMap();
	private static Map o = new TreeMap();
	private static Set p = new HashSet();

	public static void a(String paramString) throws Exception {
		a = new File(paramString);
		b = new File("memory_graph.dot");
		c = 1;
		while (c <= 3) {
			if (c == 2)
				b();
			if (c == 3)
				a(GraphConfig.max_nodes);
			a();
			a(a);
			if (c == 3)
				c();
			c += 1;
		}
	}

	public static void a(File paramFile) throws Exception {
		try {
			b(paramFile);
		} catch (Exception localException) {
			System.out.println("error at line" + e);
			throw localException;
		}
	}

	public static void b(File paramFile) throws NumberFormatException, IOException {
		System.out.println("analyzing: " + paramFile + " in pass " + c);
		FileInputStream localFileInputStream = new FileInputStream(paramFile);
		BufferedReader localBufferedReader = new BufferedReader(new InputStreamReader(localFileInputStream));
		ArrayList localArrayList = new ArrayList();
		while ((d = localBufferedReader.readLine()) != null) {
			e += 1;
			int i1 = d.length();
			int i2 = localArrayList.size();
			if (i1 == 0) {
				if (i2 > 0)
					a(localArrayList);
				localArrayList.clear();
			}
			if (d.startsWith("memory-path")) {
				int i3 = d.indexOf("memory-path,");
				if (i3 >= 0)
					f = 1048576.0D / Integer.parseInt(d.substring(i3 + 12));
				localArrayList.clear();
				localArrayList.add(d);
			} else if ((i2 > 0) && (d.startsWith("    "))) {
				localArrayList.add(d);
			} else {
				localArrayList.clear();
			}
		}
		localBufferedReader.close();
	}

	private static void a(ArrayList paramArrayList) {
		int i1 = 1;
		int i2 = -1;
		int i3 = -1;
		int i4 = -1;
		int i5 = 0;
		if (c == 1)
			g += 1;
		int i6 = 1;
		int i7 = paramArrayList.size();
		HashSet localHashSet = new HashSet();
		Object localObject = null;
		int i8 = i7;
		for (int i9 = i7 - 1; i9 >= i6; --i9) {
			String str = (String) paramArrayList.get(i9);
			if (p.contains(c(str)))
				continue;
			boolean bool = i8 - i9 > 1;
			a((String) localObject, str, bool, localHashSet);
			localObject = str;
			i8 = i9;
		}
	}

	private static void a(String paramString1, String paramString2, boolean paramBoolean, HashSet paramHashSet) {
		if (c == 1) {
			String str1 = (paramString1 == null) ? "x.x.x()" : paramString1;
			Set<?>localObject1 = (Set) m.get(paramString2);
			if (localObject1 == null) {
				localObject1 = new TreeSet();
				m.put(paramString2, localObject1);
			}
			((Set) localObject1).add(str1);
			Set<?> localObject2 = (Set) n.get(str1);
			if (localObject2 == null) {
				localObject2 = new TreeSet();
				n.put(str1, localObject2);
			}
			((Set) localObject2).add(paramString2);
		}
		String str1 = g(paramString2);
		Object localObject1 = a(paramString2, paramHashSet);
		if (paramString1 == null)
			return;
		Object localObject2 = a(paramString1, null);
		String str2 = ((String) localObject2) + " -> " + ((String) localObject1);
		String str3 = g(paramString1);
		if (!(GraphConfig.hasFieldNames(paramString1)))
			str3 = ((str3 != null) && (str3.startsWith("-"))) ? "-" : null;
		if (str3 != null)
			str2 = str2 + ":" + str3;
		int[] arrayOfInt = (int[]) i.get(str2);
		if (arrayOfInt == null) {
			arrayOfInt = new int[3];
			arrayOfInt[0] = 0;
			arrayOfInt[1] = 0;
			i.put(str2, arrayOfInt);
			h.add(str2);
		}
		arrayOfInt[1] += 1;
		if (!(paramBoolean))
			return;
		arrayOfInt[0] += 1;
	}

	private static void a() {
		h = new ArrayList();
		i = new HashMap();
		j = new ArrayList();
		k = new HashMap();
		l = 0;
	}

	private static String a(String paramString, HashSet paramHashSet) {
		String str = c(paramString);
		int[] arrayOfInt = (int[]) k.get(str);
		if (arrayOfInt == null) {
			arrayOfInt = new int[3];
			arrayOfInt[0] = (l++);
			arrayOfInt[1] = 0;
			k.put(str, arrayOfInt);
			j.add(paramString);
		}
		if ((paramHashSet != null) && (!(paramHashSet.contains(str)))) {
			paramHashSet.add(str);
			arrayOfInt[1] += 1;
		}
		return "n" + arrayOfInt[0];
	}

	private static void b() {
		for (int i1 = 0; i1 < j.size(); ++i1) {
			String str = (String) j.get(i1);
			if (GraphConfig.hasParentPolicy(str))
				o.put(str, e(str) + "_" + b(str));
			else
				o.put(str, e(str));
		}
	}

	private static String b(String paramString) {
		String str1;
		for (str1 = null; GraphConfig.hasParentPolicy(paramString); str1 = e(paramString)) {
			Set<?> localObject = (Set) m.get(paramString);
			if (localObject == null)
				break;
			if (((Set) localObject).size() == 0)
				break;
			paramString = (String) ((Set) localObject).iterator().next();
		}
		Object localObject = "";
		String str2 = g(paramString);
		if (str2 != null)
			for (int i1 = 0; i1 < str2.length(); ++i1) {
				if (!(Character.isLetter(str2.charAt(i1))))
					continue;
				localObject = ((String) localObject) + ":" + str2.substring(i1);
				break;
			}
		return ((String) str1 + ((String) localObject));
	}

	private static String c(String paramString) {
		String str = (String) o.get(paramString);
		return ((str == null) ? paramString : str);
	}

	private static void a(int paramInt) {
		long l1 = (g * GraphConfig.minNodeHitsPerMio + 500000) / 1000000;
		while (true) {
			int i1 = 0;
			Object localObject = null;
			for (int i2 = 0; i2 < j.size(); ++i2) {
				String str1 = (String) j.get(i2);
				String str2 = c(str1);
				if (p.contains(str2))
					continue;
				int[] arrayOfInt = (int[]) k.get(str2);
				int i3 = arrayOfInt[1];
				if ((localObject != null) && (i3 >= i1))
					continue;
				i1 = i3;
				localObject = str2;
			}
			if (localObject == null)
				break;
			if ((j.size() - p.size() <= paramInt) && (i1 >= l1))
				break;
			p.add(localObject);
		}
		System.out.println("supressNodes: " + p.size() + " nodes=" + j.size());
	}

	private static void c() throws FileNotFoundException {
		PrintWriter localPrintWriter = new PrintWriter(new FileOutputStream(b));
		localPrintWriter.println("digraph prof {");
		localPrintWriter.println("\tsize=\"12,9\"; ratio = fill;");
		localPrintWriter.println("\tnode [style=filled];");
		int i5;
		int i6;
		Object localObject2;
		for (int i1 = 0; i1 < h.size(); ++i1) {
			String str1 = (String) h.get(i1);
			int[] localObject1 = (int[]) i.get(str1);
			int i3 = localObject1[1];
			String str2 = " " + b(i3);
			i5 = str1.indexOf(58);
			if (i5 > 0) {
				String str3 = str1.substring(i5 + 1);
				if (str3.startsWith("-"))
					str2 = " (" + b(i3) + ") " + str3.substring(1);
				else
					str2 = str2 + " " + str3;
				str1 = str1.substring(0, i5);
			}
			i6 = (localObject1[0] > 0) ? 1 : 0;
			localObject2 = (i6 != 0) ? "dashed" : "solid";
			localPrintWriter
					.println("\t" + str1 + " [label=\"" + str2 + "\" style=\"" + ((String) localObject2) + "\"];");
		}
		int i1 = 0;
		int[] arrayOfInt;
		int i4;
		for (int i2 = 0; i2 < j.size(); ++i2) {
			String localObject1 = (String) j.get(i2);
			arrayOfInt = (int[]) k.get(c((String) localObject1));
			i4 = arrayOfInt[1];
			if (i4 <= i1)
				continue;
			i1 = i4;
		}
		for (int i2 = 0; i2 < j.size(); ++i2) {
			String localObject1 = (String) j.get(i2);
			arrayOfInt = (int[]) k.get(c((String) localObject1));
			i4 = arrayOfInt[1];
			i5 = i1 - i4;
			i6 = (int) (256L * i5 * i5 / (i1 + 1L) * (i1 + 1L));
			i6 = 16711680 + (i6 << 8) + i6;
			localObject2 = new StringBuilder();
			((StringBuilder) localObject2).append(a((String) localObject1, null));
			((StringBuilder) localObject2).append(" [label=\"")
					.append(b(i4))
					.append(" ")
					.append(d((String) localObject1))
					.append("\"");
			((StringBuilder) localObject2).append(" shape=\"box\"");
			((StringBuilder) localObject2).append(" fillcolor=\"#").append(Integer.toHexString(i6)).append("\"");
			((StringBuilder) localObject2).append(" ]");
			localPrintWriter.println(localObject2);
		}
		localPrintWriter.println("}");
		localPrintWriter.close();
	}

	private static String d(String paramString) {
		paramString = f(paramString);
		int i1 = paramString.lastIndexOf(".");
		if (i1 >= 0) {
			String str = paramString.substring(0, i1);
			int i2 = str.lastIndexOf(".");
			if (i2 >= 0)
				return paramString.substring(i2 + 1);
		}
		return paramString;
	}

	private static String b(int paramInt) {
		if (f < 10.0D) {
			paramInt = (int) ((paramInt + f / 2.0D) / f);
			return "" + paramInt;
		}
		if (f < 100.0D) {
			paramInt = (int) ((10 * paramInt + f / 2.0D) / f);
			if (paramInt >= 100)
				return "" + (paramInt / 10);
			return "" + (paramInt / 10) + '.' + (paramInt % 10);
		}
		paramInt = (int) ((100 * paramInt + f / 2.0D) / f);
		if (paramInt >= 1000)
			return "" + (paramInt / 100);
		return "" + (paramInt / 100) + '.' + (paramInt / 10 % 10) + (paramInt % 10);
	}

	private static String e(String paramString) {
		String str = f(paramString);
		int i1 = str.indexOf(60);
		int i2 = str.indexOf(62);
		if ((i1 >= 0) && (i2 > i1))
			return str.substring(0, i1 + 1) + str.substring(i2);
		return str;
	}

	private static String f(String paramString) {
		int i1 = h(paramString);
		if (i1 < 0)
			return paramString.trim();
		int i2 = paramString.indexOf(58, i1);
		if ((i2 >= 0) && (GraphConfig.hasInstancePolicy(paramString)))
			paramString = paramString.substring(0, i2) + ")";
		else
			paramString = paramString.substring(0, i1);
		return paramString.trim();
	}

	private static String g(String paramString) {
		int i1 = h(paramString);
		if (i1 < 0)
			return null;
		int i2 = paramString.indexOf(58, i1);
		if (i2 < 0)
			return null;
		int i3 = paramString.substring(i2).lastIndexOf(41);
		if (i3 < 0)
			return null;
		String str = paramString.substring(i2 + 1, i3 + i2);
		return str;
	}

	private static int h(String paramString) {
		int i1 = 0;
		for (int i2 = paramString.length() - 1; i2 >= 0; --i2) {
			int i3 = paramString.charAt(i2);
			if ((i3 == 40) && (--i1 == 0))
				break;
			if (i3 != 41)
				continue;
			++i1;
		}
		return i2;
	}
}
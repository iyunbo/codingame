/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
// Warning: No line numbers available in class file

import java.util.ArrayList;

public class h {
	private ArrayList a = new ArrayList();
	private int b = 0;
	private int c = 0;

	public void a(int arg0, int arg1) {
		int arg2 = this.c++;
		int arg3 = arg2 / 256;
		int arg4 = arg2 % 256;
		int[] arg5;
		if (arg3 < this.a.size()) {
			arg5 = (int[]) this.a.get(arg3);
		} else {
			arg5 = new int[512];
			this.a.add(arg5);
		}

		arg5[2 * arg4] = arg0;
		arg5[2 * arg4 + 1] = arg1;
	}

	public int a() {
		return this.c - this.b;
	}

	public int[] b() {
		int[] arg0 = new int[] { this.a(--this.c), this.b(this.c) };
		return arg0;
	}

	public int[] c() {
		int[] arg0 = new int[] { this.a(this.b), this.b(this.b++) };
		if (this.b % 256 == 0) {
			this.a.set((this.b - 1) / 256, (Object) null);
		}

		return arg0;
	}

	private int a(int arg0) {
		int arg1 = arg0 / 256;
		int arg2 = arg0 % 256;
		int[] arg3 = (int[]) this.a.get(arg1);
		return arg3[2 * arg2];
	}

	private int b(int arg0) {
		int arg1 = arg0 / 256;
		int arg2 = arg0 % 256;
		int[] arg3 = (int[]) this.a.get(arg1);
		return arg3[2 * arg2 + 1];
	}
}
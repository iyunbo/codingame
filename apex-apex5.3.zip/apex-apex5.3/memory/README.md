[![Build Status](https://travis-ci.com/blasd/apex.svg?token=ghVoZrM9LWCSNPczn97T&branch=master)](https://travis-ci.com/blasd/apex)

# apex
## memory
Tentative to decompile
    http://dr-brenschede.de/bheapsampler/
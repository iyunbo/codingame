/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.cube;

import java.util.Arrays;
import java.util.Properties;
import java.util.concurrent.atomic.AtomicReference;

import com.quartetfs.biz.pivot.definitions.IPostProcessorDescription;
import com.quartetfs.biz.pivot.definitions.impl.PostProcessorDescription;
import com.quartetfs.biz.pivot.postprocessing.IPostProcessor;
import com.quartetfs.biz.pivot.postprocessing.impl.AAdvancedPostProcessor;

/**
 * Helps configuring an {@link IPostProcessorDescription}
 * 
 * @author Benoit Lacelle
 *
 * @param <T>
 */
public class ApexBasePostProcessorBuilder<T extends IRawApexPostProcessorBuilder<T>>
		implements IPropertiesSetter<T>, IRawApexPostProcessorBuilder<T> {

	protected final AtomicReference<IPostProcessorDescription> postProcessorDescription = new AtomicReference<>();

	protected final String pluginKey;

	public ApexBasePostProcessorBuilder(String pluginKey) {
		this.pluginKey = pluginKey;
	}

	@Override
	public String getPluginKey() {
		IPostProcessorDescription description = getDescription();

		// Do not use the pluginKey field as it value could have been overwritten
		return description.getPluginKey();
	}

	protected void setDefaultProperties(Properties properties) {
		// By default, nothing to set
	}

	@Override
	public T setProperty(String key, String value) {
		getProperties().setProperty(key, value);

		return thisAsT();
	}

	@Override
	public IPostProcessorDescription getDescription() {
		if (postProcessorDescription.get() == null) {
			PostProcessorDescription description = new PostProcessorDescription();

			// Ensure we have not-null properties
			description.setProperties(new Properties());
			description.setPluginKey(pluginKey);

			initDescription(description);
		}

		return postProcessorDescription.get();
	}

	public void initDescription(IPostProcessorDescription description) {
		if (!postProcessorDescription.compareAndSet(null, description)) {
			throw new IllegalStateException("There was already a description: " + postProcessorDescription.get());
		}
	}

	@Override
	public T setContinuousQueryHandlers(String... continuousQueryHandlers) {
		return setPropertyList(IPostProcessor.CONTINUOUS_QUERY_HANDLER_KEYS, Arrays.asList(continuousQueryHandlers));
	}

	@Override
	public T setUnderlyingMeasures(String... underlyingMeasures) {
		return setUnderlyingMeasures(Arrays.asList(underlyingMeasures));
	}

	@Override
	public T setOutputType(String outputTypeLiteralType) {
		return setProperty(AAdvancedPostProcessor.OUTPUT_TYPE, outputTypeLiteralType);
	}

	@Override
	public T setUnderlyingMeasures(Iterable<? extends String> underlyingMeasures) {
		return setPropertyList(IPostProcessor.UNDERLYING_MEASURES, underlyingMeasures);
	}

	@Override
	public T setAnalysisLevels(String... analysisLevels) {
		return setPropertyList(AAdvancedPostProcessor.ANALYSIS_LEVELS_PROPERTY, analysisLevels);
	}

	@Override
	public T setEvaluator(String pluginKey) {
		setProperty(AAdvancedPostProcessor.EVALUATOR, pluginKey);

		return thisAsT();
	}

	@Override
	public T setUnderlyingMeasures(IHasMeasureName... underlyingMeasures) {
		return setUnderlyingMeasures(
				Arrays.stream(underlyingMeasures).map(IHasMeasureName::getMeasureName).toArray(String[]::new));
	}

	@Override
	public T setPluginKey(String pluginKey) {
		getDescription().setPluginKey(pluginKey);

		return thisAsT();
	}

	protected T thisAsT() {
		return (T) this;
	}

	@Override
	public String getMeasureName() {
		return getDescription().getName();
	}

	@Override
	public void setMeasureName(String measureName) {
		getDescription().setName(measureName);
	}

	@Override
	public T setFolder(String folder) {
		getDescription().setFolder(folder);
		return thisAsT();
	}

	@Override
	public T setVisible(boolean isVisible) {
		getDescription().setVisible(isVisible);
		return thisAsT();
	}

	@Override
	public T setGroup(String group) {
		getDescription().setGroup(group);
		return thisAsT();
	}

	@Override
	public String getName() {
		return getDescription().getName();
	}

	@Override
	public ApexBasePostProcessorBuilder<T> setName(String elementNewName) {
		getDescription().setName(elementNewName);

		return this;
	}

	@Override
	public String getId() {
		return getDescription().getName();
	}
}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.cube;

import java.util.Properties;

import com.quartetfs.biz.pivot.definitions.IPostProcessorDescription;
import com.quartetfs.biz.pivot.postprocessing.IEvaluator;
import com.quartetfs.biz.pivot.postprocessing.IPostProcessor;

import blasd.apex.server.config.cube.properties.IApexPropertiesCubeElement;

/**
 * A builder for {@link IPostProcessor}, not referencing the owning {@link IApexCubeBuilder}
 * 
 * @author Benoit Lacelle
 *
 * @param <T>
 */
public interface IRawApexPostProcessorBuilder<T extends IRawApexPostProcessorBuilder<T>>
		extends IHasMeasureName, IApexPropertiesCubeElement<IPostProcessorDescription>, IPropertiesSetter<T> {

	@Override
	default Properties getProperties() {
		return IApexPropertiesCubeElement.super.getProperties();
	}

	/**
	 * @see IPostProcessor.UNDERLYING_MEASURES
	 */
	T setUnderlyingMeasures(String... underlyingMeasures);

	/**
	 * @see IPostProcessor.UNDERLYING_MEASURES
	 */
	T setUnderlyingMeasures(Iterable<? extends String> underlyingMeasures);

	/**
	 * @see IPostProcessor.UNDERLYING_MEASURES
	 */
	T setUnderlyingMeasures(IHasMeasureName... underlyingMeasures);

	T setPluginKey(String pluginKey);

	/**
	 * 
	 * @param pluginKey
	 *            an {@link IEvaluator} or {@link IPostProcessor} pluginKey
	 * @return
	 */
	T setEvaluator(String pluginKey);

	T setOutputType(String outputTypeLiteralType);

	/**
	 * @see IPostProcessor.CONTINUOUS_QUERY_HANDLER_KEYS
	 */
	T setContinuousQueryHandlers(String... continuousQueryHandlers);

	T setFolder(String folder);

	T setVisible(boolean isVisible);

	T setGroup(String group);

	String getPluginKey();

	T setAnalysisLevels(String... analysisLevels);

}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.cube;

import java.util.Properties;
import java.util.function.Function;

import com.quartetfs.biz.pivot.definitions.IAxisDimensionDescription;
import com.quartetfs.biz.pivot.definitions.IAxisHierarchyDescription;
import com.quartetfs.biz.pivot.definitions.impl.AxisHierarchyDescription;

/**
 * Helps configuring an IAxisDimensionDescription
 * 
 * @author Benoit Lacelle
 *
 */
public class ApexDimensionBuilder implements IApexDimensionBuilder {

	protected final IApexCubeBuilder apexCubeBuilder;
	protected final IAxisDimensionDescription dimensionDescription;

	public ApexDimensionBuilder(IApexCubeBuilder apexCubeBuilder, IAxisDimensionDescription dimensionDescription) {
		this.apexCubeBuilder = apexCubeBuilder;
		this.dimensionDescription = dimensionDescription;
	}

	@Override
	public IApexHierarchyBuilder addHierarchy(IAxisHierarchyDescription hierarchyDescription) {
		getDescription().getHierarchies().add(hierarchyDescription);

		return new ApexHierarchyBuilder(this, hierarchyDescription);
	}

	@Override
	public String getName() {
		return dimensionDescription.getName();
	}

	protected IApexHierarchyBuilder getAxisHierarchy(String hierarchyName) {
		for (IAxisHierarchyDescription hierarchy : dimensionDescription.getHierarchies()) {
			if (hierarchy.getName().equals(hierarchyName)) {
				return new ApexHierarchyBuilder(this, hierarchy);
			}
		}

		return null;
	}

	@Override
	public IApexHierarchyBuilder getOrAddAxisHierarchy(String hierarchyName) {
		IApexHierarchyBuilder existing = getAxisHierarchy(hierarchyName);

		if (existing == null) {
			AxisHierarchyDescription hierarchyDescription = newDescription(hierarchyName);

			return addHierarchy(hierarchyDescription);
		} else {
			return existing;
		}
	}

	@Override
	public IApexHierarchyBuilder getOrFailAxisHierarchy(String hierarchyName) {
		IApexHierarchyBuilder existing = getAxisHierarchy(hierarchyName);

		if (existing == null) {
			throw new RuntimeException("There is no hierarchy named " + hierarchyName);
		} else {
			return existing;
		}
	}

	protected AxisHierarchyDescription newDescription(String hierarchyName) {
		final AxisHierarchyDescription hierarchyDescription = new AxisHierarchyDescription(hierarchyName);

		if (hierarchyDescription.getProperties() == null) {
			// Ensure there is a not-null Properties
			hierarchyDescription.setProperties(new Properties());
		}

		return hierarchyDescription;
	}

	@Override
	public IApexHierarchyBuilder addHierarchyAndLevels(String firstFieldAndHierarchyName, String... fieldNames) {
		// By default, a Hierarchy isAllMembersEnabled=true
		final AxisHierarchyDescription hierarchyDescription = newDescription(firstFieldAndHierarchyName);

		IApexHierarchyBuilder hBuilder = addHierarchy(hierarchyDescription);

		hBuilder.appendLevel(firstFieldAndHierarchyName);
		for (String levelName : fieldNames) {
			hBuilder.appendLevel(levelName);
		}

		return hBuilder;
	}

	@Override
	public IApexCubeBuilder getCubeBuilder() {
		return apexCubeBuilder;
	}

	@Override
	public IApexHierarchyBuilder addAnalysisHierarchy(String hierarchyName, String pluginKey) {
		// By default, a Hierarchy isAllMembersEnabled=true
		final AxisHierarchyDescription hierarchyDescription = newDescription(hierarchyName);

		IApexHierarchyBuilder hBuilder = addHierarchy(hierarchyDescription);

		hBuilder.setPluginKey(pluginKey);

		return hBuilder;
	}

	@Override
	public <T extends IApexHierarchyBuilder> T addAnalysisHierarchy(String hierarchyName,
			Function<IApexHierarchyBuilder, T> hierarchyBuilderSupplier) {
		final AxisHierarchyDescription hierarchyDescription = newDescription(hierarchyName);

		IApexHierarchyBuilder hBuilder = addHierarchy(hierarchyDescription);

		return hierarchyBuilderSupplier.apply(hBuilder);
	}

	@Override
	public String getId() {
		// Dimension names are unique withing a cube
		return getName();
	}

	@Override
	public IApexDimensionBuilder setName(String dimensionName) {
		// TODO: we should merge with an existing dimension with same name if
		// already exist
		getDescription().setName(dimensionName);

		return this;
	}

	@Override
	public IAxisDimensionDescription getDescription() {
		return dimensionDescription;
	}

}

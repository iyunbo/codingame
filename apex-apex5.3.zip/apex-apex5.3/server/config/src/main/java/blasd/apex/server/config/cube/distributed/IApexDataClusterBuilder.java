/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.cube.distributed;

import com.quartetfs.biz.pivot.definitions.IDataClusterDefinition;

/**
 * Helps configuring a {@link IDataClusterDefinition}
 * 
 * @author Benoit Lacelle
 *
 */
public interface IApexDataClusterBuilder extends IApexClusterBuilder<IDataClusterDefinition> {
	/**
	 * The applicationId represents the topology of the cube (e.g. VaR, Risk or PnL). A data-node can be associated to
	 * multiple cluster, but each cluster association is done through a single applicationId
	 */
	// http://support.quartetfs.com/confluence/pages/viewpage.action?pageId=27856726
	IApexDataClusterBuilder setApplicationId(String applicationId);
}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.cube;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.annotations.Beta;
import com.quartetfs.biz.pivot.cube.hierarchy.IHierarchy;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevel;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevelInfo.ClassificationType;
import com.quartetfs.biz.pivot.cube.hierarchy.impl.HierarchiesUtil;
import com.quartetfs.biz.pivot.definitions.IAxisDimensionDescription;
import com.quartetfs.biz.pivot.definitions.IAxisHierarchyDescription;
import com.quartetfs.biz.pivot.definitions.IPartialProviderDefinition;
import com.quartetfs.biz.pivot.definitions.impl.PartialProviderDefinition;

import blasd.apex.server.config.description.ApexDescriptionHelper;

/**
 * Add some helper methods for {@link IPartialProviderDefinition} configuration.
 * 
 * About the strategy to define a nice partitioning: sometimes, it is difficult to decide on which field one should do
 * hashed partitioning. Then, one should not hash a high-cardinality field: else, either it is a core-hashing and the
 * original high-cardinality field has to be set as level (i.e. as level) and then we get a high cardinality dimension,
 * nor to use a manual hashing as, since the bitmap will duplicate each point on each partition (e.g. France|EUR will
 * appear for hash=0, hash=1, hash=2...). One strategy could then consist in manually hashing the concatenation or
 * several field: e.g. if we have 2 nice fields for hash-partitioning except then have 1 common value (e.g. haslf-of
 * data has no value for this field), then hashing the concatenation would nicely dispatch the data on each bucket (as
 * it would be dispacthed by at least one of the field).
 * 
 * @author Benoit Lacelle
 * 
 */
public class ApexPartialProviderHelper {
	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexPartialProviderHelper.class);

	/**
	 * The name of the first {@link ILevel} of {@link IHierarchy} with isAllMembersEnabled=true
	 */
	public static final String ALL = ClassificationType.ALL.toString();

	/**
	 * Some QFS people recommend to use 2 partitions per logical core, in order to imprive the concurrency level. Others
	 * recommand not to go above 32 cores.
	 */
	public static final int DEFAULT_HASH_CONFIGURATION = 2 * Runtime.getRuntime().availableProcessors();

	protected ApexPartialProviderHelper() {
		// hidden
	}

	/**
	 * @return an {@link IPartialProviderDefinition} which contains only the selected {@link IHierarchy}, down to their
	 *         deepest level
	 */
	public static IPartialProviderDefinition makePartialProviderDefinition(String pluginKey,
			List<? extends IAxisDimensionDescription> dimensions,
			Collection<? extends String> hierarchiesToInclude,
			Collection<String> measures) {
		Map<String, Map<String, String>> scopeElts = hierarchiesToInclude.stream()
				.map(hierarchyName -> ApexDescriptionHelper.findHierarchy(dimensions, hierarchyName)
						.orElseThrow(() -> new IllegalStateException("There is no IHierarchy named " + hierarchyName)))
				.collect(Collectors.toMap(e -> e.getKey().getName(),
						e -> Collections.singletonMap(e.getValue().getName(), null)));

		IPartialProviderDefinition def =
				new PartialProviderDefinition(pluginKey, scopeElts, measures, null, null, null);

		return def;
	}

	/**
	 * @return an {@link IPartialProviderDefinition} which contains all {@link ILevel} except those excluded explicitely
	 */
	// TODO: add automatically Slicing hierarchies (including Analysis ones)
	public static Map<String, Map<String, String>> makeComplementPartialProviderDefinition(
			List<? extends IAxisDimensionDescription> dimensions,
			Map<String, Map<String, String>> dimensionToHierarchyToMaxLevelName) {

		// TODO: can not use guava Table as we put null values
		Map<String, Map<String, String>> scopeElts = new HashMap<String, Map<String, String>>();

		Set<String> dmensionUsed = new HashSet<>();

		for (IAxisDimensionDescription d : dimensions) {
			Map<String, String> hierarchyToMaxLevel = dimensionToHierarchyToMaxLevelName.get(d.getName());

			if (hierarchyToMaxLevel == null) {
				hierarchyToMaxLevel = Collections.emptyMap();
			}

			String dimensionName = d.getName();

			Set<String> hierarchyUsed = new HashSet<>();

			for (IAxisHierarchyDescription h : d.getHierarchies()) {
				String hierarchyName = h.getName();

				if (!hierarchyToMaxLevel.containsKey(hierarchyName)) {
					// Add all levels of not restricted hierarchies
					addToMapOfMap(scopeElts, dimensionName, hierarchyName, null);
				} else {
					// The Hierarchy has a constrain
					dmensionUsed.add(dimensionName);
					hierarchyUsed.add(hierarchyName);

					// Excluded hierarchy
					String maxLevelExcluded = hierarchyToMaxLevel.get(hierarchyName);

					if (maxLevelExcluded == null) {
						throw new IllegalArgumentException(
								"One can not exclude up to a given, which would mean rejecting the whole hierarchy");
					} else {
						if (h.isAllMembersEnabled() && ALL.equals(maxLevelExcluded)) {
							// Special behavior for ALL level as it is done
							// present in h.getlevels
							addToMapOfMap(scopeElts, dimensionName, hierarchyName, ClassificationType.ALL.toString());
						} else {
							boolean done = false;

							for (int i = 0; i < h.getLevels().size(); i++) {
								if (maxLevelExcluded.equals(h.getLevels().get(i).getLevelName())) {
									addLevel(i, scopeElts, dimensionName, h.getName(), maxLevelExcluded, h);

									done = true;
									break;
								}
							}

							if (!done) {
								throw new IllegalStateException(
										"There is no level named " + maxLevelExcluded + " in " + hierarchyName);
							}
						}
					}
				}
			}

			// Check the configuration was consistent
			Set<String> expected = new TreeSet<>(hierarchyToMaxLevel.keySet());
			expected.removeAll(hierarchyUsed);

			if (!expected.isEmpty()) {
				throw new IllegalStateException("Some Hierarchies (" + expected
						+ ") were expressed in the partial while they do not exist in the hierarchy "
						+ dimensionName);
			}
		}

		// Check the configuration was consistent
		{
			Set<String> expected = new HashSet<>(dimensionToHierarchyToMaxLevelName.keySet());
			expected.removeAll(dmensionUsed);

			if (!expected.isEmpty()) {
				throw new IllegalStateException(
						"Some Dimensions (" + expected + ") were expressed in the partial while they do not exist");
			}
		}

		return scopeElts;
	}

	public static IPartialProviderDefinition makeComplementPartialProviderDefinition(String pluginKey,
			List<? extends IAxisDimensionDescription> dimensions,
			Map<String, Map<String, String>> dimensionToHierarchyToMaxLevelName,
			Collection<? extends String> includedMeasures) {
		Map<String, Map<String, String>> complement =
				makeComplementPartialProviderDefinition(dimensions, dimensionToHierarchyToMaxLevelName);
		Collection<String> selectedMeasures;
		if (includedMeasures == null) {
			selectedMeasures = null;
		} else {
			selectedMeasures = Collections.unmodifiableCollection(includedMeasures);
		}
		return new PartialProviderDefinition(pluginKey, complement, selectedMeasures, null, null, null);
	}

	protected static void addLevel(int levelOrdinal,
			Map<String, Map<String, String>> scopeElts,
			String dimensionName,
			String hierarchyName,
			String maxLevelExcluded,
			IAxisHierarchyDescription h) {
		if (levelOrdinal == 0) {
			// It is the first level which is
			// excluded
			if (h.isAllMembersEnabled()) {
				// Add the ALL level, in order to handle ILocation with a
				// WildCard on the ALL level; it won't increase the partial size
				addToMapOfMap(scopeElts, dimensionName, hierarchyName, ALL);
			} else {
				// A partial has to include the first level of all dimensions:
				// add this level even if requested to reject it
				addToMapOfMap(scopeElts, dimensionName, hierarchyName, maxLevelExcluded);

				LOGGER.info("We added the slicing level {} even if it was requested to be rejected from the partial",
						maxLevelExcluded);
			}
		} else {
			// It is not the first level which is excluded: keep the parent
			// level
			addToMapOfMap(scopeElts, dimensionName, hierarchyName, h.getLevels().get(levelOrdinal - 1).getLevelName());
		}

	}

	/**
	 * Add a level to the definition of a IPartialProviderDefinition
	 * 
	 * @param hierarchyName
	 * @param levelDepth
	 * @param axisDimensionList
	 * @param dimensionToHierarchyToMaxLevelName
	 */
	@Beta
	public static void addLevelInPartial(String hierarchyName,
			int levelDepth,
			List<IAxisDimensionDescription> axisDimensionList,
			Map<String, Map<String, String>> dimensionToHierarchyToMaxLevelName) {
		addToMapOfMap(dimensionToHierarchyToMaxLevelName,
				ApexDescriptionHelper.findOwningDimension(axisDimensionList, hierarchyName).getName(),
				hierarchyName,
				ApexDescriptionHelper.getLevelName(axisDimensionList, hierarchyName, levelDepth));
	}

	/**
	 * Like {@link HierarchiesUtil#addToMap(Map, String, String, Object)} but more generic
	 */
	// This should not be used and one should use Table, However Table does not accept null values
	public static <S, T, U> U addToMapOfMap(Map<S, Map<T, U>> mapOfMap, S key1, T key2, U value) {
		Map<T, U> map = mapOfMap.computeIfAbsent(key1, (k) -> {
			if (mapOfMap instanceof ConcurrentMap<?, ?>) {
				return new ConcurrentHashMap<>();
			} else {
				return new HashMap<>();
			}
		});
		return map.put(key2, value);
	}

}

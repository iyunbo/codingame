/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.cube;

import java.util.List;

import com.google.common.collect.Lists;
import com.quartetfs.biz.pivot.definitions.IAggregatesCacheDescription;
import com.quartetfs.biz.pivot.query.aggregates.IAggregatesCache;

/**
 * Enable configuration of the {@link IAggregatesCache}
 * 
 * @author Benoit Lacelle
 *
 */
// http://support.quartetfs.com/confluence/pages/viewpage.action?pageId=19335302
// http://support.quartetfs.com/confluence/display/AP5/Aggregates+Cache
public interface IApexAggregateCacheBuilder extends IApexDescriptionHolder<IAggregatesCacheDescription> {
	void noCache();

	/**
	 * If 2 queries happens at the same time and requests the same aggregates, the second query will wait for the first
	 * query result. However, aggregates are discarded right after the end of the query
	 * 
	 * @see http://support.quartetfs.com/confluence/display/AP5/Sharing+and+Caching
	 * @see http://support.quartetfs.com/confluence/display/AP5/Sharing+Without+Caching+or+No+Caching
	 */
	void sharedConcurrentQueries();

	/**
	 * @see http://support.quartetfs.com/confluence/display/AP5/Sharing+and+Caching
	 */
	void shareAndCache(int nbOfLocationsMeasures);

	/**
	 * Include only these measures in the cache
	 * 
	 * @param measureNames
	 *            measures to exclude
	 */
	void withMeasures(List<? extends String> measureNames);

	/**
	 * Include only these measures in the cache
	 * 
	 * @param measureName
	 *            one measure to include
	 * @param moreMeasureNames
	 *            more measures to include
	 */
	default void withMeasures(String measureName, String... moreMeasureNames) {
		withMeasures(Lists.asList(measureName, moreMeasureNames));
	}

	/**
	 * Exclude these measures from the cache
	 * 
	 * @param measureNames
	 *            measures to exclude
	 */
	void withoutMeasures(List<? extends String> measureNames);

	/**
	 * Exclude these measures from the cache
	 * 
	 * @param measureName
	 *            one measure to exclude
	 * @param moreMeasureNames
	 *            more measures to exclude
	 */
	default void withoutMeasures(String measureName, String... moreMeasureNames) {
		withMeasures(Lists.asList(measureName, moreMeasureNames));
	}
}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.cube;

import com.google.common.base.Joiner;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevelInfo;
import com.quartetfs.biz.pivot.definitions.IAxisLevelDescription;
import com.quartetfs.biz.pivot.definitions.impl.ComparatorDescription;

/**
 * helps configuring IAxisLevelDescription
 * 
 * @author Benoit Lacelle
 *
 */
public class ApexLevelBuilder implements IApexLevelBuilder {

	protected final IApexHierarchyBuilder hierarchyBuilder;
	protected final IAxisLevelDescription levelDescription;

	public ApexLevelBuilder(IApexHierarchyBuilder hierarchyBuilder, IAxisLevelDescription levelDescription) {
		this.hierarchyBuilder = hierarchyBuilder;
		this.levelDescription = levelDescription;
	}

	public static String levelName(String hierarchyName, String levelName) {
		return Joiner.on(IApexHierarchyBuilder.LEVEL_SEPARATOR).join(levelName, hierarchyName);
	}

	public static String levelName(String dimensionName, String hierarchyName, String levelName) {
		if (dimensionName == null) {
			return levelName(hierarchyName, levelName);
		} else {
			return Joiner.on(IApexHierarchyBuilder.LEVEL_SEPARATOR).join(levelName, hierarchyName, dimensionName);
		}
	}

	public static String levelName(ILevelInfo levelInfo) {
		return levelName(levelInfo.getHierarchyInfo().getName(), levelInfo.getName());
	}

	@Override
	public IAxisLevelDescription getDescription() {
		return levelDescription;
	}

	@Override
	public IApexLevelBuilder setComparatorPluginKey(String pluginKey) {
		levelDescription.setComparator(new ComparatorDescription(pluginKey));

		return this;
	}

	@Override
	public IApexLevelBuilder setFormatterPluginKey(String pluginKey) {
		levelDescription.setFormatter(pluginKey);

		return this;
	}

	@Override
	public IApexCubeBuilder getCubeBuilder() {
		return hierarchyBuilder.getCubeBuilder();
	}

	@Override
	public IApexHierarchyBuilder getHierarchyBuilder() {
		return hierarchyBuilder;
	}

	@Override
	public IApexLevelBuilder appendLevel(String levelName) {
		return getHierarchyBuilder().appendLevel(levelName);
	}

	@Override
	public String getId() {
		IApexHierarchyBuilder h = getHierarchyBuilder();
		return levelName(h.getDimensionBuilder().getName(), h.getName(), getName());
	}

	@Override
	public String getName() {
		return levelDescription.getLevelName();
	}

	@Override
	public IApexLevelBuilder setName(String elementNewName) {
		levelDescription.setLevelName(elementNewName);
		return this;
	}

	@Override
	public String toString() {
		return getId();
	}

	@Override
	public IApexLevelBuilder setPropertyName(String propertyName) {
		getDescription().setPropertyName(propertyName);

		return this;
	}
}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.cube.distributed;

import java.util.Collection;

import com.google.common.base.Joiner;
import com.quartetfs.biz.pivot.definitions.IQueryClusterDefinition;

/**
 * Default implementation for {@link IApexDistributedApplicationBuilder}
 * 
 * @author Benoit Lacelle
 *
 */
public class ApexDistributedApplicationBuilder implements IApexDistributedApplicationBuilder {
	// Not in public API
	static final Joiner DISTRIBUTED_FIELDS_JOINER =
			Joiner.on(IQueryClusterDefinition.IDistributedApplicationDefinition.DISTRIBUTING_FIELD_SEPARATOR);

	protected final IQueryClusterDefinition.IDistributedApplicationDefinition app;

	public ApexDistributedApplicationBuilder(IQueryClusterDefinition.IDistributedApplicationDefinition app) {
		this.app = app;
	}

	@Override
	public String getId() {
		return app.getApplicationId();
	}

	@Override
	public String getName() {
		return getId();
	}

	@Override
	public Object setName(String elementNewName) {
		app.setApplicationId(elementNewName);
		return this;
	}

	@Override
	public IQueryClusterDefinition.IDistributedApplicationDefinition getDescription() {
		return app;
	}

	@Override
	public IApexDistributedApplicationBuilder setDistributingFields(Collection<? extends String> distributingFields) {
		final String distributedFieldsAsString;
		distributedFieldsAsString = joinDistributedFields(distributingFields);

		app.setDistributingFields(distributedFieldsAsString);

		return this;
	}

	public static String joinDistributedFields(Collection<? extends String> distributingFields) {
		final String distributedFieldsAsString;
		if (distributingFields == null || distributingFields.isEmpty()) {
			// https://support.activeviam.com/jira/browse/APS-9837
			// Interpreted by DistributedApplication constructor
			distributedFieldsAsString = null;
		} else {
			distributedFieldsAsString = DISTRIBUTED_FIELDS_JOINER.join(distributingFields);
		}
		return distributedFieldsAsString;
	}

}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.cube;

import java.util.Optional;
import java.util.Properties;

import com.quartetfs.biz.pivot.definitions.IMeasureMemberDescription;
import com.quartetfs.biz.pivot.definitions.impl.MeasureMemberDescription;

/**
 * Helps configuring an IMeasureMemberDescription
 * 
 * @author Benoit Lacelle
 *
 * @param <T>
 */
public abstract class AApexMeasureBuilder<T extends IMeasureMemberDescription> implements IApexMeasureBuilder<T> {
	protected final IApexCubeBuilder cubeBuilder;
	protected final T measureDescription;

	public AApexMeasureBuilder(IApexCubeBuilder cubeBuilder, T measureDescription) {
		this.cubeBuilder = cubeBuilder;
		this.measureDescription = measureDescription;
	}

	@Override
	public IApexCubeBuilder getCubeBuilder() {
		return cubeBuilder;
	}

	@Override
	public String getMeasureName() {
		return measureDescription.getName();
	}

	@Override
	public T getDescription() {
		return measureDescription;
	}

	@Override
	public IApexMeasureBuilder<T> setVisible(Boolean isVisible) {
		measureDescription.setVisible(isVisible);

		return this;
	}

	@Override
	public IApexMeasureBuilder<T> setFolder(String folderName) {
		measureDescription.setFolder(folderName);

		return this;
	}

	@Override
	public IApexMeasureBuilder<T> setGroup(String groupName) {
		measureDescription.setGroup(groupName);

		return this;
	}

	@Override
	public IApexMeasureBuilder<T> setName(String measureName) {
		measureDescription.setName(measureName);

		return this;
	}

	@Override
	public IApexMeasureBuilder<T> setFormatter(String formatterPluginKey) {
		((MeasureMemberDescription) measureDescription).setFormatter(formatterPluginKey);

		return this;
	}

	@Override
	public IApexPostProcessorBuilder<?> addPostProcessedMeasure(String name, String pluginKey, Properties properties) {
		return getCubeBuilder().addPostProcessedMeasure(name, pluginKey, properties);
	}

	@Override
	public IApexPostProcessorBuilder<?> addPostProcessedMeasure(String name, String pluginKey) {
		return getCubeBuilder().addPostProcessedMeasure(name, pluginKey);
	}

	@Override
	public Optional<IApexPostProcessorBuilder<?>> getPostProcessedMeasure(String measureName) {
		return getCubeBuilder().getPostProcessedMeasure(measureName);
	}

	@Override
	public IApexAggregatedMeasureBuilder addAggregatedMeasure(String fieldName, String aggregationFunctionPluginKey) {
		return getCubeBuilder().addAggregatedMeasure(fieldName, aggregationFunctionPluginKey);
	}

	@Override
	public <S extends IRawApexPostProcessorBuilder<S>> IApexPostProcessorBuilder<S> addPostProcessedMeasure(String name,
			S specificPPBuilder) {
		// Skip generic to workaround javac issues
		return getCubeBuilder().addPostProcessedMeasure(name, specificPPBuilder);
	}

}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.store;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Objects;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import com.qfs.desc.IFieldDescription;
import com.qfs.desc.INumaSelectorDescription;
import com.qfs.desc.IOptimizationDescription;
import com.qfs.desc.IStoreDescription;
import com.qfs.desc.IStoreDescriptionBuilder.ICanAddField;
import com.qfs.desc.IStoreDescriptionBuilder.ICanBuild;
import com.qfs.desc.IStoreDescriptionBuilder.IDuplicateKeyWithinTransactionListener;
import com.qfs.desc.IStoreDescriptionBuilder.INamed;
import com.qfs.desc.IStoreDescriptionBuilder.IRemoveUnknownKeyListener;
import com.qfs.desc.IStoreDescriptionBuilder.IStaticKeyFields;
import com.qfs.desc.IStoreDescriptionBuilder.IUnkeyedTaggable;
import com.qfs.desc.impl.FieldDescription;
import com.qfs.desc.impl.StoreDescription;
import com.qfs.desc.impl.StoreDescriptionBuilder;
import com.qfs.literal.ILiteralType;
import com.qfs.literal.impl.LiteralType;
import com.qfs.store.part.IPartitioningDescription;
import com.qfs.store.record.impl.Records;
import com.quartetfs.fwk.IPair;
import com.quartetfs.fwk.Registry;
import com.quartetfs.fwk.impl.Pair;

/**
 * This class helps configuring your datastores by compiling descriptions from {@link IApexStoreConfig},
 * {@link IStoreDescription} and {@link ICanBuild}. It is useful for instance when one store is filled by two kind of
 * files
 * 
 * @author Benoit Lacelle
 * 
 */
public class StoreDescriptionMerger implements IStoreDescriptionMerger {

	protected static final Logger LOGGER = LoggerFactory.getLogger(StoreDescriptionMerger.class);

	protected final List<IStoreDescription> storeDescriptions = new ArrayList<>();

	@Override
	public StoreDescriptionMerger addStoreDescription(IStoreDescription apexStoreConfig) {
		storeDescriptions.add(apexStoreConfig);

		return this;
	}

	@Override
	public StoreDescriptionMerger addStoreDescriptions(Collection<? extends IStoreDescription> apexStoreConfig) {
		storeDescriptions.addAll(apexStoreConfig);

		return this;
	}

	public static ICanBuild prepareStoreBuilder(String storeName,
			Map<? extends String, ? extends String> columnNameToColumnType,
			String... keyFields) {
		return prepareStoreBuilder(storeName, columnNameToColumnType, Collections.emptyMap(), Arrays.asList(keyFields));
	}

	public static IStaticKeyFields prepareStoreBuilder(String storeName,
			Map<? extends String, ? extends String> columnNameToLiteralType,
			Map<String, Object> columnNameToDefaultValue,
			List<? extends String> keyFields) {
		if (columnNameToDefaultValue == null) {
			columnNameToDefaultValue = Collections.emptyMap();
		}

		StoreDescriptionBuilder builder = new StoreDescriptionBuilder();

		// Maintain the order of fields
		Set<String> fieldNames = new LinkedHashSet<>();

		// First, column defined by type: maintain columns like in CSV
		fieldNames.addAll(columnNameToLiteralType.keySet());

		// Second, columns defined by default values
		fieldNames.addAll(columnNameToDefaultValue.keySet());

		// Then keyFields
		if (keyFields != null) {
			fieldNames.addAll(keyFields);
		}

		if (fieldNames.isEmpty()) {
			throw new RuntimeException("No field defined in " + storeName);
		}

		// First, we have
		// allFields.addAll(config.getKeyFields());

		INamed withStoreName = builder.withStoreName(storeName);

		ICanAddField<IUnkeyedTaggable> lastField = withStoreName;
		for (String fieldName : fieldNames) {
			String dataType = columnNameToLiteralType.get(fieldName);

			if (dataType == null) {
				// We use the Object datatype to enable inserting any object, typically String or LocalDate
				dataType = LiteralType.OBJECT;
			}

			Object defaultValue;
			// SchemaConfigurationValidator would ensure a FieldDescription with
			// a null default value is nullable
			{
				ILiteralType type = (ILiteralType) Registry.getPlugin(ILiteralType.class).valueOf(dataType);
				if (type == null) {
					throw new IllegalArgumentException("There is no ILiteralType for key=" + dataType);
				}

				if (columnNameToDefaultValue.containsKey(fieldName)) {
					defaultValue = columnNameToDefaultValue.get(fieldName);
				} else {
					defaultValue = getGlobalDefaultValue(type);
				}
			}

			lastField = lastField.withField(fieldName, dataType, defaultValue);
		}

		IStaticKeyFields keysDefined;
		if (keyFields == null || keyFields.isEmpty()) {
			keysDefined = ((IUnkeyedTaggable) lastField).withoutKey();
		} else {
			keysDefined = ((IUnkeyedTaggable) lastField).withKeyFields(keyFields.toArray(new String[0]));
		}

		return keysDefined;
	}

	/**
	 * 
	 * @param type
	 * @return the default value which will be applied when the column is nullable and the input holds null
	 */
	public static Object getGlobalDefaultValue(ILiteralType type) {
		return Records.getGlobalDefaultValue(type);
	}

	/**
	 * merge several store description. it could happens if several files with different formats are used to fill a
	 * single store
	 * 
	 * The keyFields are the union of the input keyFields. It enables usecases like conditional-references.
	 * 
	 * @param stores
	 * @return
	 */
	public Map<String, IStoreDescription> mergeStoreDescription(Collection<? extends IStoreDescription> stores) {
		Map<String, IStoreDescription> asMap = new HashMap<>();

		for (IStoreDescription store : stores) {
			if (asMap.containsKey(store.getName())) {
				// This store has already been encountered: fill the known
				// config with the new config
				IStoreDescription merged = mergeStoreDescription(asMap.get(store.getName()), store);

				asMap.put(store.getName(), merged);
			} else {
				// Nothing to merge
				asMap.put(store.getName(), store);
			}
		}

		return asMap;
	}

	public IStoreDescription mergeStoreDescription(IStoreDescription left, IStoreDescription right) {
		String storeName = left.getName();
		List<String> keys = left.getKeyFields();

		// Check what has to be equals to be able to merge
		checkSame("storeName", storeName, right.getName());
		checkSame("keyFields of " + storeName, keys, right.getKeyFields());

		String storageType = selectNotNull(left.getStorageType(), right.getStorageType());

		IPartitioningDescription partitioning = selectNotNull(left.getPartitioning(), right.getPartitioning());

		boolean updateOnlyIfDifferent = selectNotNull(left.updateOnlyIfDifferent(), right.updateOnlyIfDifferent());
		int chunkSize = selectNotNull(left.getChunkSize(), right.getChunkSize());

		IDuplicateKeyWithinTransactionListener duplicateKeyBehavior =
				selectNotNull(left.getDuplicateKeyWithinTransaction(), right.getDuplicateKeyWithinTransaction());

		IRemoveUnknownKeyListener removeUnknownKeyBehavior =
				selectNotNull(left.getRemoveUnknownKeyBehavior(), right.getRemoveUnknownKeyBehavior());
		INumaSelectorDescription numaNodeSelector = selectNotNull(left.getNumaSelector(), right.getNumaSelector());

		Map<String, IFieldDescription> fields;
		{
			// Maintain the order of columns
			fields = new LinkedHashMap<>();

			// First, we add the left fields
			for (IFieldDescription field : left.getFields()) {
				fields.put(field.getName(), field);
			}

			// Then, we merge right fields in left fields
			for (IFieldDescription field : right.getFields()) {
				addOrMergeField(storeName, fields, field);
			}
		}

		Set<IOptimizationDescription> optimizations = new LinkedHashSet<>();
		optimizations.addAll(left.getOptimizationDescriptions());
		optimizations.addAll(right.getOptimizationDescriptions());

		Properties properties = new Properties();
		properties.putAll(left.getProperties());
		properties.putAll(right.getProperties());

		boolean shouldCompressIndexes = left.shouldCompressIndexes() || right.shouldCompressIndexes();

		return new StoreDescription(storeName,
				keys,
				new ArrayList<>(fields.values()),
				storageType,
				partitioning,
				optimizations,
				updateOnlyIfDifferent,
				chunkSize,
				duplicateKeyBehavior,
				removeUnknownKeyBehavior,
				properties,
				numaNodeSelector,
				shouldCompressIndexes);
	}

	protected <T> T selectNotNull(T left, T right) {
		if (left == null) {
			return right;
		} else if (right == null) {
			return left;
		} else {
			if (!left.equals(right)) {
				LOGGER.warn("We select {} over {}", left, right);
			}
			return left;
		}
	}

	protected void checkSame(String message, Object selected, Object toCheck) {
		if (!Objects.equal(selected, toCheck)) {
			throw new RuntimeException("We can not merge IStoreDescription with incompatible " + message
					+ ": "
					+ selected
					+ " and "
					+ toCheck);
		}
	}

	protected void addOrMergeField(String storeName, Map<String, IFieldDescription> fields, IFieldDescription field) {
		String fieldName = field.getName();
		if (fields.containsKey(fieldName)) {
			IFieldDescription previous = fields.get(fieldName);

			if (sameDatatype(previous, field)) {
				// No need to merge
				LOGGER.debug("Encountered again dataType {} for field={} in store {}",
						previous.getDataType(),
						fieldName,
						storeName);
			} else {
				// Brute force merging: We expect 2 different
				// kind of data so we put in an Object
				// TODO: log and custom default value
				boolean isNullable = field.isNullable() || previous.isNullable();

				Object defaultValue = mergeDefaultValue(storeName, previous, field);

				// TODO: how should we merge the default values?
				fields.put(fieldName, new FieldDescription(fieldName, ILiteralType.OBJECT, isNullable, defaultValue));

				LOGGER.info("For field={} in store {}, merged {} from {} and {}",
						fieldName,
						storeName,
						fields.get(fieldName),
						previous,
						field);
			}
		} else {
			fields.put(fieldName, field);
		}
	}

	public static boolean sameDatatype(IFieldDescription previous, IFieldDescription field) {
		return previous.getDataType().equals(field.getDataType());
	}

	public static Object mergeDefaultValue(String storeName, IFieldDescription previous, IFieldDescription field) {
		Object comingDefaultValue = field.getDefault();

		Object mergedDefaultValue;
		if (comingDefaultValue != null) {
			mergedDefaultValue = comingDefaultValue;

			if (previous.getDefault() != null && !Objects.equal(comingDefaultValue, previous.getDefault())) {
				LOGGER.warn("Default values {} and {} for field={} in store {} are incompatible. We kept {}",
						comingDefaultValue,
						previous.getDefault(),
						previous.getName(),
						storeName,
						comingDefaultValue);
			}
		} else {
			// We get here either if previous has a default, or
			// if both has null as default
			mergedDefaultValue = previous.getDefault();
		}

		return mergedDefaultValue;
	}

	public static void checkKeyFieldsOrder(IStoreDescription storeDescription) {
		List<String> keyFields = storeDescription.getKeyFields();
		List<? extends IFieldDescription> fields = storeDescription.getFields();

		List<String> fieldNames = Lists.transform(fields, IFieldDescription::getName);

		int index = -1;

		for (String keyField : keyFields) {
			int newIndex = fieldNames.indexOf(keyField);

			if (newIndex == -1) {
				// We let AP do the actual Exception
				LOGGER.error("In store={}, there is no key field named {} in the existing fields {}",
						storeDescription.getName(),
						keyField,
						fieldNames);
			} else if (newIndex <= index) {
				// This would lead in issues when one create a key tuple as an
				// Object[] as the key order is probably not the one expected by
				// the
				// developer
				LOGGER.error("In store={}, the keyFields {} are not expressed in the same order in the fields {}",
						storeDescription.getName(),
						keyFields,
						fieldNames);
				break;
			} else {
				index = newIndex;
			}
		}
	}

	/**
	 * 
	 * @return a referenceMapping when the foreign keys in the source store and the secondary in the target store have
	 *         the same name
	 */
	public static List<? extends IPair<String, String>> simpleReferenceMapping(List<? extends String> fieldNames) {
		return Lists.transform(fieldNames, fieldName -> new Pair<String, String>(fieldName, fieldName));
	}

	public static List<? extends IPair<String, String>> simpleReferenceMapping(String... fieldNames) {
		return simpleReferenceMapping(Arrays.asList(fieldNames));
	}

	@Override
	public Collection<IStoreDescription> merge() {
		List<IStoreDescription> allStoreDescriptions = ImmutableList.copyOf(storeDescriptions);

		Map<String, IStoreDescription> mergedStoreDescription = mergeStoreDescription(allStoreDescriptions);

		for (IStoreDescription storeDescription : mergedStoreDescription.values()) {
			checkKeyFieldsOrder(storeDescription);
		}

		return mergedStoreDescription.values();
	}
}

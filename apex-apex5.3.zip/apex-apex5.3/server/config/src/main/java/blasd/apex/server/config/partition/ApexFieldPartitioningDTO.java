/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.partition;

import java.util.Objects;

/**
 * A DTO holding the description of a partitioned field
 * 
 * @author Benoit Lacelle
 * 
 */
public class ApexFieldPartitioningDTO {
	// TODO: is there a core constant for "value"?
	public static final String FUNCTION_VALUE_PARTITIONING = "value";
	public static final String FUNCTION_HASH_PARTITIONING = "hash";

	public final String fieldName;
	public final String partitioningDescription;

	public ApexFieldPartitioningDTO(String fieldName, String partitioningDescription) {
		Objects.requireNonNull(fieldName);
		Objects.requireNonNull(partitioningDescription);

		this.fieldName = fieldName;

		if ("".equals(partitioningDescription)) {
			// Since ActivePivot5.6.0-M1, the core does not accept the field name as partitioning description: we
			// enforce the 'value' function
			this.partitioningDescription = FUNCTION_VALUE_PARTITIONING;
		} else {
			this.partitioningDescription = partitioningDescription;
		}

	}

	@Override
	public String toString() {
		if (partitioningDescription.isEmpty()) {
			// ByValue
			return fieldName;
		} else {
			// By default, we partition along the first available field
			return partitioningDescription + "(" + fieldName + ")";
		}
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		if (fieldName == null) {
			result = prime * result;
		} else {
			result = prime * result + fieldName.hashCode();
		}
		if (partitioningDescription == null) {
			result = prime * result;
		} else {
			result = prime * result + partitioningDescription.hashCode();
		}
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		ApexFieldPartitioningDTO other = (ApexFieldPartitioningDTO) obj;
		if (fieldName == null) {
			if (other.fieldName != null) {
				return false;
			}
		} else if (!fieldName.equals(other.fieldName)) {
			return false;
		}
		if (partitioningDescription == null) {
			if (other.partitioningDescription != null) {
				return false;
			}
		} else if (!partitioningDescription.equals(other.partitioningDescription)) {
			return false;
		}
		return true;
	}

	public static ApexFieldPartitioningDTO valuePartitioning(String fieldName) {
		return new ApexFieldPartitioningDTO(fieldName, FUNCTION_VALUE_PARTITIONING);
	}

	public static ApexFieldPartitioningDTO hashPartitioning(String fieldName, int nbPartitions) {
		return new ApexFieldPartitioningDTO(fieldName, hashPrefix(nbPartitions));
	}

	public static String hashPrefix(int hashCardinality) {
		return FUNCTION_HASH_PARTITIONING + hashCardinality;
	}

}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.test;

import java.time.LocalDate;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import com.google.common.collect.ImmutableMap;
import com.qfs.agg.impl.AvgFunction;
import com.qfs.agg.impl.SumFunction;
import com.qfs.literal.ILiteralType;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevelInfo.ClassificationType;
import com.quartetfs.biz.pivot.definitions.IActivePivotDescription;

import blasd.apex.server.config.cube.ApexCubeBuilder;
import blasd.apex.server.config.cube.ApexLevelBuilder;

/**
 * Holds various constants to build cube and store in tests
 * 
 * @author Benoit Lacelle
 *
 */
public interface IApexTestConstants {
	String ALL = ClassificationType.ALL.toString();

	String MAIN_STORE = "MainStore";
	String MAIN_CUBE = "MainCube";
	String MAIN_SCHEMA = "MainSchema";

	String ENRICHMENT_STORE = "EnrichmentStore";

	/**
	 * Some tests relies on a second store, in addition to a main store
	 */
	String SECONDARY_STORE = "SecondaryStore";

	String ASOFDATE = "AsOfDate";

	String STRING = ILiteralType.STRING;
	String COUNTRY = "COUNTRY";
	String CITY = "City";
	String CCY = "CCY";

	/**
	 * Typical Hierarchy Names
	 */
	String COUNTRY_DIM = COUNTRY + "_Dim";
	String COUNTRY_HIE = COUNTRY + "_Hie";

	String COUNTRY_HIE_FULL = ApexLevelBuilder.levelName(COUNTRY_DIM, COUNTRY_HIE);

	String COUNTRY_ALL = ApexLevelBuilder.levelName(COUNTRY_HIE, ALL);

	String COUNTRY_LEV = ApexLevelBuilder.levelName(COUNTRY_HIE, COUNTRY);
	String COUTNRY_LEV_FULL = ApexLevelBuilder.levelName(COUNTRY_DIM, COUNTRY_HIE, COUNTRY);

	String CITY_LEV = ApexLevelBuilder.levelName(COUNTRY_HIE, CITY);

	/**
	 * Single measure name
	 */
	String DOUBLE = ILiteralType.DOUBLE;
	String DELTA = "Delta";
	String VEGA = "Vega";

	String FLOAT = ILiteralType.FLOAT;
	String FX = "FX";

	String INT = ILiteralType.INT;
	String DAYS = "DAYS";

	String LONG = ILiteralType.LONG;
	String SCORE = "SCORE";

	String SCENARIO_VALUES = "SCENARIO_VALUES";

	/**
	 * A table Country|Currency -> Delta, like an sensitivity table
	 */
	String COUNTRY_CCY_DELTA = "COUNTRY_CCY_DELTA";
	Map<String, String> COUNTRY_CCY_DELTA_DESC = ImmutableMap.of(COUNTRY, STRING, CCY, STRING, DELTA, DOUBLE);

	/**
	 * A table Country -> Currency, like an enrichment table
	 */
	String COUNTRY_CCY = "COUNTRY_CCY";
	Map<String, String> COUNTRY_CCY_DESC = ImmutableMap.of(COUNTRY, STRING, CCY, STRING);

	/**
	 * A table Currency -> FX, like a market-data table
	 */
	String CCY_FX = "CCY_FX";
	Map<String, String> CCY_FX_DESC = ImmutableMap.of(CCY, STRING, FX, FLOAT);

	String CCY_DAYS = "CCY_DAYS";
	Map<String, String> CCY_DAYS_DESC = ImmutableMap.of(CCY, STRING, DAYS, INT);

	String EUR = "EUR";
	String USD = "USD";
	String JPY = "JPY";

	String FRANCE = "France";
	String PARIS = "Paris";
	String NICE = "Nice";

	String USA = "USA";
	String NEW_YORK = "New-York";

	String CANADA = "Canada";
	String TORONTO = "Toronto";

	String JAPAN = "Japan";
	String TOKYO = "Tokyo";
	String KYOTO = "Kyoto";

	LocalDate TODAY = LocalDate.now();
	LocalDate YESTERDAY = TODAY.minusDays(1);

	/**
	 * Primitive Aggregate Function
	 */
	String SUM = SumFunction.KEY;

	/**
	 * We introduce an alternative but fast aggregation function
	 */
	String AVG = AvgFunction.PLUGIN_KEY;

	/**
	 * Full primitive aggregate measure name
	 */
	String DELTA_SUM = DELTA + "." + SUM;
	String VEGA_AVG = VEGA + "." + AVG;

	/**
	 * Used as placeholder for null, typically in Guava Collection instances
	 */
	Object NULL_MARKER = new Object();

	IActivePivotDescription CCY_COUNTRY_CITY_DELTA_SUM = ApexCubeBuilder.newDescription()
			.addHierarchyAndLevels(CCY)
			.getOrAddDimension(COUNTRY_DIM)
			.addHierarchyAndLevels(COUNTRY, CITY)
			.setName(COUNTRY_HIE)
			.getCubeBuilder()
			.addAggregatedMeasure(DELTA, SUM)
			.getCubeBuilder()
			.getActivePivotDescription();

	IActivePivotDescription ASOFDATE_CCY_COUNTRY_CITY_DELTA_SUM =
			ApexCubeBuilder.cloneActivePivotDescripion(CCY_COUNTRY_CITY_DELTA_SUM)
					.addHierarchyAndLevels(ASOFDATE)
					.setSlicing()
					.getCubeBuilder()
					.getActivePivotDescription();

	/**
	 * We consider a datastore is large if it has this number of fields: it is used as reference for performance checks
	 */
	int PERF_NB_FIELDS = 100;

	// Consider only String fields
	Map<String, String> PERF_FIELDS = IntStream.range(0, PERF_NB_FIELDS)
			.mapToObj(i -> "Field_" + i)
			.collect(Collectors.toMap(f -> f, f -> ILiteralType.STRING));
}

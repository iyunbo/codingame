/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.cube;

import java.util.Collection;
import java.util.Properties;

import com.google.common.collect.Table;
import com.qfs.pivot.cube.provider.bitmap.impl.BitmapAggregateProviderBase;
import com.qfs.pivot.cube.provider.jit.impl.JustInTimeAggregateProviderBase;
import com.qfs.pivot.cube.provider.multi.impl.GlobalMultipleAggregateProviderBase;
import com.quartetfs.biz.pivot.definitions.IAggregateProviderDefinition;

/**
 * This IAggregateProvider is the datastructure holding data for multidimentional queries. There is mainly 2 kin of
 * aggregate provider : JIT which forwards queries to the IDatastore, and the BITMAP which pre-compute aggregates
 * 
 * @author Benoit Lacelle
 *
 */
public interface IApexAggregateProviderBuilder extends IApexDescriptionHolder<IAggregateProviderDefinition> {

	Properties getProperties();

	IApexCubeBuilder getCubeBuilder();

	/**
	 * @see JustInTimeAggregateProviderBase.PLUGIN_TYPE
	 * @see BitmapAggregateProviderBase.PLUGIN_TYPE
	 * @see GlobalMultipleAggregateProviderBase.PLUGIN_TYPE
	 */
	IApexAggregateProviderBuilder setAggregateProviderPluginKey(String pluginKey);

	IApexAggregateProviderBuilder setChunkSize(int chunkSize);

	/**
	 * @see JustInTimeAggregateProviderBase.PLUGIN_TYPE
	 * @see BitmapAggregateProviderBase.PLUGIN_TYPE
	 */
	IApexAggregateProviderBuilder setUnderlyingProviderKey(String pluginType);

	IApexAggregateProviderBuilder setPrintTimings(boolean printTimings);

	/**
	 * Sometimes, one has to disable range-sharing to workaround a core bug
	 * https://support.quartetfs.com/jira/browse/APS-8299
	 */
	IApexAggregateProviderBuilder disableRangeSharingLimit();

	/**
	 * 
	 * @param rangeSharingLimit
	 *            0 to disable the range sharing
	 */
	IApexAggregateProviderBuilder setRangeSharingLimit(int rangeSharingLimit);

	IApexAggregateProviderBuilder setRebuildLimit(double zeroForAlways100ForNever);

	IApexAggregateProviderBuilder addPartialExcluding(Table<String, String, String> dnameToHNameToLName,
			Collection<? extends String> includedMeasures);

	IApexAggregateProviderBuilder addPartialIncluding(Table<String, String, String> dnameToHNameToLName,
			Collection<? extends String> includedMeasures);

}

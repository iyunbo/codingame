/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.cube;

import java.util.function.Consumer;

import com.quartetfs.biz.pivot.definitions.IPostProcessorDescription;
import com.quartetfs.biz.pivot.postprocessing.impl.ABasicPostProcessor;

/**
 * Helps configuring an {@link IPostProcessorDescription}
 * 
 * @author Benoit Lacelle
 *
 * @param <T>
 */
public class ApexPostProcessorBuilder<T extends IRawApexPostProcessorBuilder<? extends T>>
		extends AApexMeasureBuilder<IPostProcessorDescription> implements IApexPostProcessorBuilder<T> {

	protected final T specificPPBuilder;

	public ApexPostProcessorBuilder(IApexCubeBuilder apexCubeBuilder, T specificPPBuilder) {
		super(apexCubeBuilder, specificPPBuilder.getDescription());

		this.specificPPBuilder = specificPPBuilder;
	}

	@Override
	public void setMeasureName(String measureName) {
		setName(measureName);
	}

	@Override
	public IApexPostProcessorBuilder<T> setVisible(Boolean isVisible) {
		super.setVisible(isVisible);

		return this;
	}

	@Override
	public IApexPostProcessorBuilder<T> setFolder(String folderName) {
		super.setFolder(folderName);

		return this;
	}

	@Override
	public IApexPostProcessorBuilder<T> setGroup(String groupName) {
		super.setGroup(groupName);

		return this;
	}

	@Override
	public IApexPostProcessorBuilder<T> setName(String measureName) {
		super.setName(measureName);

		return this;
	}

	@Override
	public IApexPostProcessorBuilder<T> setFormatter(String formatterPluginKey) {
		super.setFormatter(formatterPluginKey);

		return this;
	}

	@Override
	public T configurePostProcessor() {
		return specificPPBuilder;
	}

	@Override
	public IApexPostProcessorBuilder<T> setProperty(String key, String value) {
		getProperties().setProperty(key, value);

		return this;
	}

	@Override
	public IApexPostProcessorBuilder<T> configurePostProcessor(Consumer<T> configurer) {
		configurer.accept(this.configurePostProcessor());

		return this;
	}

	@Override
	public IApexPostProcessorBuilder<T> setUnderlyingMeasures(String... underlyingMeasures) {
		return configurePostProcessor(c -> c.setUnderlyingMeasures(underlyingMeasures));
	}

	@Override
	public String getId() {
		return getMeasureName();
	}

	@Override
	public String getName() {
		return getMeasureName();
	}

	@Override
	public IApexPostProcessorBuilder<T> setAnalysisLevels(String... analysisLevels) {
		setPropertyList(ABasicPostProcessor.ANALYSIS_LEVELS_PROPERTY, analysisLevels);

		return this;
	}
};
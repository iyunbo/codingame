/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.cube;

import java.util.function.Function;

import com.google.common.annotations.Beta;
import com.quartetfs.biz.pivot.definitions.IAxisHierarchyDescription;

/**
 * Implemented by description holding {@link IAxisHierarchyDescription}
 * 
 * @author Benoit Lacelle
 *
 */
public interface IApexHierarchiesHolder {

	IApexCubeBuilder getCubeBuilder();

	/**
	 * 
	 * @param dimensionName
	 * @return an IApexDimensionBuilder for an IAxisDimensionDescription, creating it if necessary
	 */
	IApexDimensionBuilder getOrAddDimension(String dimensionName);

	/**
	 * 
	 * @param dimensionName
	 * @return an IApexDimensionBuilder for an existing IAxisDimensionDescription or an exception
	 */
	IApexDimensionBuilder getOrFailDimension(String dimensionName);

	/**
	 * 
	 * @param firstFieldAndDimensionAndHierarchyName
	 *            the first field to consider as first level
	 * @param secondAndMoreFields
	 *            more fields to consider as following levels in the hierarchy
	 * @return
	 */
	IApexHierarchyBuilder addHierarchyAndLevels(String firstFieldAndDimensionAndHierarchyName,
			String... secondAndMoreFields);

	/**
	 * 
	 * @param hierarchyName
	 * @param pluginKey
	 * @return add an IAxisHierarchyDescription with given name and given plugin implementation
	 * 
	 */
	IApexHierarchyBuilder addAnalysisHierarchy(String hierarchyName, String pluginKey);

	@Beta
	<T extends IApexHierarchyBuilder> T addAnalysisHierarchy(String hierarchyName,
			Function<IApexHierarchyBuilder, T> hierarchyBuilderSupplier);

	IApexHierarchyBuilder getOrAddAxisHierarchy(String hierarchyName);

	IApexHierarchyBuilder getOrFailAxisHierarchy(String hierarchyName);

}

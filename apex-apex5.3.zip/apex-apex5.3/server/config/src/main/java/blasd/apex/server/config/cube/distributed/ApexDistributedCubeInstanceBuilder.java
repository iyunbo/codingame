/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.cube.distributed;

import java.util.ArrayList;
import java.util.Objects;

import com.quartetfs.biz.pivot.definitions.IDistributedActivePivotDescription;
import com.quartetfs.biz.pivot.definitions.IQueryClusterDefinition;
import com.quartetfs.biz.pivot.definitions.impl.DistributedActivePivotDescription;
import com.quartetfs.biz.pivot.definitions.impl.QueryClusterDefinition;
import com.quartetfs.biz.pivot.distribution.IDistributedActivePivotInstanceDescription;

/**
 * Helps configuring a IDistributedActivePivotInstanceDescription
 * 
 * @author Benoit Lacelle
 *
 */
public class ApexDistributedCubeInstanceBuilder implements IApexDistributedCubeInstanceBuilder {
	protected final IDistributedActivePivotInstanceDescription activePivot;

	public ApexDistributedCubeInstanceBuilder(IDistributedActivePivotInstanceDescription activePivot) {
		Objects.requireNonNull(activePivot);
		this.activePivot = activePivot;
	}

	public IDistributedActivePivotInstanceDescription getActivePivotInstanceDescription() {
		return activePivot;
	}

	@Override
	public String getId() {
		return activePivot.getId();
	}

	@Override
	public String getName() {
		return getId();
	}

	@Override
	public Object setName(String elementNewName) {
		activePivot.setId(elementNewName);

		return this;
	}

	@Override
	public IDistributedActivePivotInstanceDescription getDescription() {
		return activePivot;
	}

	@Override
	public ApexQueryClusterBuilder getQueryCluster() {
		IQueryClusterDefinition clusterDefinition = activePivot.getClusterDefinition();

		if (clusterDefinition == null) {
			// Initialize the cluster definition
			clusterDefinition = new QueryClusterDefinition();

			// Prevent future NPEs
			clusterDefinition.setApplications(new ArrayList<>());

			activePivot.setClusterDefinition(clusterDefinition);
		}

		return new ApexQueryClusterBuilder(clusterDefinition);
	}

	@Override
	public IApexDistributedCubeBuilder getPivotDescription() {
		IDistributedActivePivotDescription cubeDescription = activePivot.getDistributedActivePivotDescription();

		if (cubeDescription == null) {
			cubeDescription = new DistributedActivePivotDescription();
			activePivot.setDistributedActivePivotDescription(cubeDescription);
		}

		return new ApexDistributedCubeBuilder(cubeDescription);
	}
}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.cube;

import java.util.List;
import java.util.Properties;
import java.util.function.Consumer;
import java.util.function.Function;

import com.google.common.base.Joiner;
import com.quartetfs.biz.pivot.cube.hierarchy.IHierarchyInfo;
import com.quartetfs.biz.pivot.definitions.IAxisHierarchyDescription;
import com.quartetfs.biz.pivot.definitions.IAxisLevelDescription;
import com.quartetfs.biz.pivot.definitions.impl.AxisLevelDescription;

import blasd.apex.server.config.cube.factless.ApexFactlessHierarchyBuilder;
import blasd.apex.server.config.cube.factless.IApexAnalysisFactlessHierarchyBuilder;

/**
 * Helps configuring an {@link IAxisHierarchyDescription}
 * 
 * @author Benoit Lacelle
 *
 */
public class ApexHierarchyBuilder implements IApexHierarchyBuilder {

	protected final IApexDimensionBuilder dimensionBuilder;
	protected final IAxisHierarchyDescription hierarchyDescription;

	public ApexHierarchyBuilder(IApexDimensionBuilder dimensionBuilder,
			IAxisHierarchyDescription hierarchyDescription) {
		this.dimensionBuilder = dimensionBuilder;
		this.hierarchyDescription = hierarchyDescription;
	}

	@Override
	public IApexHierarchyBuilder setSlicing() {
		hierarchyDescription.setAllMembersEnabled(false);

		return this;
	}

	@Override
	public IApexHierarchyBuilder withAllMember() {
		hierarchyDescription.setAllMembersEnabled(true);

		return this;
	}

	@Override
	public IApexLevelBuilder getLevel(int levelIndexSkipALL) {
		List<IAxisLevelDescription> levels = hierarchyDescription.getLevels();
		if (levels.isEmpty()) {
			throw new RuntimeException("There is not a single level in hierarchy " + getName());
		} else {
			return new ApexLevelBuilder(this, levels.get(levelIndexSkipALL));
		}
	}

	@Override
	public String getName() {
		return hierarchyDescription.getName();
	}

	@Override
	public IApexLevelBuilder getDeepestLevel() {
		List<IAxisLevelDescription> levels = hierarchyDescription.getLevels();
		if (levels.isEmpty()) {
			throw new RuntimeException("There is not a single level in hierarchy " + getName());
		} else {
			return getLevel(levels.size() - 1);
		}
	}

	@Override
	public IApexDimensionBuilder getDimensionBuilder() {
		return dimensionBuilder;
	}

	@Override
	public String getId() {
		return hierarchyName(getDimensionBuilder().getName(), hierarchyDescription.getName());
	}

	@Override
	public IApexHierarchyBuilder setProperty(String key, String value) {
		getProperty().setProperty(key, value);

		return this;
	}

	protected Properties getProperty() {
		return hierarchyDescription.getProperties();
	}

	@Override
	public IApexCubeBuilder getCubeBuilder() {
		return dimensionBuilder.getCubeBuilder();
	}

	@Override
	public IApexHierarchyBuilder setName(String hierarchyName) {
		hierarchyDescription.setName(hierarchyName);
		return this;
	}

	@Override
	public IApexLevelBuilder appendLevel(String levelName) {
		AxisLevelDescription axisLevelDescription = new AxisLevelDescription(levelName);

		hierarchyDescription.addLevel(axisLevelDescription);

		return new ApexLevelBuilder(this, axisLevelDescription);
	}

	@Override
	public IApexHierarchyBuilder setPluginKey(String pluginKey) {
		hierarchyDescription.setPluginKey(pluginKey);
		return this;
	}

	@Override
	public IAxisHierarchyDescription getDescription() {
		return hierarchyDescription;
	}

	/**
	 * 
	 * @param hierarchyInfo
	 * @return the unique id of the {@link IHierarchyInfo} amongst its cube hierarchies
	 */
	public static String hierarchyName(String dimensionName, String hierarchyName) {
		return Joiner.on(LEVEL_SEPARATOR).join(hierarchyName, dimensionName);
	}

	@Override
	public IApexDimensionBuilder getOrAddDimension(String dimensionName) {
		return getCubeBuilder().getOrAddDimension(dimensionName);
	}

	@Override
	public IApexDimensionBuilder getOrFailDimension(String dimensionName) {
		return getCubeBuilder().getOrFailDimension(dimensionName);
	}

	@Override
	public IApexHierarchyBuilder addHierarchyAndLevels(String firstFieldAndDimensionAndHierarchyName,
			String... fieldNames) {
		return getCubeBuilder().addHierarchyAndLevels(firstFieldAndDimensionAndHierarchyName, fieldNames);
	}

	@Override
	public IApexHierarchyBuilder addAnalysisHierarchy(String hierarchyName, String pluginKey) {
		return getCubeBuilder().addAnalysisHierarchy(hierarchyName, pluginKey);
	}

	@Override
	public <T extends IApexHierarchyBuilder> T addAnalysisHierarchy(String hierarchyName,
			Function<IApexHierarchyBuilder, T> hierarchyBuilderSupplier) {
		return getCubeBuilder().addAnalysisHierarchy(hierarchyName, hierarchyBuilderSupplier);
	}

	@Override
	public IApexHierarchyBuilder getOrAddAxisHierarchy(String hierarchyName) {
		return getCubeBuilder().getOrAddAxisHierarchy(hierarchyName);
	}

	@Override
	public IApexHierarchyBuilder getOrFailAxisHierarchy(String hierarchyName) {
		return getCubeBuilder().getOrFailAxisHierarchy(hierarchyName);
	}

	@Override
	public IApexHierarchyBuilder setFactless(Boolean isFactless) {
		hierarchyDescription.setFactless(isFactless);

		return this;
	}

	@Override
	public IApexAnalysisFactlessHierarchyBuilder setAnalysisFactless(String storeName) {
		setFactless(true);

		return new ApexFactlessHierarchyBuilder(this);
	}

	/**
	 * 
	 * @param hierarchyInfo
	 * @return the unique id of the {@link IHierarchyInfo} amongst its cube hierarchies
	 */
	public static String hierarchyName(IHierarchyInfo hierarchyInfo) {
		return hierarchyName(hierarchyInfo.getDimensionInfo().getName(), hierarchyInfo.getName());
	}

	@Override
	public IApexHierarchyBuilder configure(Consumer<IApexHierarchyBuilder> consumer) {
		consumer.accept(this);

		return this;
	}

}

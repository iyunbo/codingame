/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.cube;

import java.util.ArrayList;
import java.util.Optional;
import java.util.Properties;
import java.util.function.Function;

import com.qfs.distribution.IMultiVersionDistributedActivePivot;
import com.qfs.pivot.impl.MultiVersionDistributedActivePivot;
import com.qfs.pivot.impl.MultiVersionDistributedActivePivotSpy;
import com.quartetfs.biz.pivot.definitions.IActivePivotDescription;
import com.quartetfs.biz.pivot.definitions.IActivePivotInstanceDescription;
import com.quartetfs.biz.pivot.definitions.IAxisDimensionDescription;
import com.quartetfs.biz.pivot.definitions.IAxisHierarchyDescription;
import com.quartetfs.biz.pivot.definitions.IDistributedActivePivotDescription;
import com.quartetfs.biz.pivot.definitions.IPostProcessorDescription;
import com.quartetfs.biz.pivot.definitions.impl.ActivePivotDescription;
import com.quartetfs.biz.pivot.definitions.impl.ActivePivotInstanceDescription;
import com.quartetfs.biz.pivot.definitions.impl.AggregatedMeasureDescription;
import com.quartetfs.biz.pivot.definitions.impl.AxisDimensionDescription;
import com.quartetfs.biz.pivot.definitions.impl.DistributedActivePivotDescription;
import com.quartetfs.biz.pivot.definitions.impl.DistributedActivePivotInstanceDescription;
import com.quartetfs.biz.pivot.definitions.impl.PluginDefinition;
import com.quartetfs.biz.pivot.definitions.impl.PostProcessorDescription;
import com.quartetfs.biz.pivot.distribution.IDistributedActivePivotInstanceDescription;

import blasd.apex.server.config.cube.distributed.ApexDistributedCubeBuilder;
import blasd.apex.server.config.cube.distributed.ApexDistributedCubeInstanceBuilder;
import blasd.apex.server.config.cube.distributed.IApexDistributedCubeBuilder;
import blasd.apex.server.config.cube.distributed.IApexDistributedCubeInstanceBuilder;
import blasd.apex.server.test.IApexTestConstants;

/**
 * Enable creation or enrichment of an IActivePivotDescription
 * 
 * @author Benoit Lacelle
 * 
 */
public class ApexCubeBuilder implements IApexCubeBuilder {
	protected final IActivePivotDescription activePivot;

	public ApexCubeBuilder(IActivePivotDescription activePivot) {
		this.activePivot = activePivot;
	}

	public static IApexCubeBuilder newDescription() {
		return editDescription(new ActivePivotDescription());
	}

	@Deprecated
	public static IApexCubeBuilder newActivePivotDescripion() {
		return newDescription();
	}

	public static IApexCubeBuilder editDescription(IActivePivotDescription activePivot) {
		if (activePivot == IApexTestConstants.CCY_COUNTRY_CITY_DELTA_SUM
				|| activePivot == IApexTestConstants.ASOFDATE_CCY_COUNTRY_CITY_DELTA_SUM) {
			throw new IllegalArgumentException("One should mutate descriptions shared by tests");
		}

		return new ApexCubeBuilder(activePivot);
	}

	@Deprecated
	public static IApexCubeBuilder updateActivePivotDescripion(IActivePivotDescription activePivot) {
		return editDescription(activePivot);
	}

	public static IApexCubeInstanceBuilder newInstanceDescription() {
		return editInstanceDescription(new ActivePivotInstanceDescription());
	}

	public static IApexCubeInstanceBuilder editInstanceDescription(
			IActivePivotInstanceDescription activePivotInstanceDescription) {
		return new ApexCubeInstanceBuilder(activePivotInstanceDescription);
	}

	public static IApexDistributedCubeInstanceBuilder editDistributedDescription(
			IDistributedActivePivotInstanceDescription activePivot) {
		return new ApexDistributedCubeInstanceBuilder(activePivot);
	}

	public static IApexDistributedCubeBuilder editDistributedDescription(
			IDistributedActivePivotDescription activePivot) {
		return new ApexDistributedCubeBuilder(activePivot);
	}

	public static IApexDistributedCubeInstanceBuilder newDistributedInstanceDescription() {
		return editDistributedDescription(new DistributedActivePivotInstanceDescription());
	}

	public static IApexDistributedCubeBuilder newDistributedDescription() {
		return editDistributedDescription(new DistributedActivePivotDescription());
	}

	public static IApexDistributedCubeInstanceBuilder editDistributedDescription(
			IMultiVersionDistributedActivePivot mvdap) {
		if (mvdap instanceof MultiVersionDistributedActivePivot) {
			return editDistributedDescription(MultiVersionDistributedActivePivotSpy
					.getDistributedInstanceDescription((MultiVersionDistributedActivePivot) mvdap));
		} else {
			throw new IllegalArgumentException("We can not process a " + IMultiVersionDistributedActivePivot.class
					+ " which is not a "
					+ MultiVersionDistributedActivePivot.class);
		}
	}

	public static IApexCubeBuilder cloneActivePivotDescripion(IActivePivotDescription activePivot) {
		return updateActivePivotDescripion(activePivot.clone());
	}

	@Override
	public IApexAggregatedMeasureBuilder addAggregatedMeasure(String fieldName, String aggregationFunctionPluginKey) {
		final AggregatedMeasureDescription measureDescription =
				new AggregatedMeasureDescription(fieldName, aggregationFunctionPluginKey);
		activePivot.getMeasuresDescription().getAggregatedMeasuresDescription().add(measureDescription);

		return new ApexPreAggregatedMeasureBuilder(this, measureDescription);
	}

	@Override
	public IApexPostProcessorBuilder<? extends IRawApexPostProcessorBuilder<?>> addPostProcessedMeasure(String name,
			String pluginKey) {
		return addPostProcessedMeasure(name, pluginKey, new Properties());
	}

	@Override
	public IApexPostProcessorBuilder<? extends IRawApexPostProcessorBuilder<?>> addPostProcessedMeasure(String name,
			String pluginKey,
			final Properties properties) {
		PostProcessorDescription postProcessorDescription = new PostProcessorDescription(name, pluginKey, properties);
		activePivot.addPostProcessorDescription(postProcessorDescription);

		return wrapInBuilder(postProcessorDescription);
	}

	protected IApexPostProcessorBuilder<?> wrapInBuilder(IPostProcessorDescription pp) {
		return new ApexPostProcessorBuilder<ApexPreparedPostProcessorBuilder>(this,
				new ApexPreparedPostProcessorBuilder(pp));
	}

	@Override
	public Optional<IApexPostProcessorBuilder<?>> getPostProcessedMeasure(String measureName) {
		for (IPostProcessorDescription pp : activePivot.getMeasuresDescription().getPostProcessorsDescription()) {
			if (measureName.equals(pp.getName())) {
				return Optional.of(wrapInBuilder(pp));
			}
		}

		return Optional.empty();
	}

	@Override
	public <S extends IRawApexPostProcessorBuilder<S>> IApexPostProcessorBuilder<S> addPostProcessedMeasure(String name,
			S specificPPBuilder) {
		// Initialize a PostProcessorDescription
		specificPPBuilder.setMeasureName(name);

		IPostProcessorDescription postProcessorDescription = specificPPBuilder.getDescription();

		// Register it in the builder
		activePivot.addPostProcessorDescription(postProcessorDescription);

		return new ApexPostProcessorBuilder<>(this, specificPPBuilder);
	}

	@Override
	public IApexHierarchyBuilder addHierarchyAndLevels(String firstFieldAndDimensionAndHierarchyName,
			String... fieldNames) {
		final IApexDimensionBuilder dimensionBuilder = getOrAddDimension(firstFieldAndDimensionAndHierarchyName);

		return dimensionBuilder.addHierarchyAndLevels(firstFieldAndDimensionAndHierarchyName, fieldNames);
	}

	@Override
	public IApexHierarchyBuilder getOrAddAxisHierarchy(String hierarchyName) {
		IApexHierarchyBuilder hierarchy = getHierarchy(hierarchyName);

		if (hierarchy == null) {
			// We guess the dimension has same name of the hierarchy
			return getOrAddDimension(hierarchyName).getOrAddAxisHierarchy(hierarchyName);
		} else {
			return hierarchy;
		}
	}

	@Override
	public IApexHierarchyBuilder getOrFailAxisHierarchy(String hierarchyName) {
		IApexHierarchyBuilder hierarchy = getHierarchy(hierarchyName);

		if (hierarchy == null) {
			throw new RuntimeException("There is no hierarchy names " + hierarchyName);
		} else {
			return hierarchy;
		}
	}

	protected IApexHierarchyBuilder getHierarchy(String hierarchyName) {
		for (final IAxisDimensionDescription d : activePivot.getAxisDimensions().getValues()) {
			for (final IAxisHierarchyDescription h : d.getHierarchies()) {
				if (h.getName().equals(hierarchyName)) {
					return new ApexHierarchyBuilder(new ApexDimensionBuilder(this, d), h);
				}
			}
		}

		return null;
	}

	@Override
	public IApexHierarchyBuilder addAnalysisHierarchy(String hierarchyName, String pluginKey) {
		return getOrAddDimension(hierarchyName).addAnalysisHierarchy(hierarchyName, pluginKey);
	}

	@Override
	public <T extends IApexHierarchyBuilder> T addAnalysisHierarchy(String hierarchyName,
			Function<IApexHierarchyBuilder, T> hierarchyBuilderSupplier) {
		return getOrAddDimension(hierarchyName).addAnalysisHierarchy(hierarchyName, hierarchyBuilderSupplier);
	}

	// @Override
	protected IApexDimensionBuilder addDimension(String dimensionName) {
		final ArrayList<IAxisHierarchyDescription> hierarchies = new ArrayList<>();
		AxisDimensionDescription axisDimensionDescription = new AxisDimensionDescription(dimensionName, hierarchies);
		activePivot.getAxisDimensions().getValues().add(axisDimensionDescription);

		return new ApexDimensionBuilder(this, axisDimensionDescription);
	}

	@Override
	public IApexDimensionBuilder getOrAddDimension(final String dimensionName) {
		IApexDimensionBuilder dimension = getAxisDimension(dimensionName);

		if (dimension == null) {
			return addDimension(dimensionName);
		} else {
			return dimension;
		}
	}

	protected IApexDimensionBuilder getAxisDimension(final String dimensionName) {
		for (final IAxisDimensionDescription d : activePivot.getAxisDimensions().getValues()) {
			if (d.getName().equals(dimensionName)) {
				return new ApexDimensionBuilder(this, d);
			}
		}

		return null;
	}

	@Override
	public IApexDimensionBuilder getOrFailDimension(String dimensionName) {
		IApexDimensionBuilder dimension = getAxisDimension(dimensionName);

		if (dimension == null) {
			throw new RuntimeException("There is no dimension named " + dimensionName);
		} else {
			return dimension;
		}
	}

	@Override
	public IActivePivotDescription getActivePivotDescription() {
		return activePivot;
	}

	@Override
	public IApexCubeBuilder setQueryExecutorKey(String pluginKey) {
		activePivot.setQueryExecutor(new PluginDefinition(pluginKey));

		return this;
	}

	@Override
	public IApexCubeBuilder setAggregatesContinuousQueryEngineKey(String pluginKey) {
		activePivot.setAggregatesContinuousQueryEngine(new PluginDefinition(pluginKey));

		return this;
	}

	@Override
	public IApexSharedContextBuilder getSharedContextBuilder() {
		return new ApexSharedContextBuilder(this);
	}

	@Override
	public IApexCubeBuilder setAutoFactlessHierarchies(Boolean autoFactlessHierarchies) {
		activePivot.setAutoFactlessHierarchies(autoFactlessHierarchies);

		return this;
	}

	@Override
	public IApexAggregateProviderBuilder getAggregateProviderBuilder() {
		return new ApexAggregateProviderBuilder(this);
	}

	@Override
	public IApexCubeBuilder setDrillthroughQueryExecutorQuery(String pluginKey) {
		activePivot.setDrillthroughExecutor(new PluginDefinition(pluginKey));

		return this;
	}

	/**
	 * @deprecated Useless, but required because of a design flaw
	 */
	@Deprecated
	@Override
	public IApexCubeBuilder getCubeBuilder() {
		return this;
	}

	@Override
	public IApexAggregateCacheBuilder getAggregatesCacheBuilder() {
		return new ApexAggregateCacheBuilder(this.getActivePivotDescription().getAggregatesCacheDescription());
	}

	@Override
	public IApexCubeInstanceBuilder wrapAsInstance(String pivotId) {
		return editInstanceDescription(new ActivePivotInstanceDescription(pivotId, getActivePivotDescription()));
	}

	public static IApexCubeInstanceBuilder editInstanceDescription(String pivotId,
			IActivePivotDescription cubeBuilder) {
		return editDescription(cubeBuilder).wrapAsInstance(pivotId);
	}

}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.cube;

import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Strings;
import com.google.common.collect.Table;
import com.qfs.pivot.cube.provider.bitmap.impl.BitmapAggregateProviderBase;
import com.qfs.pivot.cube.provider.impl.AAggregateProviderBase;
import com.qfs.pivot.cube.provider.jit.impl.JustInTimeAggregateCollector;
import com.qfs.pivot.cube.provider.jit.impl.JustInTimeAggregateCollector.JitPointIndexFactory;
import com.qfs.pivot.cube.provider.jit.impl.JustInTimeAggregateProviderBase;
import com.qfs.pivot.cube.provider.multi.IMultipleAggregateProvider;
import com.qfs.pivot.cube.provider.multi.impl.GlobalMultipleAggregateProviderBase;
import com.quartetfs.biz.pivot.definitions.IAggregateProviderDefinition;
import com.quartetfs.biz.pivot.definitions.IAxisDimensionDescription;
import com.quartetfs.biz.pivot.definitions.IPartialProviderDefinition;
import com.quartetfs.biz.pivot.definitions.impl.AggregateProviderDefinition;
import com.quartetfs.biz.pivot.definitions.impl.PartialProviderDefinition;

/**
 * Helps configuring an IAggregateProviderDefinition
 * 
 * @author Benoit Lacelle
 *
 */
public class ApexAggregateProviderBuilder implements IApexAggregateProviderBuilder {

	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexAggregateProviderBuilder.class);

	public static final String DEFAULT_PARTIAL_PLUGIN = BitmapAggregateProviderBase.PLUGIN_TYPE;

	protected final IApexCubeBuilder apexCubeBuilder;

	public ApexAggregateProviderBuilder(IApexCubeBuilder apexCubeBuilder) {
		this.apexCubeBuilder = apexCubeBuilder;

		if (getDescription() == null) {
			apexCubeBuilder.getActivePivotDescription().setAggregateProvider(new AggregateProviderDefinition());
		}
	}

	@Override
	public IAggregateProviderDefinition getDescription() {
		return apexCubeBuilder.getActivePivotDescription().getAggregateProvider();
	}

	@Override
	public IApexCubeBuilder getCubeBuilder() {
		return apexCubeBuilder;
	}

	@Override
	public IApexAggregateProviderBuilder setAggregateProviderPluginKey(String pluginKey) {
		getDescription().setPluginKey(pluginKey);

		reportAboutJIT(pluginKey);

		return this;
	}

	@Override
	public Properties getProperties() {
		if (getDescription().getProperties() == null) {
			getDescription().setProperties(new Properties());
		}

		return getDescription().getProperties();
	}

	@Override
	public IApexAggregateProviderBuilder setChunkSize(int chunkSize) {
		getProperties().setProperty(AAggregateProviderBase.CHUNK_SIZE, Integer.toString(chunkSize));

		return this;
	}

	@Override
	public IApexAggregateProviderBuilder setUnderlyingProviderKey(String pluginKey) {
		getProperties().setProperty(IMultipleAggregateProvider.UNDERLYINGPROVIDER_PLUGINKEY, pluginKey);

		reportAboutJIT(getUnderlyingProviderKey());

		return this;
	}

	protected void reportAboutJIT(String aggregateProviderKey) {
		if (JustInTimeAggregateProviderBase.PLUGIN_TYPE.equals(aggregateProviderKey)) {
			// http://support.quartetfs.com/confluence/display/AP5/ActivePivot+5.5.5+Release+Notes
			String pointIndexType = JustInTimeAggregateCollector.POINT_INDEX_TYPE_PROPERTY;
			if (Strings.isNullOrEmpty(System.getProperty(pointIndexType, ""))) {
				// We advise using COLUMN, else the transient memory due to JIT may be very high
				String advisedPointIndexType = JitPointIndexFactory.COLUMN.name();
				LOGGER.info("You use a {}. Consider setting '-D{}={}'",
						JustInTimeAggregateProviderBase.PLUGIN_TYPE,
						pointIndexType,
						advisedPointIndexType);
			}
		}
	}

	public String getUnderlyingProviderKey() {
		return getProperties().getProperty(IMultipleAggregateProvider.UNDERLYINGPROVIDER_PLUGINKEY);
	}

	@Override
	public IApexAggregateProviderBuilder setPrintTimings(boolean printTimings) {
		getProperties().setProperty(BitmapAggregateProviderBase.PRINT_TIMINGS, Boolean.toString(printTimings));

		return this;
	}

	@Override
	public IApexAggregateProviderBuilder setRangeSharingLimit(int rangeSharingLimit) {
		getProperties().setProperty(AAggregateProviderBase.RANGE_SHARING, Integer.toString(rangeSharingLimit));

		return this;
	}

	@Override
	public IApexAggregateProviderBuilder disableRangeSharingLimit() {
		// https://support.quartetfs.com/jira/browse/APS-8299
		// https://support.activeviam.com/jira/browse/APS-9800
		return setRangeSharingLimit(0);
	}

	/**
	 * In 5.2, default is 50.0D
	 * 
	 * 100 would mean rejecting all rebuild requests
	 * 
	 * 0 means accept all of them
	 */
	@Override
	public IApexAggregateProviderBuilder setRebuildLimit(double zeroForAlways100ForNever) {
		getProperties().setProperty(AAggregateProviderBase.REBUILD_LIMIT, Double.toString(zeroForAlways100ForNever));

		return this;
	}

	// TODO is this implemented in AP5.5?
	@Override
	public IApexAggregateProviderBuilder addPartialExcluding(Table<String, String, String> dnameToHNameToLName,
			Collection<? extends String> includedMeasures) {
		ensureMultiAggregateProvider();

		List<IAxisDimensionDescription> dimensions =
				getCubeBuilder().getActivePivotDescription().getAxisDimensions().getValues();
		IPartialProviderDefinition partial =
				ApexPartialProviderHelper.makeComplementPartialProviderDefinition(DEFAULT_PARTIAL_PLUGIN,
						dimensions,
						dnameToHNameToLName.rowMap(),
						includedMeasures);

		addPartial(partial);

		return this;
	}

	protected void ensureMultiAggregateProvider() {
		setAggregateProviderPluginKey(GlobalMultipleAggregateProviderBase.PLUGIN_TYPE);

		if (getUnderlyingProviderKey() == null) {
			// No default underlyingProvider has been set: make it explicit to JIT
			setUnderlyingProviderKey(IMultipleAggregateProvider.DEFAULT_UNDERLYINGPROVIDER_PLUGINKEY);
		}
	}

	public IApexAggregateProviderBuilder addPartial(IPartialProviderDefinition partial) {
		ensureMultiAggregateProvider();

		getDescription().getPartialProviders().add(partial);

		return this;
	}

	@Override
	public IApexAggregateProviderBuilder addPartialIncluding(Table<String, String, String> dnameToHNameToLName,
			Collection<? extends String> includedMeasures) {
		ensureMultiAggregateProvider();

		Collection<String> selectedMeasures;
		if (includedMeasures == null) {
			selectedMeasures = Collections.emptyList();
		} else {
			selectedMeasures = Collections.unmodifiableCollection(includedMeasures);
		}

		return addPartial(new PartialProviderDefinition(DEFAULT_PARTIAL_PLUGIN,
				dnameToHNameToLName.rowMap(),
				selectedMeasures,
				null,
				null,
				null));
	}
}

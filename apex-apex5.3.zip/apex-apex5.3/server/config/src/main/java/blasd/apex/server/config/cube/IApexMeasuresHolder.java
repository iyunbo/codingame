/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.cube;

import java.util.Optional;
import java.util.Properties;

/**
 * Implementd by objects holding measures descriptions
 * 
 * @author Benoit Lacelle
 *
 */
public interface IApexMeasuresHolder {

	/**
	 * 
	 * @param measureName
	 * @return an existing PostProcessorDescription given its name
	 */
	Optional<IApexPostProcessorBuilder<?>> getPostProcessedMeasure(String measureName);

	/**
	 * @param name
	 * @param pluginKey
	 * @param properties
	 *            an existing Properties Object, typically used to add keys to an existing PostProcessorDescription
	 * @return add a Post-Processed measure
	 */
	IApexPostProcessorBuilder<? extends IRawApexPostProcessorBuilder<?>> addPostProcessedMeasure(String name,
			String pluginKey,
			Properties properties);

	/**
	 * 
	 * @param name
	 * @param pluginKey
	 * @return add a Post-Processed measure
	 */
	IApexPostProcessorBuilder<? extends IRawApexPostProcessorBuilder<?>> addPostProcessedMeasure(String name,
			String pluginKey);

	IApexAggregatedMeasureBuilder addAggregatedMeasure(String fieldName, String aggregationFunctionPluginKey);

	<S extends IRawApexPostProcessorBuilder<S>> IApexPostProcessorBuilder<S> addPostProcessedMeasure(String name,
			S specificPPBuilder);
}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.cube;

import java.util.function.Consumer;

import com.quartetfs.biz.pivot.definitions.IAxisHierarchyDescription;

import blasd.apex.server.config.cube.factless.IApexAnalysisFactlessHierarchyBuilder;
import blasd.apex.server.config.cube.properties.IApexPropertiesCubeElement;

/**
 * Helps configuring an {@link IAxisHierarchyDescription}
 * 
 * @author Benoit Lacelle
 *
 */
public interface IApexHierarchyBuilder extends IApexHierarchiesHolder,
		IApexPropertiesCubeElement<IAxisHierarchyDescription>, IHasPluginKey<IAxisHierarchyDescription> {

	String LEVEL_SEPARATOR = "@";

	/**
	 * Set the same of the hierarchy
	 */
	// Useful to specialize the return type
	@Override
	IApexHierarchyBuilder setName(String elementNewName);

	/**
	 * Ensures there is no ALL level with its single AllMember member
	 */
	IApexHierarchyBuilder setSlicing();

	/**
	 * Ensures there is an ALL level with its single AllMember member
	 */
	IApexHierarchyBuilder withAllMember();

	IApexDimensionBuilder getDimensionBuilder();

	IApexHierarchyBuilder setProperty(String key, String value);

	/**
	 * @return the last/deepest levelId in the form 'level@hierarchy@dimension'
	 */
	IApexLevelBuilder getDeepestLevel();

	IApexLevelBuilder appendLevel(String levelName);

	/**
	 * @return the level with given index, skipping the optional ALL level
	 */
	IApexLevelBuilder getLevel(int levelIndexSkipAllMember);

	@Override
	IApexHierarchyBuilder setPluginKey(String pluginKey);

	/**
	 * @see http://support.quartetfs.com/confluence/display/AP5/Hierarchies
	 */
	IApexHierarchyBuilder setFactless(Boolean isFactless);

	/**
	 * @see http://support.quartetfs.com/confluence/pages/viewpage.action?title=Analysis+hierarchies&spaceKey=AP5
	 */
	IApexAnalysisFactlessHierarchyBuilder setAnalysisFactless(String storeName);

	IApexHierarchyBuilder configure(Consumer<IApexHierarchyBuilder> hierarchyBuilder);

}

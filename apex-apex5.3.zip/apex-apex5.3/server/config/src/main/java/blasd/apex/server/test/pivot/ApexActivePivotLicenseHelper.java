/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.test.pivot;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UncheckedIOException;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.core.io.support.ResourcePatternResolver;
import org.springframework.util.ResourceUtils;

import com.activeviam.activation.impl.LicenseException;
import com.activeviam.activation.impl.LicenseManager;
import com.activeviam.activation.impl.Platform;
import com.activeviam.lic.impl.ActiveViamLicense;
import com.activeviam.lic.impl.Licensing;
import com.google.common.base.Strings;
import com.google.common.collect.ImmutableMap;
import com.qfs.platform.IPlatform;

import cormoran.pepper.io.PepperFileHelper;
import cormoran.pepper.logging.PepperLogHelper;

/**
 * This class may be run as main with as parameter the path to a license file in order to generate the
 * -DACTIVEPIVOT_LICENSE_BASE64 associated to it
 * 
 * @author Benoit Lacelle
 *
 */
public class ApexActivePivotLicenseHelper {
	public static final int PAUSE = 5000;

	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexActivePivotLicenseHelper.class);

	public static final String BASE64_LICENSE_ENVIRONMENT_VARIABLE =
			ActiveViamLicense.LICENSE_ENVIRONMENT_VARIABLE + "_BASE64";

	protected ApexActivePivotLicenseHelper() {
		// hidden
	}

	/**
	 * This print in the log the environment variable to set in order to provide ActivePivot license without a file in
	 * local filesystem
	 * 
	 * @param args
	 *            we take as single argument a path to an existing license
	 * @throws LicenseException
	 * @throws IOException
	 */
	public static void main(String[] args) throws LicenseException, IOException {
		final String licenseFile;
		if (args == null || args.length == 0) {
			// https://stackoverflow.com/questions/4644415/java-how-to-get-input-from-system-console
			System.out.print("Enter path to license file: ");
			try (BufferedReader br = new BufferedReader(new InputStreamReader(System.in, Charset.defaultCharset()))) {
				licenseFile = br.readLine();
			}
		} else if (args.length == 1) {
			licenseFile = args[0];
		} else {
			LOGGER.warn("We expect a single argument, being a path to a license file. Or no argument at all");
			licenseFile = null;
		}

		if (Strings.isNullOrEmpty(licenseFile)) {
			LOGGER.warn("Can not generate a license in base64 as input path is empty");
		} else {
			getLicenseInBase64(Files.readAllBytes(Paths.get(licenseFile)));
		}
	}

	/**
	 * @param licenseFolder
	 *            a path like 'classpath*:license'
	 * @return true if a license has been configured succesfully
	 * 
	 * @see ResourcePatternResolver.CLASSPATH_ALL_URL_PREFIX
	 */
	public static boolean setLicenseFromResourcesIfNotExplicitelySet(String licenseFolder) {
		if (isLicenseExplicitelySet()) {
			// There is already a license
			return false;
		} else if (tryToSetLicenseFromEnv(getLicenseAsEnv())) {
			return true;
		} else {
			// We found no license: try to find a license in resources
			return getLicenseMatchers().stream().filter(matchingLicense -> {
				try {
					return setLicenseFromMatchingString(licenseFolder, matchingLicense);
				} catch (IOException e) {
					LOGGER.debug("Issue with matcher " + matchingLicense, e);
					return false;
				}
			}).findAny().isPresent();
		}
	}

	public static boolean tryToSetLicenseFromEnv(List<String> licenseInBase64) {
		List<ActiveViamLicense> availableLicenses = new ArrayList<>();

		for (String licenseBase64 : licenseInBase64) {
			try {
				ActiveViamLicense license = getLicenseFromBase64(licenseBase64);

				LOGGER.info("Consider as license from env: {}. And host matchers: {}", license, getLicenseMatchers());

				for (String matchingLicense : getLicenseMatchers()) {
					Map<String, Supplier<String>> suppliers = ImmutableMap
							.of("hostname", license::getHostname, "ip", license::getIp, "MAC", license::getMac);
					Optional<?> found = suppliers.entrySet().stream().filter(entry -> {
						if (license.isOnDemand()) {
							// An on-demand license matches any constrain
							return true;
						}

						try {
							if (entry.getValue().get().equals(matchingLicense)) {
								return true;
							}
						} catch (RuntimeException e) {
							// We may encounter an issue, typically while fetching current MAC address
							LOGGER.warn("Issue with " + entry.getKey(), e);
						}
						return false;
					}).findAny();

					if (found.isPresent()) {
						try {
							setLicense(matchingLicense, licenseBase64);
							return true;
						} catch (IOException e) {
							throw new UncheckedIOException("Issue with license matching: " + matchingLicense, e);
						}
					}
				}

				availableLicenses.add(license);
			} catch (LicenseException | RuntimeException e) {
				LOGGER.error("Issue with license from base64='" + licenseBase64 + "'", e);
			}
		}

		LOGGER.info("Found no matching license amongst {} licenses in env", licenseInBase64);

		return false;
	}

	// Prevents concurrent License configuration
	protected static synchronized void setLicense(String matchingLicense, String licenseBase64) throws IOException {
		byte[] asBytes = toBytes(licenseBase64);
		Path licensePath = writeISAsFileAndSetAsLicense(new ByteArrayInputStream(asBytes));
		LOGGER.info("Good pattern: {} in b64='{}'. Written in {}", matchingLicense, licenseBase64, licensePath);

		long fileLength = licensePath.toFile().length();
		if (fileLength != asBytes.length) {
			throw new RuntimeException(
					"We failed writing the license file " + licensePath + ". File length=" + fileLength);
		}

		LOGGER.info("Resetting the license before loading the one in {}", licensePath);
		Licensing.reset();

		if (!Licensing.checkLicence()) {
			LOGGER.error("License is not OK ??? Current license: {} License Status: {}",
					getLicenseInfos(),
					Licensing.getLicense().getLicenseStatus());
			throw new RuntimeException("We failed setting the license");
		}
	}

	public static Object getLicenseInfos() {
		return PepperLogHelper.lazyToString(() -> Licensing.getLicense().toString());
	}

	public static ActiveViamLicense getLicenseFromBase64(String licenseBase64) throws LicenseException {
		return LicenseManager.getLicense(ActiveViamLicense.class, toBytes(licenseBase64));
	}

	public static byte[] toBytes(String licenseBase64) {
		return Base64.getDecoder().decode(licenseBase64);
	}

	public static String getLicenseInBase64() throws LicenseException {
		Optional<String> optAlreadyBase64 = getLicenseAsEnv().stream().findFirst();
		if (optAlreadyBase64.isPresent()) {
			return optAlreadyBase64.get();
		}

		byte[] binaryLicense;
		try {
			// This does work only for standard license location: not if already in BASE_64
			binaryLicense = LicenseManager.getBinaryLicense(ActiveViamLicense.class);
		} catch (RuntimeException | LicenseException e) {
			// We ensure the details are printed in the exception
			// com.activeviam.lic.impl.Licensing.toString()
			throw new RuntimeException(
					"Issue with license. Current VM has details: cpuCount="
							+ IPlatform.CURRENT_PLATFORM.getProcessorCount()
							+ " MAC="
							+ Licensing.getMac()
							+ " ip="
							+ Licensing.getIp()
							+ " hostname="
							+ Licensing.getHostname(),
					e);
		}
		return getLicenseInBase64(binaryLicense);
	}

	public static String getLicenseInBase64(byte[] bytes) throws LicenseException {
		ActiveViamLicense license = LicenseManager.getLicense(ActiveViamLicense.class, bytes);
		String base64 = Base64.getEncoder().encodeToString(bytes);
		LOGGER.info("License {} has base64='{}'", license, base64);
		LOGGER.info("Wire it with -D{}={}", BASE64_LICENSE_ENVIRONMENT_VARIABLE, base64);
		LOGGER.info("Or as OS variable 'export {}={}'", BASE64_LICENSE_ENVIRONMENT_VARIABLE, base64);
		LOGGER.info("And then load it with '{}'", "ApexActivePivotLicenseHelper.ensureLicenseWithEnv();");
		return base64;
	}

	public static List<String> getLicenseAsEnv() {
		// http://stackoverflow.com/questions/13195143/range-of-valid-character-for-a-base-64-encoding
		// '-' and '_' are not safe
		// '|' leads to issues in VSTS as it seems not escapable ('"' are removed and '\' or '^' escaping is helpless).
		// '&' seems not better
		return Arrays
				.asList(System.getenv(BASE64_LICENSE_ENVIRONMENT_VARIABLE),
						System.getProperty(BASE64_LICENSE_ENVIRONMENT_VARIABLE))
				.stream()
				.filter(Objects::nonNull)
				.flatMap(s -> Arrays.stream(s.split(":")))
				.filter(s -> !s.isEmpty())
				.collect(Collectors.toList());
	}

	public static boolean isLicenseExplicitelySet() {
		URL resourceLicense = ApexActivePivotLicenseHelper.class.getResource(ActiveViamLicense.LICENSE_FILENAME);
		if (resourceLicense != null) {
			LOGGER.debug("There is a license in resources for {}", ActiveViamLicense.LICENSE_FILENAME);
			return true;
		} else if (!Strings.isNullOrEmpty(System.getProperty(ActiveViamLicense.LICENSE_SYSTEM_PROPERTY))) {
			// -Dactivepivot.license=...
			LOGGER.debug("There is a license in system property for {}",
					System.getProperty(ActiveViamLicense.LICENSE_SYSTEM_PROPERTY));
			return true;
		} else if (!Strings.isNullOrEmpty(System.getenv(ActiveViamLicense.LICENSE_ENVIRONMENT_VARIABLE))) {
			// export ACTIVEPIVOT_LICENSE=...
			LOGGER.debug("There is a license in env variable for {}",
					System.getenv(ActiveViamLicense.LICENSE_ENVIRONMENT_VARIABLE));
			return true;
		} else {
			LOGGER.debug("There is a no license explicitely set");
			return false;
		}
	}

	public static List<String> getLicenseMatchers() {
		List<String> matchers = new ArrayList<>();

		try {
			matchers.add(Platform.getLocalHostMacAddress());
		} catch (IOException e) {
			LOGGER.warn("Failure while resolving macAdress", e);
		}
		try {
			matchers.add(Platform.getLocalHostName());
		} catch (IOException e) {
			LOGGER.warn("Failure while resolving hostName", e);
		}
		try {
			matchers.add(Platform.getLocalHostAddress());
		} catch (IOException e) {
			LOGGER.warn("Failure while resolving hostAdress", e);
		}

		return matchers;
	}

	/**
	 * This block could be set in a static block of a class loaded before all ActivePivot tests, or in a @BeforeClass
	 * method
	 * 
	 * @param licenseFolder
	 * @param hostDescriber
	 * 
	 * @return
	 * @throws IOException
	 */
	public static boolean setLicenseFromMatchingString(String licenseFolder, String hostDescriber) throws IOException {
		String fullResourcePath = makeLicensePattern(licenseFolder, hostDescriber);

		return setLicenseFromMatchingString(fullResourcePath);
	}

	// http://docs.spring.io/spring-framework/docs/2.5.x/api/org/springframework/core/io/support/PathMatchingResourcePatternResolver.html
	// CLASSPATH_ALL_URL_PREFIX with Ant-Style wildcards prefer "to have at least one root directory befor the pattern
	// starts"
	/**
	 * @see ResourceUtils
	 */
	public static String makeLicensePattern(String licenseFolder, String hostDescriber) {

		String licenseFullFolder;
		if (licenseFolder.matches("\\w+\\*?:.*")) {
			// We guess there is already a resource-type prefix
			// 'classpath*' is a special prefix
			licenseFullFolder = licenseFolder;
		} else {
			// We guess the folder is amongst resources

			// We search in all jars, as license could be put in a shared resources: we have a '*' after classpath
			// http://docs.spring.io/spring-framework/docs/2.5.x/api/org/springframework/core/io/support/PathMatchingResourcePatternResolver.html
			String prefix = ResourcePatternResolver.CLASSPATH_ALL_URL_PREFIX;

			licenseFullFolder = prefix + licenseFolder;
		}

		// License are named by default ActivePivot.lic.12345
		// We accept ActivePivot.WHATEVER.lic.12345
		return licenseFullFolder + "/ActivePivot*" + hostDescriber + "*.lic.*";
	}

	/**
	 * 
	 * @param fullResourcePath
	 *            like classpath*:someFolder/ActivePivot*78-31-C1-CE-B8-86*.lic.* or
	 *            file:C:/someFolder/ActivePivot*78-31-C1-CE-B8-86*.lic.*
	 * @return
	 * @throws IOException
	 * @see {@link ResourceUtils}
	 */
	public static boolean setLicenseFromMatchingString(String fullResourcePath) throws IOException {
		Optional<Resource> resource = getMatchingResource(fullResourcePath);

		if (resource.isPresent() && resource.get().exists()) {
			Path tmpPath = writeISAsFileAndSetAsLicense(resource.get().getInputStream());

			URL asUrl = resource.get().getURL();
			LOGGER.info("We register license as property to {} as a copy of {}", tmpPath, asUrl);

			return true;
		} else {
			LOGGER.info("We found no resource matching {}", fullResourcePath);
			return false;
		}
	}

	public static Path writeISAsFileAndSetAsLicense(InputStream inputStream) throws IOException {
		// We copy the resource to an actual File as ActivePivot requires the license not to be in a JAR
		// Delete this temporary file when done
		Path tmpFile = PepperFileHelper.createTempPath("activepivot", ".lic", true);

		// ATOMIC_MOVE can not be used with Files.copy, but only with Files.move
		Files.copy(inputStream, tmpFile, StandardCopyOption.REPLACE_EXISTING);
		LOGGER.info("We register license as property to {}", tmpFile);

		System.setProperty(ActiveViamLicense.LICENSE_SYSTEM_PROPERTY, tmpFile.toFile().toString());

		return tmpFile;
	}

	public static Optional<Resource> getMatchingResource(String fullResourcePath) throws IOException {
		Resource[] resources = new PathMatchingResourcePatternResolver().getResources(fullResourcePath);

		return Arrays.stream(resources).findFirst();
	}

	/**
	 * Ensure the license is set given the environment variable. It may be easier to configure the license as an
	 * environment variable given the output of
	 * 
	 * @return true if the license was not already set and has been set by this method
	 */
	public static boolean ensureLicenseWithEnv() {
		if (isLicenseExplicitelySet()) {
			// There is already a license
			return false;
		} else {
			return tryToSetLicenseFromEnv(getLicenseAsEnv());
		}
	}
}

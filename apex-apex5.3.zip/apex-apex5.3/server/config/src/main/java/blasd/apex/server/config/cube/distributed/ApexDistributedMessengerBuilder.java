/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.cube.distributed;

import com.quartetfs.biz.pivot.definitions.IMessengerDefinition;

/**
 * Default implementation for {@link IApexDistributedMessengerBuilder}
 * 
 * @author Benoit Lacelle
 *
 */
public class ApexDistributedMessengerBuilder implements IApexDistributedMessengerBuilder {
	protected final IMessengerDefinition messengerDefinition;

	public ApexDistributedMessengerBuilder(IMessengerDefinition messengerDefinition) {
		this.messengerDefinition = messengerDefinition;
	}

	@Override
	public String getId() {
		throw new UnsupportedOperationException("A messenger has no id");
	}

	@Override
	public String getName() {
		throw new UnsupportedOperationException("A messenger has no id");
	}

	@Override
	public Object setName(String elementNewName) {
		throw new UnsupportedOperationException("A messenger has no id");
	}

	@Override
	public IMessengerDefinition getDescription() {
		return messengerDefinition;
	}

	@Override
	public IApexDistributedMessengerBuilder setProtocolPath(String pathToProtocolXmlFile) {
		getDescription().setProtocolPath(pathToProtocolXmlFile);

		return this;
	}

	@Override
	public IApexDistributedMessengerBuilder setMessengerKey(String pluginKey) {
		getDescription().setPluginKey(pluginKey);

		return this;
	}

	@Override
	public IApexDistributedMessengerBuilder autoStart(boolean autoStartIsOn) {
		getProperties().setProperty(IMessengerDefinition.AUTO_START, Boolean.toString(autoStartIsOn));

		return this;
	}

	@Override
	public IApexDistributedMessengerBuilder setDefaultTimeout(long defaultTimeoutIsMs) {
		setHelloMessageTimeout(defaultTimeoutIsMs);
		setMessengerTimeout(defaultTimeoutIsMs);
		setSerializationDiscoveryTimeout(defaultTimeoutIsMs);
		setSerializationQueryTimeout(defaultTimeoutIsMs);
		setDiscoveryTimeout(defaultTimeoutIsMs);
		setTransactionTimeout(defaultTimeoutIsMs);

		return this;
	}

	@Override
	public IApexDistributedMessengerBuilder setHelloMessageTimeout(long helloMessageTimeoutIsMs) {
		getProperties().setProperty(IMessengerDefinition.HELLO_MESSAGE_TIMEOUT, Long.toString(helloMessageTimeoutIsMs));

		return this;
	}

	@Override
	public IApexDistributedMessengerBuilder setHelloMessageNumberTrials(int nbTrials) {
		getProperties().setProperty(IMessengerDefinition.HELLO_MESSAGE_NUMBER_TRIALS, Integer.toString(nbTrials));

		return this;
	}

	@Override
	public IApexDistributedMessengerBuilder setMessengerTimeout(long messengerTimeoutIsMs) {
		getProperties().setProperty(IMessengerDefinition.MESSENGER_TIMEOUT, Long.toString(messengerTimeoutIsMs));

		return this;
	}

	@Override
	public IApexDistributedMessengerBuilder setSerializationDiscoveryTimeout(long serializationDiscoveryTimeoutInMs) {
		getProperties().setProperty(IMessengerDefinition.SERIALIZATION_DISCOVERY_TIMEOUT,
				Long.toString(serializationDiscoveryTimeoutInMs));

		return this;
	}

	@Override
	public IApexDistributedMessengerBuilder setSerializationQueryTimeout(long serializationQueryTimeoutInMs) {
		getProperties().setProperty(IMessengerDefinition.SERIALIZATION_QUERY_TIMEOUT,
				Long.toString(serializationQueryTimeoutInMs));

		return this;
	}

	@Override
	public IApexDistributedMessengerBuilder setDiscoveryTimeout(long discoveryTimeoutInMs) {
		getProperties().setProperty(IMessengerDefinition.DISCOVERY_TIMEOUT, Long.toString(discoveryTimeoutInMs));

		return this;
	}

	@Override
	public IApexDistributedMessengerBuilder setTransactionTimeout(long transactionTimeoutInMs) {
		getProperties().setProperty(IMessengerDefinition.TRANSACTION_TIMEOUT, Long.toString(transactionTimeoutInMs));

		return this;
	}

}

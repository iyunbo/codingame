/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.cube;

import java.util.Properties;
import java.util.function.Consumer;
import java.util.function.Function;

import com.quartetfs.biz.pivot.definitions.IAxisHierarchyDescription;

import blasd.apex.server.config.cube.factless.IApexAnalysisFactlessHierarchyBuilder;

/**
 * Helps building new {@link IApexHierarchyBuilder}
 * 
 * @author Benoit Lacelle
 *
 */
public class ApexHierarchyBuilderDecorator implements IPropertiesSetter<IApexHierarchyBuilder>, IApexHierarchyBuilder {

	protected final IApexHierarchyBuilder decorated;

	public ApexHierarchyBuilderDecorator(IApexHierarchyBuilder decorated) {
		this.decorated = decorated;
	}

	public IApexHierarchyBuilder getDecorated() {
		return decorated;
	}

	@Override
	public IApexHierarchyBuilder setSlicing() {
		return decorated.setSlicing();
	}

	@Override
	public IApexLevelBuilder getDeepestLevel() {
		return decorated.getDeepestLevel();
	}

	@Override
	public IApexDimensionBuilder getDimensionBuilder() {
		return decorated.getDimensionBuilder();
	}

	@Override
	public String getId() {
		return decorated.getId();
	}

	@Override
	public IApexHierarchyBuilder setProperty(String key, String value) {
		return decorated.setProperty(key, value);
	}

	@Override
	public IApexCubeBuilder getCubeBuilder() {
		return decorated.getCubeBuilder();
	}

	@Override
	public IApexHierarchyBuilder withAllMember() {
		return decorated.withAllMember();
	}

	@Override
	public IApexLevelBuilder getLevel(int levelIndexSkipAllMember) {
		return decorated.getLevel(0);
	}

	@Override
	public IApexHierarchyBuilder setName(String hierarchyName) {
		return decorated.setName(hierarchyName);
	}

	@Override
	public IApexLevelBuilder appendLevel(String levelName) {
		return decorated.appendLevel(levelName);
	}

	@Override
	public IAxisHierarchyDescription getDescription() {
		return decorated.getDescription();
	}

	@Override
	public IApexHierarchyBuilder setPluginKey(String pluginKey) {
		return decorated.setPluginKey(pluginKey);
	}

	@Override
	public IApexDimensionBuilder getOrAddDimension(String dimensionName) {
		return decorated.getOrAddDimension(dimensionName);
	}

	@Override
	public IApexDimensionBuilder getOrFailDimension(String dimensionName) {
		return decorated.getOrFailDimension(dimensionName);
	}

	@Override
	public IApexHierarchyBuilder addHierarchyAndLevels(String firstFieldAndDimensionAndHierarchyName,
			String... fieldNames) {
		return decorated.addHierarchyAndLevels(firstFieldAndDimensionAndHierarchyName, fieldNames);
	}

	@Override
	public IApexHierarchyBuilder addAnalysisHierarchy(String hierarchyName, String pluginKey) {
		return decorated.addAnalysisHierarchy(hierarchyName, pluginKey);
	}

	@Override
	public <T extends IApexHierarchyBuilder> T addAnalysisHierarchy(String hierarchyName,
			Function<IApexHierarchyBuilder, T> hierarchyBuilderSupplier) {
		return decorated.addAnalysisHierarchy(hierarchyName, hierarchyBuilderSupplier);
	}

	@Override
	public IApexHierarchyBuilder getOrAddAxisHierarchy(String hierarchyName) {
		return decorated.getOrAddAxisHierarchy(hierarchyName);
	}

	@Override
	public IApexHierarchyBuilder getOrFailAxisHierarchy(String hierarchyName) {
		return decorated.getOrFailAxisHierarchy(hierarchyName);
	}

	@Override
	public IApexHierarchyBuilder setFactless(Boolean isFactless) {
		return decorated.setFactless(isFactless);
	}

	@Override
	public IApexAnalysisFactlessHierarchyBuilder setAnalysisFactless(String storeName) {
		return decorated.setAnalysisFactless(storeName);
	}

	@Override
	public String getName() {
		return decorated.getName();
	}

	@Override
	public IApexHierarchyBuilder configure(Consumer<IApexHierarchyBuilder> consumer) {
		return decorated.configure(consumer);
	}

	@Override
	public Properties getProperties() {
		return IApexHierarchyBuilder.super.getProperties();
	}
}

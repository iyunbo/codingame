/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.cube.distributed;

import com.qfs.messenger.impl.AJGroupsMessenger;
import com.qfs.messenger.impl.JGroupsMessenger;
import com.qfs.messenger.impl.LocalMessenger;
import com.qfs.messenger.impl.NettyMessenger;
import com.quartetfs.biz.pivot.definitions.IMessengerDefinition;

import blasd.apex.server.config.cube.properties.IApexPropertiesCubeElement;

/**
 * Helps configuring a {@link IMessengerDefinition}
 * 
 * @author Benoit Lacelle
 *
 */
// AP5.4 - http://support.quartetfs.com/confluence/pages/viewpage.action?pageId=23267250
// AP5.5 - http://support.quartetfs.com/confluence/pages/viewpage.action?pageId=27861136
// AP5.5 - http://support.quartetfs.com/confluence/pages/viewpage.action?pageId=27856726
// AP5.5 - http://support.quartetfs.com/confluence/pages/viewpage.action?pageId=27859450
public interface IApexDistributedMessengerBuilder extends IApexPropertiesCubeElement<IMessengerDefinition> {

	/**
	 * By default, a file is expected to be found at {@link AJGroupsMessenger#DEFAULT_PROTOCOL_PATH}
	 */
	IApexDistributedMessengerBuilder setProtocolPath(String pathToProtocolXmlFile);

	/**
	 * Typically one of {@link NettyMessenger#PLUGIN_KEY}, {@link LocalMessenger#PLUGIN_KEY} but probably no
	 * {@link JGroupsMessenger#PLUGIN_KEY}
	 */
	IApexDistributedMessengerBuilder setMessengerKey(String pluginKey);

	/**
	 * The default value is true
	 */
	IApexDistributedMessengerBuilder autoStart(boolean autoStartIsOn);

	IApexDistributedMessengerBuilder setHelloMessageNumberTrials(int nbTrials);

	/**
	 * 
	 * @param defaultTimeoutIsMs
	 *            set this value as timeout for all different configuration element not already configured. Each timeout
	 *            can individually been modified in a later call
	 */
	IApexDistributedMessengerBuilder setDefaultTimeout(long defaultTimeoutIsMs);

	IApexDistributedMessengerBuilder setHelloMessageTimeout(long helloMessageTimeoutIsMs);

	IApexDistributedMessengerBuilder setMessengerTimeout(long messengerTimeoutInMs);

	IApexDistributedMessengerBuilder setSerializationDiscoveryTimeout(long serializationDiscoveryTimeoutInMs);

	IApexDistributedMessengerBuilder setSerializationQueryTimeout(long serializationQueryTimeoutInMs);

	IApexDistributedMessengerBuilder setDiscoveryTimeout(long discoveryTimeoutInMs);

	IApexDistributedMessengerBuilder setTransactionTimeout(long transactionTimeoutInMs);

}

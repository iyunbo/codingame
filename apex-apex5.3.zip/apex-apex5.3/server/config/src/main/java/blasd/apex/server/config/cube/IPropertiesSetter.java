/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.cube;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import com.google.common.collect.Iterables;

import cormoran.pepper.io.PepperSerializationHelper;

/**
 * Helps feeding {@link Properties}
 * 
 * @author Benoit Lacelle
 *
 * @param <T>
 */
public interface IPropertiesSetter<T> {

	Properties getProperties();

	T setProperty(String key, String value);

	default T setPropertyList(String key, String... elements) {
		return setPropertyList(key, Arrays.asList(elements));
	}

	default T setPropertyList(String key, Iterable<? extends String> elements) {
		return setProperty(key, PepperSerializationHelper.convertToString(elements));
	}

	default T setPropertyMap(String key, Map<? extends String, ? extends String> stringMap) {
		return setProperty(key, PepperSerializationHelper.convertToString(stringMap));
	}

	default void appendPropertyToList(Properties properties, String key, String value) {
		String currentProperty = properties.getProperty(key, "");
		List<String> contextValues = PepperSerializationHelper.convertToListString(currentProperty);

		setPropertyList(key, Iterables.concat(contextValues, Collections.singleton(value)));
	}
}

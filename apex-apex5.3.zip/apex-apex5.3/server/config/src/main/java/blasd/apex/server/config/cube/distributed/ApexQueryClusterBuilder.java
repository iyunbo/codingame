/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.cube.distributed;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import com.quartetfs.biz.pivot.definitions.IQueryClusterDefinition;
import com.quartetfs.biz.pivot.definitions.IQueryClusterDefinition.IDistributedApplicationDefinition;
import com.quartetfs.biz.pivot.definitions.impl.QueryClusterDefinition;

/**
 * Helps configuring a {@link IQueryClusterDefinition}
 * 
 * @author Benoit Lacelle
 *
 */
public class ApexQueryClusterBuilder extends AApexClusterBuilder<IQueryClusterDefinition>
		implements IApexQueryClusterBuilder {

	public ApexQueryClusterBuilder(IQueryClusterDefinition clusterDefinition) {
		super(clusterDefinition);
	}

	@Override
	public IApexQueryClusterBuilder setId(String id) {
		setName(id);

		return this;
	}

	@Override
	public IApexDistributedApplicationBuilder getApplicationOrThrow(String id) {
		Optional<IDistributedApplicationDefinition> opt =
				getDescription().getApplications().stream().filter(d -> id.equals(d.getApplicationId())).findFirst();

		return new ApexDistributedApplicationBuilder(
				opt.orElseThrow(() -> new IllegalArgumentException("There is no application with id=" + id)));
	}

	@Override
	public IApexDistributedApplicationBuilder getOrAddApplication(String applicationId, String... distributingFields) {
		Optional<IDistributedApplicationDefinition> opt = getDescription().getApplications()
				.stream()
				.filter(d -> applicationId.equals(d.getApplicationId()))
				.findFirst();

		String joinedDistributedFields =
				ApexDistributedApplicationBuilder.joinDistributedFields(Arrays.asList(distributingFields));

		IDistributedApplicationDefinition app;
		if (opt.isPresent()) {
			app = opt.get();

			if (!app.getDistributingFields().equals(joinedDistributedFields)) {
				// We found an application with the right id but distributedFields are different: not save
				throw new IllegalArgumentException("The applicationId=" + applicationId
						+ " is associated to multiple distributionFields configuration: '"
						+ joinedDistributedFields
						+ "' and '"
						+ app.getDistributingFields()
						+ "'");
			}
		} else {
			app = new QueryClusterDefinition.DistributedApplicationDefinition(applicationId, joinedDistributedFields);

			// Make a brand new list as the undelrying list may not be mutable
			List<IDistributedApplicationDefinition> application = new ArrayList<>(getDescription().getApplications());
			application.add(app);
			getDescription().setApplications(application);

		}

		return new ApexDistributedApplicationBuilder(app);
	}

}
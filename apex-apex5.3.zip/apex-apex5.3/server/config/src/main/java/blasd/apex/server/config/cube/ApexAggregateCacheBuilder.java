/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.cube;

import java.util.List;

import com.quartetfs.biz.pivot.definitions.IAggregatesCacheDescription;

/**
 * Default implementation for {@link IApexAggregateCacheBuilder}
 * 
 * @author Benoit Lacelle
 *
 */
public class ApexAggregateCacheBuilder implements IApexAggregateCacheBuilder {

	protected final IAggregatesCacheDescription cacheDescription;

	public ApexAggregateCacheBuilder(IAggregatesCacheDescription cacheDescription) {
		this.cacheDescription = cacheDescription;
	}

	@Override
	public IAggregatesCacheDescription getDescription() {
		return cacheDescription;
	}

	@Override
	public void noCache() {
		// The cache is disabled by giving it a negative size
		cacheDescription.setSize(-1);
	}

	@Override
	public void sharedConcurrentQueries() {
		cacheDescription.setSize(0);
	}

	@Override
	public void shareAndCache(int nbOfLocationsMeasures) {
		cacheDescription.setSize(nbOfLocationsMeasures);
	}

	@Override
	public void withMeasures(List<? extends String> measureNames) {
		cacheDescription.setIncludeMode(true);
		cacheDescription.setSelectedMeasures(measureNames.toArray(new String[0]));
	}

	@Override
	public void withoutMeasures(List<? extends String> measureNames) {
		cacheDescription.setIncludeMode(false);
		cacheDescription.setSelectedMeasures(measureNames.toArray(new String[0]));
	}

}

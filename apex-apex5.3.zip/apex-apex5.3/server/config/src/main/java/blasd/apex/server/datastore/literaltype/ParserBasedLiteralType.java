/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.datastore.literaltype;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.qfs.literal.ILiteralType;
import com.qfs.literal.impl.LiteralType;
import com.qfs.msg.IVariablePluginValue;
import com.qfs.store.IDatastore;
import com.qfs.store.Types;
import com.qfs.vector.IVector;
import com.quartetfs.fwk.QuartetPluginValue;
import com.quartetfs.fwk.Registry;
import com.quartetfs.fwk.format.IParser;
import com.quartetfs.fwk.format.impl.FastLocalDateParser;
import com.quartetfs.fwk.format.impl.IntegerParser;
import com.quartetfs.fwk.format.impl.IntegerVectorParser;
import com.quartetfs.fwk.format.impl.ObjectVectorParser;
import com.quartetfs.fwk.format.impl.ParserPlugin;
import com.quartetfs.fwk.format.impl.ShortParser;

/**
 * An {@link ILiteralType} which is configured directly with an {@link IParser} key. It is used toconfigure
 * automatically an {@link IDatastore} column given an {@link IParser} configuration. It is used mainly by
 * CSVFileToStoreConfig
 * 
 * TODO: this should probably not be in module server-config, but {@link ApexCSVToStoreConfig} depends on this
 * 
 * @author Benoit Lacelle
 * 
 */
@QuartetPluginValue(intf = ILiteralType.class)
public class ParserBasedLiteralType extends LiteralType implements IVariablePluginValue {
	private static final long serialVersionUID = 3559616805771924899L;

	protected static final Logger LOGGER = LoggerFactory.getLogger(ParserBasedLiteralType.class);

	public static final String PARSER_KEY_UNKNOWN_CALCULATED = "UNKNOWN";

	public static final String PLUGIN_KEY_PARSER_BASED = "ParserBased";

	public static final Pattern PATTERN = Pattern.compile(PLUGIN_KEY_PARSER_BASED + "\\[(.+)\\]");

	public static final String PARSER_HEURISTIC = "0";
	private static final int PARSER_CACHE_SIZE = 100;

	// As parsing "0" may fail often (typically for date patterns), we prefer to cache this result
	private static final LoadingCache<IParser<?>, Object> PARSER_OVER_0 = CacheBuilder.newBuilder()
			.maximumSize(PARSER_CACHE_SIZE)
			.build(CacheLoader.from(parser -> parser.parse(PARSER_HEURISTIC)));

	protected final String parserKey;

	public ParserBasedLiteralType() {
		// Constructor required by the Registry
		// The most resilient type
		this(LiteralType.OBJECT, Types.CONTENT_OBJECT, false, IParser.STRING, false);
	}

	public ParserBasedLiteralType(IParser<?> parser) {
		this(LiteralType.OBJECT, Types.CONTENT_OBJECT, false, parser.key().toString(), false);
	}

	/**
	 * 
	 * @param literalType
	 *            see ILiteralType
	 * @param contentType
	 * @param isArray
	 * @param parserKey
	 * @param isPrimitive
	 */
	public ParserBasedLiteralType(String literalType,
			int contentType,
			boolean isArray,
			String parserKey,
			boolean isPrimitive) {
		super(literalType, contentType, isArray, buildKey(parserKey), isPrimitive);

		this.parserKey = parserKey;
	}

	@Override
	public String getParser() {
		return parserKey;
	}

	@Override
	public IVariablePluginValue parseKey(String pluginKey) {
		Matcher m = PATTERN.matcher(pluginKey);
		if (m.matches()) {
			String parserKey = m.group(1);

			ILiteralType literalType = convertParserKeyToFieldType(parserKey);

			if (literalType instanceof IVariablePluginValue) {
				return (IVariablePluginValue) literalType;
			} else {
				// Re-wrap in an IVariablePluginValue
				return new ParserBasedLiteralType(literalType.getLiteral(),
						literalType.getContentType(),
						literalType.isArray(),
						literalType.getParser(),
						literalType.isPrimitive());
			}
		} else {
			return null;
		}
	}

	protected static ILiteralType guessLiteralTypeFromParserResult(Object parsed, String parserKey) {
		boolean isArray = parsed.getClass().isArray();
		boolean isVector = parsed instanceof IVector;

		final String literalType;
		final int contentType;
		final boolean isPrimitive;

		if (isArray) {
			// According to LiteralTypePlugin, even double[] LiteralType is not a primitive literaltype
			isPrimitive = false;

			if (parsed instanceof float[]) {
				literalType = LiteralType.FLOAT_ARRAY;
				contentType = Types.CONTENT_FLOAT;
			} else if (parsed instanceof double[]) {
				literalType = LiteralType.DOUBLE_ARRAY;
				contentType = Types.CONTENT_DOUBLE;
			} else if (parsed instanceof int[]) {
				literalType = LiteralType.INT_ARRAY;
				contentType = Types.CONTENT_INT;
			} else if (parsed instanceof long[]) {
				literalType = LiteralType.LONG_ARRAY;
				contentType = Types.CONTENT_LONG;
			} else if (parsed instanceof String[]) {
				literalType = LiteralType.STRING_ARRAY;
				contentType = Types.CONTENT_STRING;
			} else {
				literalType = LiteralType.OBJECT_ARRAY;
				contentType = Types.CONTENT_OBJECT;
			}
		} else if (isVector) {
			isPrimitive = false;

			int componentType = ((IVector) parsed).getComponentType();

			if (componentType == Types.TYPE_FLOAT) {
				literalType = LiteralType.FLOAT_ARRAY;
				contentType = Types.CONTENT_FLOAT;
			} else if (componentType == Types.TYPE_DOUBLE) {
				literalType = LiteralType.DOUBLE_ARRAY;
				contentType = Types.CONTENT_DOUBLE;
			} else if (componentType == Types.TYPE_INT) {
				literalType = LiteralType.INT_ARRAY;
				contentType = Types.CONTENT_INT;
			} else if (componentType == Types.TYPE_LONG) {
				literalType = LiteralType.LONG_ARRAY;
				contentType = Types.CONTENT_LONG;
			} else if (componentType == Types.TYPE_STRING) {
				literalType = LiteralType.STRING_ARRAY;
				contentType = Types.CONTENT_STRING;
			} else {
				literalType = LiteralType.OBJECT_ARRAY;
				contentType = Types.CONTENT_OBJECT;
			}
		} else if (parsed instanceof Integer) {
			literalType = LiteralType.INT;
			contentType = Types.CONTENT_INT;
			isPrimitive = true;
		} else if (parsed instanceof Long) {
			literalType = LiteralType.LONG;
			contentType = Types.CONTENT_LONG;
			isPrimitive = true;
		} else if (parsed instanceof Float) {
			literalType = LiteralType.FLOAT;
			contentType = Types.CONTENT_FLOAT;
			isPrimitive = true;
		} else if (parsed instanceof Double) {
			literalType = LiteralType.DOUBLE;
			contentType = Types.CONTENT_DOUBLE;
			isPrimitive = true;
		} else {
			literalType = LiteralType.OBJECT;
			contentType = Types.CONTENT_OBJECT;
			isPrimitive = false;
		}

		return new ParserBasedLiteralType(literalType, contentType, isArray || isVector, parserKey, isPrimitive);

	}

	public static IParser<?> getParser(String parserKey) {
		return Registry.getPlugin(IParser.class).valueOf(parserKey);
	}

	public static String buildKey(String parserKey) {
		return "ParserBased[" + parserKey + "]";
	}

	public static String buildKey(IParser<?> parser) {
		return buildKey(parser.key().toString());
	}

	public static ILiteralType convertParserKeyToFieldType(String parserKey) {
		IParser<?> parser = getParser(parserKey);
		if (parser != null) {
			return convertParserKeyToFieldType(parser);
		} else {
			throw new RuntimeException("There is no parser for key: " + parserKey);
		}
	}

	private static final Set<?> CORE_PARSERS = Collections.unmodifiableSet(new ParserPlugin().values()
			.stream()
			.map(Object::getClass)
			.collect(HashSet::new, HashSet::add, HashSet::add));

	public static ILiteralType convertParserKeyToFieldType(IParser<?> parser) {
		if (CORE_PARSERS.contains(parser.getClass())) {
			// Return the core ILiteralType
			ILiteralType coreLiteralType = Registry.getPlugin(ILiteralType.class).valueOf(parser.key());

			if (coreLiteralType == null) {
				if (parser.getClass() == ObjectVectorParser.class) {
					coreLiteralType = Registry.getPlugin(ILiteralType.class).valueOf(ILiteralType.OBJECT_ARRAY);
				} else if (parser.getClass() == IntegerParser.class) {
					coreLiteralType = Registry.getPlugin(ILiteralType.class).valueOf(ILiteralType.INT);
				} else if (parser.getClass() == IntegerVectorParser.class) {
					coreLiteralType = Registry.getPlugin(ILiteralType.class).valueOf(ILiteralType.INT_ARRAY);
				} else if (parser.getClass() == FastLocalDateParser.class) {
					coreLiteralType = Registry.getPlugin(ILiteralType.class).valueOf(ILiteralType.LOCAL_DATE);
				} else if (parser.getClass() == ShortParser.class) {
					LOGGER.warn("There is no core ILiteralType for {}", parser);
					coreLiteralType = new ParserBasedLiteralType(parser);
				} else {
					throw new RuntimeException("There is no core ILiteralType for " + parser);
				}
			}

			return coreLiteralType;
		} else {
			try {
				Object parsed = PARSER_OVER_0.getUnchecked(parser);

				if (parsed == null) {
					return new ParserBasedLiteralType();
				} else {
					return guessLiteralTypeFromParserResult(parsed, parser.key().toString());
				}
			} catch (RuntimeException e) {
				LOGGER.trace("Issue while parsing the String '0'", e);

				// Return the most resilient type
				return new ParserBasedLiteralType(parser);
			}
		}
	}
}

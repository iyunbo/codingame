/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.cube.distributed;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;

import com.quartetfs.biz.pivot.definitions.IQueryClusterDefinition.IDistributedApplicationDefinition;

import blasd.apex.server.config.cube.IApexCubeElement;

/**
 * Helps configuring a {@link IDistributedApplicationDefinition}
 * 
 * @author Benoit Lacelle
 *
 */
public interface IApexDistributedApplicationBuilder extends IApexCubeElement<IDistributedApplicationDefinition> {
	/**
	 * There may be no distributing fields: all instance would then aggregates together without any constrain
	 */
	default IApexDistributedApplicationBuilder setDistributingFields(String... distributingFields) {
		final Collection<? extends String> asList;
		if (distributingFields == null) {
			asList = Collections.emptyList();
		} else {
			asList = Arrays.asList(distributingFields);
		}
		return setDistributingFields(asList);
	}

	IApexDistributedApplicationBuilder setDistributingFields(Collection<? extends String> distributingFields);
}

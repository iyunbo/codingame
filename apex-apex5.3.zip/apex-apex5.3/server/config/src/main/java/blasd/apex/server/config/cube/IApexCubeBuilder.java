/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.cube;

import com.quartetfs.biz.pivot.context.IContextValue;
import com.quartetfs.biz.pivot.definitions.IActivePivotDescription;

/**
 * This interface helps updating an IActivePivotDescription. It can be used to build one from scratch
 * 
 * @see ApexCubeBuilder
 * @author Benoit Lacelle
 * 
 */
public interface IApexCubeBuilder extends IApexHierarchiesHolder, IApexMeasuresHolder {

	IActivePivotDescription getActivePivotDescription();

	IApexCubeBuilder setQueryExecutorKey(String pluginKey);

	IApexCubeBuilder setAggregatesContinuousQueryEngineKey(String pluginKey);

	/**
	 * Helps to define the default {@link IContextValue}s
	 */
	IApexSharedContextBuilder getSharedContextBuilder();

	/**
	 * autofact-less hierarchies are hierarchies built directly from the enrichment table. However, it could lead to
	 * very high-cardinality hierarchies if the enrichment table is huge but only partly referenced by the base store
	 */
	IApexCubeBuilder setAutoFactlessHierarchies(Boolean autoFactlessHierarchies);

	IApexAggregateProviderBuilder getAggregateProviderBuilder();

	IApexAggregateCacheBuilder getAggregatesCacheBuilder();

	IApexCubeBuilder setDrillthroughQueryExecutorQuery(String pluginKey);

	IApexCubeInstanceBuilder wrapAsInstance(String pivotId);

}

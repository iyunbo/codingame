/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.cube;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.quartetfs.biz.pivot.definitions.IActivePivotInstanceDescription;
import com.quartetfs.biz.pivot.definitions.IDataClusterDefinition;
import com.quartetfs.biz.pivot.definitions.impl.DataClusterDefinition;

import blasd.apex.server.config.cube.distributed.ApexDataClusterBuilder;
import blasd.apex.server.config.cube.distributed.IApexDataClusterBuilder;

/**
 * Sefault implementation of {@link IApexCubeInstanceBuilder}
 * 
 * @author Benoit Lacelle
 *
 */
public class ApexCubeInstanceBuilder implements IApexCubeInstanceBuilder {
	protected final IActivePivotInstanceDescription activePivotInstanceDescription;

	public ApexCubeInstanceBuilder(IActivePivotInstanceDescription activePivotInstanceDescription) {
		this.activePivotInstanceDescription = activePivotInstanceDescription;
	}

	@Override
	public String getId() {
		return activePivotInstanceDescription.getId();
	}

	@Override
	public String getName() {
		return activePivotInstanceDescription.getId();
	}

	@Override
	public IApexCubeInstanceBuilder setName(String elementNewName) {
		activePivotInstanceDescription.setId(elementNewName);

		return this;
	}

	@Override
	public IActivePivotInstanceDescription getDescription() {
		return activePivotInstanceDescription;
	}

	@Override
	public IApexDataClusterBuilder getOrMakeCluster(String clusterId) {
		List<IDataClusterDefinition> clusterDefinitions = activePivotInstanceDescription.getClusterDefinitions();

		Optional<IDataClusterDefinition> optClusterDef;
		if (clusterDefinitions == null) {
			activePivotInstanceDescription.setClusterDefinitions(new ArrayList<>());

			optClusterDef = Optional.empty();
		} else {
			optClusterDef = clusterDefinitions.stream().filter(dcd -> clusterId.equals(dcd.getId())).findFirst();
		}

		IDataClusterDefinition clusterDef;
		if (optClusterDef.isPresent()) {
			clusterDef = optClusterDef.get();
		} else {
			clusterDef = new DataClusterDefinition(clusterId);

			activePivotInstanceDescription.getClusterDefinitions().add(clusterDef);
		}

		return new ApexDataClusterBuilder(clusterDef);
	}

}

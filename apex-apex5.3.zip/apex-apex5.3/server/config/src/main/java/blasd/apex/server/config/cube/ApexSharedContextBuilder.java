/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.cube;

import java.util.ArrayList;
import java.util.Collections;

import com.google.common.base.Joiner;
import com.quartetfs.biz.pivot.context.IContextValue;
import com.quartetfs.biz.pivot.context.drillthrough.impl.DrillthroughProperties;
import com.quartetfs.biz.pivot.context.impl.MdxContext;
import com.quartetfs.biz.pivot.context.impl.QueriesTimeLimit;
import com.quartetfs.biz.pivot.definitions.ICalculatedDrillthroughColumnDescription;
import com.quartetfs.biz.pivot.definitions.IContextValuesDescription;
import com.quartetfs.biz.pivot.definitions.impl.CalculatedDrillthroughColumnDescription;

/**
 * Helps configuring an IContextValuesDescription
 * 
 * @author Benoit Lacelle
 *
 */
public class ApexSharedContextBuilder implements IApexSharedContextBuilder {
	protected final IApexCubeBuilder apexCubeBuilder;

	public ApexSharedContextBuilder(IApexCubeBuilder apexCubeBuilder) {
		this.apexCubeBuilder = apexCubeBuilder;
	}

	@Override
	public IApexSharedContextBuilder addDrillthroughCalculatedColumn(String pluginKey,
			String calculatedColumnName,
			Iterable<? extends String> underlyingFields) {
		DrillthroughProperties dtProperties = getOrMake();

		if (dtProperties.getCalculatedColumns() == null) {
			dtProperties.setCalculatedColumns(new ArrayList<ICalculatedDrillthroughColumnDescription>());
		}

		// Separator defined in
		// ACalculatedDrillthroughColumn.ACalculatedDrillthroughColumn(String,
		// String, Properties)
		CalculatedDrillthroughColumnDescription dtDescription = new CalculatedDrillthroughColumnDescription(pluginKey,
				calculatedColumnName,
				Joiner.on(',').join(underlyingFields));
		dtProperties.getCalculatedColumns().add(dtDescription);

		return this;
	}

	protected DrillthroughProperties getOrMake() {
		return getOrMake(DrillthroughProperties.class);
	}

	protected <T extends IContextValue> T getOrMake(Class<? extends T> claszz) {
		// Try to find existing DrillthroughProperties
		for (IContextValue value : getDescription().getValues()) {
			if (claszz.isInstance(value)) {
				return claszz.cast(value);
			}
		}

		// None found: make a new one
		T dtProperties;
		try {
			dtProperties = claszz.newInstance();
		} catch (InstantiationException | IllegalAccessException e) {
			throw new RuntimeException(e);
		}

		addContextValue(dtProperties);

		return dtProperties;
	}

	@Override
	public IContextValuesDescription getDescription() {
		return apexCubeBuilder.getActivePivotDescription().getSharedContexts();
	}

	@Override
	public IApexSharedContextBuilder setQueriesTimeLimitInSeconds(Integer timeoutInSeconds) {
		return addContextValue(new QueriesTimeLimit(timeoutInSeconds));
	}

	@Override
	public IApexSharedContextBuilder setDisableMdxCompilation(Boolean disableMdxCompilation) {
		((MdxContext) getMdxContext()).setDisableMdxCompilation(disableMdxCompilation);

		return this;
	}

	@Override
	public IApexSharedContextBuilder setAggressiveFormulaEvaluation(Boolean aggressiveFormulaEvaluation) {
		((MdxContext) getMdxContext()).setAggressiveFormulaEvaluation(aggressiveFormulaEvaluation);

		return this;
	}

	@Override
	public IApexSharedContextBuilder addContextValue(IContextValue contextValue) {
		getDescription().addValues(Collections.singleton(contextValue));

		return this;
	}

	@Override
	public MdxContext getMdxContext() {
		MdxContext mdxContext = getOrMake(MdxContext.class);
		addContextValue(mdxContext);
		return mdxContext;
	}

	@Override
	public IApexSharedContextBuilder setDrillthroughMaxRows(Integer maxRows) {
		getDrillthroughProperties().setMaxRows(maxRows);

		return this;
	}

	@Override
	public DrillthroughProperties getDrillthroughProperties() {
		DrillthroughProperties drillthroughProperties = getOrMake(DrillthroughProperties.class);
		addContextValue(drillthroughProperties);
		return drillthroughProperties;
	}

	@Override
	public IApexSharedContextBuilder setCellSetMaxCells(Integer maxCells) {
		getMdxContext().setResultLimit(maxCells);

		return this;
	}

	@Override
	public IApexSharedContextBuilder setCellSetMaxRowsAndColumns(Integer maxRows) {
		getMdxContext().setAxisPositionLimit(maxRows);

		return this;
	}

}

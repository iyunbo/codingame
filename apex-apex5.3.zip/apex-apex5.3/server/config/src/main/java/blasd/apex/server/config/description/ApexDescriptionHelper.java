/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.description;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Optional;
import java.util.Queue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.ClassUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.google.common.annotations.Beta;
import com.google.common.base.Joiner;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import com.google.common.collect.Streams;
import com.qfs.desc.IDatastoreSchemaDescription;
import com.qfs.desc.IDatastoreSchemaDescriptionPostProcessor;
import com.qfs.desc.IFieldDescription;
import com.qfs.desc.IOptimizationDescription;
import com.qfs.desc.IOptimizationDescription.Optimization;
import com.qfs.desc.IReferenceDescription;
import com.qfs.desc.IStoreDescription;
import com.qfs.desc.impl.DatastoreSchemaDescription;
import com.qfs.desc.impl.FieldDescription;
import com.qfs.desc.impl.OptimizationDescription;
import com.qfs.desc.impl.PartitioningPostProcessor;
import com.qfs.desc.impl.ReferenceDescription;
import com.qfs.desc.impl.StoreDescription;
import com.qfs.desc.impl.StoreDescriptionBuilder;
import com.qfs.desc.impl.StoreDescriptionSpy;
import com.qfs.literal.ILiteralType;
import com.qfs.store.part.IPartitioningDescription;
import com.quartetfs.biz.pivot.definitions.IActivePivotSchemaDescription;
import com.quartetfs.biz.pivot.definitions.IAxisDimensionDescription;
import com.quartetfs.biz.pivot.definitions.IAxisDimensionsDescription;
import com.quartetfs.biz.pivot.definitions.IAxisHierarchyDescription;
import com.quartetfs.biz.pivot.definitions.IAxisLevelDescription;
import com.quartetfs.biz.pivot.definitions.IClusterDefinition;
import com.quartetfs.biz.pivot.definitions.IDataClusterDefinition;
import com.quartetfs.biz.pivot.definitions.IDescription;
import com.quartetfs.biz.pivot.definitions.IQueryClusterDefinition;
import com.quartetfs.biz.pivot.definitions.IUnresolvedImport;
import com.quartetfs.fwk.IPair;
import com.quartetfs.fwk.impl.Pair;
import com.quartetfs.fwk.serialization.SerializerException;
import com.quartetfs.fwk.serialization.impl.JaxbSerializer;

import blasd.apex.server.config.store.StoreDescriptionMerger;

/**
 * Various utility methods related to {@link IStoreDescription}, {@link IReferenceDescription},
 * 
 * @author Benoit Lacelle
 *
 */
public class ApexDescriptionHelper {
	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexDescriptionHelper.class);

	protected ApexDescriptionHelper() {
		// hidden
	}

	public static final IStoreDescription findStore(String storeName, Collection<? extends IStoreDescription> stores) {
		Optional<? extends IStoreDescription> found = findStoreNoFail(storeName, stores);

		if (found.isPresent()) {
			return found.get();
		} else {
			throw new IllegalArgumentException("There is no store named " + storeName
					+ ". Availables are "
					+ stores.stream().map(IStoreDescription::getName).collect(Collectors.toSet()));
		}
	}

	public static final Optional<? extends IStoreDescription> findStoreNoFail(String storeName,
			Collection<? extends IStoreDescription> stores) {
		return stores.stream().filter(e -> storeName.equals(e.getName())).findFirst();
	}

	/**
	 * 
	 * @param fromStoreName
	 * @param toStoreName
	 * @param references
	 * @return the first reference going from given stores, or throw
	 */
	public static final IReferenceDescription findReference(String fromStoreName,
			String toStoreName,
			Collection<? extends IReferenceDescription> references) {
		Optional<? extends IReferenceDescription> found = findReferenceNoFail(fromStoreName, toStoreName, references);

		if (found.isPresent()) {
			return found.get();
		} else {
			throw new IllegalArgumentException("There is no references from " + fromStoreName + " to " + toStoreName);
		}
	}

	public static final Optional<? extends IReferenceDescription> findReferenceNoFail(String fromStoreName,
			String toStoreName,
			Collection<? extends IReferenceDescription> references) {
		return references.stream()
				.filter(r -> r.getOwnerStore().equals(fromStoreName))
				.filter(r -> r.getTargetStore().equals(toStoreName))
				.findFirst();
	}

	public static Optional<? extends IFieldDescription> findField(String fieldName,
			List<? extends IFieldDescription> fields) {
		return fields.stream().filter(e -> fieldName.equals(e.getName())).findFirst();
	}

	@Beta
	public static String getLevelName(List<? extends IAxisDimensionDescription> axisDimensionList,
			String hierarchyName,
			int levelDepth) {
		for (IAxisDimensionDescription d : axisDimensionList) {
			for (IAxisHierarchyDescription h : d.getHierarchies()) {
				if (h.getName().equals(hierarchyName)) {
					// -1 as ALL is not expressed
					return h.getLevels().get(levelDepth - 1).getLevelName();
				}
			}
		}

		throw new IllegalArgumentException("There is no hierarchy named " + hierarchyName);
	}

	@Beta
	public static IAxisDimensionDescription findOwningDimension(
			List<? extends IAxisDimensionDescription> axisDimensionList,
			String hierarchyName) {
		IAxisDimensionDescription found = findOwningDimensionNoFail(axisDimensionList, hierarchyName);

		if (found == null) {
			throw new IllegalArgumentException("There is no hierarchy named " + hierarchyName);
		} else {
			return found;
		}
	}

	@Beta
	public static IAxisDimensionDescription findOwningDimensionNoFail(
			List<? extends IAxisDimensionDescription> axisDimensionList,
			String hierarchyName) {
		for (IAxisDimensionDescription d : axisDimensionList) {
			for (IAxisHierarchyDescription h : d.getHierarchies()) {
				if (h.getName().equals(hierarchyName)) {
					return d;
				}
			}
		}

		return null;
	}

	@Beta
	public static IAxisHierarchyDescription findHierarchyNoFail(
			List<? extends IAxisDimensionDescription> axisDimensionList,
			String hierarchyName) {
		return findHierarchy(axisDimensionList, hierarchyName).map(e -> e.getValue()).orElse(null);
	}

	public static Optional<Map.Entry<IAxisDimensionDescription, IAxisHierarchyDescription>> findHierarchy(
			List<? extends IAxisDimensionDescription> dimensions,
			String hierarchyName) {

		for (IAxisDimensionDescription d : dimensions) {
			for (IAxisHierarchyDescription h : d.getHierarchies()) {
				if (h.getName().equals(hierarchyName)) {
					return Optional.of(Maps.immutableEntry(d, h));
				}
			}
		}

		return Optional.empty();
	}

	/**
	 * 
	 * @param axisDimensions
	 * @param level
	 * @return an IAxisLevelDescription with given level name
	 */
	public static Optional<IAxisLevelDescription> findLevel(IAxisDimensionsDescription axisDimensions, String level) {
		return axisDimensions.getValues()
				.stream()
				.flatMap(d -> d.getHierarchies().stream())
				.flatMap(h -> h.getLevels().stream())
				.filter(ld -> ld.getLevelName().equals(level))
				.findAny();
	}

	/**
	 * 
	 * @param ownerStore
	 * @param targetStore
	 * @param sourceAndTargetField
	 * @return a IReferenceDescription which joins a single field having the same name in owner and target sore
	 */
	public static IReferenceDescription makeReference(String ownerStore,
			String targetStore,
			String sourceAndTargetField) {
		return makeReference(ownerStore, targetStore, sourceAndTargetField, sourceAndTargetField);
	}

	/**
	 * An alternative to {@link ReferenceDescription#builder()} which adds a nice name
	 */
	public static IReferenceDescription makeReference(String ownerStore,
			String targetStore,
			String sourceField,
			String targetField) {
		return makeReference(ownerStore, targetStore, Collections.singletonMap(sourceField, targetField));
	}

	/**
	 * An alternative to {@link ReferenceDescription#builder()} which can easily handle mapping defined as a Map
	 */
	public static IReferenceDescription makeReference(String ownerStore,
			String targetStore,
			Map<? extends String, ? extends String> sourceFieldToTarget) {
		List<IPair<String, String>> mapping = new ArrayList<>();

		for (Entry<? extends String, ? extends String> entry : sourceFieldToTarget.entrySet()) {
			mapping.add(new Pair<String, String>(entry.getKey(), entry.getValue()));
		}

		// '[' and ']' are special characters in
		// com.quartetfs.fwk.impl.BaseProperty.parseExpression()
		String name = ownerStore + "("
				+ Joiner.on(',').join(sourceFieldToTarget.keySet())
				+ ")->"
				+ targetStore
				+ "("
				+ Joiner.on(',').join(sourceFieldToTarget.values())
				+ ")";

		return new ReferenceDescription(ownerStore, targetStore, name, mapping);
	}

	public static <T extends IDescription> T unmarshallDescription(Resource resource, Class<? extends T> clazz)
			throws SerializerException, IOException {
		JaxbSerializer jaxbSerializer = new JaxbSerializer();
		@SuppressWarnings("unchecked")
		T desc = (T) jaxbSerializer.deserialize(resource.getInputStream());

		Queue<IUnresolvedImport> resolve = new LinkedBlockingQueue<>();
		resolve.addAll(desc.getUnresolvedImports());

		while (!resolve.isEmpty()) {
			IUnresolvedImport unresolved = resolve.poll();

			Object deserialized =
					jaxbSerializer.deserialize(new ClassPathResource(unresolved.getId()).getInputStream());

			if (deserialized instanceof IDescription) {
				resolve.addAll(((IDescription) deserialized).getUnresolvedImports());
			}

			unresolved.resolve(deserialized);
		}

		desc.validate();

		return desc;
	}

	/**
	 * Simple way of making a store description. More advanced use-cases should rely on {@link StoreDescriptionBuilder}
	 */
	public static IStoreDescription createStoreDescription(String storeName,
			Map<? extends String, ? extends String> fieldNameToType,
			String... keyFields) {
		if (keyFields == null) {
			return createStoreDescription(storeName, fieldNameToType, Collections.emptyList());
		} else {
			return createStoreDescription(storeName, fieldNameToType, Arrays.asList(keyFields));
		}
	}

	/**
	 * Simple way of making a store description. More advanced use-cases should rely on {@link StoreDescriptionBuilder}
	 * 
	 * @param storeName
	 * @param fieldNameToType
	 *            a field name to a {@link ILiteralType}
	 * @param keyFields
	 * @return
	 */
	public static IStoreDescription createStoreDescription(String storeName,
			Map<? extends String, ? extends String> fieldNameToType,
			List<? extends String> keyFields) {
		return StoreDescriptionMerger.prepareStoreBuilder(storeName, fieldNameToType, null, keyFields).build();
	}

	/**
	 * Helps test by forcing a field as double[]
	 * 
	 * @param fieldDescription
	 * @deprecated prefer using .upgradeToArray
	 */
	@Deprecated
	public static void forceDoubleArray(IFieldDescription fieldDescription) {
		upgradeToArray(fieldDescription);
	}

	public static void upgradeToArray(IFieldDescription fieldDescription) {
		FieldDescription impl = (FieldDescription) fieldDescription;

		String currentDataType = impl.getDataType();

		if (impl.getContentClass().isArray()) {
			LOGGER.warn("The field is already an array: {}", fieldDescription);
			return;
		}

		final String targetDataype;
		final Class<?> typeClass;

		if (ILiteralType.FLOAT.equals(currentDataType)) {
			targetDataype = ILiteralType.FLOAT_ARRAY;
			typeClass = float[].class;
		} else if (ILiteralType.DOUBLE.equals(currentDataType)) {
			targetDataype = ILiteralType.DOUBLE_ARRAY;
			typeClass = double[].class;
		} else {
			targetDataype = ILiteralType.OBJECT_ARRAY;
			typeClass = Object[].class;
		}

		impl.setDataType(targetDataype);
		impl.setTypeClass(typeClass);

		upgradeToNullable(impl);
	}

	public static void upgradeToNullable(IFieldDescription fieldDescription) {
		FieldDescription impl = (FieldDescription) fieldDescription;

		impl.setDefaultValue(null);
		impl.setNullable(true);
	}

	public static void downgradeToFloat(IFieldDescription fieldDescription) {
		FieldDescription impl = (FieldDescription) fieldDescription;

		String currentDataType = impl.getDataType();

		final String targetDataype;
		final Class<?> typeClass;

		if (ILiteralType.DOUBLE.equals(currentDataType)) {
			targetDataype = ILiteralType.FLOAT;
			typeClass = float.class;
		} else if (ILiteralType.FLOAT.equals(currentDataType)) {
			LOGGER.warn("Downgrading {} to float is a no-op", fieldDescription);
			return;
		} else if (ILiteralType.FLOAT_ARRAY.equals(currentDataType)) {
			LOGGER.warn("Downgrading {} to float is a no-op", fieldDescription);
			return;
		} else if (ILiteralType.DOUBLE_ARRAY.equals(currentDataType)) {
			targetDataype = ILiteralType.FLOAT_ARRAY;
			typeClass = float[].class;
		} else {
			throw new IllegalArgumentException("We can not downgrade " + fieldDescription + " to a float");
		}

		impl.setDataType(targetDataype);
		impl.setTypeClass(typeClass);

		impl.setDefaultValue(null);
		impl.setNullable(true);
	}

	public static void setDefaultValue(IStoreDescription storeDescription, String fieldName, Object defaultValue) {
		setDefaultValue((FieldDescription) storeDescription.getField(fieldName), defaultValue);
	}

	public static void setDefaultValue(IFieldDescription fieldDescription, Object defaultValue) {
		((FieldDescription) fieldDescription).setDefaultValue(defaultValue);

		if (defaultValue == null) {
			// Ensure the field is nullable
			((FieldDescription) fieldDescription).setNullable(true);
		} else {
			Class<?> contentClass = fieldDescription.getContentClass();
			Class<? extends Object> newDefaultClass = defaultValue.getClass();
			boolean isAssignable = contentClass.isAssignableFrom(newDefaultClass);

			if (!isAssignable && contentClass.isPrimitive()
					&& ClassUtils.primitiveToWrapper(contentClass) == newDefaultClass) {
				// int is not assignable from Integer-> handle autoboxed types specifically
				isAssignable = true;
			}
			if (!isAssignable) {
				throw new IllegalArgumentException(
						defaultValue + " (" + newDefaultClass.getName() + ") is not compatible with " + contentClass);
			}
		}
	}

	@Beta
	public static void addSecondaryIndex(IStoreDescription storeDescription, List<String> indexedFields) {
		Collection<IOptimizationDescription> optimizations = storeDescription.getOptimizationDescriptions();
		if (optimizations == null) {
			throw new IllegalArgumentException("Optimization list is null for " + storeDescription.getName());
		}

		OptimizationDescription optim = new OptimizationDescription(indexedFields, Optimization.INDEX);
		optimizations.add(optim);
	}

	@Beta
	public static void dictionarize(IStoreDescription storeDescription, String fieldName) {
		Collection<IOptimizationDescription> optimizations = storeDescription.getOptimizationDescriptions();
		if (optimizations == null) {
			throw new IllegalArgumentException("Optimization list is null for " + storeDescription.getName());
		}

		OptimizationDescription optim = new OptimizationDescription(fieldName, Optimization.DICTIONARY);
		optimizations.add(optim);
	}

	/**
	 * Mutate a {@link IStoreDescription} by adding an additional field
	 * 
	 * @param storeDescription
	 * @param fieldName
	 * @param literalType
	 * @param defaultValue
	 */
	public static void addField(IStoreDescription storeDescription,
			String fieldName,
			String literalType,
			Object defaultValue) {
		if (storeDescription.getFields().stream().filter(fd -> fieldName.equals(fd.getName())).findAny().isPresent()) {
			throw new IllegalArgumentException("There is already a field named " + fieldName);
		}

		boolean nullable = null == defaultValue;

		FieldDescription fieldDescription = new FieldDescription(fieldName, literalType, nullable, defaultValue);
		((List) storeDescription.getFields()).add(fieldDescription);

		StoreDescriptionSpy.getFieldsByName(((StoreDescription) storeDescription)).put(fieldName, fieldDescription);
	}

	public static void editLiteralType(IStoreDescription storeDescription, String fieldName, String newLiteralType) {
		IFieldDescription field = storeDescription.getField(fieldName);

		if (field == null) {
			throw new IllegalArgumentException("There is no field named " + fieldName
					+ ". Fields are: "
					+ storeDescription.getFields()
							.stream()
							.map(IFieldDescription::getName)
							.collect(Collectors.toList()));
		}

		((FieldDescription) field).setDataType(newLiteralType);
	}

	/**
	 * 
	 * @param schemaDescription
	 * @return a {@link Stream} through both the {@link IQueryClusterDefinition} and the {@link IDataClusterDefinition}
	 */
	public static Stream<IClusterDefinition> streamClusters(IActivePivotSchemaDescription schemaDescription) {
		Stream<IClusterDefinition> dataClusters = schemaDescription.getActivePivotInstanceDescriptions()
				.stream()
				// The cluster definitions may be null if not distributed at all
				.map(pivot -> pivot.getClusterDefinitions())
				.filter(Objects::nonNull)
				.flatMap(clusters -> clusters.stream());

		Stream<IClusterDefinition> queryClusters = schemaDescription.getDistributedActivePivotInstanceDescriptions()
				.stream()
				.map(pivot -> pivot.getClusterDefinition());

		// The compilation fails if this .filter is in-lined
		queryClusters = queryClusters.filter(Objects::nonNull);

		return Streams.concat(dataClusters, queryClusters);
	}

	/**
	 * 
	 * @return a new description is returned with the requested partitioning
	 */
	public static IStoreDescription withPartitioning(IStoreDescription storeDescription,
			String partitioningDescription) {
		IPartitioningDescription partitiong = storeDescription.getPartitioning();

		if (partitiong != null && !partitiong.getPartitioningFields().isEmpty()) {
			throw new IllegalStateException("Can not defined partitioning if already defined");
		}

		IDatastoreSchemaDescription schemaDescription =
				new DatastoreSchemaDescription(Collections.singletonList(storeDescription), Collections.emptyList());
		IDatastoreSchemaDescription desc =
				makeSchemaPostProcessor(ImmutableMap.of(storeDescription.getName(), partitioningDescription))
						.process(schemaDescription);

		return desc.getStoreDescriptions().iterator().next();
	}

	public static IDatastoreSchemaDescriptionPostProcessor makeSchemaPostProcessor(
			Map<? extends String, ?> storeToPartitioning) {
		// Make mutable HashMap as it is a constrain of
		// PartitioningPostProcessor
		Map<String, String> asString = new HashMap<>();

		for (Entry<? extends String, ?> oneStoreToPartitioning : storeToPartitioning.entrySet()) {
			asString.put(oneStoreToPartitioning.getKey(), oneStoreToPartitioning.getValue().toString());
		}

		return new PartitioningPostProcessor(asString);
	}
}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.qfs.pivot.impl;

import com.qfs.distribution.IMultiVersionDistributedActivePivot;
import com.quartetfs.biz.pivot.distribution.IDistributedActivePivotInstanceDescription;

/**
 * Enable retrieving the {@link IDistributedActivePivotInstanceDescription} of a
 * {@link IMultiVersionDistributedActivePivot}
 * 
 * @author Benoit Lacelle
 *
 */
public class MultiVersionDistributedActivePivotSpy {

	protected MultiVersionDistributedActivePivotSpy() {
		// hidden
	}

	// https://support.activeviam.com/jira/browse/APS-9951
	public static IDistributedActivePivotInstanceDescription getDistributedInstanceDescription(
			MultiVersionDistributedActivePivot mvdap) {
		return mvdap.getBase().distributionDescription;
	}

}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.partition;

import org.junit.Assert;
import org.junit.Test;

public class TestApexFieldPartitioningDTO {
	@Test
	public void testEquals() {
		ApexFieldPartitioningDTO dto = new ApexFieldPartitioningDTO("fieldName", "partitionType");
		ApexFieldPartitioningDTO dto2 = new ApexFieldPartitioningDTO("fieldName", "partitionType");

		Assert.assertEquals(dto.hashCode(), dto2.hashCode());
		Assert.assertEquals(dto, dto2);

		// Equals to itself
		Assert.assertEquals(dto, dto);
		// Not equals to null
		Assert.assertNotEquals(null, dto);
	}

	@Test
	public void testEquals_DifferentField() {
		ApexFieldPartitioningDTO dto = new ApexFieldPartitioningDTO("fieldName", "partitionType");
		ApexFieldPartitioningDTO dto2 = new ApexFieldPartitioningDTO("fieldName2", "partitionType");

		Assert.assertNotEquals(dto.hashCode(), dto2.hashCode());
		Assert.assertNotEquals(dto, dto2);
	}

	@Test
	public void testEquals_DifferentPartitioning() {
		ApexFieldPartitioningDTO dto = new ApexFieldPartitioningDTO("fieldName", "partitionType");
		ApexFieldPartitioningDTO dto2 = new ApexFieldPartitioningDTO("fieldName", "partitionType2");

		Assert.assertNotEquals(dto.hashCode(), dto2.hashCode());
		Assert.assertNotEquals(dto, dto2);
	}

	@Test
	public void testToString() {
		ApexFieldPartitioningDTO dto = new ApexFieldPartitioningDTO("fieldName", "partitionType");

		Assert.assertEquals("partitionType(fieldName)", dto.toString());
	}

	@Test
	public void testValuePartitionning() {
		// Leaving the second parameter as empty means Value partitioning. However, AP5.6.0-M1 requires it to be value()
		ApexFieldPartitioningDTO dto = new ApexFieldPartitioningDTO("fieldName", "");

		Assert.assertEquals("value(fieldName)", dto.toString());
	}
}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.cube;

import java.util.Arrays;

import org.assertj.core.api.Assertions;
import org.junit.Assert;
import org.junit.Test;

import com.qfs.agg.impl.SumFunction;
import com.qfs.pivot.cube.provider.bitmap.impl.BitmapAggregateProviderBase;
import com.qfs.pivot.cube.provider.impl.AAggregateProviderBase;
import com.qfs.pivot.cube.provider.multi.impl.GlobalMultipleAggregateProviderBase;
import com.quartetfs.biz.pivot.context.IContextValue;
import com.quartetfs.biz.pivot.context.drillthrough.IDrillthroughProperties;
import com.quartetfs.biz.pivot.definitions.IActivePivotDescription;
import com.quartetfs.biz.pivot.definitions.impl.ActivePivotInstanceDescription;
import com.quartetfs.biz.pivot.definitions.impl.PostProcessorDescription;
import com.quartetfs.biz.pivot.postprocessing.IPostProcessor;
import com.quartetfs.biz.pivot.postprocessing.impl.Stream2PositionPostProcessor;

import blasd.apex.server.config.cube.distributed.IApexDataClusterBuilder;
import blasd.apex.server.test.IApexTestConstants;

public class TestApexCubeBuilder implements IApexTestConstants {
	@Test
	public void buildCube() {
		IApexCubeBuilder builder = ApexCubeBuilder.newDescription()
				.setQueryExecutorKey("queryExecutor")
				.addHierarchyAndLevels(CCY, COUNTRY)
				.setSlicing()
				.getCubeBuilder()
				.addAggregatedMeasure(DELTA, SumFunction.KEY)
				.getCubeBuilder()
				.addPostProcessedMeasure("PostProcessor", Stream2PositionPostProcessor.PLUGIN_KEY)
				.getCubeBuilder();

		// Check build is OK
		IActivePivotDescription activePivotDescription = builder.getActivePivotDescription();
		Assert.assertNotNull(activePivotDescription);

		Assert.assertEquals("queryExecutor", activePivotDescription.getQueryExecutor().getPluginKey());

		Assert.assertEquals(CCY + "@" + CCY + "@" + CCY,
				builder.getOrAddDimension(CCY).getOrAddAxisHierarchy(CCY).getLevel(0).getId());
		Assert.assertEquals(CCY + "@" + CCY + "@" + CCY, builder.getOrFailAxisHierarchy(CCY).getLevel(0).getId());
		Assert.assertEquals(CCY + "@" + CCY, builder.getOrFailAxisHierarchy(CCY).getId());

		Assert.assertEquals(COUNTRY + "@" + CCY + "@" + CCY,
				builder.getOrAddDimension(CCY).getOrAddAxisHierarchy(CCY).getDeepestLevel().getId());

		Assert.assertNotNull(builder.addAnalysisHierarchy("Analysis", "SomePluginKey"));

		// CCY and Analysis
		Assert.assertEquals(2, activePivotDescription.getAxisDimensions().getValues().size());

		// Check get existing measure
		Assert.assertEquals(Stream2PositionPostProcessor.PLUGIN_KEY,
				builder.getPostProcessedMeasure("PostProcessor").get().getDescription().getPluginKey());
	}

	@Test
	public void testSetters() {
		ApexCubeBuilder.newDescription()
				.setAggregatesContinuousQueryEngineKey("pluginKey")
				.setDrillthroughQueryExecutorQuery("pluginKey")
				.setAutoFactlessHierarchies(true);
	}

	@Test
	public void testGetNotExistingMeasure() {
		IApexCubeBuilder emptyCube = ApexCubeBuilder.newDescription();
		Assertions.assertThat(emptyCube.getPostProcessedMeasure("measureName").isPresent()).isFalse();
	}

	@Test
	public void testUnderlyingMeasures() {
		PostProcessorDescription ppDesc1 = new PostProcessorDescription();
		IRawApexPostProcessorBuilder<?> ppBuilder1 = new ApexPreparedPostProcessorBuilder(ppDesc1);

		PostProcessorDescription ppDesc2 = new PostProcessorDescription("underlyingname2", "underlyingKey2", null);
		IRawApexPostProcessorBuilder<?> ppBuilder2 = new ApexPreparedPostProcessorBuilder(ppDesc2);

		PostProcessorDescription ppDesc3 = new PostProcessorDescription("underlyingname3", "underlyingKey3", null);
		IRawApexPostProcessorBuilder<?> ppBuilder3 = new ApexPreparedPostProcessorBuilder(ppDesc3);

		ppBuilder1.setUnderlyingMeasures(ppBuilder2, ppBuilder3);

		// We check we use ActivePivot postprocessor separator
		Assert.assertEquals("underlyingname2,underlyingname3",
				ppBuilder1.getProperties().get(IPostProcessor.UNDERLYING_MEASURES));
	}

	@Test
	public void testDTproperties() {
		IApexCubeBuilder ppBuilder = ApexCubeBuilder.newDescription();

		ppBuilder.getSharedContextBuilder()
				.addDrillthroughCalculatedColumn("pluginKey",
						"calculatedColumnName",
						Arrays.asList("underlyingFields"));
		ppBuilder.getSharedContextBuilder()
				.addDrillthroughCalculatedColumn("pluginKey2",
						"calculatedColumnName2",
						Arrays.asList("underlyingFields2"));

		// We check we use ActivePivot postprocessor separator
		Assert.assertEquals(1, ppBuilder.getActivePivotDescription().getSharedContexts().getValues().size());
		IContextValue singleCV = ppBuilder.getActivePivotDescription().getSharedContexts().getValues().get(0);
		Assert.assertEquals(IDrillthroughProperties.class, singleCV.getContextInterface());
		Assert.assertEquals(2, ((IDrillthroughProperties) singleCV).getCalculatedColumns().size());
	}

	@Test(expected = RuntimeException.class)
	public void testFailIfMissingHierarchy() {
		IApexCubeBuilder builder = ApexCubeBuilder.newDescription()
				.addHierarchyAndLevels(CCY)
				.withAllMember()
				.getCubeBuilder()
				.addAggregatedMeasure(DELTA, SumFunction.KEY)
				.getCubeBuilder();

		builder.getOrFailAxisHierarchy("NotExisting");
	}

	@Test(expected = RuntimeException.class)
	public void testFailIfMissingDimension() {
		IApexCubeBuilder builder = ApexCubeBuilder.newDescription()
				.addHierarchyAndLevels(CCY)
				.withAllMember()
				.getCubeBuilder()
				.addAggregatedMeasure(DELTA, SumFunction.KEY)
				.getCubeBuilder();

		builder.getOrFailDimension("NotExisting");
	}

	@Test
	public void testAggregateProvider() {
		IApexCubeBuilder builder = ApexCubeBuilder.newDescription();

		builder.addHierarchyAndLevels(CCY)
				.getCubeBuilder()
				.addAggregatedMeasure(DELTA, SumFunction.KEY)
				.getCubeBuilder();

		builder.getAggregateProviderBuilder()
				.setAggregateProviderPluginKey(GlobalMultipleAggregateProviderBase.PLUGIN_TYPE)
				.setChunkSize(123)
				.setPrintTimings(true)
				.setUnderlyingProviderKey(BitmapAggregateProviderBase.PLUGIN_TYPE);

		// Check we wrote as String in the Properties
		Assert.assertEquals("123",
				builder.getActivePivotDescription()
						.getAggregateProvider()
						.getProperties()
						.getProperty(AAggregateProviderBase.CHUNK_SIZE));
	}

	@Test
	public void editInstance_CheckHandleNullApplications() {
		IApexDataClusterBuilder cluster =
				new ApexCubeInstanceBuilder(new ActivePivotInstanceDescription()).getOrMakeCluster("clusterId");

		Assert.assertNotNull(cluster);
	}
}

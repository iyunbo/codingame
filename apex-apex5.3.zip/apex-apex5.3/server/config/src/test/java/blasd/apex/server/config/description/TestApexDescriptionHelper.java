/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.description;

import java.io.IOException;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Date;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.core.io.ClassPathResource;

import com.qfs.desc.IFieldDescription;
import com.qfs.desc.IOptimizationDescription.Optimization;
import com.qfs.desc.IReferenceDescription;
import com.qfs.desc.IStoreDescription;
import com.qfs.desc.impl.FieldDescription;
import com.qfs.desc.impl.StoreDescriptionBuilder;
import com.qfs.literal.ILiteralType;
import com.quartetfs.biz.pivot.definitions.impl.MeasuresDescription;
import com.quartetfs.fwk.serialization.SerializerException;

import blasd.apex.server.config.partition.ApexFieldPartitioningDTO;
import blasd.apex.server.test.IApexTestConstants;

public class TestApexDescriptionHelper implements IApexTestConstants {
	@Test
	public void testMakeReference() {
		IReferenceDescription ref = ApexDescriptionHelper.makeReference(MAIN_STORE, ENRICHMENT_STORE, COUNTRY, CCY);

		Assert.assertEquals(MAIN_STORE + "(" + COUNTRY + ")->" + ENRICHMENT_STORE + "(" + CCY + ")", ref.getName());
	}

	@Test
	public void testFindReference() {
		IReferenceDescription ref1 = ApexDescriptionHelper.makeReference(MAIN_STORE, ENRICHMENT_STORE, COUNTRY, CCY);
		IReferenceDescription ref2 = ApexDescriptionHelper.makeReference(ENRICHMENT_STORE, "anotherStore", CCY, DAYS);

		Assert.assertSame(ref1,
				ApexDescriptionHelper.findReference(MAIN_STORE, ENRICHMENT_STORE, Arrays.asList(ref1, ref2)));
		Assert.assertSame(ref1,
				ApexDescriptionHelper.findReference(MAIN_STORE, ENRICHMENT_STORE, Arrays.asList(ref1, ref2)));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testFindReference_nothing() {
		IReferenceDescription ref1 = ApexDescriptionHelper.makeReference(MAIN_STORE, ENRICHMENT_STORE, COUNTRY, CCY);
		IReferenceDescription ref2 = ApexDescriptionHelper.makeReference(ENRICHMENT_STORE, "anotherStore", CCY, DAYS);

		ApexDescriptionHelper.findReference(MAIN_STORE, "doesNotExist", Arrays.asList(ref1, ref2));
	}

	@Test
	public void testSetDefaultNullDouble() {
		IFieldDescription field = new FieldDescription("fieldName", ILiteralType.DOUBLE, false, 3D);

		Assert.assertFalse(field.isNullable());

		ApexDescriptionHelper.setDefaultValue(field, null);

		// Ensure the nullable status has been updated
		Assert.assertTrue(field.isNullable());
	}

	@Test
	public void testUnmrshallWithImports() throws SerializerException, IOException {
		ApexDescriptionHelper.unmarshallDescription(new ClassPathResource("/DESC-INF/test_unmarshalling_import.xml"),
				MeasuresDescription.class);
	}

	@Test
	public void testUpgradeToArray() throws SerializerException, IOException {
		FieldDescription base = new FieldDescription(COUNTRY, ILiteralType.FLOAT, false, 2F, Float.class);
		ApexDescriptionHelper.upgradeToArray(base);

		Assert.assertEquals(base.getDataType(), ILiteralType.FLOAT_ARRAY);
		Assert.assertEquals(base.getContentClass(), float[].class);
	}

	@Test
	public void testUpgradeFloatArrayToArray() throws SerializerException, IOException {
		FieldDescription base = new FieldDescription(COUNTRY, ILiteralType.FLOAT, false, 2F, Float.class);

		ApexDescriptionHelper.upgradeToArray(base);
		ApexDescriptionHelper.upgradeToArray(base);

		// Should remain a float Array
		Assert.assertEquals(base.getDataType(), ILiteralType.FLOAT_ARRAY);
		Assert.assertEquals(base.getContentClass(), float[].class);
	}

	@Test
	public void testDowngradeToFloat() throws SerializerException, IOException {
		FieldDescription base = new FieldDescription(COUNTRY, ILiteralType.DOUBLE, false, 2D);
		ApexDescriptionHelper.downgradeToFloat(base);

		Assert.assertEquals(ILiteralType.FLOAT, base.getDataType());
		Assert.assertEquals(float.class, base.getContentClass());

		ApexDescriptionHelper.downgradeToFloat(base);
	}

	@Test
	public void testDowngradeToFloatArray() throws SerializerException, IOException {
		FieldDescription base = new FieldDescription(COUNTRY, ILiteralType.DOUBLE_ARRAY, false, 2D, Float.class);
		ApexDescriptionHelper.downgradeToFloat(base);

		Assert.assertEquals(ILiteralType.FLOAT_ARRAY, base.getDataType());
		Assert.assertEquals(float[].class, base.getContentClass());

		// Down-grade again: should not fail, but may produce a log
		ApexDescriptionHelper.downgradeToFloat(base);
	}

	@Test
	public void testSetDefaultValueOnNullable() throws SerializerException, IOException {
		FieldDescription base = new FieldDescription(COUNTRY, ILiteralType.FLOAT, true, 2D);

		ApexDescriptionHelper.setDefaultValue(base, 5F);

		Assert.assertEquals(5F, base.getDefault());
	}

	@Test
	public void testSetDefaultValueOnNotNullable() throws SerializerException, IOException {
		FieldDescription base = new FieldDescription(COUNTRY, ILiteralType.FLOAT, false, 2D);

		ApexDescriptionHelper.setDefaultValue(base, 5F);

		Assert.assertEquals(5F, base.getDefault());
	}

	@Test(expected = IllegalArgumentException.class)
	public void testInvalidPrimitiveSetDefaultValue() throws SerializerException, IOException {
		FieldDescription base = new FieldDescription(COUNTRY, ILiteralType.DOUBLE_ARRAY, false, 2D);

		ApexDescriptionHelper.setDefaultValue(base, "Youpi");
	}

	@Test(expected = IllegalArgumentException.class)
	public void testInvalidObjectSetDefaultValue() throws SerializerException, IOException {
		FieldDescription base = new FieldDescription(COUNTRY, ILiteralType.STRING, false, "Before");

		ApexDescriptionHelper.setDefaultValue(base, LocalDate.now());
	}

	@Test
	public void testSetNullDefaultValue() throws SerializerException, IOException {
		FieldDescription base = new FieldDescription(COUNTRY, ILiteralType.STRING, false, 2D);

		ApexDescriptionHelper.setDefaultValue(base, null);

		Assert.assertTrue(base.isNullable());
		Assert.assertEquals(null, base.getDefault());
	}

	@Test
	public void testFindStore() {
		IStoreDescription store1 =
				new StoreDescriptionBuilder().withStoreName(MAIN_STORE).withField(COUNTRY).withoutKey().build();
		IStoreDescription store2 =
				new StoreDescriptionBuilder().withStoreName(ENRICHMENT_STORE).withField(COUNTRY).withoutKey().build();

		Assert.assertSame(store1, ApexDescriptionHelper.findStore(MAIN_STORE, Arrays.asList(store1, store2)));
		Assert.assertSame(store2, ApexDescriptionHelper.findStore(ENRICHMENT_STORE, Arrays.asList(store1, store2)));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testFindStore_notExisting() {
		IStoreDescription store1 =
				new StoreDescriptionBuilder().withStoreName(MAIN_STORE).withField(COUNTRY).withoutKey().build();

		ApexDescriptionHelper.findStore(ENRICHMENT_STORE, Arrays.asList(store1));
	}

	@Test
	public void testAddReference() {
		IStoreDescription store1 =
				new StoreDescriptionBuilder().withStoreName(MAIN_STORE).withField(COUNTRY).withoutKey().build();

		Assert.assertEquals(0, store1.getOptimizationDescriptions().size());

		ApexDescriptionHelper.addSecondaryIndex(store1, Arrays.asList(COUNTRY));

		Assert.assertEquals(1, store1.getOptimizationDescriptions().size());

		Assert.assertEquals(Optimization.INDEX, store1.getOptimizationDescriptions().iterator().next().getType());
	}

	@Test
	public void testDictionarize() {
		IStoreDescription store1 =
				new StoreDescriptionBuilder().withStoreName(MAIN_STORE).withField(COUNTRY).withoutKey().build();

		Assert.assertEquals(0, store1.getOptimizationDescriptions().size());

		ApexDescriptionHelper.dictionarize(store1, COUNTRY);

		Assert.assertEquals(1, store1.getOptimizationDescriptions().size());

		Assert.assertEquals(Optimization.DICTIONARY, store1.getOptimizationDescriptions().iterator().next().getType());
	}

	@Test
	public void testAddField_Date() {
		IStoreDescription store =
				new StoreDescriptionBuilder().withStoreName(MAIN_STORE).withField(COUNTRY).withoutKey().build();

		ApexDescriptionHelper.addField(store, ASOFDATE, ILiteralType.DATE, "N/A");

		Assert.assertEquals(Date.class, store.getField(ASOFDATE).getContentClass());
	}

	@Test(expected = IllegalArgumentException.class)
	public void testAddField_RejectAlreadyExists() {
		IStoreDescription store =
				new StoreDescriptionBuilder().withStoreName(MAIN_STORE).withField(COUNTRY).withoutKey().build();

		ApexDescriptionHelper.addField(store, ASOFDATE, ILiteralType.DATE, "N/A");
		ApexDescriptionHelper.addField(store, ASOFDATE, ILiteralType.DATE, "N/A");
	}

	@Test
	public void testChangeFieldLiteralType() {
		IStoreDescription store =
				new StoreDescriptionBuilder().withStoreName(MAIN_STORE).withField(COUNTRY).withoutKey().build();
		Assert.assertEquals(ILiteralType.STRING, store.getField(COUNTRY).getDataType());

		ApexDescriptionHelper.editLiteralType(store, COUNTRY, ILiteralType.OBJECT);
		Assert.assertEquals(ILiteralType.OBJECT, store.getField(COUNTRY).getDataType());
	}

	@Test(expected = IllegalArgumentException.class)
	public void testChangeFieldLiteralType_DoesNotExist() {
		IStoreDescription store =
				new StoreDescriptionBuilder().withStoreName(MAIN_STORE).withField(COUNTRY).withoutKey().build();

		// There is no CCY field
		ApexDescriptionHelper.editLiteralType(store, CCY, ILiteralType.DATE);
	}

	@Test
	public void testAddPartitioning() {
		IStoreDescription storeDescription =
				new StoreDescriptionBuilder().withStoreName(MAIN_STORE).withField(COUNTRY).withoutKey().build();

		// Partition vyValue along COUNTRY
		IStoreDescription withPartitioning = ApexDescriptionHelper.withPartitioning(storeDescription,
				ApexFieldPartitioningDTO.valuePartitioning(COUNTRY).toString());

		// We expect to mutate the provided description
		Assert.assertNotSame(storeDescription, withPartitioning);
		Assert.assertEquals(Arrays.asList(COUNTRY), withPartitioning.getPartitioning().getPartitioningFields());
	}
}

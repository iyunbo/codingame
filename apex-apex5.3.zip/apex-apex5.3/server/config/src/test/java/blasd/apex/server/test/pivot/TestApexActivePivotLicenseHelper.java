/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.test.pivot;

import java.io.IOException;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.Set;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.activeviam.activation.impl.LicenseException;
import com.activeviam.lic.impl.ActiveViamLicense;
import com.google.common.collect.Sets;

public class TestApexActivePivotLicenseHelper {
	@BeforeClass
	public static void loadLicense() {
		ApexActivePivotLicenseHelper.ensureLicenseWithEnv();
	}

	@Test
	public void testLicenseMatchers() throws SocketException, UnknownHostException {
		Set<String> matchers = Sets.newHashSet(ApexActivePivotLicenseHelper.getLicenseMatchers());

		NetworkInterface localhostInetAddress = NetworkInterface.getByInetAddress(InetAddress.getLocalHost());

		// .getHardwareAddress is null if offline
		if (localhostInetAddress == null || localhostInetAddress.getHardwareAddress() == null) {
			// For some reason, we may fail retrieving a mac address
			Assert.assertEquals(2, matchers.size());
		} else {
			// Check we check 3 different strings: macAddress, hsotName, ipAddress
			Assert.assertEquals(3, matchers.size());
		}
	}

	@Test
	public void testResourceLicenseFolder() {
		String matchers = ApexActivePivotLicenseHelper.makeLicensePattern("simpleFoler", "1.2.3.4");

		Assert.assertEquals("classpath*:simpleFoler/ActivePivot*1.2.3.4*.lic.*", matchers);
	}

	@Test
	public void testFileLicenseFolder() {
		String matchers = ApexActivePivotLicenseHelper.makeLicensePattern("file:/C/est/parti", "1.2.3.4");

		Assert.assertEquals("file:/C/est/parti/ActivePivot*1.2.3.4*.lic.*", matchers);
	}

	@Test
	public void testClassPathStarLicenseFolder() {
		String matchers = ApexActivePivotLicenseHelper.makeLicensePattern("classpath*:youpi", "1.2.3.4");

		Assert.assertEquals("classpath*:youpi/ActivePivot*1.2.3.4*.lic.*", matchers);
	}

	@Test
	public void testPrintCurrentLicenseAsBase64() throws LicenseException {
		// Convert current license to base64
		String licenseInBase64 = ApexActivePivotLicenseHelper.getLicenseInBase64();

		// Convert back to license
		ActiveViamLicense license = ApexActivePivotLicenseHelper.getLicenseFromBase64(licenseInBase64);

		Assert.assertNotNull(license);
	}

	@Test
	public void testSetLicenseFromMatchingString() throws IOException {
		Assert.assertFalse(ApexActivePivotLicenseHelper.setLicenseFromMatchingString("/notexisting"));
	}

	@Test
	public void testTryToSetLicenseFromEnv() throws IOException, LicenseException {
		String licenseBase64 = ApexActivePivotLicenseHelper.getLicenseInBase64();
		Assert.assertTrue(
				ApexActivePivotLicenseHelper.tryToSetLicenseFromEnv(Arrays.asList(licenseBase64, licenseBase64)));
	}

	@Test
	public void testSetLicense() throws IOException, LicenseException {
		String licenseBase64 = ApexActivePivotLicenseHelper.getLicenseInBase64();

		// Coverage
		ApexActivePivotLicenseHelper.setLicense("Anything", licenseBase64);
	}

	@Test
	public void testGetLicenseAsEnv() throws IOException, LicenseException {
		// Coverage: the actual values would depends on the tested environment
		ApexActivePivotLicenseHelper.getLicenseAsEnv();
	}
}

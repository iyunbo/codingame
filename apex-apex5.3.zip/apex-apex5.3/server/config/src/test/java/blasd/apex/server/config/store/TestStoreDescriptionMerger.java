/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.store;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.google.common.collect.ImmutableMap;
import com.qfs.desc.IOptimizationDescription;
import com.qfs.desc.IOptimizationDescription.Optimization;
import com.qfs.desc.IStoreDescription;
import com.qfs.desc.impl.OptimizationDescription;
import com.qfs.literal.ILiteralType;

import blasd.apex.server.config.description.ApexDescriptionHelper;
import blasd.apex.server.test.IApexTestConstants;

public class TestStoreDescriptionMerger implements IApexTestConstants {

	@Test
	public void testMergeConfigFailOnDifferentKeys() {
		StoreDescriptionMerger b = new StoreDescriptionMerger();

		ImmutableMap<String, String> fieldNameToType = ImmutableMap.of("c1", ILiteralType.INT);
		b.addStoreDescriptions(
				Arrays.asList(ApexDescriptionHelper.createStoreDescription(MAIN_STORE, fieldNameToType, "k1", "k2"),
						ApexDescriptionHelper.createStoreDescription(MAIN_STORE, fieldNameToType, "k1", "k3")));

		try {
			b.merge();
			Assert.fail("We should reject the merging of stores with different keyFields");
		} catch (RuntimeException e) {
			// We expected the failure
			Assert.assertNotNull(e);
		}
	}

	@Test
	public void testMergeConfig() {
		StoreDescriptionMerger mergeer = new StoreDescriptionMerger();

		List<String> keyFields = Arrays.asList("k1", "k2");

		mergeer.addStoreDescription(ApexDescriptionHelper.createStoreDescription(MAIN_STORE,
				ImmutableMap.of(
						// Change field of c1 from long to int
						"c1",
						ILiteralType.LONG,
						// Add a new field as first
						"c2",
						ILiteralType.LONG,
						// Change the ordering of existing fields: we expect to keep the
						// ordering of the first encountered store
						"c4",
						ILiteralType.LONG,
						"c5",
						ILiteralType.OBJECT),
				keyFields));

		mergeer.addStoreDescription(ApexDescriptionHelper.createStoreDescription(MAIN_STORE, // Add a new field as first
				ImmutableMap.of("c3",
						ILiteralType.INT,

						// Change the ordering of existing fields: we expect to keep the
						// ordering of the first encountered store
						"c4",
						ILiteralType.LONG,
						// Change field of c1 from long to int
						"c1",
						ILiteralType.INT),
				keyFields));

		Collection<? extends IStoreDescription> storeDesc = mergeer.merge();

		Assert.assertEquals(1, storeDesc.size());

		IStoreDescription singleStore = storeDesc.iterator().next();

		// We expect the keyFields to be rigorously the same as it is a
		// non-sense to merge them
		Assert.assertEquals(keyFields, singleStore.getKeyFields());

		Assert.assertEquals(5 + 2, singleStore.getFields().size());
		// Merged int and long to Object
		Assert.assertEquals(ILiteralType.OBJECT, singleStore.getField("c1").getDataType());
		Assert.assertEquals(ILiteralType.LONG, singleStore.getField("c4").getDataType());

		Assert.assertEquals("c1", singleStore.getFields().get(0).getName());
		Assert.assertEquals("c2", singleStore.getFields().get(1).getName());
		Assert.assertEquals("c4", singleStore.getFields().get(2).getName());
		Assert.assertEquals("c5", singleStore.getFields().get(3).getName());
		Assert.assertEquals("k1", singleStore.getFields().get(4).getName());
		Assert.assertEquals("k2", singleStore.getFields().get(5).getName());
		Assert.assertEquals("c3", singleStore.getFields().get(6).getName());
	}

	@Test
	public void testMergeFLoatArrayAndDoubleArray() {
		IStoreDescription floatArrayConfig =
				StoreDescriptionMerger
						.prepareStoreBuilder(MAIN_STORE,
								ImmutableMap.of(CCY, ILiteralType.STRING, SCENARIO_VALUES, ILiteralType.FLOAT_ARRAY),
								CCY)
						.build();

		IStoreDescription doubleArrayConfig =
				StoreDescriptionMerger
						.prepareStoreBuilder(MAIN_STORE,
								ImmutableMap.of(CCY, ILiteralType.STRING, SCENARIO_VALUES, ILiteralType.DOUBLE_ARRAY),
								CCY)
						.build();

		Collection<IStoreDescription> storeDesc =
				new StoreDescriptionMerger().addStoreDescriptions(Arrays.asList(floatArrayConfig, doubleArrayConfig))
						.merge();

		Assert.assertEquals(1, storeDesc.size());

		IStoreDescription singleStore = storeDesc.iterator().next();

		Assert.assertEquals(Arrays.asList(CCY), singleStore.getKeyFields());

		Assert.assertEquals(2, singleStore.getFields().size());
		// Merged int and long to Object
		Assert.assertEquals(ILiteralType.STRING, singleStore.getField(CCY).getDataType());
		Assert.assertEquals(ILiteralType.OBJECT, singleStore.getField(SCENARIO_VALUES).getDataType());
	}

	@Test
	public void testPreserveOptimisations() {
		StoreDescriptionMerger b = new StoreDescriptionMerger();

		ImmutableMap<String, String> fieldNameToType =
				ImmutableMap.of(CCY, ILiteralType.INT, COUNTRY, ILiteralType.STRING);

		OptimizationDescription firstOptim = new OptimizationDescription(COUNTRY, Optimization.INDEX);
		OptimizationDescription secondOptim = new OptimizationDescription(CCY, Optimization.INDEX);

		// First store has index only on Country
		{
			IStoreDescription firstStore = ApexDescriptionHelper.createStoreDescription(MAIN_STORE, fieldNameToType);
			firstStore.getOptimizationDescriptions().add(firstOptim);
			b.addStoreDescription(firstStore);
		}

		// Second store has index only in CCY
		{
			IStoreDescription secondStore = ApexDescriptionHelper.createStoreDescription(MAIN_STORE, fieldNameToType);
			secondStore.getOptimizationDescriptions().add(secondOptim);
			b.addStoreDescription(secondStore);
		}

		Collection<IStoreDescription> merged = b.merge();

		// CHeck both optimisations has been inserted
		Assert.assertEquals(1, merged.size());

		Collection<IOptimizationDescription> singleStoreOptims = merged.iterator().next().getOptimizationDescriptions();
		Assert.assertEquals(2, singleStoreOptims.size());
		Assert.assertTrue(singleStoreOptims.contains(firstOptim));
		Assert.assertTrue(singleStoreOptims.contains(secondOptim));
	}

}

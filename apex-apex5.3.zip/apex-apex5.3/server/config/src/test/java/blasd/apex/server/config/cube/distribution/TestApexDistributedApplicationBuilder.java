/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.cube.distribution;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.junit.Assert;
import org.junit.Test;

import com.quartetfs.biz.pivot.definitions.impl.QueryClusterDefinition;

import blasd.apex.server.config.cube.distributed.ApexDistributedApplicationBuilder;

public class TestApexDistributedApplicationBuilder {
	@Test
	public void testSetDistributedFields_empty() {
		ApexDistributedApplicationBuilder builder = new ApexDistributedApplicationBuilder(
				new QueryClusterDefinition.DistributedApplicationDefinition("applicationId", "distributingFields"));

		builder.setDistributingFields();

		// https://support.activeviam.com/jira/browse/APS-9837
		// It appears in AP5.5 the distributingFields has to be null in this case
		Assert.assertNull(builder.getDescription().getDistributingFields());
	}

	@Test
	public void testSetDistributedFields_1Field() {
		ApexDistributedApplicationBuilder builder = new ApexDistributedApplicationBuilder(
				new QueryClusterDefinition.DistributedApplicationDefinition("applicationId", "distributingFields"));

		builder.setDistributingFields("field1");

		Assert.assertEquals("field1", builder.getDescription().getDistributingFields());
	}

	@Test
	public void testSetDistributedFields_2Fields() {
		ApexDistributedApplicationBuilder builder = new ApexDistributedApplicationBuilder(
				new QueryClusterDefinition.DistributedApplicationDefinition("applicationId", "distributingFields"));

		builder.setDistributingFields("field1", "field2");

		Assert.assertEquals(Arrays.asList("field1", "field2").stream().collect(Collectors.joining(",")),
				builder.getDescription().getDistributingFields());
	}

	@Test
	public void testSetDistributedFields_nullArray() {
		ApexDistributedApplicationBuilder builder = new ApexDistributedApplicationBuilder(
				new QueryClusterDefinition.DistributedApplicationDefinition("applicationId", "distributingFields"));

		builder.setDistributingFields((String[]) null);

		// https://support.activeviam.com/jira/browse/APS-9837
		// It appears in AP5.5 the distributingFields has to be null in this case
		Assert.assertNull(builder.getDescription().getDistributingFields());
	}

	@Test
	public void testSetDistributedFields_nullList() {
		ApexDistributedApplicationBuilder builder = new ApexDistributedApplicationBuilder(
				new QueryClusterDefinition.DistributedApplicationDefinition("applicationId", "distributingFields"));

		builder.setDistributingFields((List<String>) null);

		// https://support.activeviam.com/jira/browse/APS-9837
		// It appears in AP5.5 the distributingFields has to be null in this case
		Assert.assertNull(builder.getDescription().getDistributingFields());
	}
}

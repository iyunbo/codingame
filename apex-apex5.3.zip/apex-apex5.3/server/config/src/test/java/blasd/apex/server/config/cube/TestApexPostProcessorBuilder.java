/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.cube;

import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;

import com.quartetfs.biz.pivot.definitions.IPostProcessorDescription;

public class TestApexPostProcessorBuilder {

	// This test the behavior, and that Java does not complain about advanced
	// generic usages
	@Test
	public void testAddPostProcessorFromKey() {
		IApexCubeBuilder cubeBuilder = ApexCubeBuilder.newDescription();

		IPostProcessorDescription measure =
				cubeBuilder.addPostProcessedMeasure("MeasureName", "PluginKey").configurePostProcessor(c -> {
					// From Eclipse 3.8, we have a compilation issue if using fluent calls
					c.setUnderlyingMeasures("UnderlyingMeasureName");
					c.setProperty("key", "value");
					c.setProperty("otherKey", "otherValue");
				}).getDescription();

		Assert.assertEquals("value", measure.getProperties().get("key"));
	}

	// TODO: mock a custom ISPecificPPBuilder
	// TODO: Issue with javac
	@Ignore
	@Test
	public void testAddPostProcessorFromBuilder() {
		// IApexCubeBuilder cubeBuilder = ApexCubeBuilder.newActivePivotDescripion();
		//
		// PostProcessorDescription desc = new PostProcessorDescription();
		//
		// String measureName = "MeasureName";
		// ApexBaseSpecificPostProcessorBuilder<?> builder = new
		// ApexBaseSpecificPostProcessorBuilder<>();
		// builder.acceptDescription(desc);

		// Can not call directly because of javac issue
		// IApexPostProcessorBuilder<? extends IRawApexPostProcessorBuilder<?>>
		// ppBuilder =
		// cubeBuilder.addPostProcessedMeasure(measureName, builder);

		// ppBuilder.configurePostProcessor()
		// .setUnderlyingMeasures("UnderlyingMeasureName")
		// .setProperty("key", "value")
		// .setProperty("otherKey", "otherValue");

		// IPostProcessorDescription measure =
		// cubeBuilder.getPostProcessedMeasure(measureName).getDescription();
		//
		// Assert.assertEquals("value", measure.getProperties().get("key"));
	}

}

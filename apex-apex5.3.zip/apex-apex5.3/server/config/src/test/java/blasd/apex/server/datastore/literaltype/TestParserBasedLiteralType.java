/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.datastore.literaltype;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.qfs.literal.ILiteralType;
import com.qfs.literal.impl.LiteralType;
import com.qfs.store.Types;
import com.quartetfs.fwk.Registry;
import com.quartetfs.fwk.contributions.impl.AnnotationContributionProvider;
import com.quartetfs.fwk.format.IParser;
import com.quartetfs.fwk.format.impl.FloatVectorParser;
import com.quartetfs.fwk.format.impl.IntegerParser;
import com.quartetfs.fwk.format.impl.ShortParser;

/**
 * 
 * @author Benoit Lacelle
 * 
 */
public class TestParserBasedLiteralType {

	protected static final Logger LOGGER = LoggerFactory.getLogger(TestParserBasedLiteralType.class);

	@BeforeClass
	public static void initRegistry() {
		Registry.setContributionProvider(new AnnotationContributionProvider(SimpleTestStringParser.class,
				FloatVectorTestParser.class,
				ParserBasedLiteralType.class));
	}

	@Test
	public void testRegistry() {
		SimpleTestStringParser parser = new SimpleTestStringParser();

		String literalTypeKey = ParserBasedLiteralType.buildKey(parser);

		ILiteralType literalType = Registry.getPlugin(ILiteralType.class).valueOf(literalTypeKey);

		Assert.assertTrue(literalType instanceof ParserBasedLiteralType);
		Assert.assertEquals(literalTypeKey, literalType.key());
		Assert.assertEquals(parser.key().toString(), literalType.getParser());

		Assert.assertFalse(literalType.isPrimitive());
	}

	@Test
	public void testLiteralBaseDataTypeOnDoubleParser() {
		String literalTypeKey = ParserBasedLiteralType.buildKey(IParser.DOUBLE);

		ILiteralType literalType = Registry.getPlugin(ILiteralType.class).valueOf(literalTypeKey);

		Assert.assertEquals(ILiteralType.DOUBLE, literalType.getLiteral());
		Assert.assertEquals(literalTypeKey, literalType.key());
		Assert.assertEquals(IParser.DOUBLE, literalType.getParser());
		Assert.assertEquals(Types.CONTENT_DOUBLE, literalType.getContentType());
		Assert.assertTrue(literalType.isPrimitive());
	}

	@Test
	public void testLiteralTypeToCoreDoubleParser() {
		ILiteralType literalType = ParserBasedLiteralType.convertParserKeyToFieldType(IParser.DOUBLE);

		Assert.assertEquals(Registry.getPlugin(ILiteralType.class).valueOf(ILiteralType.DOUBLE), literalType);
	}

	@Test
	public void testLiteralBaseDataTypeOnDoubleArrayParser() {
		String literalTypeKey = ParserBasedLiteralType.buildKey(new FloatVectorParser());

		ILiteralType literalType = Registry.getPlugin(ILiteralType.class).valueOf(literalTypeKey);

		// Core parser -> Core literaltype
		Assert.assertTrue(literalType instanceof LiteralType);
		Assert.assertEquals(ILiteralType.FLOAT_ARRAY, literalType.key());
		Assert.assertEquals(IParser.FLOAT_VECTOR, literalType.getParser());
		Assert.assertEquals(Types.CONTENT_FLOAT, literalType.getContentType());
		Assert.assertTrue(literalType.isArray());

		// double[] is NOT primitive according to LiteralTypePlugin
		Assert.assertFalse(literalType.isPrimitive());
	}

	@Test
	public void testParseNotNumber() {
		// LiteralType over a date: it will fail detecting the type as it can not parse "0"
		String dateParser = SimpleTestStringParser.PLUGIN_KEY;
		String literalTypeKey = ParserBasedLiteralType.buildKey(dateParser);

		ILiteralType literalType = Registry.getPlugin(ILiteralType.class).valueOf(literalTypeKey);

		Assert.assertTrue(literalType instanceof ParserBasedLiteralType);
		Assert.assertEquals(literalTypeKey, literalType.key());
		Assert.assertEquals(dateParser, literalType.getParser());
		Assert.assertEquals(Types.CONTENT_OBJECT, literalType.getContentType());

		// A date: not an array
		Assert.assertFalse(literalType.isArray());
		Assert.assertFalse(literalType.isPrimitive());
	}

	@Test
	public void testParseVector() {
		// LiteralType over a date: it will fail detecting the type as it can not parse "0"
		String vectorParser = FloatVectorTestParser.PLUGIN_KEY;
		String literalTypeKey = ParserBasedLiteralType.buildKey(vectorParser);

		ILiteralType literalType = Registry.getPlugin(ILiteralType.class).valueOf(literalTypeKey);

		Assert.assertTrue(literalType instanceof ParserBasedLiteralType);
		Assert.assertEquals(literalTypeKey, literalType.key());
		Assert.assertEquals(vectorParser, literalType.getParser());
		Assert.assertEquals(Types.CONTENT_FLOAT, literalType.getContentType());

		// A float array: not an array
		Assert.assertTrue(literalType.isArray());
		Assert.assertFalse(literalType.isPrimitive());
	}

	@Test
	public void testAllParser() {
		nextParser: for (IParser<?> parser : Registry.getPlugin(IParser.class).values()) {
			String literalTypeKey = ParserBasedLiteralType.buildKey(parser);

			ILiteralType literalType = Registry.getPlugin(ILiteralType.class).valueOf(literalTypeKey);

			if (literalType == null) {
				throw new IllegalStateException("Can not found literalType for " + literalTypeKey);
			}

			// We may have ParserBasedLiteralType or plain LiteralType
			if (literalType instanceof ParserBasedLiteralType) {
				if (parser.getClass() == IntegerParser.class) {
					// IParser.INTEGER -> IParser.INT
					Assert.assertEquals(IParser.INT, literalType.getParser());
				} else if (parser.getClass() == ShortParser.class) {
					// IParser.INTEGER -> IParser.INT
					Assert.assertEquals(IParser.SHORT, literalType.getParser());
				} else {
					Assert.assertEquals(literalTypeKey, literalType.key());
				}
			} else {
				Assert.assertEquals(literalType.key().toString(), literalType.getParser());

				Object parsed;
				try {
					parsed = parser.parse("0");
				} catch (RuntimeException e) {
					LOGGER.trace("Ouch", e);
					continue nextParser;
				}
				ILiteralType guessed =
						ParserBasedLiteralType.guessLiteralTypeFromParserResult(parsed, parser.key().toString());
				Assert.assertEquals(literalType.key(), guessed.getLiteral());
			}
		}
	}
}

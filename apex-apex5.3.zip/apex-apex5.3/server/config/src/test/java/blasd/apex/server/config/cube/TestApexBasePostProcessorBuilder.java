/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.cube;

import java.util.Properties;

import org.junit.Assert;
import org.junit.Test;

import com.quartetfs.biz.pivot.definitions.IPostProcessorDescription;
import com.quartetfs.biz.pivot.definitions.impl.PostProcessorDescription;
import com.quartetfs.biz.pivot.postprocessing.impl.AAdvancedPostProcessor;

public class TestApexBasePostProcessorBuilder {
	@Test
	public void testSetNameWithoutAccepting() {
		ApexBasePostProcessorBuilder<?> builder = new ApexBasePostProcessorBuilder<>("pluginKey");
		String measureName = "someName";
		builder.setMeasureName(measureName);

		Assert.assertEquals(measureName, builder.getDescription().getName());
		Assert.assertEquals(measureName, builder.getName());
		Assert.assertEquals(measureName, builder.getId());
	}

	@Test
	public void testSetProperty() {
		ApexBasePostProcessorBuilder<?> builder = new ApexBasePostProcessorBuilder<>("pluginKey");
		builder.setProperty("key", "value");

		Assert.assertEquals("value", builder.getDescription().getProperties().getProperty("key"));
	}

	@Test
	public void testSetters() {
		ApexBasePostProcessorBuilder<?> builder = new ApexBasePostProcessorBuilder<>("pluginKey");

		builder.setVisible(true);
		Assert.assertTrue(builder.getDescription().isVisible());

		builder.setGroup("group");
		Assert.assertEquals("group", builder.getDescription().getGroup());

		builder.setFolder("folder");
		Assert.assertEquals("folder", builder.getDescription().getFolder());

		builder.setOutputType("outputLiteralType");
		Assert.assertEquals("outputLiteralType",
				builder.getDescription().getProperties().getProperty(AAdvancedPostProcessor.OUTPUT_TYPE));
	}

	@Test
	public void testAddPP() {
		IApexCubeBuilder builder = ApexCubeBuilder.newDescription();

		IApexPostProcessorBuilder<?> ppBuilder = builder.addPostProcessedMeasure("name", "pluginKey", new Properties());

		Assert.assertEquals("pluginKey", ppBuilder.getDescription().getPluginKey());
		Assert.assertEquals("pluginKey", ppBuilder.getPluginKey());

		ppBuilder.setPluginKey("otherKey");
		Assert.assertEquals("otherKey", ppBuilder.getPluginKey());
	}

	@Test
	public void testAddPPFromBuilder() {
		IApexCubeBuilder builder = ApexCubeBuilder.newDescription();

		// TODO: should we throw on such inconsistencies?
		PostProcessorDescription description = new PostProcessorDescription("name2", "pluginKey", new Properties());

		IApexPostProcessorBuilder<ApexPreparedPostProcessorBuilder> measure =
				builder.addPostProcessedMeasure("name", new ApexPreparedPostProcessorBuilder(description));

		Assert.assertEquals("name", measure.getMeasureName());

		IApexPostProcessorBuilder<ApexPreparedPostProcessorBuilder> configurer =
				measure.configurePostProcessor(c -> c.setMeasureName("name3"));
		Assert.assertEquals("name3", measure.getMeasureName());
		Assert.assertEquals("pluginKey", configurer.getDescription().getPluginKey());
	}

	@Test
	public void testAddPPFromBase() {
		IApexCubeBuilder builder = ApexCubeBuilder.newDescription();

		@SuppressWarnings("unchecked")
		IApexPostProcessorBuilder<?> measure =
				builder.addPostProcessedMeasure("name", new ApexBasePostProcessorBuilder("pluginKey"));

		Assert.assertEquals("name", measure.getMeasureName());

		Assert.assertEquals("pluginKey", measure.getDescription().getPluginKey());
	}

	@Test
	public void testOverPostProcessorDescription() {
		ApexPreparedPostProcessorBuilder ppBuilder =
				new ApexPreparedPostProcessorBuilder(new PostProcessorDescription());

		ppBuilder.setProperty("A", "B");

		Assert.assertEquals("B", ppBuilder.getDescription().getProperties().getProperty("A"));
	}
}

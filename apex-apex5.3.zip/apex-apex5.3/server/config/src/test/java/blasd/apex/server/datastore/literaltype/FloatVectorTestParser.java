/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.datastore.literaltype;

import com.qfs.vector.IVector;
import com.qfs.vector.array.impl.ArrayFloatVector;
import com.quartetfs.fwk.QuartetPluginValue;
import com.quartetfs.fwk.format.IParser;
import com.quartetfs.fwk.format.impl.FloatVectorParser;
import com.quartetfs.fwk.types.impl.PluginValue;

/**
 * Used for Test purposes. Some parsers may return an IVector, typically to do reference sharing on array full of zeroes
 * 
 * @author Benoit Lacelle
 * 
 */
@QuartetPluginValue(intf = IParser.class)
public class FloatVectorTestParser extends PluginValue implements IParser<IVector> {
	private static final long serialVersionUID = 2034713959193844562L;

	public static final String PLUGIN_KEY = "TEST_" + "vector_float[]";

	private static final FloatVectorParser UNDERLYING_PARSER = new FloatVectorParser();

	@Override
	public Object key() {
		return PLUGIN_KEY;
	}

	@Override
	public String description() {
		return "may return an IVector";
	}

	@Override
	public IVector parse(CharSequence sequence) throws NumberFormatException {
		return new ArrayFloatVector(UNDERLYING_PARSER.parse(sequence));
	}

}

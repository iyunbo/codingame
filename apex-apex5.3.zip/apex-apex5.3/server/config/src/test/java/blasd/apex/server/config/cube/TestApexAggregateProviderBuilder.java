/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.cube;

import java.util.Collections;
import java.util.List;
import java.util.Set;

import org.junit.Assert;
import org.junit.Test;

import com.google.common.collect.ImmutableSet;
import com.google.common.collect.ImmutableTable;
import com.qfs.pivot.cube.provider.bitmap.impl.BitmapAggregateProviderBase;
import com.qfs.pivot.cube.provider.jit.impl.JustInTimeAggregateProviderBase;
import com.qfs.pivot.cube.provider.multi.impl.GlobalMultipleAggregateProviderBase;
import com.quartetfs.biz.pivot.definitions.IPartialProviderDefinition;

public class TestApexAggregateProviderBuilder {
	@Test
	public void testIncludePartial() {
		ApexAggregateProviderBuilder builder = new ApexAggregateProviderBuilder(ApexCubeBuilder.newDescription());

		Set<String> selectedMeasures = Collections.singleton("someMeasure");
		builder.addPartialIncluding(ImmutableTable.of("d", "h", "l"), selectedMeasures);

		// As we added a partial, the main provider is a multi
		Assert.assertEquals(GlobalMultipleAggregateProviderBase.PLUGIN_TYPE, builder.getDescription().getPluginKey());

		// Check the main undelrying provider is a JIT
		Assert.assertEquals(JustInTimeAggregateProviderBase.PLUGIN_TYPE, builder.getUnderlyingProviderKey());

		// We have 1 partial
		List<IPartialProviderDefinition> partials = builder.getDescription().getPartialProviders();
		Assert.assertEquals(1, partials.size());
		Assert.assertEquals(BitmapAggregateProviderBase.PLUGIN_TYPE, partials.get(0).getPluginKey());
		Assert.assertEquals(true, partials.get(0).getIncludeMeasures());
		Assert.assertEquals(selectedMeasures, ImmutableSet.copyOf(partials.get(0).getMeasures()));
	}

	@Test
	public void testExcludePartial() {
		IApexCubeBuilder cube = ApexCubeBuilder.newDescription();

		// 'h' has 2 levels
		cube.getOrAddDimension("d").addHierarchyAndLevels("l1", "l2").setName("h");

		ApexAggregateProviderBuilder builder = new ApexAggregateProviderBuilder(cube);

		Set<String> selectedMeasures = Collections.singleton("someMeasure");
		// We exclude l2
		builder.addPartialExcluding(ImmutableTable.of("d", "h", "l2"), selectedMeasures);

		// As we added a partial, the main provider is a multi
		Assert.assertEquals(GlobalMultipleAggregateProviderBase.PLUGIN_TYPE, builder.getDescription().getPluginKey());

		// Check the main undelrying provider is a JIT
		Assert.assertEquals(JustInTimeAggregateProviderBase.PLUGIN_TYPE, builder.getUnderlyingProviderKey());

		// We have 1 partial
		List<IPartialProviderDefinition> partials = builder.getDescription().getPartialProviders();
		Assert.assertEquals(1, partials.size());
		IPartialProviderDefinition firstPartial = partials.get(0);
		Assert.assertEquals(BitmapAggregateProviderBase.PLUGIN_TYPE, firstPartial.getPluginKey());
		Assert.assertTrue(firstPartial.getIncludeMeasures());
		Assert.assertEquals(selectedMeasures, ImmutableSet.copyOf(firstPartial.getMeasures()));
		Assert.assertTrue(firstPartial.getIncludeHierarchies());

		// The partial goes up to l1
		Assert.assertEquals("l1", firstPartial.getScope().get("d").get("h"));
	}
}

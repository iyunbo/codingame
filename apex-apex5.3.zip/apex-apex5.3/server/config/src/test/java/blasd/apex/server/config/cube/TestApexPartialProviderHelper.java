/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.cube;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;

import com.google.common.collect.ImmutableMap;
import com.qfs.pivot.cube.provider.bitmap.impl.BitmapAggregateProviderBase;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevelInfo.ClassificationType;
import com.quartetfs.biz.pivot.definitions.IActivePivotDescription;
import com.quartetfs.biz.pivot.definitions.IAxisDimensionDescription;
import com.quartetfs.biz.pivot.definitions.IAxisHierarchyDescription;
import com.quartetfs.biz.pivot.definitions.IPartialProviderDefinition;
import com.quartetfs.biz.pivot.definitions.impl.AxisDimensionDescription;
import com.quartetfs.biz.pivot.definitions.impl.AxisHierarchyDescription;
import com.quartetfs.biz.pivot.definitions.impl.AxisLevelDescription;

// TODO  Use ApexCubeBuilder
public class TestApexPartialProviderHelper {

	@Test
	public void testMakeComplementPartial() {
		List<IAxisDimensionDescription> dimensions = new ArrayList<>();

		Map<String, Map<String, String>> dimensionToHierarchyToMaxLevelName = new HashMap<>();
		Map<String, Map<String, String>> expectedScope = new HashMap<>();

		dimensions.add(new AxisDimensionDescription("d", new ArrayList<IAxisHierarchyDescription>()));
		dimensionToHierarchyToMaxLevelName.put("d", new HashMap<String, String>());
		expectedScope.put("d", new HashMap<String, String>());

		dimensions.get(0).getHierarchies().add(new AxisHierarchyDescription("h1", null, true));
		dimensions.get(0)
				.getHierarchies()
				.get(dimensions.get(0).getHierarchies().size() - 1)
				.addLevel(new AxisLevelDescription("l1"));
		dimensions.get(0)
				.getHierarchies()
				.get(dimensions.get(0).getHierarchies().size() - 1)
				.addLevel(new AxisLevelDescription("l2"));
		// No restriction
		expectedScope.get("d").put("h1", null);

		dimensions.get(0).getHierarchies().add(new AxisHierarchyDescription("h2", null, false));
		dimensions.get(0)
				.getHierarchies()
				.get(dimensions.get(0).getHierarchies().size() - 1)
				.addLevel(new AxisLevelDescription("l1"));
		dimensions.get(0)
				.getHierarchies()
				.get(dimensions.get(0).getHierarchies().size() - 1)
				.addLevel(new AxisLevelDescription("l2"));
		// No restriction
		expectedScope.get("d").put("h2", null);

		dimensions.get(0).getHierarchies().add(new AxisHierarchyDescription("h3", null, true));
		dimensions.get(0)
				.getHierarchies()
				.get(dimensions.get(0).getHierarchies().size() - 1)
				.addLevel(new AxisLevelDescription("l1"));
		dimensions.get(0)
				.getHierarchies()
				.get(dimensions.get(0).getHierarchies().size() - 1)
				.addLevel(new AxisLevelDescription("l2"));
		dimensionToHierarchyToMaxLevelName.get("d").put("h3", "l1");
		// Include ALL to handle locations with * on ALL level: the partial
		// won't grow but it will handle more locations
		expectedScope.get("d").put("h3", ClassificationType.ALL.toString());

		dimensions.get(0).getHierarchies().add(new AxisHierarchyDescription("h4", null, false));
		dimensions.get(0)
				.getHierarchies()
				.get(dimensions.get(0).getHierarchies().size() - 1)
				.addLevel(new AxisLevelDescription("l1"));
		dimensions.get(0)
				.getHierarchies()
				.get(dimensions.get(0).getHierarchies().size() - 1)
				.addLevel(new AxisLevelDescription("l2"));
		dimensionToHierarchyToMaxLevelName.get("d").put("h4", "l2");
		expectedScope.get("d").put("h4", "l1");

		IPartialProviderDefinition partial = ApexPartialProviderHelper.makeComplementPartialProviderDefinition(
				BitmapAggregateProviderBase.PLUGIN_TYPE,
				dimensions,
				dimensionToHierarchyToMaxLevelName,
				null);

		Assert.assertEquals(expectedScope, partial.getScope());
	}

	@Test
	public void testAddHierarchiesWithoutRestrictionIfSeveralHierarchiesInSameDim() {
		List<IAxisDimensionDescription> dimensions = new ArrayList<>();

		Map<String, Map<String, String>> dimensionToHierarchyToMaxLevelName = new HashMap<>();
		Map<String, Map<String, String>> expectedScope = new HashMap<>();

		dimensions.add(new AxisDimensionDescription("d", new ArrayList<IAxisHierarchyDescription>()));
		dimensionToHierarchyToMaxLevelName.put("d", new HashMap<String, String>());
		expectedScope.put("d", new HashMap<String, String>());

		dimensions.get(0).getHierarchies().add(new AxisHierarchyDescription("h1", null, true));
		dimensions.get(0)
				.getHierarchies()
				.get(dimensions.get(0).getHierarchies().size() - 1)
				.addLevel(new AxisLevelDescription("l1"));
		dimensions.get(0)
				.getHierarchies()
				.get(dimensions.get(0).getHierarchies().size() - 1)
				.addLevel(new AxisLevelDescription("l2"));
		// Exclude l2@h1: so l1@h1 is is not scope
		dimensionToHierarchyToMaxLevelName.get("d").put("h1", "l2");
		expectedScope.get("d").put("h1", "l1");

		dimensions.get(0).getHierarchies().add(new AxisHierarchyDescription("h2", null, false));
		dimensions.get(0)
				.getHierarchies()
				.get(dimensions.get(0).getHierarchies().size() - 1)
				.addLevel(new AxisLevelDescription("l1"));
		dimensions.get(0)
				.getHierarchies()
				.get(dimensions.get(0).getHierarchies().size() - 1)
				.addLevel(new AxisLevelDescription("l2"));
		// h2 has no restriction: add it in the scope
		expectedScope.get("d").put("h2", null);

		IPartialProviderDefinition partial = ApexPartialProviderHelper.makeComplementPartialProviderDefinition(
				BitmapAggregateProviderBase.PLUGIN_TYPE,
				dimensions,
				dimensionToHierarchyToMaxLevelName,
				null);

		Assert.assertEquals(expectedScope, partial.getScope());
	}

	@Test
	public void testAddPartialWithHierarchyList() {
		List<IAxisDimensionDescription> dimensions = new ArrayList<>();

		Map<String, Map<String, String>> dimensionToHierarchyToMaxLevelName = new HashMap<>();
		Map<String, Map<String, String>> expectedScope = new HashMap<>();

		dimensions.add(new AxisDimensionDescription("d", new ArrayList<IAxisHierarchyDescription>()));
		dimensionToHierarchyToMaxLevelName.put("d", new HashMap<String, String>());
		expectedScope.put("d", new HashMap<String, String>());

		dimensions.get(0).getHierarchies().add(new AxisHierarchyDescription("h1", null, true));
		dimensions.get(0)
				.getHierarchies()
				.get(dimensions.get(0).getHierarchies().size() - 1)
				.addLevel(new AxisLevelDescription("l1"));
		dimensions.get(0)
				.getHierarchies()
				.get(dimensions.get(0).getHierarchies().size() - 1)
				.addLevel(new AxisLevelDescription("l2"));
		// Exclude l2@h1: so l1@h1 is is not scope
		dimensionToHierarchyToMaxLevelName.get("d").put("h1", "l2");
		expectedScope.get("d").put("h1", null);

		dimensions.get(0).getHierarchies().add(new AxisHierarchyDescription("h2", null, false));
		dimensions.get(0)
				.getHierarchies()
				.get(dimensions.get(0).getHierarchies().size() - 1)
				.addLevel(new AxisLevelDescription("l1"));
		dimensions.get(0)
				.getHierarchies()
				.get(dimensions.get(0).getHierarchies().size() - 1)
				.addLevel(new AxisLevelDescription("l2"));
		// h2 has no restriction: add it in the scope
		// expectedScope.get("d").put("h2", null);

		IPartialProviderDefinition partial =
				ApexPartialProviderHelper.makePartialProviderDefinition(BitmapAggregateProviderBase.PLUGIN_TYPE,
						dimensions,
						Arrays.asList("h1"),
						null);

		Assert.assertEquals(expectedScope, partial.getScope());
	}

	@Test
	public void testExcludeAll() {
		List<IAxisDimensionDescription> dimensions = new ArrayList<>();

		Map<String, Map<String, String>> dimensionToHierarchyToMaxLevelName = new HashMap<>();
		Map<String, Map<String, String>> expectedScope = new HashMap<>();

		dimensions.add(new AxisDimensionDescription("d", new ArrayList<IAxisHierarchyDescription>()));
		dimensionToHierarchyToMaxLevelName.put("d", new HashMap<String, String>());
		expectedScope.put("d", new HashMap<String, String>());

		dimensions.get(0).getHierarchies().add(new AxisHierarchyDescription("h1", null, true));
		dimensions.get(0)
				.getHierarchies()
				.get(dimensions.get(0).getHierarchies().size() - 1)
				.addLevel(new AxisLevelDescription("l1"));
		dimensionToHierarchyToMaxLevelName.get("d").put("h1", ClassificationType.ALL.name());
		expectedScope.get("d").put("h1", ClassificationType.ALL.name());

		IPartialProviderDefinition partial = ApexPartialProviderHelper.makeComplementPartialProviderDefinition(
				BitmapAggregateProviderBase.PLUGIN_TYPE,
				dimensions,
				dimensionToHierarchyToMaxLevelName,
				null);

		Assert.assertEquals(expectedScope, partial.getScope());
	}

	@Test
	public void testAddLevelInPartial() {
		IApexDimensionBuilder builder = ApexCubeBuilder.newDescription()
				.getOrAddDimension("d")
				.addHierarchyAndLevels("l1", "l2")
				.setName("h1")
				.getDimensionBuilder();
		builder.addHierarchyAndLevels("l1", "l2").setName("h2");

		IActivePivotDescription desc = builder.getCubeBuilder().getActivePivotDescription();

		Map<String, Map<String, String>> dimensionToHierarchyToMaxLevelName = new HashMap<>();

		// Add first level of first hierarchy
		{
			ApexPartialProviderHelper.addLevelInPartial("h1",
					1,
					desc.getAxisDimensions().getValues(),
					dimensionToHierarchyToMaxLevelName);
			Assert.assertEquals(ImmutableMap.of("d", ImmutableMap.of("h1", "l1")), dimensionToHierarchyToMaxLevelName);
		}

		// Add second level of second hierarchy
		{
			ApexPartialProviderHelper.addLevelInPartial("h2",
					2,
					desc.getAxisDimensions().getValues(),
					dimensionToHierarchyToMaxLevelName);
			Assert.assertEquals(ImmutableMap.of("d", ImmutableMap.of("h1", "l1", "h2", "l2")),
					dimensionToHierarchyToMaxLevelName);
		}
	}
}

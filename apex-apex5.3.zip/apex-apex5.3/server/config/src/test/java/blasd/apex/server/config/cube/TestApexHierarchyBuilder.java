/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.cube;

import org.junit.Assert;
import org.junit.Test;

public class TestApexHierarchyBuilder {
	@Test
	public void testDecorator() {
		IApexCubeBuilder cubeBuilder = ApexCubeBuilder.newDescription();

		IApexHierarchyBuilder hierarchy = cubeBuilder.getOrAddAxisHierarchy("hierarchyName");

		ApexHierarchyBuilderDecorator decorator = new ApexHierarchyBuilderDecorator(hierarchy);

		decorator.setPropertyList("key", "value1", "value2");

		Assert.assertEquals("value1,value2", hierarchy.getDescription().getProperties().get("key"));

		Assert.assertEquals("hierarchyName@hierarchyName", decorator.getId());
		Assert.assertSame(hierarchy, decorator.getDecorated());

		decorator.appendLevel("firstLevel");
		Assert.assertEquals("firstLevel@hierarchyName@hierarchyName", decorator.getDeepestLevel().getId());
		Assert.assertEquals("firstLevel@hierarchyName@hierarchyName", decorator.getLevel(0).getId());

		decorator.setName("hierarchyName");
	}

	@Test
	public void testNormalHierarchy() {
		IApexCubeBuilder cubeBuilder = ApexCubeBuilder.newDescription();

		test(cubeBuilder.getOrAddAxisHierarchy("hierarchyName"));
	}

	@Test
	public void testSetFactless() {
		IApexCubeBuilder cubeBuilder = ApexCubeBuilder.newDescription();

		IApexHierarchyBuilder h = cubeBuilder.getOrAddAxisHierarchy("hierarchyName");
		// By default: null
		Assert.assertEquals(null, h.getDescription().isFactless());

		// Can set false
		h.setFactless(false);
		Assert.assertEquals(false, h.getDescription().isFactless());

		// Can set null
		h.setFactless(null);
		Assert.assertEquals(null, h.getDescription().isFactless());
	}

	@Test
	public void testDecoratedHierarchy() {
		IApexCubeBuilder cubeBuilder = ApexCubeBuilder.newDescription();

		IApexHierarchyBuilder hierarchy = cubeBuilder.getOrAddAxisHierarchy("hierarchyName");

		test(new ApexHierarchyBuilderDecorator(hierarchy));
	}

	// Mainly for coverage...
	protected void test(IApexHierarchyBuilder orAddDimension) {
		String hName = orAddDimension.getOrAddDimension("dimensionName")
				.getOrAddAxisHierarchy("hierarchyName")
				.getOrFailDimension("dimensionName")
				.getOrFailAxisHierarchy("hierarchyName")
				.getName();
		Assert.assertEquals("hierarchyName", hName);

		orAddDimension.setFactless(true)
				.setName("elementNewName")
				.setPluginKey("pluginKey")
				.setProperty("key", "value")
				.setSlicing()
				.withAllMember();
	}
}

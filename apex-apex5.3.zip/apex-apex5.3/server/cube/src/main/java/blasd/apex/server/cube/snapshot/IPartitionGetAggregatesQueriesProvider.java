/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.cube.snapshot;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Stream;

import org.joda.time.LocalDateTime;

import com.quartetfs.biz.pivot.cube.hierarchy.IHierarchy;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevelInfo;
import com.quartetfs.biz.pivot.query.IGetAggregatesQuery;

import blasd.apex.server.datastore.listener.IApexAccumulatedSelectionListener;

/**
 * Thi interface wraps an item which can be used to listen for transactions on a store and produce associated
 * {@link IGetAggregatesQuery}
 * 
 * @author Benoit Lacelle
 *
 * @param <T>
 *            the query parameters (e.g. a Map<String, Value>)
 * @param <S>
 */
public interface IPartitionGetAggregatesQueriesProvider<T, U, S extends IApexCubeQuerier<T>>
		extends IGetAggregatesQueriesProvider<S>, IApexAccumulatedSelectionListener<U> {

	/**
	 * If there is a hierarchy Year/Month and the partition is Month, then rawPartitionLevels will NOT hold Year
	 */
	Set<? extends ILevelInfo> getRawPartitionLevels();

	/**
	 * If there is a hierarchy Year/Month and the partition is Month, then cleanpartitionLevels will also hold Year
	 * 
	 * @param hierarchies
	 */
	Set<? extends ILevelInfo> getCleanPartitionLevels(List<? extends IHierarchy> hierarchies);

	Map<?, LocalDateTime> getPartitionToPendingDate();

	Stream<? extends IGetAggregatesQuery> flushPendingPartitions(S apexCubeQuerier);

}

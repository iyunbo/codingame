/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.location;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.ImmutableSet;
import com.qfs.dic.IDictionary;
import com.qfs.store.IDatastoreSchemaMetadata;
import com.quartetfs.biz.pivot.IActivePivotManager;
import com.quartetfs.biz.pivot.IActivePivotVersion;
import com.quartetfs.biz.pivot.ILocation;
import com.quartetfs.biz.pivot.IPointLocationPattern;
import com.quartetfs.biz.pivot.IPointLocationReader;
import com.quartetfs.biz.pivot.context.subcube.ISubCubeProperties;
import com.quartetfs.biz.pivot.cube.dimension.IDimension;
import com.quartetfs.biz.pivot.cube.hierarchy.IHierarchy;
import com.quartetfs.biz.pivot.cube.hierarchy.IHierarchyInfo;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevel;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevelInfo;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevelInfo.ClassificationType;
import com.quartetfs.biz.pivot.cube.hierarchy.IMultiVersionHierarchy;
import com.quartetfs.biz.pivot.cube.hierarchy.impl.HierarchiesUtil;
import com.quartetfs.biz.pivot.cube.provider.IHierarchicalMapping;
import com.quartetfs.biz.pivot.impl.LocationUtil;
import com.quartetfs.biz.pivot.impl.ModifiedLocation;
import com.quartetfs.biz.pivot.query.aggregates.IScopeLocation;
import com.quartetfs.biz.pivot.query.impl.ActivePivotVersionQueryHelper;

import blasd.apex.server.datastore.ApexDatastoreHelper;
import blasd.apex.server.query.ApexDrillthroughHelper;
import blasd.apex.server.query.hierarchy.ApexHierarchyHelper;
import blasd.apex.server.query.hierarchy.IApexAxisHierarchyInfo;
import gnu.trove.list.TIntList;
import gnu.trove.list.array.TIntArrayList;
import gnu.trove.map.TObjectIntMap;
import gnu.trove.map.hash.TObjectIntHashMap;
import gnu.trove.set.TIntSet;
import gnu.trove.set.hash.TIntHashSet;

/**
 * Many utility methods around ILocation
 * 
 * @see LocationUtil
 * @author Benoit Lacelle
 * 
 */
public class ApexLocationHelper {
	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexLocationHelper.class);

	protected ApexLocationHelper() {
		// hidden
	}

	public static final int MAX_LOCATION_COUNT = 1000;

	public static int getLevelDepth(ILocation location, IHierarchy hierarchy) {
		// The index is the ordinal minus 1 as we need to skip the measure
		// hierarchy
		return location.getLevelDepth(hierarchy.getOrdinal() - 1);
	}

	/**
	 * @return the level depth along this {@link IHierarchyInfo}. It is equal to the {@link ILevelInfo} ordinal +1
	 *         (AllMember is ordinal 0 and length 1)
	 */
	public static int getLevelDepth(ILocation location, IHierarchyInfo hierarchy) {
		// The index is the ordinal minus 1 as we need to skip the measure
		// hierarchy
		return location.getLevelDepth(hierarchy.getOrdinal() - 1);
	}

	/**
	 * 
	 * @param location
	 * @param level
	 * @return true if the {@link ILocation} has a coordinate expressed for
	 */
	public static boolean checkCoordinate(ILocation location, ILevel level) {
		return checkCoordinate(location, level.getLevelInfo());
	}

	public static boolean checkCoordinate(ILocation location, ILevelInfo level) {
		return getLevelDepth(location, level.getHierarchyInfo()) > level.getOrdinal();
	}

	public static boolean checkCoordinate(ILocation rangeLocation, IHierarchy hierarchy) {
		if (isSlicingHierarchy(hierarchy)) {
			// This is a slicing dimension: check we have a coordinate on the
			// first level
			return getLevelDepth(rangeLocation, hierarchy) > 0;
		} else {
			// This is an AllMember dimension: check we express at least the
			// second level
			return getLevelDepth(rangeLocation, hierarchy) >= 2;
		}
	}

	/**
	 * 
	 * @param location
	 * @param level
	 * @return 0 if this level is the deepest expressed, +n if n levels are expressed under this level, -n if the
	 *         deepest expressed coordinate is n level above this level
	 */
	public static int checkDeepEnough(ILocation location, ILevelInfo levelInfo) {
		// Adjust with -1 as the ordinal 0 leads to a depth of 1
		return getLevelDepth(location, levelInfo.getHierarchyInfo()) - levelInfo.getOrdinal() - 1;
	}

	/**
	 * 
	 * @param location
	 * @param necessarylevels
	 * @return the {@link List} of not expressed {@link ILevel}
	 */

	public static Set<ILevelInfo> checkCoordinates(ILocation location,
			Collection<? extends ILevelInfo> necessarylevels) {
		// Check if the level is expressed
		return necessarylevels.stream()
				.filter(necessarylevel -> !checkCoordinate(location, necessarylevel))
				.collect(Collectors.toSet());
	}

	/**
	 * 
	 * @param location
	 * @param level
	 * @return null if the {@link ILevel} is null, else the coordinate of given {@link ILevel} on given
	 *         {@link ILocation}
	 */
	public static Object getCoordinate(ILocation location, ILevel level) {
		if (level == null) {
			return null;
		} else {
			return getCoordinate(location, level.getLevelInfo());
		}
	}

	public static Object getCoordinate(ILocation location, ILevelInfo level) {
		if (level == null) {
			return null;
		} else {
			if (location instanceof IPointLocationReader) {
				return location.getCoordinate(level.getHierarchyInfo().getOrdinal() - 1, level.getOrdinal());
			} else {
				return location.getCoordinate(level.getHierarchyInfo().getOrdinal() - 1, level.getOrdinal());
			}
		}
	}

	@SuppressWarnings("unchecked")
	public static <T> T getCoordinate(ILocation location, ILevelInfo level, Class<? extends T> clazz) {
		Object coordinate = getCoordinate(location, level);

		if (coordinate == null) {
			return null;
		} else {
			if (clazz.isInstance(coordinate)) {
				return (T) coordinate;
			} else {
				throw new RuntimeException(
						"The coordinate " + coordinate + " is not a " + clazz + " but a " + coordinate.getClass());
			}
		}
	}

	/**
	 * 
	 * @param location
	 * @param level
	 * @return thge coordinate on this level, or null if the level is not expressed
	 */
	public static Object getSafeCoordinate(ILocation location, ILevelInfo level) {
		if (level == null) {
			return null;
		} else if (checkCoordinate(location, level)) {
			return location.getCoordinate(level.getHierarchyInfo().getOrdinal() - 1, level.getOrdinal());
		} else {
			return null;
		}
	}

	/**
	 * 
	 * @param location
	 *            the base {@link ILocation}
	 * @param level
	 *            the {@link ILevel} where to set the coordinate
	 * @param coordinate
	 *            the coordinate to set
	 * @param reduceIfDeeper
	 *            if true, if the input {@link ILocation} is deeper than the input ILevel, the output {@link ILocation}
	 *            won't express levels under the input {@link ILevel}
	 * @return
	 * 
	 * @warning beware this may return a range {@link ILocation} from a point {@link ILocation} (e.g. if the level has
	 *          depth 3 and the original location has depth 1 along this level)
	 */
	public static ILocation setCoordinates(ILocation location,
			ILevel level,
			Object coordinate,
			boolean reduceIfDeeper) {
		return setCoordinates(location, level.getLevelInfo(), coordinate, reduceIfDeeper);
	}

	public static ILocation setCoordinates(ILocation location,
			ILevelInfo level,
			Object coordinate,
			boolean reduceIfDeeper) {
		IHierarchyInfo hierarchyInfo = level.getHierarchyInfo();
		if (location instanceof IScopeLocation) {
			IScopeLocation scopeLocation = (IScopeLocation) location;

			// Check if the pattern can be kept
			if (!reduceIfDeeper || reduceIfDeeper && getLevelDepth(location, hierarchyInfo) == level.getOrdinal() + 1) {
				IPointLocationPattern pattern = scopeLocation.getPointLocationPattern();

				if (pattern == null) {
					// Happens if scope location is a point location
					LOGGER.trace("No optim for ScopeLocation as pointLocation");
				} else if (pattern.getRangeCoordsCount() != 1) {
					// Happens if scope location is a point location
					LOGGER.trace("We have several wildcards and the builder can produce points only");
				} else {
					int wildcardIndex = pattern.getRangeCoordIndex(hierarchyInfo.getOrdinal() - 1, level.getOrdinal());

					if (wildcardIndex >= 0) {
						// This coordinate is part of the scope wildcards
						int[] coordinates = new int[pattern.getRangeCoordsCount()];

						IHierarchicalMapping hm = scopeLocation.getHierarchicalMapping();
						coordinates[wildcardIndex] = getDictionary(hm, level).getPosition(coordinate);
						return pattern.generate(coordinates);
					} else {
						LOGGER.trace("The single wildcard is not the one requested");
					}
				}
			}
		}

		// Fallback
		Object[] newCoordinates = prepareNewCoordinates(location, level, coordinate, reduceIfDeeper);

		int currentDepth = getLevelDepth(location, hierarchyInfo);
		if (currentDepth == newCoordinates.length) {
			// reduceIfDeeper had no impact and the level is already expressed
			if (Objects.equals(getCoordinate(location, level), coordinate)) {
				// This is a no-op
				return location;
			} else {
				LOGGER.trace("This is not a no-op");
			}
		}

		// TODO: if location is already a ModifiedLocation, re-use it
		return new ModifiedLocation(location, hierarchyInfo.getOrdinal() - 1, newCoordinates);
	}

	public static Object[] prepareNewCoordinates(ILocation location,
			ILevelInfo level,
			Object coordinate,
			boolean reduceIfDeeper) {
		int hierarchyIndex = level.getHierarchyInfo().getOrdinal() - 1;
		int levelOrdinal = level.getOrdinal();
		int levelDepth = location.getLevelDepth(hierarchyIndex);

		Object[] newCoordinates;
		if (reduceIfDeeper) {
			// Go down the expressed level
			newCoordinates = new Object[levelOrdinal + 1];
		} else {
			// Go down the expressed level, or even deeper if the base location
			// was deeper
			newCoordinates = new Object[Math.max(levelDepth, levelOrdinal + 1)];
		}

		for (int i = 0; i < newCoordinates.length; i++) {
			if (i == levelOrdinal) {
				newCoordinates[i] = coordinate;
			} else if (i < levelDepth) {
				newCoordinates[i] = location.getCoordinate(hierarchyIndex, i);
			} else {
				// Leave null as this level is not expressed
				newCoordinates[i] = null;
			}
		}

		return newCoordinates;
	}

	/**
	 * 
	 * @param location
	 * @param levelToFilteredDrillUp
	 * @param reduceIfDeeper
	 * @return a new {@link ILocation} where the coordinate for given {@link ILevel} has been modified
	 */
	public static ILocation setCoordinates(ILocation location,
			Map<? extends ILevelInfo, ?> levelToFilteredDrillUp,
			boolean reduceIfDeeper) {
		ILocation newLocation = location;

		int nbLevels = levelToFilteredDrillUp.size();

		if (nbLevels == 0) {
			// Early quit
			return location;
		}

		// We use directly an Object[][] as TIntObject.values() would not
		// produce an actual 2d array
		Object[][] modifiedCoordinates = new Object[nbLevels][];

		TIntList hierarchyIndexes = new TIntArrayList(nbLevels);
		TIntSet hierarchyIndexesSet = new TIntHashSet(nbLevels);

		for (Entry<? extends ILevelInfo, ?> entry : levelToFilteredDrillUp.entrySet()) {
			int hierarchyIndex = entry.getKey().getHierarchyInfo().getOrdinal() - 1;
			if (hierarchyIndexesSet.add(hierarchyIndex)) {
				hierarchyIndexes.add(hierarchyIndex);
				modifiedCoordinates[hierarchyIndexes.size() - 1] =
						prepareNewCoordinates(newLocation, entry.getKey(), entry.getValue(), reduceIfDeeper);
			} else {
				int previousPosition = hierarchyIndexes.indexOf(hierarchyIndex);

				assert previousPosition >= 0;

				Object[] previousCoordinates = modifiedCoordinates[previousPosition];

				if (previousCoordinates.length <= entry.getKey().getOrdinal()) {
					// Grow the array
					previousCoordinates = Arrays.copyOf(previousCoordinates, entry.getKey().getOrdinal() + 1);

					// Save the new array in place of the previous array
					modifiedCoordinates[previousPosition] = previousCoordinates;
				}

				previousCoordinates[entry.getKey().getOrdinal()] = entry.getValue();
			}
		}

		if (modifiedCoordinates.length > hierarchyIndexes.size()) {
			// Several levels on same hierarchy: we initially allocated too many
			// Object[]
			modifiedCoordinates = Arrays.copyOf(modifiedCoordinates, hierarchyIndexes.size());
		}

		return new ModifiedLocation(location, hierarchyIndexes.toArray(), modifiedCoordinates);
	}

	/**
	 * Like LocationUtil.expandAll, but taking a List of {@link IDimension} as input
	 * 
	 * @see LocationUtil.expandAll
	 */
	@Deprecated
	public static Set<ILocation> expandAll(List<? extends IDimension<? extends IHierarchy>> dimensions,
			Set<ILocation> locations) {
		return LocationUtil.expandAll(HierarchiesUtil.extractHierarchies(dimensions), locations);
	}

	/**
	 * 
	 * @param originalLocation
	 * @param level
	 * @return a new {@link ILocation} where the coordinates for given {@link IHierarchy} has been either drilledUp to
	 *         given level, or drilledDown by adding null
	 */
	public static ILocation drillUpOrDown(ILocation originalLocation, ILevelInfo level) {
		int targetDepth = level.getOrdinal() + 1;

		IHierarchyInfo hierarchyInfo = level.getHierarchyInfo();

		int currentDepth = ApexLocationHelper.getLevelDepth(originalLocation, hierarchyInfo);

		if (targetDepth == currentDepth) {
			return originalLocation;
		}

		int hierarchyOrdinal = hierarchyInfo.getOrdinal();
		Object[] newCoordinates = new Object[targetDepth];

		// Iterate down to either given level or down the deepest available
		// coordinate, leaving null on additional levels
		for (int i = 0; i < Math.min(targetDepth, currentDepth); i++) {
			// -1 to shift for the measure hierarchy
			newCoordinates[i] = originalLocation.getCoordinate(hierarchyOrdinal - 1, i);
		}

		return setPath(originalLocation, hierarchyInfo, newCoordinates);
	}

	// Must NOT be mutated
	private static final Object[] ALL_MEMBER_PATH = new Object[] { ILevel.ALLMEMBER };

	/**
	 * Enforce AllMember for this IHierarchy. Beware we do not check this IHierarhcy is not slicing
	 */
	public static ILocation drillUpAllMember(ILocation originalLocation, IHierarchyInfo hierarchyInfo) {
		return new ModifiedLocation(originalLocation, hierarchyInfo.getOrdinal() - 1, ALL_MEMBER_PATH);
	}

	public static ILocation drillDownEnsured(ILocation originalLocation, ILevelInfo levelInfo) {
		if (checkCoordinate(originalLocation, levelInfo)) {
			// The level is already expressed
			return originalLocation;
		} else {
			// Do the drilldown
			return drillUpOrDown(originalLocation, levelInfo);
		}
	}

	/**
	 * 
	 * @param location
	 * @param hierarchyInfo
	 * @return the coordinates along the given {@link IHierarchyInfo}, including the optional ALL {@link ILevel}
	 */
	public static Object[] getPath(ILocation location, IHierarchyInfo hierarchyInfo) {
		return LocationUtil.copyPath(location, hierarchyInfo);
	}

	public static Object[] getPath(ILocation location, IApexAxisHierarchyInfo hierarchyInfo) {
		return getPath(location, hierarchyInfo.getHierarchyInfo());
	}

	public static Object[] getPathSkipAllMember(ILocation location, IHierarchy hierarchy) {
		// TODO: prevent instantiating the intermediate array
		Object[] fullPath = getPath(location, hierarchy.getHierarchyInfo());
		if (isSlicingHierarchy(hierarchy) || fullPath.length == 0) {
			return fullPath;
		} else {
			// Skip the AllMember coordinate
			return Arrays.copyOfRange(fullPath, 1, fullPath.length);
		}
	}

	public static Object[] getPathSkipAllMember(ILocation location, IApexAxisHierarchyInfo hierarchy) {
		Object[] fullPath = getPath(location, hierarchy);
		if (isSlicingHierarchy(hierarchy) || fullPath.length == 0) {
			return fullPath;
		} else {
			// Skip the AllMember coordinate
			return Arrays.copyOfRange(fullPath, 1, fullPath.length);
		}
	}

	public static Object[] getPath(ILocation location, ILevelInfo levelInfo) {
		Object[] hierarchyPath = ApexLocationHelper.getPath(location, levelInfo.getHierarchyInfo());

		int levelDepth = levelInfo.getOrdinal();
		if (hierarchyPath.length != levelDepth + 1) {
			// The requested ILevel is not the deepest in the ILocation
			hierarchyPath = Arrays.copyOf(hierarchyPath, levelDepth + 1);
		}

		return hierarchyPath;
	}

	/**
	 * 
	 * @param originalLocation
	 * @param hierarchy
	 * @param newCoordinates
	 * @return an {@link ILocation} where the coordinates along the {@link IHierarchyInfo} has been replaced by the
	 *         provided coordinates
	 */
	public static ILocation setPath(ILocation originalLocation, IHierarchyInfo hierarchy, Object[] newCoordinates) {
		return new ModifiedLocation(originalLocation, hierarchy.getOrdinal() - 1, newCoordinates);
	}

	/**
	 * 
	 * @param hierarchy
	 * @return true if the first {@link ILevel} of this {@link IHierarchy} is not {@link ClassificationType}.ALL
	 * 
	 */
	public static boolean isSlicingHierarchy(IHierarchy hierarchy) {
		return hierarchy.getLevels().get(0).getLevelInfo().getClassificationType() != ClassificationType.ALL;
	}

	public static boolean isSlicingHierarchy(IApexAxisHierarchyInfo hierarchy) {
		return hierarchy.getLevels().get(0).getClassificationType() != ClassificationType.ALL;
	}

	/**
	 * 
	 * @param pivot
	 * @return an {@link ILocation} pointing on AllMember for each ALL {@link ILevel}, and the wildcard if the
	 *         {@link IHierarchy} is slicing
	 */
	public static final ILocation makeTopLocation(IActivePivotVersion pivotVersion) {
		return new ActivePivotVersionQueryHelper(pivotVersion).computeLocation(Collections.<String, Object>emptyMap());
	}

	public static TObjectIntMap<String> retrieveExpressedLevels(ILocation location,
			ISubCubeProperties subCube,
			List<? extends String> hierarchyNames) {

		final TObjectIntMap<String> hierarchyToLevelDepth = new TObjectIntHashMap<>();

		ApexLocationAcceptor.acceptLocation(location, subCube, hierarchyNames, new IApexCoordinatesVisitor() {

			@Override
			public void visitCoordinate(String hierarchyName, int levelDepth, Object coordinate) {
				// We do not care about the first ILevel (levelDepth == 0) as it
				// is always
				// expressed (some member for slicing hierarchies and
				// AllMember for ALL ILevel)
				if (levelDepth >= 1) {
					// -1 on levelDepth to express levelIndex (i.e. firstLevel
					// has index 0)
					if (hierarchyToLevelDepth.containsKey(hierarchyName)) {
						// The actual depth is the deeper between the
						// ILocation depth and the ISubCubeProperties depth

						// Not -1 as restrictionDepth is already in basis 0
						hierarchyToLevelDepth.put(hierarchyName,
								Math.max(levelDepth, hierarchyToLevelDepth.get(hierarchyName)));
					} else {
						// This level is not expressed in the ILocation
						hierarchyToLevelDepth.put(hierarchyName, levelDepth);
					}
				}
			}
		});

		return hierarchyToLevelDepth;
	}

	public static boolean equalLocations(ILocation left, ILocation right) {
		if (left == null && right == null) {
			// null == null
			return true;
		} else if (left == null || right == null) {
			// One ref is null and not the others
			return false;
		} else if (left == right) {
			// LocationUtil does not check for reference
			return true;
		} else {
			return LocationUtil.equals(left, right);
		}
	}

	public static boolean sameCoordinates(int hierarchyIndex, ILocation left, ILocation right) {
		int depth = left.getLevelDepth(hierarchyIndex);

		if (right.getLevelDepth(hierarchyIndex) != depth) {
			// Not same level depth
			return false;
		}

		for (int i = 0; i < depth; i++) {
			if (!Objects.equals(left.getCoordinate(hierarchyIndex, i), right.getCoordinate(hierarchyIndex, i))) {
				// One level coordinates are different
				return false;
			}
		}

		return true;
	}

	public static ILocation setCoordinates(ILocation originalLocation,
			IHierarchyInfo hierarchy,
			Object[] newCoordinates) {
		// ordinal =1 -> index=0
		return new ModifiedLocation(originalLocation, hierarchy.getOrdinal() - 1, newCoordinates);
	}

	public static Map<ILevelInfo, Object> convertToObject(IActivePivotManager apManager,
			String pivotId,
			Map<? extends String, ?> levelToStringOrObject) {
		if (levelToStringOrObject == null) {
			// null -> wildcard -> empty filter map
			return Collections.emptyMap();
		}

		String storeName = ApexDrillthroughHelper.findBaseStore(apManager, pivotId);

		List<? extends IHierarchy> hierarchies = apManager.getActivePivots().get(pivotId).getHierarchies();

		Map<ILevelInfo, Object> filtersAsObject = new LinkedHashMap<>();
		for (Entry<? extends String, ?> entry : levelToStringOrObject.entrySet()) {
			ILevelInfo level = ApexHierarchyHelper.findLevel(hierarchies, entry.getKey()).getLevelInfo();

			Object valueAsStringOrObject = entry.getValue();

			Object valueAsObject = convertToObject(valueAsStringOrObject, apManager, storeName, pivotId, level);

			filtersAsObject.put(level, valueAsObject);
		}

		return filtersAsObject;
	}

	protected static Object convertToObject(Object stringOrObject,
			IActivePivotManager apManager,
			String storeName,
			String pivotId,
			ILevelInfo level) {

		// See DefaultLocationInterpreter
		if (level.getClassificationType().canBeInProvider()) {
			String path = ApexDrillthroughHelper.findFieldPathForLevel(level, pivotId, apManager);

			IDatastoreSchemaMetadata metadata = apManager.getDatastore().getSchemaMetadata();
			Object valueAsObject =
					ApexDatastoreHelper.convertFieldValueToObject(metadata, storeName, path, stringOrObject);
			return valueAsObject;
		} else {
			// Try to find a Discriminator with the same .toString
			List<? extends IMultiVersionHierarchy> hierarchies =
					apManager.getActivePivots().get(pivotId).getHierarchies();
			Optional<?> asObject = ApexHierarchyHelper.convertToDiscriminator(hierarchies, level, stringOrObject);

			if (asObject.isPresent()) {
				return asObject.get();
			} else {
				return stringOrObject;
			}
		}
	}

	// TODO REFACTOR, CHECK IF PARSER IN LEVEL INFO
	@Deprecated
	public static Map<ILevelInfo, Object> convertWithoutDatastore(List<? extends IHierarchy> hierarchies,
			Map<String, String> stringMap) {
		Map<ILevelInfo, Object> filtersAsObject = new LinkedHashMap<>();
		for (Entry<String, String> entry : stringMap.entrySet()) {
			ILevel level = ApexHierarchyHelper.findLevel(hierarchies, entry.getKey());

			// See DefaultLocationInterpreter
			String valueAsString = entry.getValue();
			Optional<?> asObject =
					ApexHierarchyHelper.convertToDiscriminator(hierarchies, level.getLevelInfo(), valueAsString);

			if (asObject.isPresent()) {
				filtersAsObject.put(level.getLevelInfo(), asObject.get());
			} else {
				// throw new RuntimeException("There is no member named " + entry.getValue() + " in level " + level);
				filtersAsObject.put(level.getLevelInfo(), valueAsString);
			}
		}

		return filtersAsObject;
	}

	public static Optional<Set<?>> coordinateAsSet(Object coordinate) {
		if (coordinate == null) {
			// We have a wildcard
			return Optional.empty();
		} else if (coordinate instanceof Collection<?>) {
			// The coordinate is a multi-value
			return Optional.of(ImmutableSet.copyOf((Collection<?>) coordinate));
		} else {
			// Single coordinate
			return Optional.of(ImmutableSet.of(coordinate));
		}
	}

	/**
	 * 
	 * @param value
	 * @return true if such a coordinate marks an ILocatio is a range location
	 * 
	 * @see ILocation#isRange()
	 */
	public static boolean isWildcardOrCollection(Object value) {
		return value == null || value instanceof Collection<?>;
	}

	public static IDictionary<Object> getDictionary(IHierarchicalMapping hm, ILevelInfo level) {
		return hm.getDictionaries()[hm.getCoordinate(level.getHierarchyInfo().getOrdinal(), level.getOrdinal())];
	}
}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.aggregationfunction;

import com.qfs.agg.IAggregationFunction;
import com.quartetfs.fwk.QuartetPluginValue;

/**
 * Sum which handles not {@link Number} aggregates. When encountering something not a {@link Number}, we return this
 * value which is typically an error code.
 * 
 * This should not be used as pre-aggregation function since once can't un-contribute. However, it is much useful for
 * dynamic aggregation (e.g. once would receive a String if an FX is missing).
 * 
 * @author Benoit Lacelle
 */
@QuartetPluginValue(intf = IAggregationFunction.class)
public class SafeSumAggregationFunction extends ADynamicAggregationAggregationFunction<Object, Object> {
	private static final long serialVersionUID = -505818361693459909L;

	public static final String PLUGIN_KEY = "SafeSUM";

	public SafeSumAggregationFunction() {
		super(PLUGIN_KEY);
	}

	@Override
	public String description() {
		return PLUGIN_KEY;
	}

	@Override
	protected Object cloneAggregate(Object aggregate) {
		return aggregate;
	}

	@Override
	protected Object aggregate(Object aggregate, Object inputValue) {
		if (aggregate == null) {
			return inputValue;
		} else if (inputValue == null) {
			return aggregate;
		} else if (aggregate instanceof Number) {
			if (inputValue instanceof Number) {
				return ((Number) aggregate).doubleValue() + ((Number) inputValue).doubleValue();
			} else {
				// inputValue is not a Number: it is probably an error String: keep this error String as aggregate
				return inputValue;
			}
		} else {
			// aggregate is not a Number: it is probably an error String: keep this error String as aggregate
			return aggregate;
		}
	}

	@Override
	protected Object merge(Object mainAggregate, Object contributedAggregate) {
		return aggregate(mainAggregate, contributedAggregate);
	}

}

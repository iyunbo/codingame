/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.cube.snapshot;

import com.quartetfs.biz.pivot.IMultiVersionActivePivot;

/**
 * 
 * @author Benoit Lacelle
 *
 */
public interface IApexCubeQuerier<T> {

	/**
	 * Request to do the snapshot. it will snapshot only if we think it is pertinent to do so. For instance, we will
	 * check the epoch has changed, or some pending queue is not empty
	 * 
	 * @param snapshotParameters
	 *            could be used to configure which queries has to be done, like the considered asOfDate
	 */
	void snapshot(T snapshotParameters);

	/**
	 * Request to do the snapshot, without doing any check if it is pertinent to do so
	 * 
	 * @param snapshotParameters
	 *            could be used to configure which queries has to be done, like the considered asOfDate
	 */
	void forceSnapshot(T snapshotParameters);

	/**
	 * 
	 * @return the underlying cube
	 */
	IMultiVersionActivePivot getQueriedCube();

}

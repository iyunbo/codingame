/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.location;

import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import com.google.common.base.Optional;
import com.google.common.collect.Iterables;
import com.quartetfs.biz.pivot.ILocation;
import com.quartetfs.biz.pivot.context.IContextValue;
import com.quartetfs.biz.pivot.context.subcube.ISubCubeProperties;
import com.quartetfs.biz.pivot.cube.hierarchy.IHierarchy;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevel;
import com.quartetfs.biz.pivot.cube.hierarchy.measures.IMeasureHierarchy;

/**
 * This helper enables iterating only on the relevant {@link IHierarchy} expressed in an {@link ILocation}. An
 * {@link IHierarchy} is not relevant if the only expressed coordinates is AllMember
 * 
 * @author Benoit Lacelle
 * 
 */
public class ApexLocationAcceptor {
	protected ApexLocationAcceptor() {
		// hidden
	}

	/**
	 * 
	 * @param location
	 *            the ILocation to be visited
	 * @param locationVisitor
	 *            the {@link IApexLocationVisitor} to call on each relevant {@link IHierarchy}
	 */
	public static void acceptLocation(ILocation location, IApexLocationVisitor locationVisitor) {
		int hierarchyCount = location.getHierarchyCount();

		for (int hIndex = 0; hIndex < hierarchyCount; ++hIndex) {
			if (location.getLevelDepth(hIndex) == 1 && ILevel.ALLMEMBER.equals(location.getCoordinate(hIndex, 0))) {
				// We express a single ILevel and the only coordinates is
				// AllMember: this IHierarchy is not useful
				continue;
			} else {
				// We are not on AllMember: either it is not expressed, or it is
				// a slicing hierarchy, or anything else which is interesting
				locationVisitor.visit(location, hIndex);
			}
		}
	}

	public static void acceptLocation(ILocation location,
			ISubCubeProperties subCube,
			List<? extends String> hierarchyNames,
			IApexCoordinatesVisitor apexCoordinatesVisitor) {
		acceptLocation(location, Optional.fromNullable(subCube).asSet(), hierarchyNames, apexCoordinatesVisitor);
	}

	public static void acceptLocation(final ILocation location,
			Iterable<? extends IContextValue> contextValues,
			final List<? extends String> hierarchyNames,
			final IApexCoordinatesVisitor apexCoordinatesVisitor) {
		final int hierarchyShift;

		if (hierarchyNames == null || hierarchyNames.isEmpty()) {
			hierarchyShift = Integer.MIN_VALUE;
		} else {
			if (hierarchyNames.get(0).equals(IMeasureHierarchy.MEASURE_HIERARCHY)) {
				hierarchyShift = 1;
			} else {
				hierarchyShift = 0;
			}
		}

		acceptLocation(location, (hierarchyIndex, levelDepth, coordinate) -> {
			String hierarchyName;
			if (hierarchyNames == null || hierarchyNames.isEmpty()) {
				hierarchyName = Integer.toString(hierarchyIndex);
			} else {
				hierarchyName = hierarchyNames.get(hierarchyIndex + hierarchyShift);
			}

			// d is generally an ISubCubeDimension. Then .getLevels()
			// could be a bit slow. So we restrict ourselves to the
			// level depth and not
			// the level name
			// Moreover, we often do not have access neither to the
			// IDimension object, nor to the ILevel list
			apexCoordinatesVisitor.visitCoordinate(hierarchyName, levelDepth, coordinate);
		});

		if (contextValues != null) {
			Iterables.filter(contextValues, ISubCubeProperties.class).forEach(subCube -> {
				for (Entry<String, Set<String>> dimensionToHierarchy : subCube.getRestrictedHierarchies().entrySet()) {
					String restrictedDimension = dimensionToHierarchy.getKey();

					for (String rectrictedHierarchy : dimensionToHierarchy.getValue()) {
						subCube.getGrantedMembers(restrictedDimension, rectrictedHierarchy).forEach(restrictedPath -> {
							for (int levelDepth = 0; levelDepth < restrictedPath.size(); levelDepth++) {
								Object coordinate = restrictedPath.get(levelDepth);

								apexCoordinatesVisitor.visitCoordinate(rectrictedHierarchy, levelDepth, coordinate);
							}
						});
					}
				}
			});
		}
	}

	public static void acceptLocation(ILocation location, final IApexRawCoordinatesVisitor apexCoordinatesVisitor) {
		acceptLocation(location, (l, hierarchyIndex) -> {
			for (int levelDepth = 0; levelDepth < location.getLevelDepth(hierarchyIndex); levelDepth++) {
				Object coordinate = location.getCoordinate(hierarchyIndex, levelDepth);

				// d is generally an ISubCubeDimension. Then .getLevels()
				// could be a bit slow. So we restrict ourselves to the
				// level depth and not
				// the level name
				// Moreover, we often do not have access neither to the
				// IDimension object, nor to the ILevel list
				apexCoordinatesVisitor.visitCoordinate(hierarchyIndex, levelDepth, coordinate);
			}
		});
	}
}

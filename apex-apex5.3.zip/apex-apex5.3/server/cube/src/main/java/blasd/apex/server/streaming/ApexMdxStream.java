/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.streaming;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicReference;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.annotations.Beta;
import com.google.common.base.Strings;
import com.google.common.collect.ImmutableMap;
import com.google.common.eventbus.EventBus;
import com.quartetfs.biz.pivot.dto.CellDTO;
import com.quartetfs.biz.pivot.query.IMDXQuery;
import com.quartetfs.biz.pivot.query.impl.MDXQuery;
import com.quartetfs.biz.pivot.streaming.impl.MdxStream;
import com.quartetfs.biz.pivot.webservices.impl.CellSetState;
import com.quartetfs.fwk.QuartetException;
import com.quartetfs.fwk.QuartetExtendedPluginValue;
import com.quartetfs.tech.streaming.IStream;
import com.quartetfs.tech.streaming.IStreamProperties;
import com.quartetfs.tech.streaming.IStreamPublisher;

import blasd.apex.server.registry.RegistryInject;
import cormoran.pepper.eventbus.PepperEventBusHelper;
import cormoran.pepper.logging.PepperLogHelper;
import cormoran.pepper.memory.IPepperMemoryConstants;
import cormoran.pepper.metrics.AutoCloseableTaskStartEvent;
import cormoran.pepper.metrics.TaskEndEvent;
import cormoran.pepper.metrics.TaskStartEvent;

/**
 * This MDXStream will enforce we never submit a too big view to the client by restricting the returned view to the
 * top-left window
 * 
 * @author Benoit Lacelle
 *
 *         TODO deactivate pagination on exports
 * 
 *         TODO deactivate limits in cell sets
 */
@Beta
@QuartetExtendedPluginValue(intf = IStream.class, key = IMDXQuery.PLUGIN_KEY)
public class ApexMdxStream extends MdxStream {
	private static final long serialVersionUID = 8592719799968123933L;

	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexMdxStream.class);

	// Log if a query returned more than this number of cells
	public static final int LIMIT_FOR_LOG = IPepperMemoryConstants.MB_INT;

	// Reject input MDX if they are bigger than this
	public static final int LIMIT_FOR_INPUT_MDX = 10 * IPepperMemoryConstants.MB_INT;

	// We may not receive any eventBus: an AtomicReference helps handling this case
	protected final AtomicReference<EventBus> eventBus = new AtomicReference<>();

	@RegistryInject
	public void setEventBus(EventBus eventBus) {
		this.eventBus.set(eventBus);
	}

	public ApexMdxStream(IMDXQuery mdxQuery, IStreamProperties properties, IStreamPublisher publisher) {
		super(mdxQuery, properties, publisher);
	}

	@Override
	protected synchronized void restart(State streamState, IMDXQuery previousQuery) throws QuartetException {
		// TODO: enable somebody to reject queries bigger than this
		if (query != null && query.getContent() != null) {
			beforeRestarting(Optional.ofNullable(query.getContent()));
		}

		Optional<AutoCloseableTaskStartEvent> startEvent = prepareQueryExecution();
		try {
			super.restart(streamState, previousQuery);
		} finally {
			finallyQueryExecution(startEvent);
		}
	}

	/**
	 * 
	 * @param optionalMdx
	 *            may be null of the stream is cleaned
	 */
	protected void beforeRestarting(Optional<String> optionalMdx) {
		onMdx(optionalMdx);
	}

	/**
	 * Apex default behavior on MDX: for now, we only log huge queries
	 * 
	 * @param mdx
	 */
	public static void onMdx(Optional<String> optionalMdx) {
		if (optionalMdx.isPresent()) {
			String mdx = optionalMdx.get();

			if (mdx.length() > LIMIT_FOR_INPUT_MDX) {
				LOGGER.warn("We are consider an MDX which is quite big: {}",
						PepperLogHelper.getFirstChars(mdx, IPepperMemoryConstants.MB_INT));
			}
		}
	}

	protected void finallyQueryExecution(Optional<AutoCloseableTaskStartEvent> optStartEvent) {
		// Register the result size and close the event
		if (optStartEvent.isPresent()) {
			final int cellsCount;
			CellSetState cellState = getCellSetState();
			if (cellState != null) {
				Collection<CellDTO> cells = cellState.getCellsFollower().values();
				if (cells != null) {
					cellsCount = cells.size();
				} else {
					cellsCount = 0;
				}
			} else {
				cellsCount = 0;
			}

			if (cellsCount > LIMIT_FOR_LOG) {
				LOGGER.warn("We see many cells ({}) for {}", cellsCount, query);
			}

			AutoCloseableTaskStartEvent startEvent = optStartEvent.get();

			startEvent.getStartEvent().setEndDetails(ImmutableMap.of(TaskEndEvent.KEY_RESULT_SIZE, cellsCount));
			if (pivot != null) {
				// The pivot fields is updated after .restart: now should be OK
				startEvent.getStartEvent().setEndDetails(ImmutableMap.of(TaskStartEvent.KEY_SOURCE_ID, pivot.getId()));
			}
			startEvent.close();
		}
	}

	protected Optional<AutoCloseableTaskStartEvent> prepareQueryExecution() {
		if (eventBus == null || query == null || Strings.isNullOrEmpty(query.getContent())) {
			// MDX is null if user does .clear in the UI
			return Optional.empty();
		} else {
			String userName = getUserName();

			final Map<String, Object> details = new HashMap<>();

			if (userName != null) {
				details.put(TaskStartEvent.KEY_USERNAME, userName);
			}

			// The pivot field is updated after .restart: do not update KEY_PIVOT_ID yet!
			details.put(TaskStartEvent.KEY_CLIENT, TaskStartEvent.VALUE_CLIENT_STREAMING);

			return Optional.of(TaskStartEvent.post(PepperEventBusHelper.asConsumer(eventBus.get())
					.orElse(null), query, details, () -> -1L, MDXQuery.PLUGIN_KEY));
		}
	}
}

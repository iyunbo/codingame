/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.location;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Joiner;
import com.google.common.base.Joiner.MapJoiner;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.quartetfs.biz.pivot.IActivePivot;
import com.quartetfs.biz.pivot.IActivePivotVersion;
import com.quartetfs.biz.pivot.ILocation;
import com.quartetfs.biz.pivot.ILocationFormatter;
import com.quartetfs.biz.pivot.IMultiVersionActivePivot;
import com.quartetfs.biz.pivot.cube.hierarchy.IHierarchy;
import com.quartetfs.biz.pivot.cube.hierarchy.IHierarchyInfo;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevel;
import com.quartetfs.biz.pivot.cube.hierarchy.IMultiVersionHierarchy;
import com.quartetfs.biz.pivot.cube.hierarchy.axis.IAxisHierarchy;
import com.quartetfs.biz.pivot.cube.hierarchy.measures.IMeasureHierarchy;
import com.quartetfs.biz.pivot.impl.ALocationFormatter;
import com.quartetfs.biz.pivot.impl.Location;
import com.quartetfs.biz.pivot.impl.LocationUtil;
import com.quartetfs.fwk.QuartetType;

import blasd.apex.server.location.ApexLocationBuilder;
import blasd.apex.server.query.hierarchy.ApexHierarchyHelper;

/**
 * This {@link ILocationFormatter} reports only the {@link IHierarchy} which are not on the AllMember coordinate of an
 * ALL {@link ILevel}
 * 
 * @author Benoit Lacelle
 * 
 */
@QuartetType(intf = ILocationFormatter.class, description = "ILocation.toString express only relevant dimensions")
public class ApexShortLocationFormatter extends ALocationFormatter {
	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexShortLocationFormatter.class);

	public static final String AFTER_HIERARCHY_SEPARATOR =
			System.getProperty("activepivot.location.separator.hierarchyname", ":");

	/**
	 * This dirty hacks is a way to keep in mind the {@link IHierarchy} for each known {@link IActivePivot}
	 */
	protected static final Map<Integer, List<String>> HIERARCHY_CARDINALITY_TO_NAMES = new ConcurrentHashMap<>();
	protected static final Set<Integer> NB_DIMENSION_WITH_SEVERAL_PIVOT = Sets.newConcurrentHashSet();

	public static void clearRegistered() {
		HIERARCHY_CARDINALITY_TO_NAMES.clear();
		NB_DIMENSION_WITH_SEVERAL_PIVOT.clear();
	}

	@Override
	public void format(final StringBuilder buff, ILocation location) {
		if (location == null) {
			buff.append("null");
		} else {
			final List<? extends String> hierarchies = getAxisHierarchyNames(location);

			// This flag is used to add separators correctly
			final AtomicBoolean hasFirstDimension = new AtomicBoolean();

			ApexLocationAcceptor.acceptLocation(location, (locationBis, hierarchyIndex) -> {

				int levelDepth = location.getLevelDepth(hierarchyIndex);

				if (hasFirstDimension.get()) {
					buff.append(ILocation.HIERARCHY_SEPARATOR);
				} else {
					hasFirstDimension.set(true);
				}

				String hierarchyName;
				if (hierarchies == null) {
					hierarchyName = Integer.toString(hierarchyIndex);
				} else {
					hierarchyName = hierarchies.get(hierarchyIndex);
				}

				buff.append(hierarchyName);
				buff.append(AFTER_HIERARCHY_SEPARATOR);

				for (int l = 0; l < levelDepth; ++l) {
					if (l > 0) {
						buff.append(ILocation.LEVEL_SEPARATOR);
					}
					Object coordinate = location.getCoordinate(hierarchyIndex, l);
					if (coordinate == null) {
						buff.append(ILocation.WILDCARD);
					} else {
						buff.append(coordinate);
					}
				}
			});
		}
	}

	public static String makeLevelAsString(String hierarchyName, int levelDepth) {
		return hierarchyName + ApexShortLocationFormatter.AFTER_HIERARCHY_SEPARATOR + levelDepth;
	}

	public static List<? extends String> getAxisHierarchyNames(ILocation location) {
		int nbHierarchies = location.getHierarchyCount();

		if (NB_DIMENSION_WITH_SEVERAL_PIVOT.contains(nbHierarchies)) {
			// As we can not choose the associate pivot, we prefer to show
			// indexes in the .toString
			return null;
		} else {
			// We guess there is a single cube with this amount of hierarchies
			List<String> hierarchyNames = HIERARCHY_CARDINALITY_TO_NAMES.get(nbHierarchies);

			if (hierarchyNames == null) {
				return null;
			} else {
				// TODO : cache IHierarchyInfo list as it generate some
				// transient
				// memory?
				return hierarchyNames;
			}
		}
	}

	public static void registerActivePivot(IMultiVersionActivePivot pivot) {

		List<? extends IHierarchyInfo> hierarchies = ApexHierarchyHelper.extractAxisHierarchiesInfo(pivot);

		if (hierarchies.isEmpty()) {
			// Typically happens for distributed cubes
			LOGGER.info("We found no hierarchies for {}", pivot.getId());
			return;
		} else if (hierarchies.get(0) instanceof IMeasureHierarchy) {
			hierarchies = hierarchies.subList(1, hierarchies.size());
		}

		int size = hierarchies.size();

		if (NB_DIMENSION_WITH_SEVERAL_PIVOT.contains(size)) {
			LOGGER.info("Several cubes have {} hierarchies", size);
		} else {
			List<String> hierarchyNames = Lists.newArrayList(Lists.transform(hierarchies, IHierarchyInfo::getName));

			List<String> before = HIERARCHY_CARDINALITY_TO_NAMES.put(size, hierarchyNames);

			if (before != null && !before.equals(hierarchyNames)) {
				LOGGER.info("Several cubes (including {}) have {} hierarchies but with different names: "
						+ "({} and {}). We will stick to indexes instead of dimensions names in ILocation.toString()",
						pivot.getId(),
						size,
						before,
						hierarchyNames);
				HIERARCHY_CARDINALITY_TO_NAMES.remove(size);
				NB_DIMENSION_WITH_SEVERAL_PIVOT.add(size);
			}
		}
	}

	public static ILocation locationFromString(IMultiVersionActivePivot pivot, String locationAsString) {
		List<? extends IMultiVersionHierarchy> mvHierarchies = pivot.getHierarchies();
		List<? extends IHierarchyInfo> hierarchiesInfo = ApexHierarchyHelper.extractAxisHierarchiesInfo(pivot);

		String[] hierarchies = locationAsString.split(Pattern.quote(ILocation.HIERARCHY_SEPARATOR), -1);
		if (hierarchies.length == hierarchiesInfo.size()) {
			// All hierarchies are expressed
			for (String hierarchy : hierarchies) {
				if (!hierarchy.contains(AFTER_HIERARCHY_SEPARATOR)) {
					// And at least one of then does not have the format of a
					// short .toString: it is certainly a core .toString
					return new Location(LocationUtil.stringToArrayLocation(locationAsString));
				}
			}

		}

		{
			// Not all hierarchies are expressed or all of them has the short
			// format: this is certainly a ShortLocationFormatter .toString
			Map<String, Object> template = new HashMap<>();

			IActivePivotVersion latestVersion = pivot.getHead();

			for (String expressedHierarchy : hierarchies) {
				String[] nameToPath = expressedHierarchy.split(Pattern.quote(AFTER_HIERARCHY_SEPARATOR), 2);

				if (nameToPath.length < 2) {
					throw new IllegalArgumentException(
							locationAsString + " can not be parsed as it is not like hierarchyName:path");
				}

				String[] path = nameToPath[1].split(Pattern.quote(ILocation.LEVEL_SEPARATOR), -1);

				IAxisHierarchy hierarchy = ApexHierarchyHelper.findAxisHierarchy(mvHierarchies, null, nameToPath[0]);
				for (int depth = 0; depth < path.length; depth++) {
					String coordinateAsString = path[depth];

					if (ILocation.WILDCARD.equals(coordinateAsString)) {
						template.put(ApexHierarchyHelper.levelName(hierarchy, depth), null);
					} else {
						template.put(ApexHierarchyHelper.levelName(hierarchy, depth), coordinateAsString);
					}
				}
			}

			return ApexLocationBuilder.on(latestVersion).filter(template).build();
		}
	}

	public static String locationFromDepth(Map<String, Integer> hierarchyToDepth) {
		MapJoiner hierarchyJoiner =
				Joiner.on(ILocation.HIERARCHY_SEPARATOR).withKeyValueSeparator(AFTER_HIERARCHY_SEPARATOR);
		Joiner levelJoiner = Joiner.on(ILocation.LEVEL_SEPARATOR);

		// Comparator.comparing(Entry::getKey)
		return hierarchyJoiner
				.join(hierarchyToDepth.entrySet().stream().sorted((l, r) -> l.getKey().compareTo(r.getKey())).map(e -> {
					// If depth is 1, we have 2 elements (e.g. 'AllMember' and 'France')
					// It is OK to set a wildcard on the ALL level
					Object[] asArray = new Object[e.getValue() + 1];
					Arrays.fill(asArray, ILocation.WILDCARD);

					return Maps.immutableEntry(e.getKey(), levelJoiner.join(asArray));
				}).iterator());
	}
}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.cube.snapshot;

import java.util.Collection;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;
import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;

import com.codahale.metrics.Timer;
import com.codahale.metrics.Timer.Context;
import com.google.common.annotations.Beta;
import com.google.common.collect.Sets;
import com.qfs.condition.ICondition;
import com.quartetfs.biz.pivot.IActivePivotVersion;
import com.quartetfs.biz.pivot.IMultiVersionActivePivot;
import com.quartetfs.biz.pivot.cellset.ICellSet;
import com.quartetfs.biz.pivot.query.IGetAggregatesQuery;

import blasd.apex.server.datastore.condition.ApexConditionHelper;
import blasd.apex.server.loading.transaction.IApexAddRemoveWhereBatcher;
import blasd.apex.server.query.ApexQueryCubeHelper;
import cormoran.pepper.jmx.PepperJMXHelper;
import cormoran.pepper.logging.PepperLogHelper;
import cormoran.pepper.metrics.ITaskActivityEvent;
import cormoran.pepper.thread.PepperExecutorsHelper;

/**
 * A base implementation for query cube querying
 * 
 * @author Benoit Lacelle
 *
 */
@Beta
@ManagedResource
public abstract class AApexCubeQuerier<T, U> implements IApexCubeQuerier<T> {
	protected final Logger lOGGER = LoggerFactory.getLogger(this.getClass());

	protected final IMultiVersionActivePivot sourceCube;

	public static final int DEFAULT_CONCURRENCY = PepperExecutorsHelper.DEFAULT_ACTIVE_TASKS;
	protected final AtomicInteger concurrency = new AtomicInteger(DEFAULT_CONCURRENCY);

	protected final Timer partitionTimer;

	// protected final int secondsTimeout = 3600;
	protected final ForkJoinPool les;

	protected final Set<SnapshotStatus> snapshotStatuses = Sets.newConcurrentHashSet();
	protected final Consumer<ITaskActivityEvent> eventBus;

	protected final AtomicReference<Object> latestStartedSnapshotId = new AtomicReference<>();

	public AApexCubeQuerier(Consumer<ITaskActivityEvent> eventBus,
			IMultiVersionActivePivot sourceCube,
			Timer partitionTimer) {
		this.eventBus = eventBus;
		this.sourceCube = sourceCube;
		this.partitionTimer = partitionTimer;

		les = PepperExecutorsHelper.newForkJoinPool(this.getClass().getSimpleName());
	}

	@ManagedAttribute
	public int getConcurrency() {
		return concurrency.get();
	}

	@ManagedAttribute
	public void setConcurrency(int newConcurrency) {
		// For next snapshot, we will use a queue limiting to this concurrency,
		// without needing to renew ES
		concurrency.set(newConcurrency);
	}

	@ManagedAttribute
	public double getMeanComputationTime() {
		return partitionTimer.getSnapshot().getMean();
	}

	@Override
	public void snapshot(T snapshotParameters) {
		final IActivePivotVersion pivotToQuery = sourceCube.getHead();
		Object currentSnapshotId = getCandidateSnapshotId(pivotToQuery);

		if (compareAndSetSnapshotId(currentSnapshotId)) {
			lOGGER.debug("SnapshotId moved to {}: run snapshot", currentSnapshotId);
			forceSnapshot(pivotToQuery, snapshotParameters);
		} else {
			lOGGER.debug("SnapshotId is still {}: skip snapshot", currentSnapshotId);
		}
	}

	/**
	 * 
	 * @param pivotToQuery
	 * @return an Object describing the Id of current state of querying. 2 different snapshots should have different
	 *         snapshotIds.
	 */
	protected Object getCandidateSnapshotId(IActivePivotVersion pivotToQuery) {
		// Given a cube, we consider queries for same epochId would lead to same result. It may be wrong if a
		// PostProcessor relies on a PostProcessor which relies on another data-structure (e.g. some outer cache, the
		// datastore)
		return pivotToQuery.getEpochId();
	}

	@ManagedOperation
	@Override
	public void forceSnapshot(T snapshotParameters) {
		final IActivePivotVersion pivotToQuery = getVersionToSnpashot();

		forceSnapshot(pivotToQuery, snapshotParameters);
	}

	protected IActivePivotVersion getVersionToSnpashot() {
		return sourceCube.getHead();
	}

	protected void forceSnapshot(IActivePivotVersion pivotToQuery, T snapshotParameters) {
		Object snapshotedEpochId = computeSnapshotId(pivotToQuery);

		setSnapshotId(snapshotedEpochId);

		Stream<? extends IGetAggregatesQuery> queries = partitionedQueries();

		computeQueries(pivotToQuery, queries, snapshotedEpochId);
	}

	protected abstract Stream<? extends IGetAggregatesQuery> partitionedQueries();

	protected Object computeSnapshotId(IActivePivotVersion pivotToQuery) {
		return pivotToQuery.getEpochId();
	}

	protected long computeQueries(IActivePivotVersion pivotToQuery,
			Stream<? extends IGetAggregatesQuery> queries,
			Object snapshotId) {
		AtomicLong nbQueries = new AtomicLong();

		SnapshotStatus status = new SnapshotStatus(-1, snapshotId);
		snapshotStatuses.add(status);
		try {
			// The execution should be done asynchronously
			queries.parallel()
					.peek(q -> nbQueries.getAndIncrement())
					.map(input -> new QueryAndResult<>(input, executeGetAggregates(pivotToQuery, input)))
					.forEach(r -> drainResults(pivotToQuery, r, status));
		} finally {
			snapshotStatuses.remove(status);
		}

		lOGGER.info("We have completed snapshotting of cube={} epoch={}. Lasted={}",
				pivotToQuery.getId(),
				snapshotId,
				PepperLogHelper.humanDuration(System.currentTimeMillis() - status.start));

		return nbQueries.get();
	}

	protected void drainResults(IActivePivotVersion pivotToQuery,
			QueryAndResult<ICellSet> nextCellSet,
			SnapshotStatus status) {
		status.done++;
		final long currentDone = status.done;
		if (status.todo > 0 && currentDone > 0) {
			long now = System.currentTimeMillis();
			// long partitionLeft = nbPartition - status.done;
			// assert partitionLeft != 0;
			long timeSpent = now - status.start;
			long estimatedTotalTime = timeSpent * status.todo / currentDone;
			long left = estimatedTotalTime - timeSpent;

			lOGGER.info("We received result #{} out of {} on {}. Would finish in {}",
					status.done,
					status.todo,
					sourceCube.getId(),
					PepperLogHelper.humanDuration(left));
		} else {
			lOGGER.info("We received result #{} on {}", status.done, sourceCube.getId());
		}
		processCellSet(pivotToQuery, nextCellSet);
	}

	protected abstract boolean compareAndSetSnapshotId(Object id);

	protected abstract void setSnapshotId(Object id);

	protected abstract void processCellSet(IActivePivotVersion pivotToQuery, QueryAndResult<ICellSet> nextCellSet);

	protected ICellSet executeGetAggregates(IActivePivotVersion pivotToQuery, IGetAggregatesQuery input) {
		try (Context c = partitionTimer.time()) {
			return ApexQueryCubeHelper.executeQuery(pivotToQuery, input);
		}
	}

	// TODO: The partitionIds should probably be updated if several snapshooters feeds the same same, else the
	// removeWheres would overlap
	protected abstract void publishPartition(Set<? extends T> partitionIds, Stream<? extends Map<String, ?>> asRows);

	/**
	 * 
	 * @param transactionWrapper
	 * @param targetStore
	 * @param partitionIds
	 * @param asRows
	 * @return true if we encountered a collision
	 */
	public static boolean publishPartitionToTransactionWrapper(IApexAddRemoveWhereBatcher transactionWrapper,
			String targetStore,
			Set<? extends Map<String, ?>> partitionIds,
			Stream<? extends Map<String, ?>> asRows) {
		// If we have 2 concurrent snapshots, we want to make sure only one of
		// the snapshot result is inserted: as we do
		// a add/removeWhere on the partitionId, we also use this partitionId as
		// submissionId: we then make sure we keep
		// the addRemoveWhere on the same partitionId to be done in 2 different
		// transactions
		// prevent inserting the same country from 2 different queries
		ICondition removeWhere = ApexConditionHelper.convertToCondition(partitionIds);
		return transactionWrapper.send(partitionIds, targetStore, asRows, removeWhere, null);
	}

	@ManagedOperation
	public Collection<String> getRunningSnapshot() {
		return PepperJMXHelper.convertToJMXStringSet(snapshotStatuses);
	}

	@Override
	public String toString() {
		return this.getClass() + " [sourceCube="
				+ sourceCube
				+ ", concurrency="
				+ concurrency
				+ ", snapshotStatuses="
				+ snapshotStatuses
				+ "]";
	}

}

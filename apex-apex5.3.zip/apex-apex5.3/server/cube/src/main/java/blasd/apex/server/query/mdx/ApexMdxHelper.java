/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.mdx;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import com.google.common.annotations.Beta;
import com.google.common.base.Joiner;
import com.google.common.base.Strings;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Iterables;
import com.google.common.collect.ListMultimap;
import com.google.common.collect.MultimapBuilder.ListMultimapBuilder;

import cormoran.pepper.io.PepperFileHelper;
import javolution.util.function.Consumer;

/**
 * Utility methods related to MDX manipulations
 * 
 * @author Benoit Lacelle
 *
 */
public class ApexMdxHelper {
	private static final Pattern MEMBER_PATH_PATTERN =
			Pattern.compile("\\[([^\\]]+)\\](\\.(\\[([^\\]]+)\\])((?:\\.\\[[^\\]]+\\])*(?:\\.\\[([^\\]]+)\\])?))?");

	private static final Pattern CUBE_NAME_PATTERN = Pattern.compile("FROM\\s+\\[([^\\]]+)\\]");
	private static final Pattern SELECT_PATTERN = Pattern.compile("\\s*SELECT\\s");

	private static final int PATH_AFTER_THIRD_INDEX = 5;

	protected ApexMdxHelper() {
		// hidden
	}

	public static ListMultimap<String, String> extractCoordinates(String mdx) {
		final ListMultimap<String, String> hierarchyToCoordinate =
				ListMultimapBuilder.linkedHashKeys().arrayListValues().build();

		extractCoordinates(mdx, matchedPath -> {
			String cleanFirst = matchedPath.group(1);
			String pathAfterFirst = matchedPath.group(2);

			if (Strings.isNullOrEmpty(pathAfterFirst)) {
				// We have only a dimension or hierarchy name or cubeName
				hierarchyToCoordinate.put("[" + cleanFirst + "]", "");
			} else {
				// Hardcoded indexes
				// CHECKSTYLE:OFF
				String secondMemberDirty = matchedPath.group(3);
				// CHECKSTYLE:ON
				// String secondMemberClean = matchedPath.group(4);
				String pathAfterThird = matchedPath.group(PATH_AFTER_THIRD_INDEX);

				if (Strings.isNullOrEmpty(pathAfterThird)) {
					hierarchyToCoordinate.put("[" + cleanFirst + "]", secondMemberDirty);
				} else {
					pathAfterThird = pathAfterThird.substring(1);

					// We guess we have dimension and hierarchy name,
					// followed by path
					hierarchyToCoordinate.put("[" + cleanFirst + "]." + secondMemberDirty, pathAfterThird);
				}
			}
		});

		return hierarchyToCoordinate;
	}

	public static ListMultimap<String, String> extractCoordinates(String mdx, Consumer<Matcher> consumer) {
		ListMultimap<String, String> hierarchyToCoordinate = ListMultimapBuilder.treeKeys().arrayListValues().build();

		Matcher m = MEMBER_PATH_PATTERN.matcher(mdx);

		while (m.find()) {
			consumer.accept(m);
		}

		return hierarchyToCoordinate;
	}

	@Beta
	public static String applyCoordinates(String mdx, ListMultimap<String, String> hierarchyToCoordinates) {
		final StringBuffer sb = new StringBuffer();

		final Iterator<Entry<String, String>> baseCoordinatesIterator = extractCoordinates(mdx).entries().iterator();
		final Iterator<Entry<String, String>> replacementIterator = hierarchyToCoordinates.entries().iterator();

		extractCoordinates(mdx, matchedPath -> {
			Entry<String, String> base = baseCoordinatesIterator.next();
			Entry<String, String> replacement = replacementIterator.next();

			if (base.equals(replacement)) {
				// not changed
				matchedPath.appendReplacement(sb, "$0");
			} else {
				if (matchedPath.group(2) == null) {
					matchedPath.appendReplacement(sb, "[$1]." + replacement.getValue());
				} else if (Strings.isNullOrEmpty(matchedPath.group(PATH_AFTER_THIRD_INDEX))) {
					matchedPath.appendReplacement(sb, "[$1]." + replacement.getValue());
				} else {
					matchedPath.appendReplacement(sb, "[$1].$3." + replacement.getValue());
				}
			}
		});

		return sb.toString();
	}

	public static void replaceCoordinate(ListMultimap<String, String> coordinates,
			String levelPath,
			String newCoordinate) {
		List<String> existing = coordinates.get(levelPath);
		for (int i = 0; i < existing.size(); i++) {
			existing.set(i, newCoordinate);
		}
	}

	@Beta
	public static String normalizeMdx(String mdx) {
		ListMultimap<String, String> coordinates = extractCoordinates(mdx);

		Map<String, String> originalValueToTemplate = new HashMap<>();
		for (String key : coordinates.keySet()) {
			List<String> pathes = coordinates.get(key);

			for (int i = 0; i < pathes.size(); i++) {
				String path = pathes.get(i);

				if (!Strings.isNullOrEmpty(path) && key.indexOf('.') >= 0) {
					// Consider only actual pathes (e.g. and not cube names, or
					// [hName].Members)

					String templateForPath = originalValueToTemplate.get(path);
					if (templateForPath == null) {
						// First time we encounter this path
						templateForPath = "%" + Integer.toString(originalValueToTemplate.size()) + "%";
						originalValueToTemplate.put(path, templateForPath);
					}

					pathes.set(i, templateForPath);
				}
			}
		}

		return applyCoordinates(PepperFileHelper.cleanWhitespaces(mdx), coordinates);
	}

	@Deprecated
	public static String cleanWhitespaces(String content) {
		return PepperFileHelper.cleanWhitespaces(content);
	}

	public static boolean isSelectMdx(String mdx) {
		return SELECT_PATTERN.matcher(mdx).find();
	}

	public static Optional<String> extractCubeName(String mdx) {
		Matcher m = CUBE_NAME_PATTERN.matcher(mdx);

		if (m.find()) {
			return Optional.of(m.group(1));
		} else {
			return Optional.empty();
		}
	}

	public static String makeTopMdxQuery(String cubeName) {
		return "SELECT [Measures].Members ON ROWS FROM [" + cubeName + "]";
	}

	public static String makeCrossJoinMdxQuery(String cubeName, Iterable<? extends String> hierarchyNames) {
		List<String> hierarchyNamesAsList = ImmutableList.copyOf(hierarchyNames);

		if (hierarchyNamesAsList.size() == 1) {
			String fullHierarchyName;
			if (hierarchyNamesAsList.get(0).startsWith("[") && hierarchyNamesAsList.get(0).endsWith("]")) {
				fullHierarchyName = hierarchyNamesAsList.get(0);
			} else {
				fullHierarchyName = "[" + hierarchyNamesAsList.get(0) + "]";
			}

			return "SELECT NON EMPTY " + fullHierarchyName
					+ ".Members"
					+ " ON ROWS, [Measures].Members ON COLUMNS FROM ["
					+ cubeName
					+ "]";

		} else {
			return "SELECT NON EMPTY CrossJoin("
					+ Joiner.on(",").join(Iterables.transform(hierarchyNames, hierarchyName -> {
						String fullHierarchyName;
						if (hierarchyName.startsWith("[") && hierarchyName.endsWith("]")) {
							fullHierarchyName = hierarchyName;
						} else {
							fullHierarchyName = "[" + hierarchyName + "]";
						}

						return fullHierarchyName + ".Members";
					}))
					+ ") ON ROWS, [Measures].Members ON COLUMNS FROM ["
					+ cubeName
					+ "]";
		}

	}

	public static String makePointCell(String cubeName, Map<String, String> hierarchyToValue) {
		StringBuilder mdx = new StringBuilder("SELECT FROM [" + cubeName + "] WHERE (");

		Joiner.on(',')
				.appendTo(mdx,
						hierarchyToValue.entrySet()
								.stream()
								.map(e -> "[" + e.getKey() + "].[" + e.getValue() + "]")
								.collect(Collectors.toList()));

		mdx.append(")");
		return mdx.toString();
	}
}

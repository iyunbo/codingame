/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query;

import com.google.common.annotations.Beta;
import com.quartetfs.biz.pivot.query.IGetAggregatesQuery;
import com.quartetfs.biz.pivot.query.IMDXQuery;
import com.quartetfs.biz.pivot.query.impl.ActivePivotSyncActionQuery;
import com.quartetfs.biz.pivot.query.impl.ActivePivotSyncUtils.IAction;
import com.quartetfs.biz.pivot.query.impl.StreamEventProcessingQuery;
import com.quartetfs.biz.xmla.discovery.impl.IPivotDiscoveryHandler;
import com.quartetfs.fwk.query.IQuery;

/**
 * Wraps the various IQuery behind a single abstraction
 * 
 * @author Benoit Lacelle
 * @see ApexQueryCubeHelper#dispatchQuery
 */
@Beta
public interface IApexQueryHandler {

	void onGetAggregatesQuery(IGetAggregatesQuery query);

	void onMDXQuery(IMDXQuery query);

	void onDiscoveryQuery(IQuery<?> query, Class<? extends IPivotDiscoveryHandler> handlerClass);

	void onOtherQueryDone(IQuery<?> query);

	void onStreamEventProcessingQuery(StreamEventProcessingQuery<?> query);

	/**
	 * 
	 * @param action
	 * @see ActivePivotSyncActionQuery
	 */
	void onActionQueryDone(IAction<?, ?> action);
}

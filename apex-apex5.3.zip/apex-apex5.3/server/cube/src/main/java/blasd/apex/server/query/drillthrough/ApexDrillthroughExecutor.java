/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.drillthrough;

import java.util.Properties;

import com.qfs.store.IFilteredFieldInformation;
import com.quartetfs.biz.pivot.IActivePivotSession;
import com.quartetfs.biz.pivot.IActivePivotVersion;
import com.quartetfs.biz.pivot.postprocessing.IPrefetcher;
import com.quartetfs.biz.pivot.postprocessing.impl.ALocationShiftPostProcessor;
import com.quartetfs.biz.pivot.query.ILocationInterpreter;
import com.quartetfs.biz.pivot.query.aggregates.IDrillthroughExecutor;
import com.quartetfs.biz.pivot.query.aggregates.impl.DrillthroughExecutor;
import com.quartetfs.fwk.QuartetExtendedPluginValue;

/**
 * A {@link IDrillthroughExecutor} which returns relevant rows depending on {@link IPrefetcher}. It can then support
 * {@link IApexDynamicManyToManyPostProcessor} and many more postprocessors like any {@link ALocationShiftPostProcessor}
 * 
 * @author Benoit Lacelle
 *
 */
@QuartetExtendedPluginValue(intf = IDrillthroughExecutor.class, key = ApexDrillthroughExecutor.PLUGIN_KEY)
public class ApexDrillthroughExecutor extends DrillthroughExecutor {
	private static final long serialVersionUID = -5491983659126629762L;

	public static final String PLUGIN_KEY = "FOLLOW_POSTPROCESSOR_PREFETCHERS";

	public ApexDrillthroughExecutor(IActivePivotSession session, Properties properties) {
		super(session, properties);
	}

	@Override
	protected ILocationInterpreter createLocationInterpreter(IActivePivotVersion pivot,
			IFilteredFieldInformation fieldInformations,
			Properties properties) {
		return new ApexLocationInterpreter(fieldInformations);
	}
}

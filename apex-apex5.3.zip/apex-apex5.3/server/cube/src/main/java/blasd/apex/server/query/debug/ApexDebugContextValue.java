/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.debug;

import java.util.Objects;

import com.google.common.base.MoreObjects;
import com.quartetfs.biz.pivot.context.IContextValue;
import com.quartetfs.biz.pivot.context.impl.AContextValue;

/**
 * Default implementation for IApexDebugContextValue
 * 
 * @author Benoit Lacelle
 *
 */
public class ApexDebugContextValue extends AContextValue implements IApexDebugContextValue {
	private static final long serialVersionUID = -5092823713972147499L;

	protected boolean isDebugging = false;

	protected long queryMemoryLimit = -1L;

	protected ApexDebugContextValue() {
		// JaxB
	}

	public ApexDebugContextValue(boolean isDebugging, long queryMemoryLimit) {
		this.isDebugging = isDebugging;
		this.queryMemoryLimit = queryMemoryLimit;
	}

	@Override
	public Class<? extends IContextValue> getContextInterface() {
		return IApexDebugContextValue.class;
	}

	@Override
	public int hashCode() {
		return Objects.hash(isDebugging, queryMemoryLimit);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		ApexDebugContextValue other = (ApexDebugContextValue) obj;
		if (isDebugging != other.isDebugging) {
			return false;
		}
		if (queryMemoryLimit != other.queryMemoryLimit) {
			return false;
		}
		return true;
	}

	@Override
	public boolean isDebugging() {
		return isDebugging;
	}

	@Override
	public long getQueryMemoryLimit() {
		return queryMemoryLimit;
	}

	@Override
	public String toString() {
		return MoreObjects.toStringHelper(this)
				.add("isDebugging", isDebugging)
				.add("queryMemoryLimit", queryMemoryLimit)
				.toString();
	}

}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.hierarchy;

import java.io.Serializable;
import java.util.List;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import com.quartetfs.biz.pivot.cube.hierarchy.IHierarchyInfo;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevel;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevelInfo;

/**
 * Makes ILevelInfo available from the IHierarchyInfo object
 * 
 * @author Benoit Lacelle
 *
 */
// Serializable because of IApexQueriesService. Remove it
public class ApexHierarchyInfo implements IApexAxisHierarchyInfo, Serializable {
	private static final long serialVersionUID = -1912329972383408611L;

	protected final IHierarchyInfo hierarchyInfo;
	protected final List<? extends ILevelInfo> levelInfos;

	public ApexHierarchyInfo(IHierarchyInfo hierarchyInfo, List<? extends ILevelInfo> levelInfos) {
		if (ApexHierarchyHelper.isMeasureHierarchy(hierarchyInfo)) {
			throw new RuntimeException("We accept only axis hierarchies");
		}

		this.hierarchyInfo = hierarchyInfo;
		this.levelInfos = levelInfos;
	}

	public static ApexHierarchyInfo makeFromLevels(IHierarchyInfo hierarchyInfo, List<? extends ILevel> levels) {
		// Do not maintain a reference to the ILevel object!
		List<ILevelInfo> levelInfos = ImmutableList.copyOf(Lists.transform(levels, ILevel::getLevelInfo));

		return new ApexHierarchyInfo(hierarchyInfo, levelInfos);
	}

	@Override
	public List<? extends ILevelInfo> getLevels() {
		return levelInfos;
	}

	@Override
	public IHierarchyInfo getHierarchyInfo() {
		return hierarchyInfo;
	}

	@Override
	public String toString() {
		return "Apex" + getHierarchyInfo().toString();
	}
}

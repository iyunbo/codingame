/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.cube.snapshot;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Stream;

import org.joda.time.LocalDateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.ImmutableSet;
import com.qfs.store.IDatastoreVersion;
import com.qfs.store.transaction.ITransactionInformation;
import com.quartetfs.biz.pivot.ILocation;
import com.quartetfs.biz.pivot.IMultiVersionActivePivot;
import com.quartetfs.biz.pivot.cube.hierarchy.IHierarchy;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevel;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevelInfo;
import com.quartetfs.biz.pivot.cube.hierarchy.axis.IAxisHierarchy;
import com.quartetfs.biz.pivot.query.IGetAggregatesQuery;
import com.quartetfs.biz.pivot.query.impl.GetAggregatesQuery;

import blasd.apex.server.query.ApexQueryCubeHelper;
import blasd.apex.server.query.hierarchy.ApexHierarchyHelper;

/**
 * Default implementation of IPartitionGetAggregatesQueriesProvider
 * 
 * @author Benoit Lacelle
 *
 */
public class PartitionGetAggregatesQueriesProvider implements
		IPartitionGetAggregatesQueriesProvider<Map<? extends ILevelInfo, ?>, List<?>, IApexCubePartitionedSnapshooter<Map<? extends ILevelInfo, ?>, List<?>>> {
	protected static final Logger LOGGER = LoggerFactory.getLogger(PartitionGetAggregatesQueriesProvider.class);

	protected final Set<ILevelInfo> partitionLevels;
	protected final Collection<String> measureNames;

	protected final AtomicBoolean recomputeAll = new AtomicBoolean();

	protected final Map<List<?>, LocalDateTime> partitionsToFirsdtNotFlushedTransactionTime = new ConcurrentHashMap<>();

	public PartitionGetAggregatesQueriesProvider(ILevelInfo partitionLevel, Set<String> measureNames) {
		this(Collections.singleton(partitionLevel), measureNames);
	}

	public PartitionGetAggregatesQueriesProvider(Set<? extends ILevelInfo> partitionLevels, Set<String> measureNames) {
		Objects.requireNonNull(partitionLevels, "The partition level is null");
		Objects.requireNonNull(measureNames, "The measureNames is null");

		this.partitionLevels = ImmutableSet.copyOf(partitionLevels);
		this.measureNames = ImmutableSet.copyOf(measureNames);
	}

	public boolean getAndResetRecomputeAll() {
		// Return the state of recomputeAll and ensure it is set back to false
		return recomputeAll.getAndSet(false);
	}

	public Map<List<?>, LocalDateTime> getAndResetPartitions() {
		// Return the state of recomputeAll and ensure it is set back to false

		if (partitionsToFirsdtNotFlushedTransactionTime.isEmpty()) {
			// No partitions: do nothing
			return Collections.emptyMap();
		} else {
			// Flush the partitions
			Map<List<?>, LocalDateTime> toRecompute = new HashMap<>(partitionsToFirsdtNotFlushedTransactionTime);

			if (toRecompute.isEmpty()) {
				// Flushed in the meantime
				LOGGER.trace("Concurrent calls to getAndResetPartitions");
				return Collections.emptyMap();
			} else {
				partitionsToFirsdtNotFlushedTransactionTime.keySet().removeAll(toRecompute.keySet());
				return toRecompute;
			}
		}
	}

	protected int getPartitionSize() {
		// By default, we do one query by members of the partition level
		// It is necessary to compute a key for each result, as this key will be
		// used to remove the previous data
		// associated to the same key
		return 1;
	}

	protected List<? extends ILocation> partitionLocation(ILocation snapshotLocation,
			IAxisHierarchy partitionHierarchy) {
		return ApexQueryCubeHelper.partitionLocation(snapshotLocation, partitionHierarchy, getPartitionSize());
	}

	@Override
	public Stream<? extends IGetAggregatesQuery> getPartitionedQueries(
			IApexCubePartitionedSnapshooter<Map<? extends ILevelInfo, ?>, List<?>> apexCubeQuerier) {
		// Retrieve the main ILocation, expressing the wildcards where necessary
		ILocation snapshotLocation = apexCubeQuerier.makeSnapshotLocation(Collections.emptyMap());

		final IMultiVersionActivePivot pivotToQuery = apexCubeQuerier.getQueriedCube();

		Map<IAxisHierarchy, Integer> hierarchyToMaxCardinality = new HashMap<>();
		for (ILevelInfo l : getRawPartitionLevels()) {
			IAxisHierarchy h = ApexHierarchyHelper.getAxisHierarchy(pivotToQuery.getHierarchies(), l);

			int cardinality = h.estimateLevelCardinality(l.getOrdinal());

			if (hierarchyToMaxCardinality.containsKey(h)) {
				int currentMax = hierarchyToMaxCardinality.get(h);

				if (cardinality > currentMax) {
					hierarchyToMaxCardinality.put(h, cardinality);
				}
			} else {
				hierarchyToMaxCardinality.put(h, cardinality);
			}
		}

		if (hierarchyToMaxCardinality.isEmpty()) {
			// There is no partition level
			return convertLocationToGAQ(pivotToQuery.getId(), Collections.singleton(snapshotLocation).stream());
		} else {
			// Along which hierarchy should we do partitioning: the one with highest cardinality
			Optional<IAxisHierarchy> maxCardinalityHierarchy = hierarchyToMaxCardinality.entrySet()
					.stream()
					.sorted((l, r) -> l.getValue() - r.getValue())
					.findFirst()
					.map(Entry::getKey);

			// if (hierarchyToMaxCardinality.size() > 1) {
			// // The other partitionHierarchy will hold a plain wildcard (e.g. we stream by CounterParty, and for each
			// // counterparty, we compute all dates). This is because we do not know in advance the pair
			// // CounterParty/AsOfDate which are relevant
			// Set<IAxisHierarchy> wildcardedHierarchies = new HashSet<>(hierarchyToMaxCardinality.keySet());
			// wildcardedHierarchies.remove(maxCardinalityHierarchy);
			//
			//
			// snapshotLocation = ApexLocationHelper.drillDownEnsured(snapshotLocation);
			// }

			if (maxCardinalityHierarchy.isPresent()) {
				// Partition the main ILocation in smaller ILocations
				List<? extends ILocation> locations =
						partitionLocation(snapshotLocation, maxCardinalityHierarchy.get());

				return convertLocationToGAQ(pivotToQuery.getId(), locations.stream());
			} else {
				return Stream.empty();
			}
		}
	}

	protected ILocation makeSinglePartitionLocation(
			IApexCubePartitionedSnapshooter<Map<? extends ILevelInfo, ?>, List<?>> apexCubeQuerier,
			Map<? extends ILevelInfo, ?> partitionId) {
		// Make a query by forcing the partition level value
		return apexCubeQuerier.makeSnapshotLocation(partitionId);
	}

	protected Stream<? extends IGetAggregatesQuery> convertLocationToGAQ(final String pivotId,
			Stream<? extends ILocation> locations) {
		return locations.map(input -> makeHasGAQ(pivotId, input));
	}

	protected IGetAggregatesQuery makeHasGAQ(String pivotId, ILocation input) {
		final GetAggregatesQuery getAggregates = ApexQueryCubeHelper
				.makeGetAggregates(() -> pivotId, Arrays.asList(input), measureNames, Collections.emptyList());
		return getAggregates;
	}

	@Override
	public Stream<? extends IGetAggregatesQuery> flushPendingPartitions(
			IApexCubePartitionedSnapshooter<Map<? extends ILevelInfo, ?>, List<?>> apexCubeQuerier) {
		if (getAndResetRecomputeAll()) {
			Map<List<?>, LocalDateTime> explicitPartitions = getAndResetPartitions();

			if (!explicitPartitions.isEmpty()) {
				LOGGER.info("We skip {} pending partitions as we recompute everything", explicitPartitions);
			}

			// We should resync the whole snapshooter
			return getPartitionedQueries(apexCubeQuerier);
		} else {
			// We have a limited number of partitions which are pending

			// Snapshot pending partitions
			Map<List<?>, LocalDateTime> flushed = new HashMap<>(partitionsToFirsdtNotFlushedTransactionTime);

			if (flushed.isEmpty()) {
				// nothing to flush
				return Collections.<IGetAggregatesQuery>emptyList().stream();
			} else {
				LOGGER.info("We resync {} partitions for {} on {}",
						flushed.size(),
						apexCubeQuerier.getQueriedCube().getId(),
						apexCubeQuerier);
				if (LOGGER.isDebugEnabled()) {
					for (Entry<List<?>, LocalDateTime> oneFlushed : flushed.entrySet()) {
						LOGGER.debug("We resync {}", oneFlushed);
					}
				}

				// Remove detected partitions
				partitionsToFirsdtNotFlushedTransactionTime.keySet().removeAll(flushed.keySet());

				final IMultiVersionActivePivot pivotToQuery = apexCubeQuerier.getQueriedCube();

				Stream<ILocation> locations = flushed.keySet()
						.stream()
						.map(p -> makeSinglePartitionLocation(apexCubeQuerier, convertToPartitionId(p)));

				return convertLocationToGAQ(pivotToQuery.getId(), locations);
			}
		}
	}

	protected Map<? extends ILevelInfo, ?> convertToPartitionId(List<?> p) {
		if (p.size() == 1 && getRawPartitionLevels().size() == 1) {
			return Collections.singletonMap(getRawPartitionLevels().iterator().next(), p.get(0));
		} else {
			throw new UnsupportedOperationException("TODO");
		}
	}

	@Override
	public void transactionStarted(IDatastoreVersion datastoreVersion, ITransactionInformation transactionInformation) {
		// nothing to do
	}

	@Override
	public void transactionRolledBack() {
		// nothing to do
	}

	@Override
	public void transactionCommitted(IDatastoreVersion version,
			String storeName,
			Collection<List<?>> added,
			Collection<List<?>> deleted,
			Collection<Entry<List<?>, List<?>>> updated) {
		if (recomputeAll.get()) {
			LOGGER.debug("Skip partial update over {} as we already have to recompute everything", storeName);
		} else {
			LocalDateTime now = new LocalDateTime();
			// using ConcurrentHashMap.putAll would not guarantee atomicity
			// More over, we need to use .putIfAbsent to keep oldest date
			for (List<?> oneUpdated : added) {
				partitionsToFirsdtNotFlushedTransactionTime.putIfAbsent(oneUpdated, now);
			}

			for (List<?> oneUpdated : deleted) {
				partitionsToFirsdtNotFlushedTransactionTime.putIfAbsent(oneUpdated, now);
			}

			for (Entry<List<?>, List<?>> oneUpdated : updated) {
				partitionsToFirsdtNotFlushedTransactionTime.putIfAbsent(oneUpdated.getKey(), now);
				partitionsToFirsdtNotFlushedTransactionTime.putIfAbsent(oneUpdated.getValue(), now);
			}
		}
	}

	@Override
	public void transactionCommittedWithTooManyEntries(IDatastoreVersion version) {
		recomputeAll.set(true);

		// No need to remember the partial updates as we will recompute
		// everything
		partitionsToFirsdtNotFlushedTransactionTime.clear();
	}

	@Override
	public Map<?, LocalDateTime> getPartitionToPendingDate() {
		return partitionsToFirsdtNotFlushedTransactionTime;
	}

	@Override
	public Set<? extends ILevelInfo> getRawPartitionLevels() {
		return partitionLevels;
	}

	@Override
	public Set<? extends ILevelInfo> getCleanPartitionLevels(List<? extends IHierarchy> hierarchies) {
		Set<ILevelInfo> cleanLevels = new HashSet<>();

		for (ILevelInfo leafPartitionLevel : getRawPartitionLevels()) {
			IHierarchy h = ApexHierarchyHelper.getAxisHierarchy(hierarchies, leafPartitionLevel);

			for (ILevel partitionLevel : ApexHierarchyHelper.getInterestingLevels(h)) {
				if (partitionLevel.getOrdinal() > leafPartitionLevel.getOrdinal()) {
					// Do not consider levels above the partition level
					break;
				} else {
					// We need to consider levels above the partition level (e.g. the partition Id if level is Month
					// of hierarchy Year/Month is then 2016/January)
					cleanLevels.add(partitionLevel.getLevelInfo());
				}
			}
		}

		return cleanLevels;
	}

}

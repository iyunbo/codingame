/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.cellset;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.NavigableMap;
import java.util.TreeMap;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.annotations.Beta;
import com.google.common.base.Functions;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import com.quartetfs.biz.pivot.ILocation;
import com.quartetfs.biz.pivot.cellset.ICellSet;
import com.quartetfs.biz.pivot.cube.hierarchy.IHierarchy;
import com.quartetfs.biz.pivot.cube.hierarchy.IHierarchyInfo;
import com.quartetfs.biz.pivot.cube.hierarchy.measures.IMeasureHierarchy;
import com.quartetfs.biz.pivot.query.aggregates.impl.NegativeCellSet;

import blasd.apex.server.query.hierarchy.ApexHierarchyHelper;
import blasd.apex.server.query.hierarchy.IApexAxisHierarchyInfo;
import blasd.apex.server.query.location.ApexLocationAcceptor;
import blasd.apex.server.query.location.ApexLocationHelper;
import gnu.trove.list.TIntList;
import gnu.trove.list.array.TIntArrayList;

/**
 * Helpers for ICellSet manipulations
 * 
 * @author Benoit Lacelle
 *
 */
public class ApexCellSetHelper {
	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexCellSetHelper.class);

	public static final String MEASURE = IMeasureHierarchy.MEASURE_HIERARCHY;

	protected ApexCellSetHelper() {
		// hidden
	}

	public static NavigableMap<? extends String, ? extends List<String>> of(String hierarchyName,
			List<String> coordinates) {
		return new TreeMap<>(ImmutableMap.of(hierarchyName, coordinates));
	}

	public static NavigableMap<? extends String, ? extends List<String>> of(String hierarchyName,
			List<String> coordinates,
			String hierarchyName2,
			List<String> coordinates2) {
		return new TreeMap<>(ImmutableMap.of(hierarchyName, coordinates, hierarchyName2, coordinates2));
	}

	public static NavigableMap<? extends String, ? extends List<String>> of(String hierarchyName,
			List<String> coordinates,
			String hierarchyName2,
			List<String> coordinates2,
			String hierarchyName3,
			List<String> coordinates3) {
		return new TreeMap<>(ImmutableMap
				.of(hierarchyName, coordinates, hierarchyName2, coordinates2, hierarchyName3, coordinates3));
	}

	@Deprecated
	public static <T> NavigableMap<NavigableMap<String, List<String>>, T> convertKeyToStringCoordinates(
			NavigableMap<? extends NavigableMap<String, ? extends List<?>>, T> objectMap) {
		@SuppressWarnings({ "unchecked", "rawtypes" })
		NavigableMap<NavigableMap<String, List<String>>, T> stringKey =
				new TreeMap<>((Comparator) objectMap.comparator());

		for (Entry<? extends NavigableMap<String, ? extends List<?>>, T> entry : objectMap.entrySet()) {
			stringKey.put(convertToStringCoordinates(entry.getKey()), entry.getValue());
		}

		return stringKey;
	}

	public static NavigableMap<String, List<String>> convertToStringCoordinates(
			NavigableMap<String, ? extends List<?>> objectMap) {
		NavigableMap<String, List<String>> stringKey = new TreeMap<>(objectMap.comparator());

		for (Entry<String, ? extends List<?>> entry : objectMap.entrySet()) {
			stringKey.put(entry.getKey(), convertToStringList(entry.getValue()));
		}

		return stringKey;
	}

	public static List<String> convertToStringList(List<?> value) {
		// Make JMX compatible
		return new ArrayList<>(Lists.transform(value, Functions.toStringFunction()));
	}

	protected static NavigableMap<String, List<Object>> computeApexHierarchyToPath(final ILocation pointLocation,
			final List<? extends IApexAxisHierarchyInfo> hierarchies) {
		final NavigableMap<String, List<Object>> pointCoordinate = new TreeMap<>();

		// Add each relevant Axis coordinate
		ApexLocationAcceptor.acceptLocation(pointLocation, (location, hierarchyIndex) -> {
			IApexAxisHierarchyInfo hierarchy = hierarchies.get(hierarchyIndex);

			List<Object> path = Arrays.asList(ApexLocationHelper.getPathSkipAllMember(location, hierarchy));

			pointCoordinate.put(hierarchy.getHierarchyInfo().getName(), path);
		});

		return pointCoordinate;
	}

	protected static NavigableMap<String, List<Object>> computeHierarchyToPath(final ILocation pointLocation,
			final List<? extends IHierarchyInfo> hierarchies) {
		final NavigableMap<String, List<Object>> pointCoordinate = new TreeMap<>();

		// Add each relevant Axis coordinate
		ApexLocationAcceptor.acceptLocation(pointLocation, (location, hierarchyIndex) -> {
			IHierarchyInfo hierarchy = hierarchies.get(hierarchyIndex);

			List<Object> path = Arrays.asList(ApexLocationHelper.getPath(location, hierarchy));

			pointCoordinate.put(hierarchy.getName(), path);
		});

		return pointCoordinate;
	}

	/**
	 * 
	 * @param cellset
	 * @param hierarchies
	 *            the hierarchies of the cube, preferable IApexHierarchyInfo objects
	 * @return an Iterable of CoordinateAndAggregates which expressed only the relevant hierarchy under a Map format.
	 *         Each Map has an entry per expressed hierarchy. We try not to express the AllMember in the path, but it
	 *         required to receive an IApexHierarchyInfo as input
	 */
	@Beta
	public static List<? extends CoordinateAndAggregates> convertToList(ICellSet cellset,
			final List<? extends IApexAxisHierarchyInfo> hierarchies) {
		if (cellset instanceof NegativeCellSet) {
			List<CoordinateAndAggregates> removed = new ArrayList<>();

			cellset.forEachCell((location, measure, nullValue) -> {
				NavigableMap<String, List<Object>> hToPath = computeApexHierarchyToPath(location, hierarchies);

				removed.add(new CoordinateAndAggregates(hToPath,
						Collections.singletonList(measure),
						Collections.singletonList(null)));

				return true;
			}, cellset.availableMeasures());

			return removed;
		} else {
			TIntList allRowId = new TIntArrayList();

			// Collect all relevant rowIds: this will enable RandomAccess
			cellset.forEachLocation(rowId -> {
				allRowId.add(rowId);

				return true;
			});

			List<String> measures = Arrays.asList(cellset.availableMeasures());

			return new AbstractList<CoordinateAndAggregates>() {

				@Override
				public int size() {
					return allRowId.size();
				}

				@Override
				public CoordinateAndAggregates get(int index) {
					// Associate this coordinate to the list of values
					// We copy the input array for safety as we are typically
					// provided a buffered Object[]
					int rowId = allRowId.get(index);
					NavigableMap<String, List<Object>> hToPath =
							computeApexHierarchyToPath(cellset.getLocation(rowId), hierarchies);

					List<Object> values =
							measures.stream().map(m -> cellset.getCellValue(rowId, m)).collect(Collectors.toList());

					return new CoordinateAndAggregates(hToPath, measures, values);
				}
			};
		}
	}

	public static List<? extends CoordinateAndAggregates> convertToList2(ICellSet cellset,
			final List<? extends IHierarchy> hierarchies) {
		return convertToList(cellset, ApexHierarchyHelper.extractApexAxisHierarchiesInfo(hierarchies));
	}

	public static List<NavigableMap<String, List<?>>> convertToMap(
			List<? extends CoordinateAndAggregates> coordinates) {
		return coordinates.stream().map(ApexCellSetHelper::convertToMap).collect(Collectors.toList());
	}

	public static List<NavigableMap<String, List<?>>> convertToListMap(ICellSet cellset,
			final List<? extends IApexAxisHierarchyInfo> hierarchies) {
		return convertToMap(convertToList(cellset, hierarchies));
	}

	public static List<NavigableMap<String, List<?>>> convertToListMap2(ICellSet cellset,
			final List<? extends IHierarchy> hierarchies) {
		return convertToMap(convertToList2(cellset, hierarchies));
	}

	public static List<NavigableMap<String, List<?>>> convertToListMap(
			List<? extends CoordinateAndAggregates> coordinates) {
		return coordinates.stream().map(ApexCellSetHelper::convertToMap).collect(Collectors.toList());
	}

	/**
	 * Merge in a single Map by putting the measures associated to the IMeasureHierarchy
	 */
	public static NavigableMap<String, List<?>> convertToMap(CoordinateAndAggregates c) {
		NavigableMap<String, List<?>> allCoordinates = new TreeMap<>(c.hierarchyToPath);

		List<?> measureNames = c.measureNames;
		List<?> measureValues = c.measureValues;
		allCoordinates.put(MEASURE, Arrays.asList(measureNames, measureValues));

		return allCoordinates;
	}

	public static Object extractValues(List<? extends Map<String, ? extends List<?>>> asMap,
			String measureName,
			Map<String, ? extends List<?>> hierarchyToCoordinates) {
		List<Map<String, ? extends List<?>>> matching = getMatchingCoordinates(asMap, hierarchyToCoordinates);

		if (matching.isEmpty()) {
			// Consider null is the value for no aggregate
			return null;
		} else if (matching.size() >= 2) {
			// We had 2 cells with the same coordinate but associated to 2 different measures (typically as produced
			// by a CellSetDTO)

			List<Map<String, ? extends List<?>>> matchingMeasure =
					matching.stream().filter(e -> extractValue(e, measureName) != null).collect(Collectors.toList());

			if (matchingMeasure.isEmpty()) {
				// Consider null is the value for no aggregate
				return null;
			} else if (matchingMeasure.size() >= 2) {
				throw new RuntimeException(
						matching.size() + " cells matches " + measureName + " on " + hierarchyToCoordinates);
			} else {
				return extractValue(matchingMeasure.get(0), measureName);
			}
		} else {
			// TODO: check it is associated to the right measure
			return extractValue(matching.get(0), measureName);
		}

	}

	public static Object extractValue(Map<String, ? extends List<?>> coordinate, String testedMeasureName) {
		List<?> measures = coordinate.get(MEASURE);

		if (measures == null || measures.isEmpty()) {
			// We prefer not to throw for resilience purposes
			return null;
		}

		List<?> measureNames = (List<?>) measures.get(0);
		List<?> measureValues = (List<?>) measures.get(1);

		int indexOf = measureNames.indexOf(testedMeasureName);

		// There is no value for given measure
		if (indexOf < 0) {
			return null;
		} else {
			return measureValues.get(indexOf);
		}
	}

	public static <T extends Map<String, ? extends List<?>>> void setValue(List<T> asMap, T update) {
		List<T> matching = getMatchingCoordinates(asMap, update);

		if (matching.isEmpty()) {
			// This is a brand new cell
			asMap.add(update);
		} else if (matching.size() >= 2) {
			throw new RuntimeException(matching.size() + " cells matches " + update);
		} else {
			T existingCell = matching.get(0);
			List<?> existingMeasures = existingCell.get(MEASURE);

			if (existingMeasures.isEmpty()) {
				throw new RuntimeException("The is no measures in " + existingCell);
			}

			List<Object> existingMeasureNames = (List<Object>) existingMeasures.get(0);
			List<Object> existingMeasureValues = (List<Object>) existingMeasures.get(1);

			List<?> updateMeasures = update.get(MEASURE);
			List<?> updateMeasureNames = (List<?>) updateMeasures.get(0);
			List<?> updateMeasureValues = (List<?>) updateMeasures.get(1);

			for (int i = 0; i < updateMeasureNames.size(); i++) {
				Object testedMeasureName = updateMeasureNames.get(i);
				Object newValue = updateMeasureValues.get(i);

				int indexOf = existingMeasureNames.indexOf(testedMeasureName);

				// There is no value for given measure
				if (indexOf < 0) {
					if (newValue == null) {
						LOGGER.warn("Removing an unknown cell: {}", update);
					} else {
						LOGGER.debug("New cell {} to {}", update, newValue);
						existingMeasureNames = Lists.newArrayList(existingMeasureNames);
						existingMeasureNames.add(testedMeasureName);

						existingMeasureValues = Lists.newArrayList(existingMeasureValues);
						existingMeasureValues.add(newValue);

						// Update the referenced array
						((List) existingMeasures).set(0, existingMeasureNames);
						((List) existingMeasures).set(1, existingMeasureValues);
					}
				} else {
					Object oldValue = existingMeasureValues.set(indexOf, newValue);
					LOGGER.debug("Update {} from {} to {}", update, oldValue, newValue);
				}
			}
		}
	}

	protected static <T extends Map<String, ? extends List<?>>> List<T> getMatchingCoordinates(List<? extends T> asMap,
			Map<String, ? extends List<?>> update) {
		Map<String, List<?>> hierarchyToCoordinates = update.entrySet()
				.stream()
				.filter(e -> !MEASURE.equals(e.getKey()))
				.collect(Collectors.toMap(Entry::getKey, Entry::getValue));

		return asMap.stream().filter(e -> {
			boolean hasMeasure = e.keySet().contains(MEASURE);

			int expectedCurrentKeySetSize = hierarchyToCoordinates.size();
			if (hasMeasure) {
				expectedCurrentKeySetSize = expectedCurrentKeySetSize + 1;
			}

			if (expectedCurrentKeySetSize != e.size()) {
				// Incompatible number of expressed hierarchies
				return false;
			} else if (!e.keySet().containsAll(hierarchyToCoordinates.keySet())) {
				// Current coordinate express some hierarchies not expressed by update
				return false;
			} else if (!e.entrySet().containsAll(hierarchyToCoordinates.entrySet())) {
				// We have differing values
				return false;
			} else {
				return true;
			}
		}).collect(Collectors.<T>toList());
	}

}

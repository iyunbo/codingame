/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.NavigableMap;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.Callable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.annotations.Beta;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import com.qfs.multiversion.IHasId;
import com.quartetfs.biz.pivot.IActivePivot;
import com.quartetfs.biz.pivot.IActivePivotVersion;
import com.quartetfs.biz.pivot.ILocation;
import com.quartetfs.biz.pivot.IMultiVersionActivePivot;
import com.quartetfs.biz.pivot.cellset.ICellSet;
import com.quartetfs.biz.pivot.context.IActivePivotContext;
import com.quartetfs.biz.pivot.context.IContextSnapshot;
import com.quartetfs.biz.pivot.context.IContextValue;
import com.quartetfs.biz.pivot.context.impl.ContextUtils;
import com.quartetfs.biz.pivot.cube.hierarchy.IHierarchyInfo;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevelInfo;
import com.quartetfs.biz.pivot.cube.hierarchy.axis.IAxisHierarchy;
import com.quartetfs.biz.pivot.cube.hierarchy.axis.IAxisMember;
import com.quartetfs.biz.pivot.dto.CellSetDTO;
import com.quartetfs.biz.pivot.query.IContextualQuery;
import com.quartetfs.biz.pivot.query.IDrillthroughQuery;
import com.quartetfs.biz.pivot.query.IGetAggregatesQuery;
import com.quartetfs.biz.pivot.query.IMDXQuery;
import com.quartetfs.biz.pivot.query.impl.ActivePivotSyncActionQuery;
import com.quartetfs.biz.pivot.query.impl.ActivePivotSyncUtils;
import com.quartetfs.biz.pivot.query.impl.ActivePivotSyncUtils.IAction;
import com.quartetfs.biz.pivot.query.impl.DrillthroughQuery;
import com.quartetfs.biz.pivot.query.impl.GetAggregatesQuery;
import com.quartetfs.biz.pivot.query.impl.MDXQuery;
import com.quartetfs.biz.pivot.query.impl.StreamEventProcessingQuery;
import com.quartetfs.biz.pivot.streaming.impl.MdxStreamHelper;
import com.quartetfs.biz.xmla.discovery.impl.IPivotDiscoveryHandler;
import com.quartetfs.fwk.QuartetException;
import com.quartetfs.fwk.query.IContinuousQuery;
import com.quartetfs.fwk.query.IContinuousQueryListener;
import com.quartetfs.fwk.query.IContinuousQueryUpdate;
import com.quartetfs.fwk.query.IQuery;
import com.quartetfs.fwk.query.QueryException;
import com.quartetfs.pivot.mdx.IExecutor;
import com.quartetfs.pivot.mdx.MdxException;
import com.quartetfs.pivot.mdx.result.impl.MdxCellSet;

import blasd.apex.server.query.location.ApexLocationHelper;

/**
 * Helpers for running queries over {@link IActivePivot}
 * 
 * @author Benoit Lacelle
 *
 */
public class ApexQueryCubeHelper {
	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexQueryCubeHelper.class);

	protected ApexQueryCubeHelper() {
		// hidden
	}

	public static GetAggregatesQuery makeGetAggregates(ILocation location,
			String firstMeasure,
			String... otherMeasures) {
		return makeGetAggregates(ImmutableList.of(location),
				Lists.asList(firstMeasure, otherMeasures),
				Collections.emptyList());
	}

	public static GetAggregatesQuery makeGetAggregates(String measure,
			ILocation firstLocation,
			ILocation... otherLocations) {
		return makeGetAggregates(Lists.asList(firstLocation, otherLocations),
				Arrays.asList(measure),
				Collections.emptyList());
	}

	public static GetAggregatesQuery makeGetAggregates(String pivotId,
			Iterable<? extends ILocation> locations,
			Iterable<? extends String> measures,
			Iterable<? extends IContextValue> contextValues) {
		GetAggregatesQuery getAggregatesQuery = makeGetAggregates(locations, measures, contextValues);

		getAggregatesQuery.setPivotId(pivotId);

		return getAggregatesQuery;
	}

	/**
	 * 
	 * @param locations
	 * @param measures
	 * @return an GetAggregatesQuery where the pivotId has not been set
	 */
	public static GetAggregatesQuery makeGetAggregates(Iterable<? extends ILocation> locations,
			Iterable<? extends String> measures) {
		return makeGetAggregates(locations, measures, Collections.emptyList());
	}

	public static GetAggregatesQuery makeGetAggregates(Iterable<? extends ILocation> locations,
			Iterable<? extends String> measures,
			Iterable<? extends IContextValue> contextValues) {
		GetAggregatesQuery getAggregatesQuery = new GetAggregatesQuery(null,
				ImmutableList.copyOf(locations),
				ImmutableList.copyOf(measures),
				ImmutableList.copyOf(contextValues));

		return getAggregatesQuery;
	}

	public static GetAggregatesQuery makeGetAggregates(IHasId pivot,
			Iterable<? extends ILocation> locations,
			Iterable<? extends String> measures,
			Iterable<? extends IContextValue> contextValues) {
		GetAggregatesQuery getAggregatesQuery = makeGetAggregates(locations, measures, contextValues);

		getAggregatesQuery.setPivotId(pivot.getId());

		return getAggregatesQuery;
	}

	/**
	 * Handle {@link Iterable} instead of {@link Collection} and throw {@link RuntimeException}
	 * 
	 * @return
	 */
	public static ICellSet executeGetAggregates(IActivePivot pivot,
			Iterable<? extends ILocation> locations,
			Iterable<? extends String> measures) {
		return executeQuery(pivot, makeGetAggregates(pivot.getId(), locations, measures, Collections.emptyList()));
	}

	public static <T> T executeQuery(IActivePivot pivotVersion, IQuery<T> query) {
		try {
			if (query instanceof IContextualQuery<?>) {
				// IContextValues in IContextualQuery are not applied by default
				List<? extends IContextValue> contextValues = ((IContextualQuery<?>) query).getContextValues();
				return executeActionContextually(pivotVersion, contextValues, () -> pivotVersion.execute(query));
			} else {
				return pivotVersion.execute(query);
			}
		} catch (QueryException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * @see #executeGetAggregates(IActivePivotVersion, Iterable, Iterable)
	 */
	public static ICellSet executeGetAggregates(IActivePivot pivot,
			Iterable<? extends ILocation> locations,
			String... measures) {
		return executeGetAggregates(pivot, locations, Arrays.asList(measures));
	}

	public static ICellSet executeGetAggregates(IActivePivot pivot,
			ILocation location,
			Iterable<? extends String> measures) {
		return executeGetAggregates(pivot, Arrays.asList(location), measures);
	}

	public static ICellSet executeGetAggregates(IActivePivot pivot,
			ILocation location,
			String firstMeasure,
			String... otherMeasures) {
		return executeGetAggregates(pivot, Arrays.asList(location), Lists.asList(firstMeasure, otherMeasures));
	}

	public static ICellSet executeGetAggregates(IActivePivot pivot,
			String underlyingMeasure,
			ILocation firstLocation,
			ILocation... otherLocations) {
		return executeGetAggregates(pivot,
				Lists.asList(firstLocation, otherLocations),
				Arrays.asList(underlyingMeasure));
	}

	/**
	 * Inspired by AQueriesService#executeActionContextualy to make it statically available
	 */
	public static <ResultType> ResultType executeContextually(IActivePivot pivot,
			Collection<? extends IContextValue> contextValues,
			Callable<ResultType> action) {
		// Execute on the latest version
		IActivePivotContext context = pivot.getContext();

		// Apply contextValues to current thread
		IContextSnapshot oldContextSnapshot = ContextUtils.applyContextValues(context, contextValues, true);
		try {
			// Execute the query
			return action.call();
		} catch (QuartetException | RuntimeException e) {
			throw new RuntimeException(e);
		} catch (Exception e) {
			throw new RuntimeException(e);
		} finally {
			// Restore the original context
			ContextUtils.replaceContextValues(context, oldContextSnapshot);
		}
	}

	/**
	 * @deprecated Prefer {@link #executeContextually(IActivePivot, Collection, Callable)}
	 */
	@Deprecated
	public static <ResultType> ResultType executeActionContextually(IActivePivot pivot,
			Collection<? extends IContextValue> contextValues,
			Callable<ResultType> action) {
		return executeContextually(pivot, contextValues, action);
	}

	public static <ResultType> ResultType executeContextually(final IActivePivotVersion pivot,
			Collection<? extends IContextValue> contextValues,
			final ActivePivotSyncUtils.IAction<ResultType, Void> action) {
		return executeContextually(pivot, contextValues, new Callable<ResultType>() {

			@Override
			public ResultType call() throws Exception {
				// Execute the query
				return ActivePivotSyncUtils.activePivotSyncExec(pivot, action, null);
			}

			// A .toString is useful for active tasks monitoring
			@Override
			public String toString() {
				return "On " + pivot.getId() + ": " + action.toString();
			}
		});
	}

	/**
	 * @deprecated Prefer {@link #executeContextually(IActivePivot, Collection, IAction)}
	 */
	@Deprecated
	public static <ResultType> ResultType executeActionContextually(IActivePivotVersion pivot,
			Collection<? extends IContextValue> contextValues,
			ActivePivotSyncUtils.IAction<ResultType, Void> action) {
		return executeContextually(pivot, contextValues, action);
	}

	public static <ResultType> ResultType executeContextually(final IActivePivotVersion pivot,
			Collection<? extends IContextValue> contextValues,
			final IQuery<ResultType> query) {
		return executeContextually(pivot, contextValues, new Callable<ResultType>() {

			@Override
			public ResultType call() throws Exception {
				// Execute the query
				return pivot.execute(query);
			}

			// A .toString is useful for active tasks monitoring
			@Override
			public String toString() {
				return "On " + pivot.getId() + ": " + query.toString();
			}
		});
	}

	/**
	 * @deprecated Prefer {@link #executeContextually(IActivePivot, Collection, IQuery)}
	 */
	@Deprecated
	public static <ResultType> ResultType executeActionContextually(IActivePivotVersion pivot,
			Collection<? extends IContextValue> contextValues,
			IQuery<ResultType> query) {
		return executeContextually(pivot, contextValues, query);
	}

	public static <ResultType> ResultType executeContextually(final IMultiVersionActivePivot pivot,
			Collection<? extends IContextValue> contextValues,
			IQuery<ResultType> query) {
		return executeContextually(pivot.getHead(), contextValues, query);
	}

	/**
	 * @deprecated Prefer {@link #executeContextually(IMultiVersionActivePivot, Collection, IQuery)}
	 */
	@Deprecated
	public static <ResultType> ResultType executeActionContextually(final IMultiVersionActivePivot pivot,
			Collection<? extends IContextValue> contextValues,
			IQuery<ResultType> query) {
		return executeActionContextually(pivot.getHead(), contextValues, query);
	}

	/**
	 * 
	 * @param pivot
	 * @param location
	 *            an {@link ILocation} expected to be range along the partition {@link IHierarchyInfo}
	 * @param partitionHierarchyInfo
	 * @param partitionSize
	 *            the number of coordinates per returned {@link ILocation}
	 * @return a List of {@link ILocation} which covers exactly the input {@link ILocation}
	 */
	@Beta
	public static List<? extends ILocation> partitionLocation(ILocation location,
			IAxisHierarchy partitionHierarchy,
			int partitionSize) {
		// We partition automatically along the deepest level in order to
		// encounter the highest cardinality
		int deepestLevelInHierarchy = ApexLocationHelper.getLevelDepth(location, partitionHierarchy) - 1;

		return partitionLocation(location, partitionHierarchy, deepestLevelInHierarchy, partitionSize);
	}

	/**
	 * 
	 * @param pivot
	 * @param location
	 * @param partitionLevel
	 * @param partitionSize
	 * @return
	 */
	@Beta
	public static List<? extends ILocation> partitionLocation(ILocation location,
			IAxisHierarchy partitionHierarchy,
			int partitionLevelIndex,
			int partitionSize) {

		List<ILocation> locations;
		{
			Object[] path = ApexLocationHelper.getPath(location, partitionHierarchy.getHierarchyInfo());

			Set<ILevelInfo> levelsToSet = new LinkedHashSet<>();

			List<Object> levelsToCoordinate = new ArrayList<>();
			for (int i = 0; i < path.length; i++) {
				Object coordinate = path[i];

				// We have to set on collection coordinates
				if (coordinate == null || coordinate instanceof Collection<?>) {
					levelsToSet.add(partitionHierarchy.getLevels().get(i).getLevelInfo());
					levelsToCoordinate.add(new HashSet<>());
				} else {
					// This level is not considered
					levelsToCoordinate.add(coordinate);
				}
			}

			// Given AllMember/*/A, we can partition on *
			// Given AllMember/[A,B]/*, we can partition on* on AllMember/A/*
			// and AllMember/B/*
			// Given AllMember/*/*/A, we can NOT partition
			// Given AllMember/[A,B]/[C,D], we can partition pathes manually

			// We only have to handle the wildcard case
			Iterator<? extends IAxisMember> members = retrieveMembers(partitionHierarchy, path).iterator();

			locations = new ArrayList<>();

			while (members.hasNext()) {
				final IAxisMember nextMember = members.next();

				Object[] currentMemberPath = nextMember.getObjectPath();

				ILocation oneMoreLocation = acceptNextMember(location,
						partitionHierarchy,
						levelsToCoordinate,
						currentMemberPath,
						partitionSize);

				if (oneMoreLocation != null) {
					locations.add(oneMoreLocation);
				}
			}

			// Flush the remainder
			locations
					.add(flushToPartitionLocation(partitionHierarchy.getHierarchyInfo(), levelsToCoordinate, location));
		}

		LOGGER.info("{} partitions for {} with a wildcard along hierarchy {}",
				locations.size(),
				location,
				partitionHierarchy.getName());

		return locations;
	}

	private static ILocation acceptNextMember(ILocation location,
			IAxisHierarchy partitionHierarchy,
			List<Object> levelsToCoordinate,
			Object[] currentMemberPath,
			int partitionSize) {

		boolean severalLevelTurningToCollection = false;
		int levelTurningToCollection = -1;
		int bringSizeTo = 0;

		for (int i = 0; i < levelsToCoordinate.size(); i++) {
			// Consider the coordinates ready for next partition
			Object nextPartitionCoordinate = levelsToCoordinate.get(i);

			if (nextPartitionCoordinate instanceof Collection<?>) {
				Collection<?> pendingCoordinates = (Collection<?>) nextPartitionCoordinate;

				// Consider current member coordinate
				Object currentMemberCoordinate = currentMemberPath[i];

				if (pendingCoordinates.isEmpty()) {
					// We have flushed previous partition: no level will be
					// turned to Collection
					break;
				} else if (pendingCoordinates.contains(currentMemberCoordinate)
				// && pendingCoordinates.size() == 1
				) {
					// This is compatible with current partition
					continue;
				} else {
					// This coordinate is not already consider by current set of
					// size >=1
					if (levelTurningToCollection == -1) {
						levelTurningToCollection = i;

						// We are going to increase the size by 1
						bringSizeTo = pendingCoordinates.size() + 1;
					} else {
						severalLevelTurningToCollection = true;
					}
				}
			}
		}

		ILocation oneMoreLocation = null;

		if (severalLevelTurningToCollection || bringSizeTo > partitionSize) {
			// This member is not compatible with current partition

			oneMoreLocation =
					flushToPartitionLocation(partitionHierarchy.getHierarchyInfo(), levelsToCoordinate, location);

			severalLevelTurningToCollection = false;
			levelTurningToCollection = -1;
		}

		// Here, we are guaranteed not to turn several levels to Collection
		for (int i = 0; i < levelsToCoordinate.size(); i++) {
			// Consider the coordinates ready for next partition
			Object nextPartitionCoordinate = levelsToCoordinate.get(i);

			if (nextPartitionCoordinate instanceof Collection<?>) {
				@SuppressWarnings("unchecked")
				Collection<Object> pendingCoordinates = (Collection<Object>) nextPartitionCoordinate;

				// Consider current member coordinate
				Object currentMemberCoordinate = currentMemberPath[i];

				if (pendingCoordinates.add(currentMemberCoordinate)) {
					LOGGER.debug("Consider {} for {}",
							currentMemberCoordinate,
							partitionHierarchy.getLevels().get(i).getName());
				}
			}
		}

		return oneMoreLocation;
	}

	private static ILocation flushToPartitionLocation(IHierarchyInfo hierarchy,
			List<Object> levelsToCoordinate,
			ILocation location) {
		Object[] coordinatesToSet = new Object[levelsToCoordinate.size()];

		for (int levelOrdinal = 0; levelOrdinal < levelsToCoordinate.size(); levelOrdinal++) {
			Object coordinateToSet = levelsToCoordinate.get(levelOrdinal);

			if (coordinateToSet instanceof Collection<?>) {
				Collection<?> asCollection = (Collection<?>) coordinateToSet;
				if (asCollection.size() == 1) {
					coordinatesToSet[levelOrdinal] = asCollection.iterator().next();
				} else {
					coordinatesToSet[levelOrdinal] = coordinateToSet;
				}

				// Reset for next partition
				levelsToCoordinate.set(levelOrdinal, new HashSet<>());
			} else {
				coordinatesToSet[levelOrdinal] = coordinateToSet;
			}
		}

		// Prepare a partition ILocation
		// Do NOT reduce the location, in order to keep the original
		// requested depth
		return ApexLocationHelper.setCoordinates(location, hierarchy, coordinatesToSet);
	}

	protected static Iterable<? extends IAxisMember> retrieveMembers(IAxisHierarchy partitionHierarchy, Object[] path) {
		// TODO: Make an Iterator as retrieveMembers materialize a List
		return partitionHierarchy.retrieveMembers(path);
	}

	public static <
			UpdateType extends IContinuousQueryUpdate<ICellSet>> IContinuousQuery<ICellSet, UpdateType> registerContinuousQuery(
					IMultiVersionActivePivot pivot,
					String queryName,
					Iterable<? extends ILocation> locations,
					Iterable<? extends String> measures,
					Iterable<? extends IContinuousQueryListener<ICellSet, UpdateType>> listeners) {
		try {
			return pivot.registerContinuousQuery(queryName,
					makeGetAggregates(locations, measures),
					new Properties(),
					Lists.newArrayList(listeners));
		} catch (QueryException e) {
			throw new RuntimeException(e);
		}
	}

	public static void dispatchQuery(IQuery<?> query, IApexQueryHandler apexQueryHandler) {
		if (query instanceof ActivePivotSyncActionQuery<?, ?>) {
			IAction<?, ?> action = ((ActivePivotSyncActionQuery<?, ?>) query).getAction();

			if (action.getClass().isAnonymousClass()) {
				Class<?> enclosingClass = action.getClass().getEnclosingClass();

				if (IPivotDiscoveryHandler.class.isAssignableFrom(enclosingClass)) {
					apexQueryHandler.onDiscoveryQuery(query, (Class<? extends IPivotDiscoveryHandler>) enclosingClass);
				} else {
					apexQueryHandler.onOtherQueryDone(query);
				}
			} else if (action.getClass().isMemberClass()) {
				Class<?> enclosingClass = action.getClass().getEnclosingClass();

				if (IExecutor.class.isAssignableFrom(enclosingClass)) {
					String mdx = getMdxFromEnclosing(action);

					if (mdx == null) {
						apexQueryHandler.onOtherQueryDone(query);
					} else {
						apexQueryHandler.onMDXQuery(new MDXQuery(mdx));
					}
					// } else if
					// (RTSelectSupervisor.class.isAssignableFrom(enclosingClass))
					// {
					// String mdx = RTSelectSupervisorSpy.getMdx(action);
					//
					// if (mdx == null) {
					// apexQueryHandler.onOtherQueryDone(query);
					// } else {
					// apexQueryHandler.onMDXQuery(new MDXQuery(mdx));
					// }
				} else {
					apexQueryHandler.onOtherQueryDone(query);
				}
			} else {
				apexQueryHandler.onActionQueryDone(action);
			}
		} else if (query instanceof IGetAggregatesQuery) {
			apexQueryHandler.onGetAggregatesQuery((IGetAggregatesQuery) query);
		} else if (query instanceof IMDXQuery) {
			apexQueryHandler.onMDXQuery((IMDXQuery) query);
		} else if (query instanceof StreamEventProcessingQuery<?>) {
			apexQueryHandler.onStreamEventProcessingQuery((StreamEventProcessingQuery<?>) query);
		} else {
			apexQueryHandler.onOtherQueryDone(query);
		}
	}

	/**
	 * Dirty way to extract the MDX from an {@link IAction}
	 * 
	 * @param action
	 * @return
	 */
	private static String getMdxFromEnclosing(IAction<?, ?> action) {
		Field executorField;
		try {
			// OK for:
			// SelectStatementExecutor.MdxAction
			executorField = action.getClass().getDeclaredField("mdx");
			executorField.setAccessible(true);

			return (String) executorField.get(action);
		} catch (NoSuchFieldException | SecurityException | IllegalArgumentException | IllegalAccessException e) {
			return null;
		}
	}

	public static List<NavigableMap<String, List<?>>> registerContinuousGetAggregqatesQuery(
			IMultiVersionActivePivot pivot,
			IGetAggregatesQuery query,
			String queryName) {
		try {
			ApexGetAggregatesAsMapListener listener =
					ApexGetAggregatesAsMapListener.makeListener(pivot.getHierarchies());

			pivot.registerContinuousQuery(queryName, query, new Properties(), Arrays.asList(listener));

			return listener.getLiveStateAsList();
		} catch (QueryException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * Add an {@link IContextValue} in the one attached to a {@link IContextualQuery}
	 * 
	 * @param query
	 * @param contextValue
	 */
	public static void addContextValue(IContextualQuery<?> query, IContextValue contextValue) {
		// TODO: what if the List is Immutable?
		((List) query.getContextValues()).add(contextValue);
	}

	public static CellSetDTO executeContextually(IMultiVersionActivePivot pivot,
			IMDXQuery mdxQuery,
			Collection<? extends IContextValue> contextValues) {
		// Why: do we need to applyContextValue as we later use MdxStreamHelper.executeContextually?
		// Because: we have to apply additional contextValues
		// We prefer modifying the context twice, instead of mutating the IQuery
		IContextSnapshot oldCtx = ContextUtils.applyContextValues(pivot.getContext(), contextValues, true);

		MdxCellSet mdxCellSet;
		try {
			mdxCellSet = MdxStreamHelper.executeContextually(pivot, mdxQuery);
		} catch (MdxException e) {
			throw new RuntimeException(e);
		} finally {
			ContextUtils.replaceContextValues(pivot.getContext(), oldCtx);
		}

		return MdxStreamHelper.convertToCellSetDTO(mdxCellSet, false);
	}

	public static IDrillthroughQuery makeDrillthrough(String measureName,
			ILocation firstLocation,
			ILocation... moreLocations) {
		return new DrillthroughQuery(Lists.asList(firstLocation, moreLocations), measureName);
	}

}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.location;

import java.util.Collections;
import java.util.Optional;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.ImmutableSet;
import com.quartetfs.biz.pivot.ILocation;
import com.quartetfs.biz.pivot.context.subcube.ISubCubeProperties;
import com.quartetfs.biz.pivot.context.subcube.ISubCubeTree;
import com.quartetfs.biz.pivot.cube.hierarchy.IHierarchyInfo;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevelInfo;
import com.quartetfs.biz.pivot.cube.hierarchy.axis.IAxisHierarchy;
import com.quartetfs.biz.pivot.cube.hierarchy.axis.IAxisMember;

/**
 * Helps manipulating {@link ISubCubeProperties}
 * 
 * @author Benoit Lacelle
 *
 */
public class ApexSubCubeHelper {
	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexSubCubeHelper.class);

	protected ApexSubCubeHelper() {
		// hidden
	}

	public static boolean isHierarchyExpressed(ILocation location,
			IHierarchyInfo hierarchy,
			ISubCubeProperties subCube) {
		if (subCube == null) {
			LOGGER.trace("The query on {} probably does not express any subcube", location);
			return false;
		} else {
			String dimensioName = hierarchy.getDimensionInfo().getName();
			int subCubeRestrictedDepth = subCube.isHierarchyRestricted(dimensioName, hierarchy.getName());

			if (subCubeRestrictedDepth >= 0) {
				return true;
			} else {
				return false;
			}
		}
	}

	public static boolean isLevelExpressed(ILocation location, ILevelInfo level, ISubCubeProperties subCube) {
		if (subCube == null) {
			LOGGER.trace("The query on {} probably does not express any subcube", location);
			return false;
		} else {
			IHierarchyInfo hierarchyInfo = level.getHierarchyInfo();
			String dimensioName = hierarchyInfo.getDimensionInfo().getName();
			int subCubeRestrictedDepth = subCube.isHierarchyRestricted(dimensioName, hierarchyInfo.getName());

			if (subCubeRestrictedDepth >= level.getOrdinal()) {
				return true;
			} else {
				return false;
			}
		}
	}

	public static Optional<ISubCubeTree> getSubCubeTree(ISubCubeProperties subCube, IHierarchyInfo hierarchy) {
		if (subCube == null) {
			// No subCube in current query
			return Optional.empty();
		} else {
			String dimensionName = hierarchy.getDimensionInfo().getName();

			ISubCubeTree subCubeTree = subCube.getSubCubeTree(dimensionName, hierarchy.getName());

			if (subCubeTree == null) {
				// No subCube on given hierarchy
				return Optional.empty();
			} else {
				return Optional.of(subCubeTree);
			}
		}
	}

	public static Optional<? extends Set<? extends IAxisMember>> getRestrictedPathes(ISubCubeProperties subCube,
			IAxisHierarchy hierarchy,
			int targetLevelDepth) {
		IHierarchyInfo hierarchyInfo = hierarchy.getHierarchyInfo();

		Optional<ISubCubeTree> subCubeTree = ApexSubCubeHelper.getSubCubeTree(subCube, hierarchyInfo);

		if (subCubeTree.isPresent()) {
			return getRestrictedPathes(subCubeTree.get(), hierarchy, targetLevelDepth);
		} else {
			return Optional.empty();
		}
	}

	public static Optional<? extends Set<? extends IAxisMember>> getRestrictedPathes(ISubCubeProperties subCube,
			IAxisHierarchy hierarchy) {
		IHierarchyInfo hierarchyInfo = hierarchy.getHierarchyInfo();

		Optional<ISubCubeTree> subCubeTree = ApexSubCubeHelper.getSubCubeTree(subCube, hierarchyInfo);

		if (subCubeTree.isPresent()) {
			return getRestrictedPathes(subCubeTree.get(), hierarchy, subCubeTree.get().getRestrictionDepth());
		} else {
			return Optional.empty();
		}
	}

	public static Optional<? extends Set<? extends IAxisMember>> getRestrictedPathes(ISubCubeTree subCubeTree,
			IAxisHierarchy hierarchy,
			int targetLevelDepth) {
		if (subCubeTree.getRestrictionDepth() >= targetLevelDepth) {
			Set<IAxisMember> path = subCubeTree.retrieveAxisMembers(targetLevelDepth, hierarchy);

			return Optional.ofNullable(path);
		} else {
			// No restriction down to given level (e.g. restriction on 2016 and we requested targetLevelDepth as Month
			// level)
			return Optional.empty();
		}
	}

	/**
	 * 
	 * @param subCube
	 * @param hierarchy
	 * @param targetLevelDepth
	 * @return the Set of discriminators explicitely included in the subCube. Empty if the level is not discriminated
	 */
	public static Set<?> getRestrictedDiscriminators(ISubCubeProperties subCube,
			IAxisHierarchy hierarchy,
			int targetLevelDepth) {
		Optional<? extends Set<? extends IAxisMember>> pathes =
				getRestrictedPathes(subCube, hierarchy, targetLevelDepth);

		if (!pathes.isPresent() || pathes.get().isEmpty()) {
			return Collections.emptySet();
		} else {
			ImmutableSet.Builder<Object> coordinates = ImmutableSet.builder();
			for (IAxisMember matching : pathes.get()) {
				coordinates.add(matching.getDiscriminator());
			}

			return coordinates.build();
		}
	}

}

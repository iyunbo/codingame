/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.cube.snapshot;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;
import java.util.stream.Stream;

import org.joda.time.LocalDateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;

import com.codahale.metrics.Timer;
import com.google.common.annotations.Beta;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Streams;
import com.qfs.store.IReadableDatastore;
import com.qfs.store.selection.IContinuousSelection;
import com.qfs.store.selection.impl.Selection;
import com.quartetfs.biz.pivot.IActivePivotManager;
import com.quartetfs.biz.pivot.IActivePivotVersion;
import com.quartetfs.biz.pivot.ILocation;
import com.quartetfs.biz.pivot.IMultiVersionActivePivot;
import com.quartetfs.biz.pivot.cellset.ICellSet;
import com.quartetfs.biz.pivot.cube.hierarchy.IHierarchy;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevel;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevelInfo;
import com.quartetfs.biz.pivot.cube.hierarchy.IMultiVersionHierarchy;
import com.quartetfs.biz.pivot.cube.hierarchy.axis.IAxisHierarchy;
import com.quartetfs.biz.pivot.query.IGetAggregatesQuery;

import blasd.apex.server.datastore.ApexDatastoreHelper;
import blasd.apex.server.datastore.listener.ApexTupleAccumulatingSelectionListener;
import blasd.apex.server.datastore.listener.IAccumulatingSelectionListener;
import blasd.apex.server.location.ApexLocationBuilder;
import blasd.apex.server.location.IApexLocationBuilder;
import blasd.apex.server.query.ApexDrillthroughHelper;
import blasd.apex.server.query.cellset.ApexCellSetHelper;
import blasd.apex.server.query.cellset.CoordinateAndAggregates;
import blasd.apex.server.query.hierarchy.ApexHierarchyHelper;
import blasd.apex.server.query.hierarchy.IApexAxisHierarchyInfo;
import blasd.apex.server.query.location.ApexLocationHelper;
import cormoran.pepper.jmx.PepperJMXHelper;
import cormoran.pepper.metrics.ITaskActivityEvent;

/**
 * The goal of the {@link AApexCubeSnapshooter} is to maintain a view of a cube along some levels and for some measures.
 * It is useful if these measures are slow to compute. We partition automatically the query in order not to run a single
 * huge query for the snapshot.
 * 
 * It can be used to produce a bunch of files representing some kind of report. It can also be used to feed another
 * cube, faster as it would not require to apply some post-processors.
 * 
 * @author Benoit Lacelle
 *
 */
@Beta
@ManagedResource
public abstract class AApexCubeSnapshooter<M extends Map<? extends ILevelInfo, ?>> extends AApexCubeQuerier<M, List<?>>
		implements IApexCubePartitionedSnapshooter<M, List<?>> {
	protected static final Logger LOGGER = LoggerFactory.getLogger(AApexCubeSnapshooter.class);

	protected final Set<ILevelInfo> levelsToSnapshot;

	protected final IPartitionGetAggregatesQueriesProvider<M, List<?>, IApexCubePartitionedSnapshooter<M, List<?>>> getAggregatesQueriesProvider;

	protected final AtomicReference<Object> latestStartedSnapshotId = new AtomicReference<>();

	public AApexCubeSnapshooter(Consumer<ITaskActivityEvent> eventBus,
			IMultiVersionActivePivot sourceCube,
			IPartitionGetAggregatesQueriesProvider<M, List<?>, IApexCubePartitionedSnapshooter<M, List<?>>> getAggregatesQueriesProvider,
			Collection<? extends ILevelInfo> levelsToSnapshot,
			Timer partitionTimer) {
		super(eventBus, sourceCube, partitionTimer);

		this.levelsToSnapshot = ImmutableSet.copyOf(levelsToSnapshot);

		this.getAggregatesQueriesProvider = getAggregatesQueriesProvider;
	}

	@ManagedOperation
	public void jmxSnapshot(String keyEqualsValueComa) {
		Map<String, String> stringMap = PepperJMXHelper.convertToMap(keyEqualsValueComa);

		M levelMap = (M) ApexLocationHelper.convertWithoutDatastore(getQueriedCube().getHierarchies(), stringMap);

		snapshot(levelMap);
	}

	@ManagedOperation
	public void jmxForceSnapshot(String keyEqualsValueComa) {
		Map<String, String> stringMap = PepperJMXHelper.convertToMap(keyEqualsValueComa);

		M levelMap = (M) ApexLocationHelper.convertWithoutDatastore(getQueriedCube().getHierarchies(), stringMap);

		forceSnapshot(levelMap);
	}

	@Override
	public IMultiVersionActivePivot getQueriedCube() {
		return sourceCube;
	}

	@Override
	public IPartitionGetAggregatesQueriesProvider<M, List<?>, IApexCubePartitionedSnapshooter<M, List<?>>> getPartitionGAQProvider() {
		return getAggregatesQueriesProvider;
	}

	@Override
	protected boolean compareAndSetSnapshotId(Object id) {
		// TODO: the method suggest an atomic operation which is not the case
		if (Objects.equals(id, latestStartedSnapshotId.get())) {
			LOGGER.debug("The snapshotId is still {}", id);
			return false;
		} else {
			setSnapshotId(id);
			return true;
		}
	}

	@Override
	protected void setSnapshotId(Object id) {
		latestStartedSnapshotId.set(id);
	}

	protected Stream<? extends Map<String, ?>> convertCellSetToRows(ICellSet cellset,
			List<? extends IHierarchy> hierarchies) {
		final List<? extends IApexAxisHierarchyInfo> axisHierarchiesInfo =
				ApexHierarchyHelper.extractApexAxisHierarchiesInfo(hierarchies);
		Collection<? extends CoordinateAndAggregates> coordinatesToValue =
				ApexCellSetHelper.convertToList(cellset, axisHierarchiesInfo);

		final List<String> measureNamesAsList = Arrays.asList(cellset.availableMeasures());

		return coordinatesToValue.stream().map(input -> convertToMap(input, measureNamesAsList, axisHierarchiesInfo));
	}

	@Override
	protected void processCellSet(IActivePivotVersion pivotToQuery, QueryAndResult<ICellSet> nextCellSet) {
		// Compute the partitionIds in this cellSet. If we split a cube by country, each cellset will hold the
		// data associated to a set of countries. Then, when inserting in the target store, we should remove the
		// data previously associated to these countries
		Set<? extends Map<? extends ILevelInfo, Object>> partitionIds = computePartitionIds(nextCellSet);

		LOGGER.info("We received {} locations for partitionIds={}",
				nextCellSet.result.getLocationCount(),
				partitionIds);

		Stream<? extends Map<String, ?>> asRows =
				convertCellSetToRows(nextCellSet.result, pivotToQuery.getHierarchies());

		publishPartition((Set) partitionIds, asRows);
	}

	/**
	 * This should be overridden to publish the result to the IDatastore, or to a file writer
	 */
	// TODO: remove this override?
	@Override
	protected abstract void publishPartition(Set<? extends M> partitionIds, Stream<? extends Map<String, ?>> asRows);

	protected Set<Map<ILevelInfo, Object>> computePartitionIds(QueryAndResult<ICellSet> nextCellSet) {
		Set<Map<ILevelInfo, Object>> partitionIds = new HashSet<>();

		IGetAggregatesQuery query = (IGetAggregatesQuery) nextCellSet.query;

		// For each queried location (as we could have 1 location per partition, or 2 partitions, each of them in a
		// dedicated location)
		for (ILocation queriedLocation : query.getLocations()) {
			// Extract the coordinate on the partition level: the associated result ICellSet will hold the whole data
			// (maybe empty) for this partition id
			Set<? extends ILevelInfo> partitionLevels =
					getAggregatesQueriesProvider.getCleanPartitionLevels(getQueriedCube().getHierarchies());

			Map<ILevelInfo, Object> partitionId = new HashMap<>();
			for (ILevelInfo leafPartitionLevel : partitionLevels) {

				IHierarchy h =
						ApexHierarchyHelper.getAxisHierarchy(getQueriedCube().getHierarchies(), leafPartitionLevel);

				for (ILevel partitionLevel : ApexHierarchyHelper.getInterestingLevels(h)) {
					if (partitionLevel.getOrdinal() > leafPartitionLevel.getOrdinal()) {
						// Do not consider levels deeper than the partition level
						break;
					} else {
						// We need to consider levels above the partition level (e.g. the partition Id if level is Month
						// of hierarchy Year/Month is then 2016/January)
						Object partitionCoordinate = ApexLocationHelper.getCoordinate(queriedLocation, partitionLevel);

						partitionId.put(partitionLevel.getLevelInfo(), partitionCoordinate);
					}
				}
			}

			if (partitionIds.add(partitionId)) {
				LOGGER.debug("Add as partitionId {} in {}", partitionId, this);
			} else {
				LOGGER.trace("Receive several rows for same partitionId {} in {}", partitionId, this);
			}

		}

		return partitionIds;
	}

	/**
	 * 
	 * @param input
	 * @param measureNamesAsList
	 * @param axisHierarchiesInfo
	 * @return A Map which holds as keys each level name and each measure
	 */
	protected Map<String, Object> convertToMap(CoordinateAndAggregates input,
			List<String> measureNamesAsList,
			List<? extends IApexAxisHierarchyInfo> axisHierarchiesInfo) {
		// Make tuple
		Map<String, Object> asTuple = new HashMap<>();

		List<? extends IMultiVersionHierarchy> hierarchies = sourceCube.getHierarchies();

		// For each coordinate in the CellSet, compute the key in the output Map
		for (Entry<String, ? extends List<?>> hNameToPath : input.hierarchyToPath.entrySet()) {
			IAxisHierarchy hierarchy = ApexHierarchyHelper.findAxisHierarchy(hierarchies, hNameToPath.getKey());

			List<? extends ILevel> interestingLevels = ApexHierarchyHelper.getInterestingLevels(hierarchy);

			// Iterate through the expressed coordinates
			for (int i = 0; i < hNameToPath.getValue().size(); i++) {
				ILevelInfo levelInfo = interestingLevels.get(i).getLevelInfo();

				String targetColumnName = getTargetColumnName(levelInfo);

				Object coordinate = hNameToPath.getValue().get(i);
				Object previousValue = asTuple.put(targetColumnName, coordinate);
				if (previousValue != null && !Objects.equals(previousValue, coordinate)) {
					throw new RuntimeException(
							"We have replaced " + previousValue + " by " + coordinate + " for " + targetColumnName);
				}
			}

		}

		// add each measure associate to its measure name
		for (int i = 0; i < measureNamesAsList.size(); i++) {
			String originalMeasureName = measureNamesAsList.get(i);
			String targetColumnName = getTargetColumnName(originalMeasureName);

			Object measureValue = input.measureValues.get(i);
			Object previousValue = asTuple.put(targetColumnName, measureValue);
			if (previousValue != null && !Objects.equals(previousValue, measureValue)) {
				throw new RuntimeException(
						"We have replaced " + previousValue + " by " + measureValue + " for " + targetColumnName);
			}
		}

		return asTuple;
	}

	protected String getTargetColumnName(String measureName) {
		// by default, we keep the measure name
		return measureName;
	}

	protected String getTargetColumnName(ILevelInfo levelInfo) {
		// Consider the uniqueId of the level
		return ApexHierarchyHelper.levelName(levelInfo);
	}

	/**
	 * 
	 * @param pivotVersion
	 * @return an ILocation with wildcard on the snapshotted levels
	 */
	@Override
	public ILocation makeSnapshotLocation(M snapshotParameters) {
		IApexLocationBuilder locationBuilder = new ApexLocationBuilder(getQueriedCube().getHierarchies())

				// Ensure details levels are expressed
				.wildcard(levelsToSnapshot)

				// Ensure partitions levels are expressed
				.wildcard(getAggregatesQueriesProvider.getRawPartitionLevels());

		// Add as filter the parameters of the incoming map
		for (Entry<? extends ILevelInfo, ?> entry : snapshotParameters.entrySet()) {
			locationBuilder.filter(entry.getKey(), entry.getValue());
		}

		return locationBuilder.build();
	}

	/**
	 * 
	 * @param apManager
	 * @param snapshooter
	 *            the snapshooter to trigger when a partition is updated
	 * @param nbPartitionBeforeAll
	 *            how many partitions should be listed before switching to a "recompute all partitions" mode
	 */
	public static <M extends Map<?, ?>> void registerAsBaseStoreListener(IActivePivotManager apManager,
			IApexCubeSnapshooter<M> snapshooter,
			IPartitionGetAggregatesQueriesProvider<M, List<?>, ?> queriesProvider,
			int nbPartitionBeforeAll) {
		IMultiVersionActivePivot pivot = snapshooter.getQueriedCube();

		String cubeName = pivot.getId();
		String baseStore = ApexDrillthroughHelper.findBaseStore(apManager, cubeName);

		// Consider the main ILocation to register a continuous query
		ILocation snapshotLocation = snapshooter.makeSnapshotLocation((M) Collections.emptyMap());

		List<String> partitionPathes = new ArrayList<>();

		// Given a partition on the second level (e.g. Year/Month), a commit on January should give a partition on
		// 2016/January
		for (ILevelInfo interestingLevel : queriesProvider.getCleanPartitionLevels(pivot.getHierarchies())) {
			if (ApexLocationHelper.checkCoordinate(snapshotLocation, interestingLevel)) {
				// This level is both in the partition expression and in the queried location
				String partitionPath =
						ApexDrillthroughHelper.findFieldPathForLevel(interestingLevel, cubeName, apManager);

				if (ApexDatastoreHelper.splitFieldPath(partitionPath).size() != 1) {
					LOGGER.info("We will do update over a referenced field: {}", partitionPath);
				}

				partitionPathes.add(partitionPath);
			}
		}

		// Track all fields underlying partition level
		Selection selection = new Selection(baseStore, partitionPathes.toArray(new String[0]));

		IReadableDatastore datastore = apManager.getDatastore();

		// Register the listener in the datastore
		{
			IAccumulatingSelectionListener<List<?>> listener =
					new ApexTupleAccumulatingSelectionListener(nbPartitionBeforeAll, datastore, selection);

			listener.registerListener(queriesProvider);

			IContinuousSelection continuousSelection = datastore.register(selection);

			continuousSelection.addListener(listener);
		}
	}

	/**
	 * 
	 * @return how many partitions have been recomputed
	 */
	@Override
	public long flushPendingPartitions() {
		Stream<? extends IGetAggregatesQuery> locations = getAggregatesQueriesProvider.flushPendingPartitions(this);

		// Consume the stream to check if there is at least one item
		Iterator<? extends IGetAggregatesQuery> iterator = locations.iterator();

		if (iterator.hasNext()) {
			LOGGER.info("There is {} pending partitions in {}", "?", this);

			// Request to compute all queries for pending partitions
			String snapshotedId = "Flush at " + LocalDateTime.now();

			// We need to wrap back the iterator, as the stream as been consumed to build the iterator
			return computeQueries(getVersionToSnpashot(), Streams.stream(iterator), snapshotedId);
		} else {
			LOGGER.info("There is no pending partitions in {}", this);

			return 0;
		}
	}

	@Override
	protected Stream<? extends IGetAggregatesQuery> partitionedQueries() {
		return getAggregatesQueriesProvider.getPartitionedQueries(this);
	}

	public static Set<Map<String, ?>> convertToTarget(AApexCubeSnapshooter<?> snapshooter,
			Set<? extends Map<? extends ILevelInfo, ?>> partitionIds) {
		Set<Map<String, ?>> asString = new HashSet<>();

		for (Map<? extends ILevelInfo, ?> partition : partitionIds) {
			Map<String, Object> asStringMap = new HashMap<>();
			for (Entry<? extends ILevelInfo, ?> entry : partition.entrySet()) {
				asStringMap.put(snapshooter.getTargetColumnName(entry.getKey()), entry.getValue());
			}
			asString.add(asStringMap);
		}

		return asString;
	}
}

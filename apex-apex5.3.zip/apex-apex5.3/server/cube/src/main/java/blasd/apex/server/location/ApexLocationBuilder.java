/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.location;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.quartetfs.biz.pivot.IActivePivotManager;
import com.quartetfs.biz.pivot.IActivePivotVersion;
import com.quartetfs.biz.pivot.ILocation;
import com.quartetfs.biz.pivot.IMultiVersionActivePivot;
import com.quartetfs.biz.pivot.cube.hierarchy.IHierarchy;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevel;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevelInfo;
import com.quartetfs.biz.pivot.cube.hierarchy.axis.IAxisHierarchy;
import com.quartetfs.biz.pivot.impl.Location;
import com.quartetfs.biz.pivot.query.impl.ActivePivotVersionQueryHelper;

import blasd.apex.server.query.hierarchy.ApexHierarchyHelper;
import blasd.apex.server.query.location.ApexLocationHelper;

/**
 * Helps building an ILocation object
 * 
 * @author Benoit Lacelle
 *
 */
public class ApexLocationBuilder implements IApexLocationBuilder, Cloneable {
	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexLocationBuilder.class);

	protected final IActivePivotVersion pivotVersion;
	protected final ILocation baseLocation;
	protected final List<? extends IHierarchy> hierarchies;

	// Not final for .clone
	protected Map<ILevelInfo, Object> levelToValueToSet = new HashMap<>();

	/**
	 * By default, we keep wildcards on slicing hierarchies to see all top {@link ILocation}
	 */
	protected boolean defaultValuesOnNotExpressedSlicingHierarchies;

	/**
	 * 
	 * @param pivotVersion
	 *            we need an actual version for default member resolution
	 */
	public ApexLocationBuilder(IActivePivotVersion pivotVersion) {
		this.pivotVersion = pivotVersion;
		this.baseLocation = null;
		this.hierarchies = pivotVersion.getHierarchies();
	}

	/**
	 * @param baseLocation
	 *            the underlying {@link ILocation}. If not used, we will process over a top ILocation
	 */
	public ApexLocationBuilder(ILocation baseLocation) {
		this.pivotVersion = null;
		this.baseLocation = baseLocation;
		this.hierarchies = null;
	}

	public ApexLocationBuilder(List<? extends IHierarchy> hierarchies) {
		this.pivotVersion = null;
		this.baseLocation = null;
		this.hierarchies = hierarchies;
	}

	@Override
	public String toString() {
		return "ApexLocationBuilder: " + levelToValueToSet.toString();
	}

	@Override
	public ApexLocationBuilder clone() { // NOPMD Can remove //NOPMD with Apex-core1.6
		try {
			final ApexLocationBuilder clone = (ApexLocationBuilder) super.clone();

			// Deep clone the mutable not-primitive fields
			clone.levelToValueToSet = new HashMap<>(clone.levelToValueToSet);

			return clone;
		} catch (CloneNotSupportedException e) {
			throw new RuntimeException(e);
		}
	}

	public static IApexLocationBuilder on(IActivePivotVersion pivot) {
		return on(pivot.getHierarchies());
	}

	public static IApexLocationBuilder on(IMultiVersionActivePivot pivot) {
		return on(pivot.getHierarchies());
	}

	/**
	 * @param baseLocation
	 *            the underlying {@link ILocation}. If not used, we will process over a top ILocation
	 */
	public static IApexLocationBuilder on(ILocation baseLocation) {
		return new ApexLocationBuilder(baseLocation);
	}

	public static IApexLocationBuilder on(List<? extends IHierarchy> hierarchies) {
		return new ApexLocationBuilder(hierarchies);
	}

	public static IApexLocationBuilder on(IActivePivotManager activePivotmanager, String pivotId) {
		IActivePivotVersion pivot = activePivotmanager.getActivePivots().get(pivotId).getHead();

		return on(pivot);
	}

	@Override
	public IApexLocationBuilder filter(Map<String, ?> levelNamesToValues) {
		for (Entry<String, ?> entry : levelNamesToValues.entrySet()) {
			filter(entry.getKey(), entry.getValue());
		}

		return this;
	}

	@Override
	public IApexLocationBuilder filterLevels(Map<? extends ILevelInfo, ?> levelNamesToValues) {
		for (Entry<? extends ILevelInfo, ?> entry : levelNamesToValues.entrySet()) {
			filter(entry.getKey(), entry.getValue());
		}

		return this;
	}

	/**
	 * Beware using only actual value could lead to range locations. For instance, if you set only the third level of a
	 * dimension, the second level will be left with a wildacard while originally the location was on AllMember
	 */
	@Override
	public IApexLocationBuilder filter(String levelAsString, Object value) {
		ILevel level = ApexHierarchyHelper.findLevel(hierarchies, levelAsString);

		if (level == null) {
			throw new IllegalArgumentException("There is no level named " + levelAsString);
		}

		return filter(level.getLevelInfo(), value);
	}

	@Override
	public IApexLocationBuilder filter(String levelAsString, String hierarchyAsString, Object value) {
		ILevel level = ApexHierarchyHelper.findLevel(hierarchies, null, hierarchyAsString, levelAsString);

		return filter(level.getLevelInfo(), value);
	}

	@Override
	public IApexLocationBuilder filter(String levelAsString,
			String hierarchyAsString,
			String dimensionAsString,
			Object value) {
		ILevel level = ApexHierarchyHelper.findLevel(hierarchies, dimensionAsString, hierarchyAsString, levelAsString);

		return filter(level.getLevelInfo(), value);
	}

	@Override
	public IApexLocationBuilder filter(String hierarchyName, int levelIndexSkippingAll, Object value) {
		IHierarchy hierarchy = ApexHierarchyHelper.findAxisHierarchy(hierarchies, hierarchyName);

		ILevel level = ApexHierarchyHelper.getInterestingLevels(hierarchy).get(levelIndexSkippingAll);

		return filter(level.getLevelInfo(), value);
	}

	@Override
	public IApexLocationBuilder wildcard(Iterable<? extends ILevelInfo> wildcardLevels) {
		for (ILevelInfo wildcardLevel : wildcardLevels) {
			filter(wildcardLevel, null);
		}

		return this;
	}

	@Override
	public IApexLocationBuilder wildcard(Collection<? extends String> wildcardLevels) {
		for (String wildcardLevel : wildcardLevels) {
			filter(wildcardLevel, null);
		}

		return this;
	}

	@Override
	public IApexLocationBuilder filter(ILevelInfo level, Object value) {
		if (levelToValueToSet.containsKey(level)) {
			Object previousValue = levelToValueToSet.get(level);

			if (previousValue == null) {
				// Keep the new condition which is more restricted
				unsafeFilter(level, value);
			} else if (value == null) {
				LOGGER.trace("Keep the old value");
			} else if (!Objects.equals(previousValue, value)) {
				throw new IllegalArgumentException(
						"The level " + level + " is already set to " + previousValue + ", can not set to " + value);
			} else {
				assert previousValue.equals(value);
			}
		} else {
			unsafeFilter(level, value);
		}

		return this;
	}

	private void unsafeFilter(ILevelInfo level, Object value) {
		levelToValueToSet.put(level, value);
	}

	@Override
	public IApexLocationBuilder setDefaultValuesOnSlicingHierarchies() {
		// defaultValuesOnNotExpressedSlicingHierarchies = true;
		//
		// return this;
		throw new UnsupportedOperationException("TODO");
	}

	@Override
	public IApexLocationBuilder setWildcardsOnSlicingHierarchies() {
		defaultValuesOnNotExpressedSlicingHierarchies = false;

		return this;
	}

	@Override
	public ILocation build() {
		ILocation topLocation;
		if (baseLocation != null) {
			topLocation = baseLocation;
		} else if (pivotVersion != null) {
			// Cache this location
			// ActivePivotVersionQueryHelper will keep null on slicing
			// hierarchies
			topLocation = new ActivePivotVersionQueryHelper(pivotVersion).computeLocation(Collections.emptyMap());

		} else if (hierarchies != null) {
			List<? extends IAxisHierarchy> axisHierarchies = ApexHierarchyHelper.filterAxisHierarchies(hierarchies);

			int nbAxisHierarchy = axisHierarchies.size();

			Object[][] coordinates = new Object[nbAxisHierarchy][];

			for (int i = 0; i < nbAxisHierarchy; i++) {
				IAxisHierarchy axisHierarchy = axisHierarchies.get(i);
				if (ApexHierarchyHelper.isAllMembersEnabled(axisHierarchy)) {
					coordinates[i] = new Object[] { ILevel.ALLMEMBER };
				} else {
					// TODO: ability to set default member
					coordinates[i] = new Object[] { null };
				}
			}
			topLocation = new Location(coordinates);
		} else {
			throw new IllegalStateException("Everything is null");
		}

		return ApexLocationHelper.setCoordinates(topLocation, levelToValueToSet, false);
	}

	@Override
	public IApexLocationBuilder wildcard(String... wildcardLevels) {
		return wildcard(Arrays.asList(wildcardLevels));
	}

	@Override
	public IApexLocationBuilder wildcard(String hierarchyName, int levelIndexSkipAll) {
		return filter(hierarchyName, levelIndexSkipAll, null);
	}

	@Override
	public IApexLocationBuilder wildcardOne(String levelAsString, String hierarchyAsString) {
		return filter(levelAsString, hierarchyAsString, null);
	}

}

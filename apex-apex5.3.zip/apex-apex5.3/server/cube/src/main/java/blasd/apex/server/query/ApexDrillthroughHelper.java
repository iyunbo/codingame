/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query;

import java.util.List;

import com.qfs.store.IFieldInformation;
import com.qfs.store.selection.ISelection;
import com.qfs.store.selection.ISelectionField;
import com.quartetfs.biz.pivot.IActivePivot;
import com.quartetfs.biz.pivot.IActivePivotManager;
import com.quartetfs.biz.pivot.IActivePivotSchema;
import com.quartetfs.biz.pivot.IMultiVersionActivePivot;
import com.quartetfs.biz.pivot.context.drillthrough.IDrillthroughHeader;
import com.quartetfs.biz.pivot.context.drillthrough.IDrillthroughRow;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevel;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevelInfo;
import com.quartetfs.biz.pivot.cube.hierarchy.IMultiVersionHierarchy;

import blasd.apex.server.datastore.ApexDatastoreHelper;
import blasd.apex.server.query.hierarchy.ApexHierarchyHelper;

/**
 * Helpers related to drillthrough queries
 * 
 * @author Benoit Lacelle
 *
 */
public class ApexDrillthroughHelper {
	protected ApexDrillthroughHelper() {
		// hidden
	}

	/**
	 * 
	 * @param apManager
	 * @param pivotId
	 * @return the store name which is the base store of given {@link IActivePivot}
	 */
	public static String findBaseStore(IActivePivotManager apManager, String pivotId) {
		return findOwningSchema(apManager, pivotId).getDescription().getDatastoreSelection().getBaseStore();
	}

	public static IActivePivotSchema findOwningSchema(IActivePivotManager apManager, String pivotId) {
		for (IActivePivotSchema apSchema : apManager.getSchemas().values()) {
			if (apSchema.getPivotIds().contains(pivotId)) {
				return apSchema;
			}
		}

		// We found no matching store
		throw new RuntimeException("No cube named " + pivotId + ". Cubes are: " + apManager.getActivePivots().keySet());
	}

	public static String findCubeForStore(IActivePivotManager apManager, String storeName) {
		for (IActivePivotSchema schema : apManager.getSchemas().values()) {
			if (schema.getDatastoreSession().getBaseStoreMetadata().getName().equals(storeName)) {
				if (schema.getPivotIds().size() != 1) {
					throw new RuntimeException(
							"There is not a single cube for " + storeName + ": " + schema.getPivotIds());
				} else {
					return schema.getPivotIds().iterator().next();
				}
			}
		}

		// We found no matching store
		throw new RuntimeException("No cube for store name " + storeName);
	}

	public static Object[] makeKey(IActivePivotManager apManager, String pivotId, IDrillthroughRow row) {
		final String baseStore = findBaseStore(apManager, pivotId);

		return ApexDatastoreHelper.buildKeyTuple(apManager.getDatastore(), baseStore, row.getContent());
	}

	/**
	 * 
	 * @param levelName
	 * @param hierarchyName
	 * @param cubeName
	 * @param apManager
	 * @param datastore
	 * @return the path to the field which is the underlying of given level
	 */
	public static String findFieldPathForLevel(String levelName,
			String hierarchyName,
			String cubeName,
			IActivePivotManager apManager) {
		List<? extends IMultiVersionHierarchy> hierarchies = apManager.getActivePivots().get(cubeName).getHierarchies();
		ILevel level = ApexHierarchyHelper.findLevel(hierarchies, null, hierarchyName, levelName);

		return findFieldPathForLevel(level.getLevelInfo(), cubeName, apManager);
	}

	public static String findFieldPathForLevel(ILevelInfo level, String cubeName, IActivePivotManager apManager) {
		IActivePivotSchema schema = ApexDrillthroughHelper.findOwningSchema(apManager, cubeName);

		return findFieldPathForLevel(level, schema.getDatastoreSession());
	}

	public static String findFieldPathForLevel(ILevelInfo level, IFieldInformation fieldInformation) {
		String selectionFieldName = level.getField().getProperty().getName();

		return fieldInformation.getFieldExpressions().get(selectionFieldName);
	}

	/**
	 * 
	 * @param fieldName
	 *            the name of the IField for which you need an ILevel
	 * @param storeName
	 *            the name of the store holding this field
	 * @param apManager
	 *            the IActivePivotManager holding the cube
	 * @param cubeName
	 *            the name of the cube for which you need an ILevel
	 * @return an ILevel which is based on the request field, or null of the search has been fruitless
	 */
	public static ILevel findLevelForDatastoreColumn(String fieldName,
			String storeName,
			IActivePivotManager apManager,
			String cubeName) {
		String selectionFieldName = findSelectionFieldForField(apManager, storeName, fieldName, cubeName);

		if (selectionFieldName == null) {
			// There is no selectionFields for this field
			return null;
		} else {
			return findLevelForSelectionName(apManager, selectionFieldName, cubeName);
		}
	}

	public static ILevel findLevelForSelectionName(IActivePivotManager apManager,
			String selectionFieldName,
			String cubeName) {
		IMultiVersionActivePivot pivot = apManager.getActivePivots().get(cubeName);

		// Search
		for (IMultiVersionHierarchy h : pivot.getHierarchies()) {
			for (ILevel l : h.getLevels()) {
				if (selectionFieldName.equals(l.getLevelInfo().getField().getProperty().getName())) {
					return l;
				}
			}
		}

		// No level has been found
		return null;
	}

	public static String findSelectionFieldForField(IActivePivotManager apManager,
			String storeName,
			String fieldName,
			String cubeName) {
		// First we need the position of the field in the IDatastore
		int fieldIndex = apManager.getDatastore()
				.getSchemaMetadata()
				.getStoreMetadata(storeName)
				.getStoreFormat()
				.getRecordFormat()
				.getFieldIndex(fieldName);

		if (fieldIndex < 0) {
			// The field does not exist in the store
			return null;
		}

		IActivePivotSchema schema = ApexDrillthroughHelper.findOwningSchema(apManager, cubeName);

		// Second we need the name of of field selection matching this field
		String selectionFieldName = null;
		outer: for (ISelection s : schema.getDatastoreSession().getSelection().getSelections()) {
			for (ISelectionField sf : s.getFields()) {
				// TODO: Currently, we manage fields only in the baseStore, not
				// in an enrichment store
				if (fieldName.equals(sf.getExpression())) {
					selectionFieldName = sf.getName();
					break outer;
				}
			}
		}

		return selectionFieldName;
	}

	public static int getFieldIndex(Iterable<? extends IDrillthroughHeader> drillthroughHeaders, String fieldName) {
		int index = 0;
		for (IDrillthroughHeader header : drillthroughHeaders) {
			if (fieldName.equals(header.getName())) {
				return index;
			}

			index++;
		}

		return -1;
	}

	public static Object getLevelValue(IActivePivotManager apManager,
			String cubeName,
			IDrillthroughRow row,
			String levelId) {
		String field = findFieldPathForLevel(levelId, null, cubeName, apManager);
		String baseStore = findBaseStore(apManager, cubeName);
		int fieldIndex = ApexDatastoreHelper.getFieldIndex(apManager.getDatastore(), baseStore, field);

		return row.getContent()[fieldIndex];
	}
}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.drillthrough;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.atomic.AtomicBoolean;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.annotations.Beta;
import com.google.common.base.Optional;
import com.qfs.condition.ICondition;
import com.qfs.store.IFieldInformation;
import com.qfs.store.IFilteredFieldInformation;
import com.qfs.store.Types;
import com.quartetfs.biz.pivot.IActivePivot;
import com.quartetfs.biz.pivot.IActivePivotSchema;
import com.quartetfs.biz.pivot.ILocation;
import com.quartetfs.biz.pivot.context.subcube.ICubeFilter;
import com.quartetfs.biz.pivot.context.subcube.impl.CubeFilter;
import com.quartetfs.biz.pivot.cube.hierarchy.IHierarchy;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevel;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevelInfo;
import com.quartetfs.biz.pivot.cube.hierarchy.measures.IAggregatedMeasure;
import com.quartetfs.biz.pivot.cube.hierarchy.measures.IMeasureMember;
import com.quartetfs.biz.pivot.cube.hierarchy.measures.IMeasuresProvider;
import com.quartetfs.biz.pivot.cube.hierarchy.measures.IPostProcessedMeasure;
import com.quartetfs.biz.pivot.definitions.IField;
import com.quartetfs.biz.pivot.impl.ActivePivotVersion;
import com.quartetfs.biz.pivot.postprocessing.IPostProcessor;
import com.quartetfs.biz.pivot.postprocessing.IPrefetchRequest;
import com.quartetfs.biz.pivot.postprocessing.IPrefetcher;
import com.quartetfs.biz.pivot.query.IDrillthroughQuery;
import com.quartetfs.biz.pivot.query.ILocationInterpreter;
import com.quartetfs.fwk.query.IAttachedQuery;
import com.quartetfs.fwk.query.IContinuousQuery;
import com.quartetfs.fwk.types.impl.ExtendedPluginInjector;

import blasd.apex.server.datastore.condition.ApexConditionHelper;
import blasd.apex.server.query.ApexDrillthroughHelper;
import blasd.apex.server.query.hierarchy.ApexHierarchyHelper;
import blasd.apex.server.query.location.ApexLocationAcceptor;
import cormoran.pepper.collection.CartesianProductHelper;
import cormoran.pepper.logging.PepperLogHelper;

/**
 * This {@link ILocationInterpreter} relies on IPrefetcher do compute the actual ICondition for the facts having
 * contribute to a measure for a location
 * 
 * To activate this feature, use ApexDrillthroughExecutor.PLUGIN_KEY in the cube description
 * 
 * Serializable as HorizontalDrillthroughExecutor.execute(IDrillthroughQuery, ILocationInterpreter) will submit the
 * ILocationInterpreter over the network
 * 
 * @author Benoit Lacelle
 * 
 *         Do not extend DefaultLocationInterpreter which is not Serializable-friendly
 *         https://support.quartetfs.com/jira/browse/APS-8028
 * @see ApexDrillthroughExecutor
 */
@Beta
public class ApexLocationInterpreter implements ILocationInterpreter {
	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexLocationInterpreter.class);

	protected transient IFieldInformation fieldInformations;

	protected ApexLocationInterpreter(IFieldInformation fieldInformations) {
		this.fieldInformations = fieldInformations;
	}

	@Override
	public ICondition buildCondition(IActivePivot pivot,
			Collection<ILocation> baseLocations,
			Collection<String> measures) {
		if (fieldInformations == null) {
			if (pivot instanceof ActivePivotVersion) {
				ILocationInterpreter niceInterpreter =
						makeNiceLocationInterpreter(((ActivePivotVersion) pivot).getSession().getFieldInformations());

				return niceInterpreter.buildCondition(pivot, baseLocations, measures);
			} else {
				throw new UnsupportedOperationException("We need pivot which is a ActivePivotVersion. It was a "
						+ PepperLogHelper.getObjectAndClass(pivot));
			}
		} else {
			// Compute conditions as Maps
			Set<Map<? extends String, ?>> allConditions = actualBuildCondition(pivot, baseLocations, measures);

			// Compute a covering Cartesian product in order to have a faster drill-through
			Set<? extends Map<String, ? extends Set<?>>> coveringCartesianProduct =
					CartesianProductHelper.groupByKeyAndInValues(allConditions);

			// Convert to an actual ICondition object
			return ApexConditionHelper.convertToCondition(coveringCartesianProduct);
		}
	}

	protected Set<Map<? extends String, ?>> actualBuildCondition(IActivePivot pivot,
			Collection<ILocation> locations,
			Collection<String> measures) {
		Set<Map<? extends String, ?>> allLocationConditions = new HashSet<>();

		IMeasuresProvider measuresProvider = pivot.getMeasuresProvider();
		ICubeFilter cubeFilter = pivot.getContext().get(ICubeFilter.class);

		if (cubeFilter == null) {
			// In drillthrough queries, we may have no ICubeFilter initialized by default
			cubeFilter = CubeFilter.NO_FILTER;
		}

		// COnsider all requested locations
		for (ILocation location : locations) {
			List<? extends IHierarchy> hierarchies = ApexHierarchyHelper.filterAxisHierarchies(pivot.getHierarchies());

			Queue<MeasureAndLocationDTO> prefetchQueue = new LinkedBlockingQueue<>();

			// Consider all requested measures
			for (String measure : measures) {
				IMeasureMember measureMember = measuresProvider.getMeasure(measure);
				prefetchQueue.add(new MeasureAndLocationDTO(measureMember, location));
			}

			// Iterate until the queue is empty
			while (!prefetchQueue.isEmpty()) {
				MeasureAndLocationDTO prefetchMe = prefetchQueue.poll();

				// Addinf a condition may push more measure/location in the queue
				Collection<? extends Map<? extends String, ?>> conditions =
						addConditionFromMeasure(cubeFilter, measuresProvider, hierarchies, prefetchMe, prefetchQueue);
				allLocationConditions.addAll(conditions);
			}
		}

		return allLocationConditions;
	}

	protected Collection<? extends Map<? extends String, ?>> addConditionFromMeasure(ICubeFilter cubeFilter,
			IMeasuresProvider measuresProvider,
			List<? extends IHierarchy> hierarchies,
			MeasureAndLocationDTO poll,
			Queue<MeasureAndLocationDTO> sink) {
		// Extract the condition for axis hierarchies
		final Optional<Map<String, Object>> naturalCondition =
				convertFromLevelToField(locationConditionsAsMap(hierarchies, poll.location));

		IMeasureMember measureMember = poll.measureMember;

		if (measureMember instanceof IPostProcessedMeasure<?>) {
			IPostProcessedMeasure<?> postProcessorMember = (IPostProcessedMeasure<?>) measureMember;
			IPostProcessor<?> actualPP = measuresProvider.getPostProcessor(postProcessorMember);

			// Add the underlying measures
			sink.addAll(addMany2ManyCondition(cubeFilter, measuresProvider, actualPP, poll.location));

			// No condition comes directly from Many2Many: we may have an underlying Many2Many measure
			return Collections.emptyList();
		} else if (measureMember instanceof IAggregatedMeasure) {
			if (hasAnalysisSecondLevel(hierarchies, poll.location)) {
				// ActivePivot propagates AnalysisLevel only along the first level
				return Collections.emptyList();
			} else {
				// We have a natural measure: keep the original condition
				return Arrays.asList(naturalCondition.get());
			}
		} else {
			LOGGER.debug("Unexpexted case: {}", measureMember.getClass());
			return Arrays.asList(naturalCondition.get());
		}
	}

	protected List<MeasureAndLocationDTO> addMany2ManyCondition(ICubeFilter cubeFilter,
			IMeasuresProvider measuresProvider,
			IPostProcessor<?> actualPP,
			ILocation location) {
		List<MeasureAndLocationDTO> underlyingMeasures = new ArrayList<>();

		for (IPrefetcher<?> prefetcher : actualPP.getPrefetchers()) {
			for (IPrefetchRequest<?> retrieval : prefetcher.computePrefetches(location, cubeFilter)) {
				for (IMeasureMember underlyingMeasure : retrieval.getMeasures()) {
					underlyingMeasures.add(new MeasureAndLocationDTO(underlyingMeasure, retrieval.getLocation()));
				}
			}
		}

		return underlyingMeasures;
	}

	protected ILocationInterpreter makeNiceLocationInterpreter(IFilteredFieldInformation fieldInformations) {
		return new ApexLocationInterpreter(fieldInformations);
	}

	protected Map<ILevelInfo, ?> locationConditionsAsMap(final List<? extends IHierarchy> hierarchies,
			ILocation location) {
		final Map<ILevelInfo, Object> fieldExpressionToCondition = new HashMap<>();

		// SubCube are handled somewhere else
		ApexLocationAcceptor.acceptLocation(location, (hierarchyIndex, levelDepth, coordinate) -> {

			ILevel level = hierarchies.get(hierarchyIndex).getLevels().get(levelDepth);

			if (!level.getLevelInfo().getClassificationType().canBeInProvider()) {
				LOGGER.debug("We skip condition on {}", level.getName());
				return;
			}

			if (coordinate == null) {
				LOGGER.trace("There is no constrain associated to a null coordinate. Level={}", level);
			} else {
				fieldExpressionToCondition.put(level.getLevelInfo(), coordinate);
			}
		});

		return fieldExpressionToCondition;
	}

	// ActivePivot propagate native measures only along the first level of analysis hierarchies: we should do the same
	protected boolean hasAnalysisSecondLevel(final List<? extends IHierarchy> hierarchies, ILocation location) {
		// By default, we expect not to find one
		final AtomicBoolean hasAnalysisSecondLevel = new AtomicBoolean(false);

		// SubCube are handled somewhere else
		ApexLocationAcceptor.acceptLocation(location, (hierarchyIndex, levelDepth, coordinate) -> {

			if (levelDepth < 1) {
				return;
			} else {

				ILevel level = hierarchies.get(hierarchyIndex).getLevels().get(levelDepth);

				if (level.getLevelInfo().getClassificationType().isAnalysis()) {
					hasAnalysisSecondLevel.set(true);
				}
			}
		});

		return hasAnalysisSecondLevel.get();
	}

	/**
	 * 
	 * @param levelToConstrain
	 * @return a mapping from a field path to a field valid, describing the same constrain as input cube template
	 */
	protected Optional<Map<String, Object>> convertFromLevelToField(Map<? extends ILevelInfo, ?> levelToConstrain) {
		final Map<String, Object> fieldExpressionToCondition = new HashMap<>();

		for (Entry<? extends ILevelInfo, ?> entry : levelToConstrain.entrySet()) {
			ILevelInfo level = entry.getKey();
			Object coordinate = entry.getValue();

			IField field = level.getField();

			if (field == null) {
				LOGGER.debug("We skip field {}. It may be a analysis level", field);
				return Optional.absent();
			} else {
				if (Types.isDictionary(field.getDataType())) {
					String fieldExpression =
							ApexDrillthroughHelper.findFieldPathForLevel(level, getFieldInformations());

					// TODO: reject if false
					CartesianProductHelper
							.intersectCoordinates(fieldExpressionToCondition, fieldExpression, coordinate);
					fieldExpressionToCondition.put(fieldExpression, coordinate);
				} else {
					throw new UnsupportedOperationException("All fields must be dictionarized: " + field);
				}
			}
		}

		return Optional.of(fieldExpressionToCondition);
	}

	protected IFieldInformation getFieldInformations() {
		return this.fieldInformations;
	}

	/**
	 * @deprecated Probably useless
	 */
	@Deprecated
	public static void install(IActivePivotSchema activePivotSchema) {
		install(activePivotSchema.getDatastoreSession());
	}

	/**
	 * Install IFieldInformation once and for all.
	 * 
	 * TODO: is it required?
	 * 
	 * @param fieldInformation
	 * @deprecated Probably useless
	 */
	@Deprecated
	public static void install(IFieldInformation fieldInformation) {
		ILocationInterpreter locationInterpreter = new ApexLocationInterpreter(fieldInformation);
		ExtendedPluginInjector.inject(IAttachedQuery.class, IDrillthroughQuery.PLUGIN_KEY, locationInterpreter);
		ExtendedPluginInjector.inject(IContinuousQuery.class, IDrillthroughQuery.PLUGIN_KEY, locationInterpreter);
	}
}

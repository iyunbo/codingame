/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.cellset;

import java.util.List;
import java.util.NavigableMap;
import java.util.Objects;

import com.quartetfs.biz.pivot.cellset.ICellSet;

/**
 * Wrap together a point and its measures
 * 
 * @author Benoit Lacelle
 * @see ICellSet
 */
// final as DTO class
public final class CoordinateAndAggregates {
	public final NavigableMap<String, ? extends List<?>> hierarchyToPath;
	public final List<? extends String> measureNames;
	public final List<?> measureValues;

	public CoordinateAndAggregates(NavigableMap<String, ? extends List<?>> coordinates,
			List<? extends String> measureNames,
			List<Object> values) {
		Objects.requireNonNull(coordinates);
		Objects.requireNonNull(measureNames);
		Objects.requireNonNull(values);

		if (measureNames.size() != values.size()) {
			throw new RuntimeException("We received incompatible measures " + measureNames + " with values " + values);
		}

		this.hierarchyToPath = coordinates;
		this.measureNames = measureNames;
		this.measureValues = values;
	}

	@Override
	public String toString() {
		return "CoordinateAndAggregates [coordinates=" + hierarchyToPath + ", values=" + measureValues + "]";
	}

}

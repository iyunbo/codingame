/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.test.pivot;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Queue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.stream.Collectors;

import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.qfs.agg.IAggregationFunction;
import com.qfs.desc.IDatastoreSchemaDescription;
import com.qfs.desc.IFieldDescription;
import com.qfs.desc.IReferenceDescription;
import com.qfs.desc.IStoreDescription;
import com.qfs.literal.ILiteralType;
import com.qfs.store.selection.ISelectionField;
import com.qfs.store.selection.impl.SelectionField;
import com.quartetfs.biz.pivot.definitions.IActivePivotDescription;
import com.quartetfs.biz.pivot.definitions.IActivePivotInstanceDescription;
import com.quartetfs.biz.pivot.definitions.IActivePivotManagerDescription;
import com.quartetfs.biz.pivot.definitions.IActivePivotSchemaDescription;
import com.quartetfs.biz.pivot.definitions.IActivePivotSchemaInstanceDescription;
import com.quartetfs.biz.pivot.definitions.ICatalogDescription;
import com.quartetfs.biz.pivot.definitions.ISelectionDescription;
import com.quartetfs.biz.pivot.definitions.impl.ActivePivotInstanceDescription;
import com.quartetfs.biz.pivot.definitions.impl.ActivePivotManagerDescription;
import com.quartetfs.biz.pivot.definitions.impl.ActivePivotSchemaDescription;
import com.quartetfs.biz.pivot.definitions.impl.ActivePivotSchemaInstanceDescription;
import com.quartetfs.biz.pivot.definitions.impl.CatalogDescription;
import com.quartetfs.biz.pivot.definitions.impl.SelectionDescription;
import com.quartetfs.fwk.Registry;

import blasd.apex.server.config.description.ApexDescriptionHelper;
import blasd.apex.server.datastore.ApexDatastoreHelper;
import blasd.apex.server.datastore.test.ApexTestDatastoreHelper;
import blasd.apex.server.query.memory.ApexActivePivotManagerBuilderHelper;

/**
 * Helps method for cube description
 * 
 * @author Benoit Lacelle
 * @see IActivePivotManagerDescription
 *
 */
public class ApexActivePivotDescriptionHelper {
	protected ApexActivePivotDescriptionHelper() {
		// hidden
	}

	public static IActivePivotManagerDescription makeManagerDescription(
			List<? extends IActivePivotSchemaInstanceDescription> schemaDescriptions) {
		// TODO: we can not rely on ActiveViam builders as they would not accept an input
		// IActivePivotSchemaInstanceDescription
		// IActivePivotManagerDescriptionBuilder builder =
		// StartBuilding.managerDescription().withCatalog(ApexActivePivotManagerBuilderHelper.DEFAULT_CATALOG_NAME).containingAllCubes();

		ActivePivotManagerDescription desc = new ActivePivotManagerDescription();

		// Make a single catalog holding all cubes
		ICatalogDescription catalog =
				makeSingleCatalogFromSchema(ApexActivePivotManagerBuilderHelper.DEFAULT_CATALOG_NAME,
						schemaDescriptions);

		desc.setCatalogs(Collections.singletonList(catalog));
		desc.setSchemas(schemaDescriptions);

		return desc;
	}

	public static ICatalogDescription makeSingleCatalogFromSchema(String catalogName,
			List<? extends IActivePivotSchemaInstanceDescription> schemaDescriptions) {
		List<String> activePivotIds = new ArrayList<>();

		for (IActivePivotSchemaInstanceDescription schemaDescription : schemaDescriptions) {
			IActivePivotSchemaDescription schema = schemaDescription.getActivePivotSchemaDescription();

			// Add actual cubes in the catalog
			schema.getActivePivotInstanceDescriptions().forEach(d -> activePivotIds.add(d.getId()));

			// Add distributed cubes in the catalog
			schema.getDistributedActivePivotInstanceDescriptions().forEach(d -> activePivotIds.add(d.getId()));
		}

		return new CatalogDescription(catalogName, activePivotIds);
	}

	public static ICatalogDescription makeSingleCatalog(String catalogName,
			List<? extends IActivePivotInstanceDescription> descriptions) {
		List<String> activePivotIds = new ArrayList<>();

		for (IActivePivotInstanceDescription pivotDesc : descriptions) {
			activePivotIds.add(pivotDesc.getId());
		}

		return new CatalogDescription(catalogName, activePivotIds);
	}

	public static IActivePivotManagerDescription makeManagerDescription(String schemaName,
			IStoreDescription baseStoreDescriptions,
			List<? extends IActivePivotInstanceDescription> apDescriptions) {
		IActivePivotSchemaInstanceDescription singleSchema =
				makeSchemaDescription(schemaName, baseStoreDescriptions, apDescriptions);
		return makeManagerDescription(Collections.singletonList(singleSchema));
	}

	public static IActivePivotManagerDescription makeManagerDescription(String schemaName,
			IStoreDescription baseStoreDescriptions,
			IActivePivotInstanceDescription firstApDescription,
			IActivePivotInstanceDescription... apDescriptions) {
		return makeManagerDescription(schemaName,
				baseStoreDescriptions,
				Lists.asList(firstApDescription, apDescriptions));
	}

	public static IActivePivotManagerDescription makeManagerDescription(String schemaName,
			IDatastoreSchemaDescription datastoreDescription,
			String baseStore,
			List<? extends IActivePivotInstanceDescription> apDescriptions) {
		IActivePivotSchemaInstanceDescription singleSchema =
				makeSchemaDescription(schemaName, datastoreDescription, baseStore, apDescriptions);
		return makeManagerDescription(Collections.singletonList(singleSchema));
	}

	// TODO refactor with
	// ApexTestDatastoreHelper.createCubeDescription(IDatastoreSchemaDescription,
	// String)
	public static ISelectionDescription makeSelectionDescription(IStoreDescription baseStoreDescription) {
		return makeSelectionDescription(baseStoreDescription.getName(),
				Arrays.asList(baseStoreDescription),
				Collections.emptyList());
	}

	// TODO refactor with
	// ApexTestDatastoreHelper.createCubeDescription(IDatastoreSchemaDescription,
	// String)
	public static ISelectionDescription makeSelectionDescription(IDatastoreSchemaDescription datastoreDescription,
			String baseStoreName) {
		return makeSelectionDescription(baseStoreName,
				datastoreDescription.getStoreDescriptions(),
				datastoreDescription.getReferenceDescriptions());
	}

	/**
	 * 
	 * @param baseStoreName
	 * @param stores
	 * @param references
	 * @return a {@link ISelectionDescription} with all available fields
	 */
	public static ISelectionDescription makeSelectionDescription(String baseStoreName,
			Collection<? extends IStoreDescription> stores,
			Collection<? extends IReferenceDescription> references) {
		// https://support.activeviam.com/confluence/pages/viewpage.action?spaceKey=AP5&title=Cube+Fluent+Description
		// We can not use the builder as it will not differentiate between fields with same name but different
		// reference/pathes
		// We make a temporary DatastoreSchemaDescription to help the builder
		// return StartBuilding.selection(new DatastoreSchemaDescription(stores, references))
		// .fromBaseStore(baseStoreName)
		// .withAllReachableFields()
		// .build();

		IStoreDescription baseStore = ApexDescriptionHelper.findStore(baseStoreName, stores);

		// Add all fields in the selection: as this is for tests purposes,
		// we do not care about performance
		List<ISelectionField> selectionField = new ArrayList<>();

		baseStore.getFields().forEach(field -> selectionField.add(new SelectionField(field.getName())));

		Queue<List<List<String>>> prefixAndStore = new LinkedBlockingQueue<>();

		prefixAndStore.add(Arrays.asList(Collections.emptyList(), Arrays.asList(baseStoreName)));

		// Iterate through all available pathes/references
		while (!prefixAndStore.isEmpty()) {
			List<List<String>> next = prefixAndStore.poll();

			// The prefix is a chain of references
			List<String> prefix = next.get(0);
			// Until a store
			String store = next.get(1).get(0);

			// For each references following in the chain
			references.stream().filter(r -> r.getOwnerStore().equals(store)).forEach(ref -> {

				List<String> newPrefix = Lists.newArrayList(Iterables.concat(prefix, Arrays.asList(ref.getName())));

				Optional<? extends IStoreDescription> targetStore =
						ApexDescriptionHelper.findStoreNoFail(ref.getTargetStore(), stores);

				if (!targetStore.isPresent()) {
					throw new RuntimeException("The target store is missing in " + ref);
				}

				// Add the next path of references for further processing
				prefixAndStore.add(Arrays.asList(newPrefix, Arrays.asList(ref.getTargetStore())));

				for (IFieldDescription field : targetStore.get().getFields()) {
					String joinedPath = ApexDatastoreHelper.joinFieldPath(newPrefix, field.getName());
					String fieldName = ApexTestDatastoreHelper.makeFieldName(newPrefix, field.getName());

					selectionField.add(new SelectionField(fieldName, joinedPath));
				}
			});
		}

		return new SelectionDescription(baseStoreName, selectionField);
	}

	public static IActivePivotSchemaInstanceDescription makeSchemaDescription(String schemaName,
			List<? extends IActivePivotInstanceDescription> apDescriptions,
			ISelectionDescription selectionDescription) {
		IActivePivotSchemaInstanceDescription schema = new ActivePivotSchemaInstanceDescription();

		schema.setId(schemaName);

		IActivePivotSchemaDescription schemaDescription;
		{
			schemaDescription = new ActivePivotSchemaDescription();

			schemaDescription.setActivePivotInstanceDescriptions(apDescriptions);
			schemaDescription.setDatastoreSelection(selectionDescription);
		}
		schema.setActivePivotSchemaDescription(schemaDescription);

		return schema;
	}

	public static Map<String, String> convertToLiteralType(Map<String, String> rawFieldDescriptions) {
		return rawFieldDescriptions.entrySet().stream().collect(Collectors.toMap(Map.Entry::getKey, e -> {
			String pluginKey = e.getValue();
			ILiteralType type = Registry.getPlugin(ILiteralType.class).valueOf(pluginKey);
			if (type == null) {
				IAggregationFunction aggregationFunction =
						Registry.getPlugin(IAggregationFunction.class).valueOf(pluginKey);

				if (aggregationFunction == null) {
					throw new IllegalArgumentException("The value '" + pluginKey
							+ "' seems to be neither an ILiteralType nor an IAggregationFunction");
				} else {
					// The developer requested an ILiteralType for this aggregationFunction
					// TODO: for now, we consider it is necessarily a DOUBLE
					type = Registry.getPlugin(ILiteralType.class).valueOf(ILiteralType.DOUBLE);
				}
			}

			return type.key().toString();
		}));
	}

	public static IActivePivotSchemaInstanceDescription makeSchemaDescription(String schemaName,
			IStoreDescription baseStoreDescriptions,
			List<? extends IActivePivotInstanceDescription> apDescriptions) {
		// TODO : restrict ISelection to fields used by AP
		ISelectionDescription selectionDescription = makeSelectionDescription(baseStoreDescriptions);

		return makeSchemaDescription(schemaName, apDescriptions, selectionDescription);
	}

	public static IActivePivotSchemaInstanceDescription makeSchemaDescription(String schemaName,
			IDatastoreSchemaDescription datastoreDescription,
			String baseStoreName,
			List<? extends IActivePivotInstanceDescription> apDescriptions) {
		// TODO : restrict ISelection to fields used by AP
		ISelectionDescription selectionDescription = makeSelectionDescription(datastoreDescription, baseStoreName);

		return makeSchemaDescription(schemaName, apDescriptions, selectionDescription);
	}

	public static IActivePivotInstanceDescription makeActivePivotDescription(String cubeId,
			IActivePivotDescription activePivotDescription) {
		return new ActivePivotInstanceDescription(cubeId, activePivotDescription);
	}

	public static IActivePivotManagerDescription makeSimpleAPManagerDescription(String schemaName,
			String cubeName,
			String storeName,
			Map<String, String> fieldDescriptions) {
		IStoreDescription storeDescription = ApexTestDatastoreHelper
				.createStoreDescription(storeName, convertToLiteralType(fieldDescriptions), Collections.emptyList());

		IActivePivotDescription cubeDescription = ApexTestDatastoreHelper.createCubeDescription(fieldDescriptions);

		return makeManagerDescription(schemaName,
				storeDescription,
				makeActivePivotDescription(cubeName, cubeDescription));
	}

	public static IActivePivotManagerDescription makeSimpleAPManagerDescription(String schemaName,
			String cubeName,
			IStoreDescription storeDescription) {
		IActivePivotDescription cubeDescription = ApexTestDatastoreHelper.createCubeDescription(storeDescription);

		return makeSimpleAPManagerDescription(schemaName, cubeName, storeDescription, cubeDescription);
	}

	public static IActivePivotManagerDescription makeSimpleAPManagerDescription(String schemaName,
			String cubeName,
			IStoreDescription storeDescription,
			IActivePivotDescription cubeDescription) {
		return makeManagerDescription(schemaName,
				storeDescription,
				makeActivePivotDescription(cubeName, cubeDescription));
	}
}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.mdx;

import java.text.DecimalFormat;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.quartetfs.fwk.QuartetType;
import com.quartetfs.pivot.mdx.IDefaultCellPropertiesHandler;
import com.quartetfs.pivot.mdx.impl.DefaultCellPropertiesHandler;

import cormoran.pepper.logging.PepperLogHelper;

/**
 * A nice DefaultCellPropertiesHandler formatting doubles with a limited number of decimals
 * 
 * @author Benoit Lacelle
 * @see https://support.activeviam.com/jira/browse/APS-8775
 */
// TODO How is this related to ICubeFormatter?
@QuartetType(intf = IDefaultCellPropertiesHandler.class, description = "ApexDefaultCellPropertiesHandler")
public class ApexCellPropertiesHandler extends DefaultCellPropertiesHandler {

	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexCellPropertiesHandler.class);

	@Override
	protected String getFormattedValue(Object cellValue) {
		if (cellValue == null) {
			return null;
		} else if (cellValue instanceof Throwable) {
			return "Error(" + ((Throwable) cellValue).getLocalizedMessage() + ')';
		} else {
			if (cellValue instanceof Number) {
				String formattedNumber = getFormattedNumber((Number) cellValue);

				LOGGER.trace("{}({}) has been formatted to {}",
						PepperLogHelper.getObjectAndClass(cellValue),
						formattedNumber);

				return formattedNumber;
			} else {
				return cellValue.toString();
			}
		}
	}

	protected String getFormattedNumber(Number cellValue) {
		if (cellValue instanceof Float || cellValue instanceof Double) {
			return new DecimalFormat("#,##0.0#;-#,##0.0#").format(cellValue);
		} else {
			return cellValue.toString();
		}
	}
}

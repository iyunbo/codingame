/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.subcube;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import com.quartetfs.biz.pivot.context.subcube.ISubCubeProperties;
import com.quartetfs.biz.pivot.context.subcube.impl.SubCubeProperties;
import com.quartetfs.biz.pivot.cube.hierarchy.IHierarchy;
import com.quartetfs.biz.pivot.cube.hierarchy.IHierarchyInfo;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevel;
import com.quartetfs.biz.pivot.cube.hierarchy.axis.IAxisHierarchy;
import com.quartetfs.fwk.filtering.ICondition;
import com.quartetfs.fwk.filtering.impl.EqualCondition;
import com.quartetfs.fwk.filtering.impl.OrCondition;

import blasd.apex.server.config.cube.ApexHierarchyBuilder;
import blasd.apex.server.query.hierarchy.ApexHierarchyHelper;

/**
 * Facilitate the building of an ISubCubeProperties, by managing AllMember and not String discriminators
 * 
 * @author Benoit Lacelle
 *
 */
public class ApexSubCubeConfigurer implements IApexSubCubeConfigurer {
	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexSubCubeConfigurer.class);

	protected final List<? extends IHierarchy> hierarchies;
	protected final ISubCubeProperties subCubeProperties;

	public ApexSubCubeConfigurer(List<? extends IHierarchy> hierarchies, ISubCubeProperties subCubeProperties) {
		this.hierarchies = hierarchies;
		this.subCubeProperties = subCubeProperties;
	}

	/**
	 * Initialize a new ISubCubeProperties with access granted
	 */
	public ApexSubCubeConfigurer(List<? extends IHierarchy> hierarchies) {
		this(hierarchies, makeGrantedSubCube());
	}

	/**
	 * 
	 * @return ISubCubeProperties which gives access to everything
	 */
	public static ISubCubeProperties makeGrantedSubCube() {
		return new SubCubeProperties(true);
	}

	/**
	 * 
	 * @return ISubCubeProperties which gives access to nothing
	 */
	public static ISubCubeProperties makeUnauthorizedSubCube() {
		return new SubCubeProperties(false);
	}

	public static IApexSubCubeConfigurer newBuilder(List<? extends IHierarchy> hierarchies) {
		return new ApexSubCubeConfigurer(hierarchies);
	}

	@Override
	public ApexSubCubeConfigurer grantPath(String dimension,
			String hierarchy,
			List<?> discriminatorOrNullOrCollectionOrCondition) {
		subCubeProperties.grantMembers(dimension,
				hierarchy,
				ensureStringOrCondition(discriminatorOrNullOrCollectionOrCondition));

		return this;
	}

	/**
	 * @see com.quartetfs.biz.pivot.context.subcube.impl.SubCubeNode.addConditions(int, List<?>)
	 */
	protected List<?> ensureStringOrCondition(List<?> discriminatorOrNullOrCollectionOrCondition) {
		return Lists.newArrayList(Lists.transform(discriminatorOrNullOrCollectionOrCondition, input -> {
			if (input instanceof ICondition) {
				// ICondition are handled natively
				return input;
			} else if (input instanceof Collection) {
				// Collections are not handled directly

				List<ICondition> asList = new ArrayList<>();

				// TODO: recursive call
				for (Object oneInput : (Collection<?>) input) {
					if (oneInput instanceof ICondition) {
						asList.add((ICondition) oneInput);
					} else {
						asList.add(new EqualCondition(oneInput));
					}
				}

				return new OrCondition(asList);
			} else if (input instanceof String) {
				// String are handled natively
				return input;
			} else {
				if (input == null) {
					return null;
				} else {
					// Not-String objects has to be handled with a ICondition
					return new EqualCondition(input);
				}
			}
		}));
	}

	@Override
	public ApexSubCubeConfigurer grantPath(String hierarchyId, Object... discriminatorOrNullOrCollectionOrCondition) {
		grantPath(hierarchyId, Arrays.asList(discriminatorOrNullOrCollectionOrCondition));

		return this;
	}

	@Override
	public ApexSubCubeConfigurer grantPath(String hierarchyId, List<?> discriminatorOrNullOrCollectionOrCondition) {
		IAxisHierarchy h = ApexHierarchyHelper.findAxisHierarchy(hierarchies, hierarchyId);

		IHierarchyInfo hInfo = h.getHierarchyInfo();
		String dimensionName = hInfo.getDimensionInfo().getName();
		if (ApexHierarchyHelper.isAllMembersEnabled(h)
				&& discriminatorOrNullOrCollectionOrCondition.size() < h.getLevels().size()) {
			// We might need to add the AllMember in the path
			if (discriminatorOrNullOrCollectionOrCondition.isEmpty()) {
				LOGGER.info("We are granting an empty path in {}", ApexHierarchyBuilder.hierarchyName(hInfo));
			} else {
				Object firstCondition = discriminatorOrNullOrCollectionOrCondition.get(0);

				if (!ILevel.ALLMEMBER.equals(firstCondition)) {
					// Add AllMember at the beginning
					discriminatorOrNullOrCollectionOrCondition = ImmutableList.builder()
							.add(ILevel.ALLMEMBER)
							.addAll(discriminatorOrNullOrCollectionOrCondition)
							.build();
				}
			}
		}

		grantPath(dimensionName, h.getName(), discriminatorOrNullOrCollectionOrCondition);

		return this;
	}

	@Override
	public ISubCubeProperties getSubCubeProperties() {
		return subCubeProperties;
	}

	@Override
	public ApexSubCubeConfigurer grantMeasure(String measureName) {
		getSubCubeProperties().grantMeasure(measureName);
		return this;
	}
}

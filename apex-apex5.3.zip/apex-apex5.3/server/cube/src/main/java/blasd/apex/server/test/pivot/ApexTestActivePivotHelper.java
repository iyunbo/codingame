/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.test.pivot;

import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assume;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.activeviam.builders.StartBuilding;
import com.activeviam.lic.impl.Licensing;
import com.google.common.base.Strings;
import com.google.common.eventbus.EventBus;
import com.qfs.desc.IDatastoreSchemaDescription;
import com.qfs.desc.IStoreDescription;
import com.qfs.desc.impl.DatastoreSchemaDescription;
import com.qfs.desc.impl.DictionarizeObjectsPostProcessor;
import com.qfs.multiversion.IEpoch;
import com.qfs.multiversion.impl.Epoch;
import com.qfs.store.IDatastore;
import com.qfs.store.IReadableDatastore;
import com.qfs.store.Types;
import com.qfs.store.build.IDatastoreBuilder;
import com.qfs.store.record.IByteRecordFormat;
import com.quartetfs.biz.pivot.IActivePivotManager;
import com.quartetfs.biz.pivot.IMultiVersionActivePivot;
import com.quartetfs.biz.pivot.definitions.IActivePivotDescription;
import com.quartetfs.biz.pivot.definitions.IActivePivotManagerDescription;
import com.quartetfs.biz.pivot.definitions.ISelectionDescription;
import com.quartetfs.biz.pivot.definitions.impl.ActivePivotDatastorePostProcessor;
import com.quartetfs.biz.pivot.definitions.impl.ActivePivotInstanceDescription;
import com.quartetfs.biz.pivot.definitions.impl.ActivePivotManagerDescription;
import com.quartetfs.biz.pivot.definitions.impl.ActivePivotSchemaDescription;
import com.quartetfs.biz.pivot.definitions.impl.ActivePivotSchemaInstanceDescription;
import com.quartetfs.fwk.AgentException;
import com.quartetfs.fwk.IAgent;
import com.quartetfs.fwk.IAgent.State;

import blasd.apex.server.datastore.test.ApexTestDatastoreHelper;
import blasd.apex.server.datastore.transaction.ApexTransactionHelper;
import blasd.apex.server.query.ApexDrillthroughHelper;
import blasd.apex.server.query.location.ApexShortLocationFormatter;
import blasd.apex.server.query.mdx.ApexMdxHelper;
import blasd.apex.server.query.memory.ApexActivePivotManagerBuilderHelper;
import blasd.apex.server.test.IApexTestConstants;

/**
 * 
 * @author Benoit Lacelle
 * 
 */
public class ApexTestActivePivotHelper implements IApexTestConstants {
	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexTestActivePivotHelper.class);

	/**
	 * We have a default timeout of 10 minutes: it is not so long for integration tests, and it enables a developer to
	 * debug
	 */
	public static final int QUERY_TIME_OUT = 10 * 60;

	public static final String ASOFDATE_DIM = ASOFDATE;
	public static final String ASOFDATE_LEVEL = ASOFDATE + "@" + ASOFDATE_DIM;

	public static final String CCY_DIM = CCY;
	public static final String CCY_HIE = CCY;
	public static final String CCY_ALL = ALL + "@" + CCY_DIM;
	public static final String CCY_LEVEL = CCY + "@" + CCY_DIM;

	public static final String COUNTRY_DIM = COUNTRY;
	public static final String COUNTRY_LEVEL = COUNTRY_LEV;
	public static final String CITY_LEVEL = CITY_LEV;

	private static final double DATA_DEFAULT_SHIFT = 123D;

	protected ApexTestActivePivotHelper() {
		// hidden
	}

	/**
	 * This can be called in an @Before method in order to skip a test if the JVM has "-Dactivepivot.license=missing" it
	 * is useful in case the server running tests has no license
	 */
	public static void assumeLicenseIsOk() {
		if (Licensing.checkLicence()) {
			LOGGER.debug("The license is valid");
		} else {
			// We ensure the license is logged anyway
			Licensing.logLicenseInfoOnce();

			// We skip this test as there is explicitely no available license
			String license = System.getProperty("activepivot.license");
			boolean explicitNoLicense = "missing".equalsIgnoreCase(license);

			Assume.assumeFalse(explicitNoLicense);
			if (explicitNoLicense) {
				LOGGER.info("We have -Dactivepivot.license={} meaning ActivePivot tests should be skipped", license);
			}
		}
	}

	public static IMultiVersionActivePivot makeCcyCountryAsOfDateActivePivot(String pivotId) {
		return makeActivePivot(pivotId, ASOFDATE_CCY_COUNTRY_CITY_DELTA_SUM);
	}

	public static IActivePivotManager makeCcyCountryAsOfDateActivePivotManager(String pivotId) {
		return makeActivePivotManager(pivotId, ASOFDATE_CCY_COUNTRY_CITY_DELTA_SUM);
	}

	public static IActivePivotManagerDescription makeActivePivotManagerDescription(String pivotId,
			IActivePivotDescription activePivotDescription) {
		IStoreDescription storeDescription = ApexTestDatastoreHelper
				.createStoreDescription(pivotId, activePivotDescription, Collections.emptyList());

		return ApexActivePivotDescriptionHelper
				.makeSimpleAPManagerDescription(pivotId, pivotId, storeDescription, activePivotDescription);
	}

	public static IActivePivotManager makeActivePivotManager(String pivotId,
			IActivePivotDescription activePivotDescription) {
		IStoreDescription storeDescription = ApexTestDatastoreHelper
				.createStoreDescription(pivotId, activePivotDescription, Collections.emptyList());

		IActivePivotManagerDescription apDesc = makeActivePivotManagerDescription(pivotId, activePivotDescription);

		IDatastoreSchemaDescription schemaDesc =
				ApexTestDatastoreHelper.prepareDescription(Arrays.asList(storeDescription));

		final IActivePivotManager apManager = buildCubeOverDatastore(schemaDesc, apDesc);

		initAndStartActivePivotManager(apManager);

		return apManager;
	}

	public static void initAndStartActivePivotManager(IAgent activePivotManager) {
		if (activePivotManager.getStatus() == State.STARTED) {
			LOGGER.warn("The IActivePivotManager uis already started");
			return;
		}
		unsafeEnsureSecurityFacade();

		try {
			activePivotManager.init(null);
			activePivotManager.start();

			if (activePivotManager instanceof IActivePivotManager) {
				ApexShortLocationFormatter.clearRegistered();
				for (IMultiVersionActivePivot pivot : ((IActivePivotManager) activePivotManager).getActivePivots()
						.values()) {
					ApexShortLocationFormatter.registerActivePivot(pivot);
				}
			}
		} catch (AgentException e) {
			throw new RuntimeException(e);
		}
	}

	private static void unsafeEnsureSecurityFacade() {
		// apex-server-test is not available
		try {
			// Static class
			Class.forName("blasd.apex.server.test.registry.ApexTestRegistryHelper")
					.getMethod("ensureSecurityFacade")
					.invoke(null);
		} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException | NoSuchMethodException
				| SecurityException | ClassNotFoundException e) {
			throw new RuntimeException("Ouch", e);
		}
	}

	/**
	 * 
	 * @param pivotId
	 *            the name of the cube
	 * @param activePivotDescription
	 *            the description of the cube
	 * @return a {@link IMultiVersionActivePivot}
	 */
	public static IMultiVersionActivePivot makeActivePivot(String pivotId,
			IActivePivotDescription activePivotDescription) {
		IActivePivotManager apManager = makeActivePivotManager(pivotId, activePivotDescription);

		return apManager.getActivePivots().get(pivotId);
	}

	public static IDatastore makeSimpleDatastore(String storeName,
			Map<String, String> fieldDescriptions,
			List<? extends String> keyFields) {
		IStoreDescription storeDescription =
				ApexTestDatastoreHelper.createStoreDescription(storeName, fieldDescriptions, keyFields);

		IDatastoreSchemaDescription description =
				ApexTestDatastoreHelper.prepareDescription(Arrays.asList(storeDescription));

		return ApexTestDatastoreHelper.buildApexDatastore(description);
	}

	public static IActivePivotManager buildCubeOverDatastore(String schemaName,
			String cubeName,
			String storeName,
			Map<String, String> rawFieldDescriptions,
			List<? extends String> keyFields) {
		// We convert aggregationFunction to ILiteralType for the store description
		Map<String, String> fieldDescriptions =
				ApexActivePivotDescriptionHelper.convertToLiteralType(rawFieldDescriptions);

		IStoreDescription storeDescription =
				ApexTestDatastoreHelper.createStoreDescription(storeName, fieldDescriptions, keyFields);

		IActivePivotManagerDescription apManagerDescription = ApexActivePivotDescriptionHelper
				.makeSimpleAPManagerDescription(schemaName, cubeName, storeName, rawFieldDescriptions);

		IDatastoreSchemaDescription description =
				ApexTestDatastoreHelper.prepareDescription(Collections.singletonList(storeDescription));

		return buildCubeOverDatastore(description, apManagerDescription);
	}

	public static IActivePivotManager buildCubeOverDatastore(String cubeName,
			Map<String, String> fieldDescriptions,
			String... keyFields) {
		return buildCubeOverDatastore(cubeName, cubeName, cubeName, fieldDescriptions, keyFields);
	}

	public static IActivePivotManager buildCubeOverDatastore(String schemaName,
			String cubeName,
			String storeName,
			Map<String, String> fieldDescriptions,
			String... keyFields) {
		return buildCubeOverDatastore(schemaName, cubeName, storeName, fieldDescriptions, Arrays.asList(keyFields));
	}

	public static IActivePivotManager buildCubeOverDatastore(IDatastoreSchemaDescription description,
			IActivePivotManagerDescription apManagerDescription) {
		// This pp will automatically dictionarized fields used for levels
		ActivePivotDatastorePostProcessor postProcessor =
				ActivePivotDatastorePostProcessor.createFrom(apManagerDescription);

		IDatastoreBuilder datastoreBuilder = ApexTestDatastoreHelper.makeDefaultDatastoreBuilder(new EventBus());
		DictionarizeObjectsPostProcessor dictionarizePostProcessor = new DictionarizeObjectsPostProcessor();
		IDatastore datastore = ApexTestDatastoreHelper
				.buildDatastore(datastoreBuilder, description, dictionarizePostProcessor, postProcessor);

		return ApexActivePivotManagerBuilderHelper.makeActivePivotManager(datastore, description, apManagerDescription);
	}

	// public static void initAndStartActivePivot(IMultiVersionActivePivot pivot) {
	// ensureSecurityFacade();
	//
	// try {
	// pivot.init(null);
	// // TODO
	// // ApexShortLocationFormatter.registerActivePivot(pivot);
	// pivot.getContext().set(IQueriesTimeLimit.class, new QueriesTimeLimit(QUERY_TIME_OUT));
	// pivot.start();
	//
	// ApexShortLocationFormatter.clearRegistered();
	// ApexShortLocationFormatter.registerActivePivot(pivot);
	// } catch (AgentException e) {
	// throw new RuntimeException(e);
	// }
	// }

	public static void contributeSimpleFact(IActivePivotManager apManager, String cubeName) {
		contributeSimpleFact(apManager, cubeName, 1D);
	}

	public static void contributeSimpleFact(IActivePivotManager apManager, String cubeName, final double someDouble) {
		final String baseStore = ApexDrillthroughHelper.findBaseStore(apManager, cubeName);

		final IReadableDatastore datastore = apManager.getDatastore();

		Map<String, Object> sampleEntry = makeRandomEntry(datastore, baseStore, someDouble);

		ApexTransactionHelper.addOne(apManager, baseStore, sampleEntry);
	}

	public static Map<String, Object> makeRandomEntry(IReadableDatastore datastore,
			String baseStore,
			double someDouble) {
		Map<String, Object> sampleEntry = new HashMap<>();

		IByteRecordFormat format =
				datastore.getSchemaMetadata().getStoreMetadata(baseStore).getStoreFormat().getRecordFormat();
		for (int i = 0; i < format.getFieldCount(); i++) {
			double baseAsDouble = DATA_DEFAULT_SHIFT + someDouble;

			int currentContentType = Types.getContentType(format.getType(i));

			if (currentContentType == Types.CONTENT_DOUBLE) {
				sampleEntry.put(format.getFieldName(i), baseAsDouble);
			} else if (currentContentType == Types.CONTENT_FLOAT) {
				sampleEntry.put(format.getFieldName(i), (float) baseAsDouble);
			} else if (currentContentType == Types.CONTENT_LONG) {
				sampleEntry.put(format.getFieldName(i), (long) baseAsDouble);
			} else if (currentContentType == Types.CONTENT_INT) {
				sampleEntry.put(format.getFieldName(i), (int) baseAsDouble);
			} else {
				sampleEntry.put(format.getFieldName(i), "SomeStringFor" + format.getFieldName(i) + "-" + someDouble);
			}
		}

		return sampleEntry;
	}

	/**
	 * @see com.quartetfs.biz.pivot.test.util.Util#nextEpoch()
	 */
	public static IEpoch nextEpoch(IEpoch before) {
		return new Epoch(before.getId() + 1L);
	}

	public static IActivePivotManagerDescription makeActivePivotManagerDescription(String schemaName,
			String cubeName,
			IActivePivotDescription cubeDescription,
			IStoreDescription storeDescription) {
		ActivePivotManagerDescription apm = new ActivePivotManagerDescription();

		ActivePivotSchemaDescription s = new ActivePivotSchemaDescription();
		s.setActivePivotInstanceDescriptions(
				Arrays.asList(new ActivePivotInstanceDescription(cubeName, cubeDescription)));

		// We make a temporary DatastoreSchemaDescription to help the builder
		ISelectionDescription selection = StartBuilding
				.selection(new DatastoreSchemaDescription(Arrays.asList(storeDescription), Collections.emptyList()))
				.fromBaseStore(storeDescription.getName())
				.withAllReachableFields()
				.build();

		// Add all fields in the selection
		s.setDatastoreSelection(selection);

		apm.setSchemas(Arrays.asList(new ActivePivotSchemaInstanceDescription(schemaName, s)));

		return apm;
	}

	@Deprecated
	public static String makeTopMdxQuery(String cubeName) {
		return ApexMdxHelper.makeTopMdxQuery(cubeName);
	}

	@Deprecated
	public static String makeCrossJoinMdxQuery(String cubeName, Iterable<? extends String> hierarchyNames) {
		return ApexMdxHelper.makeCrossJoinMdxQuery(cubeName, hierarchyNames);
	}

	/**
	 * Tomcat would load logging.properties in the classpath resources; help to do the same
	 */
	public static void setJULFromClassPath() {
		if (Strings.isNullOrEmpty(System.getProperty("java.util.logging.config.file"))) {
			// JUL loads by default logging.properties in <JAVA_HOME>/lib
			// We want to load the logging.properties in resources, just like it would be done by Tomcat
			System.setProperty("java.util.logging.config.file", "logging.properties");
			// There is no logger yet
			System.err.println("We set automatically -Djava.util.logging.config.file=logging.properties");
		}
	}
}

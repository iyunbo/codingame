/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.postprocessor.basic;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Maps;
import com.quartetfs.biz.pivot.ILocation;
import com.quartetfs.biz.pivot.cube.hierarchy.measures.IPostProcessorCreationContext;
import com.quartetfs.biz.pivot.postprocessing.IPostProcessor;
import com.quartetfs.fwk.QuartetExtendedPluginValue;

/**
 * Combines the 2 underlyingValues in a Map.Entry
 * 
 * @author Benoit Lacelle
 *
 */
@QuartetExtendedPluginValue(intf = IPostProcessor.class, key = MapEntryBasicPostProcessor.PLUGIN_KEY)
public class MapEntryBasicPostProcessor extends LevelCoordinatePostProcessor {
	private static final long serialVersionUID = 4508011783377080797L;

	protected static final Logger LOGGER = LoggerFactory.getLogger(MapEntryBasicPostProcessor.class);

	public static final String PLUGIN_KEY = "MapEntry";

	public MapEntryBasicPostProcessor(String name, IPostProcessorCreationContext creationContext) {
		super(name, creationContext);
	}

	@Override
	public String getType() {
		return PLUGIN_KEY;
	}

	@Override
	public Object evaluate(ILocation pointLocation, Object[] underlyingValues) {
		// Clone the underlying arrays as it is re-used as buffer by ActivePivot
		Object[] clonedValues = underlyingValues.clone();
		return Maps.immutableEntry(levelCoordinate(pointLocation, clonedValues), clonedValues);
	}

}

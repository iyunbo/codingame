/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.dimension.test;

import blasd.apex.server.test.IApexTestConstants;

/**
 * Additional constants specific to tests for analysis hierarchies
 * 
 * @author Benoit Lacelle
 *
 */
public interface IAnalysisHierarchyTestHelper extends IApexTestConstants {

	String GROUP_NAME = "GroupName";
	String GROUP_DETAIL_TYPE = "DetailType";
	String GROUP_DETAIL = "DetailValue";

	String COUNTRY_GROUP_DIM = "CountryGroup";
	String COUNTRY_GROUP_ALL_LEVEL = "ALL@" + COUNTRY_GROUP_DIM;
	String COUNTRY_GROUP_LEVEL = GROUP_NAME + "@" + COUNTRY_GROUP_DIM;
	String COUNTRY_GROUP_COUNTRY_LEVEL = GROUP_DETAIL + "@" + COUNTRY_GROUP_DIM;

	String CCY_GROUP_DIM = "CcyGroup";

	String G8 = "G8";
	String FRANCE_GROUP = FRANCE + "_Group";
	String USA_GROUP = USA + "_Group";
}

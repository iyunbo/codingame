/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.cellset;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.NavigableMap;
import java.util.TreeMap;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.quartetfs.biz.pivot.cube.hierarchy.measures.IMeasureHierarchy;
import com.quartetfs.biz.pivot.dto.AxisDTO;
import com.quartetfs.biz.pivot.dto.AxisMemberDTO;
import com.quartetfs.biz.pivot.dto.AxisPositionDTO;
import com.quartetfs.biz.pivot.dto.CellDTO;
import com.quartetfs.biz.pivot.dto.CellSetDTO;
import com.quartetfs.biz.pivot.dto.HierarchyDTO;

/**
 * Helps manipulating CellSetDTO
 * 
 * @author Benoit Lacelle
 *
 */
public class ApexCellSetDTOHelper {
	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexCellSetDTOHelper.class);

	protected ApexCellSetDTOHelper() {
		// hidden
	}

	/**
	 * 
	 * @param cellsetDTO
	 *            the typical output of an IMdxQuery
	 * @return
	 */
	public static List<? extends CoordinateAndAggregates> convertToList(CellSetDTO cellsetDTO) {
		if (cellsetDTO == null || cellsetDTO.getCells() == null) {
			return Collections.emptyList();
		}

		return cellsetDTO.getCells().stream().map(c -> {
			NavigableMap<String, ? extends List<?>> coordinates = getCellCoordinates(cellsetDTO, c);
			List<? extends String> measureNames = Collections.singletonList(getCellMeasure(cellsetDTO, c));
			List<Object> values = Collections.singletonList(c.getValue());
			return new CoordinateAndAggregates(coordinates, measureNames, values);
		}).collect(Collectors.toList());
	}

	public static List<NavigableMap<String, List<?>>> convertToListMap(CellSetDTO cellsetDTO) {
		return ApexCellSetHelper.convertToListMap(convertToList(cellsetDTO));
	}

	public static NavigableMap<String, ? extends List<?>> getCellCoordinates(CellSetDTO cellsetDTO, CellDTO c) {
		int ordinal = c.getOrdinal();

		NavigableMap<String, List<String>> coordinates = extractCoordinates(cellsetDTO, ordinal);

		if (coordinates.containsKey(IMeasureHierarchy.MEASURE_HIERARCHY)) {
			coordinates.remove(IMeasureHierarchy.MEASURE_HIERARCHY);
		}

		return coordinates;
	}

	public static String getCellMeasure(CellSetDTO cellsetDTO, CellDTO c) {
		int ordinal = c.getOrdinal();

		NavigableMap<String, List<String>> coordinates = extractCoordinates(cellsetDTO, ordinal);

		if (coordinates.containsKey(IMeasureHierarchy.MEASURE_HIERARCHY)) {
			return coordinates.get(IMeasureHierarchy.MEASURE_HIERARCHY).get(0).toString();
		} else {
			throw new RuntimeException("There is no measure in " + coordinates);
		}

	}

	public static NavigableMap<String, List<String>> extractCoordinates(CellSetDTO cellset, int ordinal) {
		NavigableMap<String, List<String>> axisNameToCoordinate = new TreeMap<>();

		if (cellset.getSlicerAxis() != null && !cellset.getSlicerAxis().getHierarchies().isEmpty()) {
			extractCoordinate(axisNameToCoordinate,
					cellset.getSlicerAxis().getHierarchies(),
					cellset.getSlicerAxis().getPositions().get(0));
		}

		List<Integer> ordinalToCoordinates = ordinalToCoordinates(ordinal, cellset);

		for (AxisDTO axis : cellset.getAxes()) {
			Integer coordinate = ordinalToCoordinates.get(axis.getIndex());
			extractCoordinate(axisNameToCoordinate, axis.getHierarchies(), axis.getPositions().get(coordinate));
		}

		return axisNameToCoordinate;
	}

	public static void extractCoordinate(NavigableMap<String, List<String>> axisNameToCoordinate,
			List<? extends HierarchyDTO> hierarchies,
			AxisPositionDTO position) {
		for (int j = 0; j < hierarchies.size(); j++) {
			HierarchyDTO h = hierarchies.get(j);
			AxisMemberDTO member = position.getMembers().get(j);

			String[] memberAsString = member.getPath().getPath();
			if (memberAsString.length == 1 && memberAsString[0].equals("AllMember")) {
				// We don't express the level which are on the AllMember single
				// position of the ALL level
				LOGGER.trace("Skip member on hierarchy {} as it expresses AllMember", h);
			} else {
				axisNameToCoordinate.put(h.getName(), Arrays.asList(memberAsString));
			}
		}
	}

	public static List<Integer> ordinalToCoordinates(int ordinal, CellSetDTO cellSet) {
		// Duplicated from XmlaOlap4jCellSet.ordinalToCoordinates
		Collection<AxisDTO> axes = cellSet.getAxes();

		if (axes.isEmpty()) {
			return Collections.emptyList();
		}

		NavigableMap<Integer, AxisDTO> ordinalToAxis = new TreeMap<>();

		// Some ordinal might not be present
		for (AxisDTO axis : axes) {
			ordinalToAxis.put(axis.getIndex(), axis);
		}

		List<Integer> list = new ArrayList<>(ordinalToAxis.lastKey());

		int modulo = 1;

		for (int i = 0; i <= ordinalToAxis.lastKey(); i++) {
			AxisDTO axis = ordinalToAxis.get(i);
			if (axis == null) {
				// Missing axis
				list.add(0);
			} else {
				int prevModulo = modulo;
				modulo *= axis.getPositions().size();
				list.add(Integer.valueOf(ordinal % modulo / prevModulo));
			}
		}

		if (ordinal < 0 || ordinal >= modulo) {
			throw new IndexOutOfBoundsException(
					"Cell ordinal " + ordinal + ") lies outside CellSet bounds (" + getBoundsAsString(cellSet) + ")");
		}
		return list;
	}

	// Duplicated from XmlaOlap4jCellSet.ordinalToCoordinates
	private static String getBoundsAsString(CellSetDTO cellSet) {
		StringBuilder buf = new StringBuilder();
		int k = 0;
		for (AxisDTO axis : cellSet.getAxes()) {
			if (k++ > 0) {
				buf.append(", ");
			}
			buf.append(axis.getPositions().size());
		}
		return buf.toString();
	}
}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.postprocessor.dynamic;

import java.util.Map.Entry;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Strings;
import com.quartetfs.biz.pivot.ILocation;
import com.quartetfs.biz.pivot.context.IContextValue;
import com.quartetfs.biz.pivot.cube.hierarchy.measures.IPostProcessorCreationContext;
import com.quartetfs.biz.pivot.postprocessing.IBasicPostProcessor;
import com.quartetfs.biz.pivot.postprocessing.IPostProcessor;
import com.quartetfs.biz.pivot.postprocessing.impl.ABasicPostProcessor;
import com.quartetfs.biz.pivot.postprocessing.impl.ADynamicAggregationPostProcessor;
import com.quartetfs.fwk.QuartetException;
import com.quartetfs.fwk.QuartetExtendedPluginValue;

import blasd.apex.server.query.postprocessor.ApexPostProcessorHelper;
import blasd.apex.server.query.postprocessor.basic.IdentityPostProcessor;

/**
 * Aggregate the result of a {@link IBasicPostProcessor} given leaf levels and an aggregation function.
 * 
 * An {@link ABasicPostProcessor} can not be used directly: you have to make it first implements
 * {@link IBasicPostProcessor}
 * 
 * @author Benoit Lacelle
 * 
 */
@QuartetExtendedPluginValue(intf = IPostProcessor.class, key = LeafDynamicAggregationPostProcessor.PLUGIN_KEY)
public class LeafDynamicAggregationPostProcessor<LeafType, OutputType>
		extends ADynamicAggregationPostProcessor<LeafType, OutputType> {
	private static final long serialVersionUID = 6964402069735185301L;

	public static final String PLUGIN_KEY = "LEAF";

	public static final String INNER_POST_PROCESSOR = "innerPostProcessor";
	public static final String PROPERTY_INNER_PREFIX = "inner.";

	protected static final Logger LOGGER = LoggerFactory.getLogger(LeafDynamicAggregationPostProcessor.class);

	// Hide parent JUL Logger
	// Checkstyle needs UpperCase for static
	// CHECKSTYLE:OFF
	protected static final Logger logger = LOGGER;
	// CHECKSTYLE:ON

	// TODO: remove this to re-use IEvaluator logic, or not since Properties are
	// not propagated to them: not usable
	protected IBasicPostProcessor<? extends LeafType> doLeafAggregationBasicPP;

	// TODO: we have a flag as we do not know how to detect automatically when to outerPostProcess
	// protected boolean hasPartitions;

	public LeafDynamicAggregationPostProcessor(String name, IPostProcessorCreationContext pivot) {
		super(name, pivot);
	}

	@Override
	public void init(Properties properties) throws QuartetException {
		// Init BasicPP and then this
		super.init(properties);

		{
			doLeafAggregationBasicPP =
					(IBasicPostProcessor<? extends LeafType>) ApexPostProcessorHelper.makeBasicPostProcessor(this,
							properties.getProperty(INNER_POST_PROCESSOR, IdentityPostProcessor.PLUGIN_KEY));
			doLeafAggregationBasicPP.init(makeProperties(properties, PROPERTY_INNER_PREFIX));

			for (Class<? extends IContextValue> cvClass : doLeafAggregationBasicPP.getContextDependencies()) {
				addContextDependency(cvClass);
			}
		}

		// TODO By default, we keep the old/bad behavior. However, the new behaviour would not work if the PP is
		// evaluated on a single partition
		if (!Strings.isNullOrEmpty(properties.getProperty("hasPartitions"))) {
			throw new IllegalArgumentException("The property " + "hasPartitions" + " is deprecated");
		}
		// hasPartitions = Boolean.parseBoolean(properties.getProperty("hasPartitions", Boolean.toString(false)));
	}

	protected Properties makeProperties(Properties properties, String propertyInnerPrefix) {
		Properties newProperties = new Properties();

		for (Entry<Object, Object> entry : properties.entrySet()) {
			final Object key;
			if (entry.getKey().toString().startsWith(propertyInnerPrefix)) {
				key = entry.getKey().toString().substring(propertyInnerPrefix.length());
			} else {
				key = entry.getKey();
			}
			newProperties.put(key, entry.getValue());
		}

		return newProperties;
	}

	// TODO: improve partitioning as in ManyToMany

	@Override
	protected void handleNoLeafLevel() {
		// TODO: make it throw
		LOGGER.info("No leaf levels are defined in {}", getName());
	}

	/**
	 * On each leaf {@link ILocation}, apply doLeafAggregationBasicPP
	 */
	@Override
	protected LeafType evaluateLeaf(ILocation leafLocation, Object[] underlyingMeasures) {
		return doLeafAggregationBasicPP.evaluate(leafLocation, underlyingMeasures);
	}

	@Override
	public String getType() {
		return PLUGIN_KEY;
	}

}

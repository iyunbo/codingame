/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.postprocessor.basic;

import com.quartetfs.biz.pivot.ILocation;
import com.quartetfs.biz.pivot.cube.hierarchy.measures.IPostProcessorCreationContext;
import com.quartetfs.biz.pivot.postprocessing.IPostProcessor;
import com.quartetfs.biz.pivot.postprocessing.impl.ABasicPostProcessor;
import com.quartetfs.fwk.QuartetExtendedPluginValue;

import blasd.apex.server.query.postprocessor.dynamic.LeafDynamicAggregationPostProcessor;

/**
 * A {@link IPostProcessor} which returns the first element of the underlying array of measures. It is used as default
 * when {@link IPostProcessor} can be set as parameters. See {@link LeafDynamicAggregationPostProcessor} as an example.
 * 
 * @author Benoit Lacelle
 */
@QuartetExtendedPluginValue(intf = IPostProcessor.class, key = IdentityPostProcessor.PLUGIN_KEY)
public class IdentityPostProcessor extends ABasicPostProcessor<Object> {
	private static final long serialVersionUID = 8640605892163883783L;

	public static final String PLUGIN_KEY = "IDENTITY";

	public IdentityPostProcessor(String name, IPostProcessorCreationContext creationContext) {
		super(name, creationContext);
	}

	@Override
	public String getType() {
		return PLUGIN_KEY;
	}

	@Override
	public Object evaluate(ILocation location, Object[] underlyingMeasures) {
		return underlyingMeasures[0];
	}

}

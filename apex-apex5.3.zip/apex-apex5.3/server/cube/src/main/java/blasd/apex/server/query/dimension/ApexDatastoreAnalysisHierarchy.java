/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.dimension;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Strings;
import com.google.common.base.Supplier;
import com.qfs.store.IDatastore;
import com.qfs.store.IDatastoreVersion;
import com.qfs.store.IReadableDatastore;
import com.qfs.store.selection.IContinuousSelection;
import com.qfs.store.selection.impl.Selection;
import com.qfs.store.transaction.ITransactionManager;
import com.quartetfs.biz.pivot.IActivePivotManager;
import com.quartetfs.biz.pivot.IMultiVersionActivePivot;
import com.quartetfs.biz.pivot.cube.hierarchy.IAnalysisHierarchy;
import com.quartetfs.biz.pivot.cube.hierarchy.IAnalysisHierarchyInfo;
import com.quartetfs.biz.pivot.cube.hierarchy.IMultiVersionHierarchy;
import com.quartetfs.biz.pivot.postprocessing.IPostProcessor;
import com.quartetfs.fwk.QuartetExtendedPluginValue;

import blasd.apex.server.config.cube.ApexHierarchyBuilder;
import blasd.apex.server.config.cube.IApexCubeBuilder;
import blasd.apex.server.config.cube.IApexHierarchyBuilder;
import blasd.apex.server.datastore.ApexDatastoreHelper;
import blasd.apex.server.datastore.listener.ApexDefaultSelectionListener;
import blasd.apex.server.datastore.search.ApexSearchBuilder;
import blasd.apex.server.datastore.search.HasCursor;
import blasd.apex.server.datastore.transaction.ApexTransactionHelper;
import blasd.apex.server.query.ApexDrillthroughHelper;
import blasd.apex.server.registry.RegistryInject;
import cormoran.pepper.io.PepperSerializationHelper;
import cormoran.pepper.thread.PepperExecutorsHelper;

/**
 * An {@link IAnalysisHierarchy} which build its discriminator paths based on the content of an {@link IDatastore}
 * 
 * @author Benoit Lacelle
 * @see https://support.quartetfs.com/confluence/display/AP5/Migrate+to+ActivePivot+5.3#MigratetoActivePivot5.3-Factlessanalysishierachies
 */
@QuartetExtendedPluginValue(intf = IMultiVersionHierarchy.class, key = ApexDatastoreAnalysisHierarchy.PLUGIN_KEY)
public class ApexDatastoreAnalysisHierarchy extends ApexStaticAnalysisHierarchy {
	private static final long serialVersionUID = -5522224602918265654L;

	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexDatastoreAnalysisHierarchy.class);

	public static final String PLUGIN_KEY = "ApexDatastore";

	public static final String PROPERTY_PIVOT_ID = "PIVOT_ID";

	// This conflicts with "storeName" introduced in AP5.3
	// https://support.quartetfs.com/confluence/display/AP5/Migrate+to+ActivePivot+5.3#MigratetoActivePivot5.3-Factlessanalysishierachies
	@Deprecated
	public static final String OLD_PROPERTY_STORE_NAME = "storeName";

	public static final String PROPERTY_STORE_NAME = "datastoreName";
	public static final String PROPERTY_COLUMN_NAMES = "columnNames";
	public static final String PROPERTY_SEARCH_TEMPLATE = "searchTemplate";

	// We use a Supplier to make sure the injection in
	// ApexDatastoreAnalysisHierarchy does not require to build the whole
	// IActivePivotManager
	@RegistryInject
	protected transient Supplier<IActivePivotManager> apManager;

	protected String storeName;
	protected List<String> columnNames;
	protected String pivotId;
	protected Map<String, Object> searchTemplate;

	// The hierarchy needs a pivot transaction to rebuild itself
	// http://support.quartetfs.com/confluence/display/AP5/How+to+Force+an+Analysis+Hierarchy+to+be+Called+for+Rebuild
	protected final AtomicLong latestRebuiltEpoch = new AtomicLong(-1);

	/**
	 * An {@link ExecutorService} used to request empty transaction for {@link IAnalysisHierarchy} rebuilding
	 */
	protected static final ExecutorService REBUILD_ES;

	@VisibleForTesting
	public static final AtomicInteger REBUILD_ACTIVE = new AtomicInteger();

	public static final int REBUILD_QUEUE = 100;

	static {
		// The ExecutorService is daemon so that it does not prevent the JVM
		// from closing
		REBUILD_ES = PepperExecutorsHelper.newSingleThreadExecutor("RebuildAnalysisDimension",
				REBUILD_QUEUE,
				new ThreadPoolExecutor.DiscardOldestPolicy());
	}

	public ApexDatastoreAnalysisHierarchy(IAnalysisHierarchyInfo info) {
		super(info);
	}

	protected IReadableDatastore getDatastore() {
		if (datastore == null) {
			// Happens on IActivePivot not build over an IDatastore
			return null;
		} else {
			return datastore.getDatastore();
		}
	}

	@Override
	public void init() {
		super.init();

		Properties p = getProperties();

		pivotId = p.getProperty(PROPERTY_PIVOT_ID);

		columnNames = Arrays.asList(p.getProperty(PROPERTY_COLUMN_NAMES).split(IPostProcessor.SEPARATOR));
		storeName = p.getProperty(PROPERTY_STORE_NAME);

		if (storeName == null && p.containsKey(OLD_PROPERTY_STORE_NAME)) {
			throw new RuntimeException(
					"You have to change the property from " + OLD_PROPERTY_STORE_NAME + " to " + PROPERTY_STORE_NAME);
		}

		levelCountNotALL.set(columnNames.size());

		if (apManager != null && getDatastore() != null && !Strings.isNullOrEmpty(pivotId)) {
			// http://support.quartetfs.com/jira/browse/APS-6119: there is no
			// easy way to retrieve the pivotId
			final IMultiVersionActivePivot pivot = apManager.get().getActivePivots().get(pivotId);

			registerContinuousQuery(pivot);
		} else {
			LOGGER.warn(
					"Either Datastore or ActivePivotManager is not injected in {}: updates on {} won't be propagated",
					this,
					storeName);
		}
	}

	public static ApexDatastoreAnalysisHierarchyBuilder addDatastoreAnalysisHierarchy(IApexCubeBuilder builder,
			String hierarchyName) {
		IApexHierarchyBuilder hierarchyBuilder = builder.addAnalysisHierarchy(hierarchyName, PLUGIN_KEY);
		return new ApexDatastoreAnalysisHierarchyBuilder(hierarchyBuilder);
	}

	@Override
	protected List<String> makeLevelNames(Properties properties) {
		if (properties.containsKey(PROPERTY_LEVEL_NAMES)) {
			// Default behavior rely on a specific property
			return super.makeLevelNames(properties);
		} else {
			// But by default, we give as name the column name
			return PepperSerializationHelper.convertToListString(properties.getProperty(PROPERTY_COLUMN_NAMES));
		}

	}

	public void setActivePivotManager(Supplier<IActivePivotManager> apManager) {
		if (getDatastore() != null && apManager.get().getDatastore() != getDatastore()) {
			throw new RuntimeException("We are setting 2 different datastores");
		}

		this.apManager = apManager;
	}

	protected void registerContinuousQuery(final IMultiVersionActivePivot pivot) {
		IContinuousSelection continuousSelection = getDatastore().register(new Selection(storeName));

		final String baseStore = ApexDrillthroughHelper.findBaseStore(apManager.get(), pivotId);

		if (baseStore == null) {
			LOGGER.warn("For IHierarchy {}, We did not found a IActivePivotSchema for pivot={}",
					this.getHierarchyInfo().getName(),
					pivotId);
		} else if (baseStore.equals(storeName)) {
			// No need to do empty transactions since getNeedRebuild will be
			// called on the underlying store transaction
			LOGGER.info(
					"For IHierarchy {}, We did not registered an ContinuousQuery for pivot={} and store={} as it is the baseStore",
					this.getHierarchyInfo().getName(),
					pivotId,
					storeName);
		} else {
			continuousSelection.addListener(new ApexDefaultSelectionListener() {

				@Override
				public void transactionCommitted(IDatastoreVersion commitedVersion) {
					onTransactionComitted(baseStore, pivot, commitedVersion);
				}
			});
		}
	}

	protected void onTransactionComitted(String baseStore,
			IMultiVersionActivePivot pivot,
			IDatastoreVersion commitedVersion) {
		// TODO: We could skip rebuilding if thw store content did
		// not changed (e.g. a transaction with only existing
		// entries)

		if (pivot == null) {
			LOGGER.error("Null pivot: {}. Available pivotIds are {}",
					pivotId,
					apManager.get().getActivePivots().keySet());
		} else if (pivot.getHead() == null) {
			LOGGER.error("Null Head in {}. Status is {}", pivotId, pivot.getStatus());
		} else {
			// Remember the epoch we need to leave (i.e. as the rebuild
			// will be done asynchronously, we will do the rebuild only
			// if the epoch
			// would not have changed yet)
			final long currentPivotEpochId = pivot.getHead().getEpochId();

			// We can't do the transaction synchronously since we are
			// already in a transaction (as we are in
			// .transactionCommitted,
			// we are at the end of current transaction)
			REBUILD_ACTIVE.incrementAndGet();
			REBUILD_ES.execute(() -> {
				try {
					onStoreTransaction(baseStore, pivot, currentPivotEpochId);
				} catch (RuntimeException e) {
					LOGGER.warn("Exception while rebuilding IAnalysisHierarchy=" + getName());
				} finally {
					REBUILD_ACTIVE.decrementAndGet();
				}
			});
		}
	}

	protected void onStoreTransaction(String baseStore, IMultiVersionActivePivot pivot, long triggerPivotEpochId) {
		final long currentPivotEpochId = pivot.getHead().getEpochId();

		// We do an empty transaction only if the store holding the cube has not
		// been rebuilt in the meantime
		if (triggerPivotEpochId == currentPivotEpochId) {
			doEmptyTransaction(baseStore);
		} else {
			LOGGER.debug("We skip the rebuild triggered on {} as the cube has a transaction in the meantime",
					triggerPivotEpochId);
		}
	}

	protected void doEmptyTransaction(String baseStore) {
		if (getDatastore() instanceof IDatastore) {

			LOGGER.info("Do empty transaction on {} to rebuild hierarchy {}",
					baseStore,
					ApexHierarchyBuilder.hierarchyName(this.getHierarchyInfo()));

			// There have been not transactions yet to rebuild the dimension
			ITransactionManager transactionManager = ((IDatastore) getDatastore()).getTransactionManager();
			ApexTransactionHelper.doEmptyTransaction(transactionManager, Collections.singleton(baseStore));
		} else {
			LOGGER.warn("The datastore is not an IReadableDatastore."
					+ "We can not do an empty transaction to rebuild the cube");
		}
	}

	@Override
	public boolean getNeedRebuild() {
		if (getDatastore() == null) {
			return false;
		} else {
			long currentEpoch = getCurrentStoreVersion(getDatastore().getHead());

			if (currentEpoch > latestRebuiltEpoch.get()) {
				// The store has been updated since last time we built the
				// discriminator from the store content
				return true;
			} else {
				return false;
			}
		}
	}

	protected long getCurrentStoreVersion(IDatastoreVersion latestStoreVersion) {
		// TODO: we should return the version of storeName, not of the whole
		// datastore: a transaction on any store will lead to rebuilding the AD
		return latestStoreVersion.getEpochId();
	}

	@Override
	protected List<Object[]> buildPathes(Properties p) {
		if (getDatastore() == null) {
			// As part of the initialization is done during construction, we
			// don't have access to injected resources
			// throw new
			// IllegalStateException("IDatastore has not been injected");

			return Collections.emptyList();
		}

		if (p.containsKey(PROPERTY_SEARCH_TEMPLATE)) {
			Map<String, Object> searchTemplateWithStringObject =
					PepperSerializationHelper.convertToMap(p.getProperty(PROPERTY_SEARCH_TEMPLATE));

			searchTemplate = ApexDatastoreHelper.convertFromStringToObject(getDatastore().getSchemaMetadata(),
					storeName,
					searchTemplateWithStringObject);
		} else {
			searchTemplate = Collections.emptyMap();
		}

		// TODO: filter based on searchCriteriaFieldsNames

		// Do the whole search on the same version
		IDatastoreVersion latestStoreVersion = getDatastore().getHead();
		HasCursor query =
				ApexSearchBuilder.search(latestStoreVersion, storeName).select(columnNames).where(searchTemplate);

		latestRebuiltEpoch.set(getCurrentStoreVersion(latestStoreVersion));

		// We use a set to remove the duplicate paths (which is possible since
		// the columnNames may not be the primary keys)
		Set<List<Object>> newPathes = new HashSet<>();

		query.stream().map(entry -> {
			List<Object> newPath = new ArrayList<>();

			for (String columnName : columnNames) {
				newPath.add(entry.read(columnName));
			}

			return newPath;
		}).forEach(newPathes::add);

		List<Object[]> actualPathes = new ArrayList<>();

		for (List<Object> newPath : newPathes) {
			actualPathes.add(cleanPath(newPath.toArray()));
		}

		return actualPathes;
	}

	public static boolean waitForRebuild(long timeout, TimeUnit timeoutUnit) throws InterruptedException {
		final long maxDate = System.currentTimeMillis() + timeoutUnit.toMillis(timeout);
		while (REBUILD_ACTIVE.get() > 0) {
			if (System.currentTimeMillis() > maxDate) {
				LOGGER.debug("{} rebuilds left after having waited {} {}", REBUILD_ACTIVE, timeout, timeoutUnit);
				return false;
			} else {
				LOGGER.trace("Sleeping while rebuilding");
				Thread.sleep(1);
			}
		}
		return true;
	}
}

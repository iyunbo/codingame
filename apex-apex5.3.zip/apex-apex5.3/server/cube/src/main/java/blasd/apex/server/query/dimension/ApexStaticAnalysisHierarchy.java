/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.dimension;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.atomic.AtomicInteger;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.annotations.Beta;
import com.google.common.collect.ObjectArrays;
import com.quartetfs.biz.pivot.cube.hierarchy.IAnalysisHierarchy;
import com.quartetfs.biz.pivot.cube.hierarchy.IAnalysisHierarchyInfo;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevel;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevelInfo.ClassificationType;
import com.quartetfs.biz.pivot.cube.hierarchy.IMultiVersionHierarchy;
import com.quartetfs.biz.pivot.cube.hierarchy.axis.impl.AAnalysisHierarchy;
import com.quartetfs.biz.pivot.postprocessing.IPostProcessor;
import com.quartetfs.fwk.QuartetExtendedPluginValue;
import com.quartetfs.fwk.Registry;
import com.quartetfs.fwk.ordering.IComparator;
import com.quartetfs.fwk.ordering.impl.NaturalOrderComparator;

import blasd.apex.server.config.cube.ApexHierarchyBuilderDecorator;
import blasd.apex.server.config.cube.IApexCubeBuilder;
import blasd.apex.server.config.cube.IApexDimensionBuilder;
import blasd.apex.server.config.cube.IApexHierarchyBuilder;
import cormoran.pepper.io.PepperSerializationHelper;

/**
 * An {@link IAnalysisHierarchy} defined by a {@link Properties} object
 * 
 * @author Benoit Lacelle
 * 
 * @see https://support.activeviam.com/confluence/display/AP5/Analysis+hierarchies
 * @see http://support.quartetfs.com/confluence/display/AP5/Many+to+Many+mapping
 */
@QuartetExtendedPluginValue(intf = IMultiVersionHierarchy.class, key = ApexStaticAnalysisHierarchy.PLUGIN_KEY)
public class ApexStaticAnalysisHierarchy extends AAnalysisHierarchy {
	private static final long serialVersionUID = -78085552549706644L;

	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexStaticAnalysisHierarchy.class);

	public static final String PLUGIN_KEY = "ApexStatic";

	@Deprecated
	public static final String PROPERTY_DEFAULT_DISCRIMINATOR = "defaultDiscriminator";

	public static final String PROPERTY_PATH_PREFIX = "path_";

	public static final String PROPERTY_COMPARATOR = "comparator";

	/**
	 * If there is not a single entry, we need to have at least one path in the analysis hierarchy else all queries will
	 * fail
	 */
	public static final String PROPERTY_EMPTY_PATH = "emptyPath";
	public static final Object DEFAULT_EMPTY_MEMBER = "EMPTY";

	/**
	 * The name of the {@link ILevel}, not including ALL
	 */
	public static final String PROPERTY_LEVEL_NAMES = "levelNames";

	// protected String defaultDiscriminator = DEFAULT_DISCRIMINATOR;

	private static final int MAX_PATH_IN_LOGS = 100;

	protected IComparator<?> comparator;

	protected final AtomicInteger levelCountNotALL = new AtomicInteger(-1);
	protected final List<String> levelNames = new ArrayList<>();

	protected Object[] emptyPath;

	/**
	 * Initialized to null. We will fill it with first call to doInit, and then with each call to doInit when
	 * getNeedRebuild returns true
	 */
	protected Collection<Object[]> discriminatorPaths = null;

	public ApexStaticAnalysisHierarchy(IAnalysisHierarchyInfo info) {
		super(info);
	}

	@Override
	public void init() {
		doInit();

		super.init();
	}

	protected void doInit() {
		Properties properties = getHierarchyInfo().getProperties();

		// The default discriminator can be overridden
		if (properties.containsKey(PROPERTY_DEFAULT_DISCRIMINATOR)) {
			throw new RuntimeException(
					"The property " + PROPERTY_DEFAULT_DISCRIMINATOR + " is not used anymore (AP > 5.3.0)");
		}
		// TODO: Add type to enable not-string default discriminator

		if (properties.containsKey(PROPERTY_EMPTY_PATH)) {
			String[] stringPath = properties.getProperty(PROPERTY_EMPTY_PATH).split(IPostProcessor.SEPARATOR);

			// TODO: rely on PepperSerializationHelper.convertStringToObject
			emptyPath = Arrays.copyOf(stringPath, stringPath.length, Object[].class);
		} else {
			emptyPath = null;
		}

		comparator = Registry.getExtendedPlugin(IComparator.class)
				.valueOf(properties.getProperty(PROPERTY_COMPARATOR, NaturalOrderComparator.type))
				.create();

		levelNames.addAll(makeLevelNames(properties));

		if (!levelNames.isEmpty()) {
			levelCountNotALL.set(getLevelCountFromLevelNames());

			assert levelCountNotALL.get() >= 0;
		}
	}

	public static ApexStaticAnalysisHierarchyBuilder addStaticAnalysisHierarchy(IApexCubeBuilder builder,
			String hierarchyName) {
		IApexHierarchyBuilder hierarchyBuilder = builder.addAnalysisHierarchy(hierarchyName, PLUGIN_KEY);
		return new ApexStaticAnalysisHierarchyBuilder(hierarchyBuilder);
	}

	/**
	 * Helps configuring an {@link IAnalysisHierarchy}
	 * 
	 * @author Benoit Lacelle
	 *
	 */
	protected static class AApexAnalysisHierarchyBuilder extends ApexHierarchyBuilderDecorator {

		public AApexAnalysisHierarchyBuilder(IApexHierarchyBuilder hierarchyBuilder) {
			super(hierarchyBuilder);
		}

		public AApexAnalysisHierarchyBuilder(IApexDimensionBuilder dimensionBuilder, String hierarchyName) {
			super(dimensionBuilder.addAnalysisHierarchy(hierarchyName, ApexStaticAnalysisHierarchy.PLUGIN_KEY));
		}

		public AApexAnalysisHierarchyBuilder(IApexCubeBuilder cubeBuilder, String hierarchyName) {
			this(cubeBuilder.addAnalysisHierarchy(hierarchyName, ApexStaticAnalysisHierarchy.PLUGIN_KEY));
		}

		// TODO: find a way to defined it on a per-level basis
		@Beta
		public AApexAnalysisHierarchyBuilder setComparatorPluginKey(String comparatorPluginKey) {
			setProperty(PROPERTY_COMPARATOR, comparatorPluginKey);
			return this;
		}

		public AApexAnalysisHierarchyBuilder setLevelNames(String... levelNames) {
			setPropertyList(PROPERTY_LEVEL_NAMES, levelNames);
			return this;
		}

		public AApexAnalysisHierarchyBuilder setDefaultEmptyPath(String... emptyPathElements) {
			setPropertyList(PROPERTY_EMPTY_PATH, emptyPathElements);
			return this;
		}
	}

	protected List<String> makeLevelNames(Properties p) {
		if (p.containsKey(PROPERTY_LEVEL_NAMES)) {
			return PepperSerializationHelper.convertToListString(p.getProperty(PROPERTY_LEVEL_NAMES));
		} else {
			// We will rely on default level naming, as defined in
			// AAnalysisHierarchy
			return Collections.emptyList();
		}
	}

	protected int getLevelCountFromLevelNames() {
		return levelNames.size();
	}

	protected List<Object[]> buildPathes(Properties p) {
		List<Object[]> newPathes = new ArrayList<>();

		int i = 0;
		while (p.getProperty(PROPERTY_PATH_PREFIX + i) != null) {
			// Ensure to accept serialized Objects
			Object[] asArray =
					PepperSerializationHelper.convertToList(p.getProperty(PROPERTY_PATH_PREFIX + i)).toArray();

			asArray = cleanPath(asArray);

			newPathes.add(asArray);

			if (i < MAX_PATH_IN_LOGS) {
				LOGGER.info("We registered {} as path for {}", asArray, this.getHierarchyInfo().getName());
			} else {
				// We do not want to log too much, especially in Autopivot where we systematically generate 1000
				// scenarios
				LOGGER.debug("We registered {} as path for {}", asArray, this.getHierarchyInfo().getName());
			}

			i++;
		}

		if (i >= MAX_PATH_IN_LOGS) {
			LOGGER.info("We registered in total {} pathes for {}", newPathes.size(), this.getHierarchyInfo().getName());
		}

		return newPathes;
	}

	protected Object[] cleanPath(Object[] asArray) {
		if (isAllMembersEnabled) {
			// Add automatically the AllMember depending on if the IHierarchy
			// has an ALL level
			asArray = ObjectArrays.concat(ILevel.ALLMEMBER, asArray);
		}

		return asArray;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public IComparator<Object> getLevelComparator(int levelOrdinal) {
		return (IComparator) comparator;
	}

	@Override
	public int getLevelsCount() {
		if (levelCountNotALL.get() == -1) {
			// No explicit levelNames: we rely on discriminator pathes
			buildDiscriminatorPaths();

			if (levelCountNotALL.get() == -1) {
				throw new RuntimeException("The configuration did not enable us to count the number of levels");
			}
		}

		if (isAllMembersEnabled) {
			return levelCountNotALL.get() + 1;
		} else {
			return levelCountNotALL.get();
		}
	}

	@Override
	public Collection<Object[]> buildDiscriminatorPaths() {
		if (discriminatorPaths == null || getNeedRebuild()) {
			discriminatorPaths = buildPathes(getHierarchyInfo().getProperties());

			if (discriminatorPaths.isEmpty()) {
				if (emptyPath == null) {
					if (levelCountNotALL.get() >= 0) {
						emptyPath = new Object[levelCountNotALL.get()];
						Arrays.fill(emptyPath, DEFAULT_EMPTY_MEMBER);
					} else {
						LOGGER.error("The analsysis hierarchy {} is empty. All cube queries will be empty",
								this.getHierarchyInfo().getName());
					}
				}

				if (emptyPath != null) {
					discriminatorPaths = Collections.singletonList(cleanPath(emptyPath));
				}
			}

			// We might have added a default empty path
			if (!discriminatorPaths.isEmpty()) {
				// Initialize levelCountNotALL with first path encountered
				// if level names were not defined
				Object[] firstPath = discriminatorPaths.iterator().next();

				int length;
				if (isAllMembersEnabled) {
					length = firstPath.length - 1;
				} else {
					length = firstPath.length;
				}

				assert length >= 0;

				levelCountNotALL.compareAndSet(-1, length);
			}

			for (Object[] path : discriminatorPaths) {
				if (path.length != getLevelsCount()) {
					throw new RuntimeException("We are publishing a path with unexpected size (" + getLevelsCount()
							+ ") : "
							+ Arrays.toString(path)
							+ " along "
							+ this);
				}
			}
		}

		return discriminatorPaths;
	}

	@Override
	public String getLevelName(int levelOrdinal) {
		if (levelNames.isEmpty()) {
			String prefix = getHierarchyInfo().getName();
			if (isAllMembersEnabled) {
				if (levelOrdinal == 0) {
					return ClassificationType.ALL.name();
				} else if (levelOrdinal == 1) {
					return prefix;
				} else {
					return prefix + "_" + (levelOrdinal - 1);
				}
			} else {
				if (levelOrdinal == 0) {
					return prefix;
				} else {
					return prefix + "_" + levelOrdinal;
				}
			}
		} else {
			if (isAllMembersEnabled) {
				return levelNames.get(levelOrdinal - 1);
			} else {
				return levelNames.get(levelOrdinal);
			}
		}
	}

	@Override
	public String getType() {
		return PLUGIN_KEY;
	}
}

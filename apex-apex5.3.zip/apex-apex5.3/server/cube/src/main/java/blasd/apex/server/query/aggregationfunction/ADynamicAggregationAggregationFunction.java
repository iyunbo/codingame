/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.aggregationfunction;

import com.qfs.agg.impl.AGenericAggregationFunction;

/**
 * Facilitate the implementation of {@link AGenericAggregationFunction} when they can be used only for aggregation
 * purposes (i.e. no decontribution)
 * 
 * @author Benoit Lacelle
 * 
 */
public abstract class ADynamicAggregationAggregationFunction<AggregateType, InputType>
		extends AGenericAggregationFunction<AggregateType, InputType> {
	private static final long serialVersionUID = 2846260843363254284L;

	public ADynamicAggregationAggregationFunction(String name, int aggregateDataType) {
		super(name, aggregateDataType);
	}

	public ADynamicAggregationAggregationFunction(String name) {
		super(name);
	}

	@Override
	public String description() {
		return this.getClass().getName() + "(" + name + ")";
	}

	@Override
	protected AggregateType aggregate(boolean removal, AggregateType aggregate, InputType inputValue) {
		if (removal) {
			throw new RuntimeException(
					this.getClass() + " should not be used for primitive aggregation, but only in ADynamicAggregation");
		}

		try {
			return aggregate(aggregate, inputValue);
		} catch (RuntimeException e) {
			throw new RuntimeException("Failure while aggregating " + inputValue + " in " + aggregate, e);
		}
	}

	/**
	 * 
	 * @param aggregate
	 *            an aggregate which can be mutated with inputValue.
	 * @param inputValue
	 *            typically
	 * @return the output aggregate, having merged the initial aggregate and the inputValue. It is allowed to be the
	 *         same reference as the initial aggregate. It is NOT allowed to return the same reference as the inputValue
	 *         if the inputValue is mutable, as it might be an intermediate aggregate which might be later mutated by
	 *         ActivePivot
	 */
	protected abstract AggregateType aggregate(AggregateType aggregate, InputType inputValue);

	@Override
	protected AggregateType merge(boolean removal, AggregateType mainAggregate, AggregateType contributedAggregate) {
		if (removal) {
			throw new RuntimeException(
					this.getClass() + " should not be used for primitive aggregation, but only in ADynamicAggregation");
		}

		try {
			return merge(mainAggregate, contributedAggregate);
		} catch (RuntimeException e) {
			throw new RuntimeException("Failure while aggregating " + contributedAggregate + " in " + mainAggregate, e);
		}
	}

	protected abstract AggregateType merge(AggregateType mainAggregate, AggregateType contributedAggregate);

}

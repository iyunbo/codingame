/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query;

import java.util.List;
import java.util.NavigableMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicLong;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.quartetfs.biz.pivot.cellset.ICellSet;
import com.quartetfs.biz.pivot.cube.hierarchy.IMultiVersionHierarchy;
import com.quartetfs.biz.pivot.query.IGetAggregatesContinuousQueryListener;
import com.quartetfs.biz.pivot.query.IGetAggregatesQuery;
import com.quartetfs.biz.pivot.query.IVersionedContinuousQueryUpdate;
import com.quartetfs.fwk.query.IContinuousQuery;

import blasd.apex.server.query.cellset.ApexCellSetHelper;
import blasd.apex.server.query.hierarchy.ApexHierarchyHelper;
import blasd.apex.server.query.hierarchy.IApexAxisHierarchyInfo;

/**
 * Listen to an {@link IGetAggregatesQuery} but wraps the result in a Map for user-friendlyness
 * 
 * @author Benoit Lacelle
 *
 */
public class ApexGetAggregatesAsMapListener implements IGetAggregatesContinuousQueryListener {

	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexGetAggregatesAsMapListener.class);
	protected final List<? extends IApexAxisHierarchyInfo> hierarchies;
	protected final List<NavigableMap<String, List<?>>> mapCellSet;

	/**
	 * The IActievPivotVersion epochId of the latest received IVersionedContinuousQueryUpdate
	 */
	protected final AtomicLong latestImpactedAPVersion = new AtomicLong();

	/**
	 * The IDatastoreVersion epochId of the latest received IVersionedContinuousQueryUpdate
	 */
	protected final AtomicLong latestDatastoreVersion = new AtomicLong();

	public ApexGetAggregatesAsMapListener(List<? extends IApexAxisHierarchyInfo> hierarchies) {
		this.hierarchies = hierarchies;
		this.mapCellSet = new CopyOnWriteArrayList<>();
	}

	public static ApexGetAggregatesAsMapListener makeListener(List<? extends IMultiVersionHierarchy> hierarchies) {
		return new ApexGetAggregatesAsMapListener(ApexHierarchyHelper.extractApexAxisHierarchiesInfo(hierarchies));
	}

	@Override
	public void viewUpdated(IVersionedContinuousQueryUpdate<ICellSet> update) {
		latestImpactedAPVersion.set(update.getVersion().getEpochId());
		latestDatastoreVersion.set(update.getDatastoreVersion().getEpochId());

		LOGGER.trace("Update: {}", update);
		{
			List<NavigableMap<String, List<?>>> humanRemoved =
					ApexCellSetHelper.convertToListMap(update.getRemoved(), hierarchies);

			for (NavigableMap<String, List<?>> oneRemoved : humanRemoved) {
				ApexCellSetHelper.setValue(mapCellSet, oneRemoved);
			}
		}

		{
			List<NavigableMap<String, List<?>>> humanAdded =
					ApexCellSetHelper.convertToListMap(update.getAdded(), hierarchies);

			for (NavigableMap<String, List<?>> oneAdded : humanAdded) {
				ApexCellSetHelper.setValue(mapCellSet, oneAdded);
			}
		}

		{
			List<NavigableMap<String, List<?>>> humanRefreshed =
					ApexCellSetHelper.convertToListMap(update.getRefreshed(), hierarchies);

			for (NavigableMap<String, List<?>> oneAdded : humanRefreshed) {
				ApexCellSetHelper.setValue(mapCellSet, oneAdded);
			}
		}

	}

	@Override
	public void registration(
			IContinuousQuery<? extends ICellSet, ? extends IVersionedContinuousQueryUpdate<ICellSet>> paramIContinuousQuery) {
		// do nothing
	}

	@Override
	public void deregistration(
			IContinuousQuery<? extends ICellSet, ? extends IVersionedContinuousQueryUpdate<ICellSet>> paramIContinuousQuery) {
		// do nothing
	}

	public List<NavigableMap<String, List<?>>> getLiveStateAsList() {
		return mapCellSet;
	}

}

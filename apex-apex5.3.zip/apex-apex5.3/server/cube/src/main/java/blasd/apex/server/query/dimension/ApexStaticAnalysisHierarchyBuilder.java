/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.dimension;

import java.util.Arrays;

import com.google.common.collect.Iterables;

import blasd.apex.server.config.cube.IApexDimensionBuilder;
import blasd.apex.server.config.cube.IApexHierarchiesHolder;
import blasd.apex.server.config.cube.IApexHierarchyBuilder;
import blasd.apex.server.query.dimension.ApexStaticAnalysisHierarchy.AApexAnalysisHierarchyBuilder;
import cormoran.pepper.io.PepperSerializationHelper;

/**
 * Helps building an analysis hierarchy based over a static list of values
 * 
 * @author Benoit Lacelle
 *
 */
public class ApexStaticAnalysisHierarchyBuilder extends AApexAnalysisHierarchyBuilder {

	protected int nextPathIndex = 0;

	public ApexStaticAnalysisHierarchyBuilder(IApexHierarchyBuilder hierarchyBuilder) {
		super(hierarchyBuilder);

		hierarchyBuilder.setPluginKey(ApexStaticAnalysisHierarchy.PLUGIN_KEY);
	}

	public ApexStaticAnalysisHierarchyBuilder(IApexDimensionBuilder dimensionBuilder, String hierarchyName) {
		super(dimensionBuilder.addAnalysisHierarchy(hierarchyName, ApexStaticAnalysisHierarchy.PLUGIN_KEY));
	}

	public ApexStaticAnalysisHierarchyBuilder(IApexHierarchiesHolder cubeBuilder, String hierarchyName) {
		this(cubeBuilder.addAnalysisHierarchy(hierarchyName, ApexStaticAnalysisHierarchy.PLUGIN_KEY));
	}

	public ApexStaticAnalysisHierarchyBuilder addPath(Iterable<?> path) {
		// Search for next path index: in case a path has been added in the
		// property by any other mean
		while (getDescription().getProperties()
				.containsKey(ApexStaticAnalysisHierarchy.PROPERTY_PATH_PREFIX + nextPathIndex)) {
			nextPathIndex++;
		}

		setPropertyList(ApexStaticAnalysisHierarchy.PROPERTY_PATH_PREFIX + nextPathIndex,
				// Convert a LocalDate to 'joda.time:2016-05-13'
				Iterables.transform(path, input -> PepperSerializationHelper.convertObjectToString(input)));
		return this;
	}

	public ApexStaticAnalysisHierarchyBuilder addPath(Object... path) {
		return addPath(Arrays.asList(path));
	}

	@Override
	public ApexStaticAnalysisHierarchyBuilder setLevelNames(String... levelNames) {
		setPropertyList(ApexStaticAnalysisHierarchy.PROPERTY_LEVEL_NAMES, levelNames);
		return this;
	}

	@Override
	public ApexStaticAnalysisHierarchyBuilder setDefaultEmptyPath(String... emptyPathElements) {
		setPropertyList(ApexStaticAnalysisHierarchy.PROPERTY_EMPTY_PATH, emptyPathElements);
		return this;
	}
}
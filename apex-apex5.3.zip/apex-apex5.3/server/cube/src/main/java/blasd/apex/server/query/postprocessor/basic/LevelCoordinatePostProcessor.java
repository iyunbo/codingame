/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.postprocessor.basic;

import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Strings;
import com.quartetfs.biz.pivot.ILocation;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevelInfo;
import com.quartetfs.biz.pivot.cube.hierarchy.measures.IPostProcessorCreationContext;
import com.quartetfs.biz.pivot.postprocessing.IPostProcessor;
import com.quartetfs.biz.pivot.postprocessing.impl.ABasicPostProcessor;
import com.quartetfs.fwk.QuartetException;
import com.quartetfs.fwk.QuartetExtendedPluginValue;

import blasd.apex.server.query.hierarchy.ApexHierarchyHelper;
import blasd.apex.server.query.location.ApexLocationHelper;

/**
 * Combines the 2 underlyingValues in a Map.Entry
 * 
 * @author Benoit Lacelle
 *
 */
@QuartetExtendedPluginValue(intf = IPostProcessor.class, key = LevelCoordinatePostProcessor.PLUGIN_KEY)
public class LevelCoordinatePostProcessor extends ABasicPostProcessor<Object> {
	private static final long serialVersionUID = 4508011783377080797L;

	protected static final Logger LOGGER = LoggerFactory.getLogger(LevelCoordinatePostProcessor.class);

	public static final String PLUGIN_KEY = "LevelCoordinate";

	public static final String PROPERTY_LEVEL_ID = "levelId";

	protected ILevelInfo levelInfo;

	public LevelCoordinatePostProcessor(String name, IPostProcessorCreationContext creationContext) {
		super(name, creationContext);
	}

	@Override
	public void init(Properties properties) throws QuartetException {
		super.init(properties);

		String mapEntryDesc = properties.getProperty(PROPERTY_LEVEL_ID);
		if (Strings.isNullOrEmpty(mapEntryDesc)) {
			throw new RuntimeException("We are missing the property " + PROPERTY_LEVEL_ID);
		} else {
			levelInfo = ApexHierarchyHelper.findLevel(getActivePivot().getHierarchies(), mapEntryDesc).getLevelInfo();
		}
	}

	@Override
	public String getType() {
		return PLUGIN_KEY;
	}

	@Override
	public Object evaluate(ILocation pointLocation, Object[] underlyingValues) {
		return levelCoordinate(pointLocation, underlyingValues);
	}

	protected Object levelCoordinate(ILocation pointLocation, Object[] underlyingValues) {
		return ApexLocationHelper.getSafeCoordinate(pointLocation, levelInfo);
	}

}

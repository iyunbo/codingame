/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.postprocessor;

import java.util.concurrent.Callable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Optional;
import com.quartetfs.biz.pivot.context.IActivePivotContext;
import com.quartetfs.biz.pivot.cube.hierarchy.measures.impl.PostProcessorCreationContext;
import com.quartetfs.biz.pivot.postprocessing.IBasicPostProcessor;
import com.quartetfs.biz.pivot.postprocessing.IPostProcessor;
import com.quartetfs.biz.pivot.postprocessing.impl.AAdvancedPostProcessor;
import com.quartetfs.biz.pivot.postprocessing.impl.AAdvancedPostProcessorSpy;
import com.quartetfs.biz.pivot.query.IQueryCache;
import com.quartetfs.biz.pivot.query.impl.QueryCache;
import com.quartetfs.fwk.QuartetException;
import com.quartetfs.fwk.Registry;
import com.quartetfs.fwk.types.IFactory;

import blasd.apex.server.datastore.ApexDatastoreHelper;
import blasd.apex.server.query.postprocessor.dynamic.LeafDynamicAggregationPostProcessor;
import cormoran.pepper.collection.ArrayWithHashcodeEquals;

/**
 * Utility methods for {@link IPostProcessor}
 * 
 * @author Benoit Lacelle
 *
 */
public class ApexPostProcessorHelper {

	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexPostProcessorHelper.class);

	public static final char S = ',';

	protected ApexPostProcessorHelper() {
		// hidden
	}

	/**
	 * @return An {@link IBasicPostProcessor} to be used as underlying by a {@link IPostProcessor} like
	 *         {@link LeafDynamicAggregationPostProcessor}
	 * @throws QuartetException
	 */
	public static IBasicPostProcessor<?> makeBasicPostProcessor(AAdvancedPostProcessor<?> parent,
			String postProcessorKey) throws QuartetException {
		@SuppressWarnings("rawtypes")
		IFactory<IPostProcessor> factory = Registry.getExtendedPlugin(IPostProcessor.class).valueOf(postProcessorKey);

		if (factory == null) {
			throw new RuntimeException("There is no post-processor associated to the key: " + postProcessorKey
					+ ". Available: "
					+ Registry.getExtendedPlugin(IPostProcessor.class).keys());
		}

		IPostProcessor<?> postProcessor = factory.create(postProcessorKey + "@" + parent.getName(),
				new PostProcessorCreationContext(AAdvancedPostProcessorSpy.getActivePivot(parent),
						AAdvancedPostProcessorSpy.getMeasuresProvider(parent)));
		if (postProcessor instanceof IBasicPostProcessor<?>) {
			return (IBasicPostProcessor<?>) postProcessor;
		} else {
			throw new RuntimeException(
					postProcessorKey + "(" + postProcessor.getClass() + ") should be a " + IBasicPostProcessor.class);
		}
	}

	/**
	 * Throw if current query has been executing for longer than the IQueryTimeOut
	 */
	@Deprecated
	public static void checkInterruption() {
		ApexDatastoreHelper.checkInterruption(ApexPostProcessorHelper.class.getName());
	}

	public static <T> T getOrCache(IActivePivotContext context, Callable<T> makeValue, Object... key) {
		IQueryCache queryCache = context.get(IQueryCache.class);
		if (queryCache == null) {
			LOGGER.trace("Unit Test?");
			queryCache = new QueryCache();
		}

		// Build a key with a nice hascode/equals
		ArrayWithHashcodeEquals keyAsList = new ArrayWithHashcodeEquals(key);

		// Try to get current value
		Optional<?> cached = (Optional<?>) queryCache.get(keyAsList);
		if (cached == null) {
			try {
				cached = Optional.fromNullable(makeValue.call());
			} catch (Exception e) {
				throw new RuntimeException(e);
			}

			LOGGER.trace("Put {} for key {}", cached, keyAsList);
			queryCache.putIfAbsent(keyAsList, cached);
		}

		if (cached.isPresent()) {
			return (T) cached.get();
		} else {
			return null;
		}
	}
}

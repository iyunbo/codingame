/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.location;

import java.util.Collection;
import java.util.Map;

import com.quartetfs.biz.pivot.ILocation;
import com.quartetfs.biz.pivot.cube.hierarchy.IHierarchy;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevelInfo;

/**
 * Helps building ILocation objects
 * 
 * @author Benoit Lacelle
 *
 */
public interface IApexLocationBuilder extends Cloneable {

	IApexLocationBuilder clone(); // NOPMD Can remove //NOPMD with Apex-core1.6

	/**
	 * By default, we leave null on slicing {@link IHierarchy}
	 * 
	 * @deprecated Not implemented yet
	 */
	@Deprecated
	IApexLocationBuilder setDefaultValuesOnSlicingHierarchies();

	/**
	 * This is the default behavior: we leave null on slicing {@link IHierarchy}
	 */
	IApexLocationBuilder setWildcardsOnSlicingHierarchies();

	IApexLocationBuilder filter(Map<String, ?> levelNamesToValues);

	IApexLocationBuilder filterLevels(Map<? extends ILevelInfo, ?> levelNamesToValues);

	IApexLocationBuilder filter(ILevelInfo level, Object value);

	/**
	 * 
	 * @param level
	 *            the level id on which to apply a filter
	 * @param value
	 * @throws IllegalArgumentException
	 *             if the level is already filtered on another value
	 */
	IApexLocationBuilder filter(String level, Object value);

	/**
	 * 
	 * @param level
	 *            the level id on which to apply a filter
	 * @param hierarchy
	 *            the hierarchy owning the level on which to apply a filter
	 * @param value
	 * @throws IllegalArgumentException
	 *             if the level is already filtered on another value
	 */
	IApexLocationBuilder filter(String level, String hierarchy, Object value);

	/**
	 * 
	 * @param level
	 *            the level id on which to apply a filter
	 * @param hierarchy
	 *            the hierarchy owning the level on which to apply a filter
	 * @param dimension
	 *            the dimension owning the hierarchy on which to apply a filter
	 * @param value
	 * @throws IllegalArgumentException
	 *             if the level is already filtered on another value
	 */
	IApexLocationBuilder filter(String level, String hierarchy, String dimension, Object value);

	IApexLocationBuilder wildcard(Iterable<? extends ILevelInfo> wildcardLevels);

	// Collection not to overload the ILevelInfo equivalent
	IApexLocationBuilder wildcard(Collection<? extends String> wildcardLevels);

	IApexLocationBuilder wildcard(String... levels);

	IApexLocationBuilder wildcardOne(String level, String hierarchy);

	IApexLocationBuilder wildcard(String hierarchyName, int levelIndexSkipAll);

	IApexLocationBuilder filter(String hierarchyName, int levelIndexSkipAll, Object value);

	ILocation build();

}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.spring;

import java.util.concurrent.Future;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.security.core.userdetails.UserDetailsService;

import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;
import com.qfs.desc.IDatastoreSchemaDescription;
import com.qfs.desc.impl.DictionarizeFieldsPostProcessor;
import com.qfs.desc.impl.NonNullableFieldsPostProcessor;
import com.qfs.pivot.content.IActivePivotContentService;
import com.qfs.pivot.content.impl.DynamicActivePivotContentServiceMBean;
import com.qfs.server.cfg.impl.ActivePivotConfig;
import com.qfs.store.IReadableDatastore;
import com.quartetfs.biz.pivot.IActivePivotManager;
import com.quartetfs.biz.pivot.definitions.IActivePivotManagerDescription;
import com.quartetfs.biz.pivot.definitions.IAxisLevelDescription;
import com.quartetfs.biz.pivot.definitions.impl.ActivePivotDatastorePostProcessor;
import com.quartetfs.biz.pivot.security.IAuthorityComparator;
import com.quartetfs.biz.pivot.security.IContextValueManager;
import com.quartetfs.biz.pivot.security.IEntitlementsProvider;
import com.quartetfs.biz.pivot.security.impl.AuthorityComparatorAdapter;
import com.quartetfs.biz.pivot.security.impl.BasicEntitlementsProvider;
import com.quartetfs.biz.pivot.security.impl.ContextValueManager;
import com.quartetfs.biz.pivot.security.impl.UserDetailsServiceWrapper;
import com.quartetfs.fwk.AgentException;
import com.quartetfs.fwk.monitoring.jmx.impl.JMXEnabler;
import com.quartetfs.fwk.ordering.impl.CustomComparator;
import com.quartetfs.fwk.security.IUserDetailsService;

import blasd.apex.server.registry.ApexRegistryHelper;

/**
 * By using this class, you do not needs to use the core {@link ActivePivotConfig}
 * 
 * 
 * @author Benoit Lacelle
 * 
 */
@Configuration
@Import({ ApexFakeActivePivotConfig.class })
public class ApexActivePivotSpringConfig {

	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexActivePivotSpringConfig.class);

	/**
	 * Default Catalog Name, which enables re-using the same Excel connection as the CatalogName did not change
	 */
	public static final String DEFAULT_CATALOG_NAME = "AllCubes";

	@Bean
	public IEntitlementsProvider apexRoleMapping(IAuthorityComparator authorityComparator) {
		BasicEntitlementsProvider entitlementsProvider = new BasicEntitlementsProvider();

		entitlementsProvider.setAuthorityComparator(authorityComparator);

		return entitlementsProvider;
	}

	/**
	 * Defines the comparator used by the {@link ContextValueManager#setAuthorityComparator(IAuthorityComparator)
	 * ContextValueManager} and the IJwtService.
	 *
	 * @return a comparator that indicates which authority/role prevails over another. <b>NOTICE - an authority coming
	 *         AFTER another one prevails over this "previous" authority.</b> This authority ordering definition is
	 *         essential to resolve possible ambiguity when, for a given user, a context value has been defined in more
	 *         than one authority applicable to that user. In such case, it is what has been set for the "prevailing"
	 *         authority that will be effectively retained for that context value for that user.
	 */
	// Also defined in ApexAllSecurityConfigurer.apexAuthorityComparator()
	@Bean
	public IAuthorityComparator apexAuthorityComparator() {
		final CustomComparator<String> comp = new CustomComparator<>();

		return new AuthorityComparatorAdapter(comp);
	}

	// Also defined in ApexAllSecurityConfigurer.apexQfsUserDetailsService()
	@Bean
	public IUserDetailsService apexQfsUserDetailsService(UserDetailsService userDetailsService) {
		UserDetailsServiceWrapper userDetailsServiceWrapper = new UserDetailsServiceWrapper(userDetailsService);

		ApexRegistryHelper.injectDistributedDependencies(userDetailsServiceWrapper);

		return userDetailsServiceWrapper;
	}

	/**
	 * As defined in ActivePivotConfig
	 */
	@Bean(destroyMethod = "shutdown")
	public IContextValueManager apexContextValueManager(IEntitlementsProvider entitlementsProvider,
			IAuthorityComparator authorityComparator) {
		ContextValueManager contextValueManager = new ContextValueManager();
		contextValueManager.setEntitlementsProvider(entitlementsProvider);
		contextValueManager.setAuthorityComparator(authorityComparator);

		ApexRegistryHelper.injectDistributedDependencies(contextValueManager);

		return contextValueManager;
	}

	@Bean
	public IApexActivePivotManagerFactory apexActivePivotManagerFactory() {
		return new DefaultApexActivePivotManagerFactory();
	}

	/**
	 * As defined in ActivePivotConfig.
	 */
	// IActivePivotConfig requires the bean to be associated to given name. However, we do not want to be identified
	// with
	// "activePivotManager" else Apex may override a custom piece of config: we use an alias
	// TODO in Apex4.0, we introduced a constant in ApexFakeActivePivotConfig
	@Bean(destroyMethod = "stop", name = "activePivotManager")
	public IActivePivotManager apexActivePivotManager(IReadableDatastore datastore,
			IDatastoreSchemaDescription datastoreSchemaDescription,
			IActivePivotManagerDescription apManagerDescription,
			IApexActivePivotManagerFactory apexActivePivotManagerBuildersupplier) {
		return apexActivePivotManagerBuildersupplier
				.makeActivePivotManager(datastore, datastoreSchemaDescription, apManagerDescription);
	}

	/**
	 * 
	 * @param activePivotManagerDescription
	 * @return a IDatastoreSchemaDescriptionPostProcessor which enforce {@link NonNullableFieldsPostProcessor} and
	 *         {@link DictionarizeFieldsPostProcessor} based on {@link IAxisLevelDescription} fields
	 */
	@Bean
	public ActivePivotDatastorePostProcessor apexActivePivotDatastorePostProcessor(
			IActivePivotManagerDescription managerDescription) {
		return createActivePivotDatastorePostProcessorFrom(managerDescription);
	}

	/**
	 * This can not be in ApexDatastoreConfig as its module does not see ActivePivot jar
	 */
	public static ActivePivotDatastorePostProcessor createActivePivotDatastorePostProcessorFrom(
			IActivePivotManagerDescription managerDescription) {
		// Rely on IActivePivotManagerDescription, as it could hold several
		// IActivePivotSchemaDescription

		// http://support.quartetfs.com/jira/browse/APS-7853
		// This issue is not prevented anymore since AP5.7.X

		return ActivePivotDatastorePostProcessor.createFrom(managerDescription);
	}

	/**
	 * Initialize and start the {@link IActivePivotManager}
	 * 
	 * @param contextValueManager
	 * @param userDetailsService
	 */
	@Bean
	public @Qualifier(IApexAsyncQualifiers.ACTIVEPIVOT_MANAGER_IS_INIT) ListenableFuture<IActivePivotManager> apexInitAPManager(
			IActivePivotManager activePivotManager,
			IContextValueManager contextValueManager,
			IUserDetailsService userDetailsService) throws AgentException {
		// We need to ensure the core ExtendedPlugins are injected before initializing the ActivePivotManager
		ApexRegistryHelper.injectDistributedDependencies(contextValueManager);
		ApexRegistryHelper.injectDistributedDependencies(userDetailsService);

		activePivotManager.init(null);

		return Futures.immediateFuture(activePivotManager);
	}

	@Bean
	public @Qualifier(IApexAsyncQualifiers.ACTIVEPIVOT_MANAGER_IS_STARTED) ListenableFuture<IActivePivotManager> apexStartAPManager(
			@Qualifier(IApexAsyncQualifiers.ACTIVEPIVOT_MANAGER_IS_INIT) ListenableFuture<IActivePivotManager> apManagerFuture)
			throws AgentException {
		IActivePivotManager apManagerInit = Futures.getUnchecked(apManagerFuture);

		// Register the Bean right away, not to have to wait for the end of
		// ApplicationContext loading before being able to see it in the
		// JConsole
		apexActivePivotJmxEnabler(Futures.immediateFuture(apManagerInit));

		apManagerInit.start();

		return Futures.immediateFuture(apManagerInit);
	}

	/**
	 * This {@link Bean} is loaded lazily as it must not be started before the {@link IActivePivotManager} is
	 * initialized
	 */
	@Bean
	public JMXEnabler apexActivePivotJmxEnabler(
			@Qualifier(IApexAsyncQualifiers.ACTIVEPIVOT_MANAGER_IS_STARTED) Future<IActivePivotManager> apManagerIsStarted) {
		return new JMXEnabler(Futures.getUnchecked(apManagerIsStarted));
	}

	@Bean
	public JMXEnabler apexContextServiceJmxEnabler(IActivePivotContentService contentService,
			IActivePivotManager apManager) throws Exception {
		return new JMXEnabler(new DynamicActivePivotContentServiceMBean(contentService, apManager));
	}

	/**
	 * Ensure all JMXEnablers records all statistics from the startup of the application
	 */
	@Bean
	public EnableAllStatisticsAtStartupBeanPostProcessor apexEnableAllStatisticsAtStartup() {
		return new EnableAllStatisticsAtStartupBeanPostProcessor();
	}
}

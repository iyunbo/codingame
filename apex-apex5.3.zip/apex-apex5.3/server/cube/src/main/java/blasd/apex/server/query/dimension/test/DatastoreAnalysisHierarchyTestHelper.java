/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.dimension.test;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;

import com.google.common.collect.ImmutableMap;
import com.qfs.desc.IStoreDescription;
import com.qfs.desc.IStoreDescriptionBuilder;
import com.qfs.desc.IStoreDescriptionBuilder.ICanBuild;
import com.qfs.literal.ILiteralType;
import com.quartetfs.biz.pivot.definitions.IActivePivotDescription;
import com.quartetfs.biz.pivot.postprocessing.IPostProcessor;

import blasd.apex.server.config.cube.ApexCubeBuilder;
import blasd.apex.server.config.cube.IApexCubeBuilder;
import blasd.apex.server.config.cube.IApexHierarchyBuilder;
import blasd.apex.server.datastore.test.ApexTestDatastoreHelper;
import blasd.apex.server.query.dimension.ApexDatastoreAnalysisHierarchy;
import blasd.apex.server.query.dimension.ApexDatastoreAnalysisHierarchyBuilder;
import cormoran.pepper.io.PepperSerializationHelper;

/**
 * Helpers for tests based on Analysis hierarchies
 * 
 * @author Benoit Lacelle
 *
 */
public class DatastoreAnalysisHierarchyTestHelper implements IDatastoreAnalysisHierarchyTestHelper {

	protected DatastoreAnalysisHierarchyTestHelper() {
		// hidden
	}

	public static IStoreDescription getGroupNameTypeDetailStoreDescription() {
		Map<String, String> fieldDescriptions = new LinkedHashMap<>();
		fieldDescriptions.put(GROUP_NAME, STRING);
		fieldDescriptions.put(GROUP_DETAIL, STRING);
		fieldDescriptions.put(GROUP_DETAIL_TYPE, STRING);

		IStoreDescription storeDescription = ApexTestDatastoreHelper
				.createStoreDescription(GROUP_STORE_NAME, fieldDescriptions, Arrays.asList(GROUP_NAME, GROUP_DETAIL));

		ICanBuild canBuild = ApexTestDatastoreHelper.loadStoreDescriptionBuilder(storeDescription);

		// We index all possibilities

		IStoreDescriptionBuilder.ICanHaveIndex canAddIndex = (IStoreDescriptionBuilder.ICanHaveIndex) canBuild;

		// In CCY, we do NOT have GROUP_DETAIL_TYPE as hardcoded
		canAddIndex.withIndexOn(GROUP_NAME);
		canAddIndex.withIndexOn(GROUP_DETAIL);

		// In CountryGroup, we have GROUP_DETAIL_TYPE as hardcoded
		canAddIndex.withIndexOn(GROUP_DETAIL_TYPE, GROUP_NAME);
		canAddIndex.withIndexOn(GROUP_DETAIL_TYPE, GROUP_DETAIL);
		canAddIndex.withIndexOn(GROUP_DETAIL_TYPE, GROUP_NAME, GROUP_DETAIL);

		return canBuild.build();
	}

	public static IStoreDescription getAnalysisDimensionStoreDescriptionWithAsOfDate() {
		Map<String, String> fieldDescriptions = new LinkedHashMap<>();
		fieldDescriptions.put(GROUP_NAME, ILiteralType.STRING);
		fieldDescriptions.put(GROUP_DETAIL, ILiteralType.STRING);
		fieldDescriptions.put(GROUP_DETAIL_TYPE, ILiteralType.STRING);
		fieldDescriptions.put(ASOFDATE, ILiteralType.OBJECT);

		return ApexTestDatastoreHelper.createStoreDescription(GROUP_STORE_NAME,
				fieldDescriptions,
				Arrays.asList(GROUP_NAME, GROUP_DETAIL, ASOFDATE));
	}

	public static void addCountryGroupAnalysisHierarchy(String pivotId, IActivePivotDescription description) {
		IApexCubeBuilder builder = ApexCubeBuilder.updateActivePivotDescripion(description);

		// First group is not slicing
		ApexDatastoreAnalysisHierarchyBuilder countryGroupDimBuilder =
				ApexDatastoreAnalysisHierarchy.addDatastoreAnalysisHierarchy(builder, COUNTRY_GROUP_DIM);

		countryGroupDimBuilder.withAllMember();

		countryGroupDimBuilder.setStoreName(GROUP_STORE_NAME);
		countryGroupDimBuilder.setColumnNames(GROUP_NAME, GROUP_DETAIL);
		countryGroupDimBuilder.setSearchTemplate(ImmutableMap.of(GROUP_DETAIL_TYPE, COUNTRY));

		countryGroupDimBuilder.setProperty(ApexDatastoreAnalysisHierarchy.PROPERTY_PIVOT_ID, pivotId);
	}

	public static void addCcyGroupAnalysisHierarchy(String pivotId, IActivePivotDescription description) {
		IApexCubeBuilder builder = ApexCubeBuilder.updateActivePivotDescripion(description);

		// Second group is slicing
		IApexHierarchyBuilder d =
				builder.addAnalysisHierarchy(CCY_GROUP_DIM, ApexDatastoreAnalysisHierarchy.PLUGIN_KEY).setSlicing();

		d.setProperty(ApexDatastoreAnalysisHierarchy.PROPERTY_STORE_NAME, GROUP_STORE_NAME);
		d.setProperty(ApexDatastoreAnalysisHierarchy.PROPERTY_COLUMN_NAMES,
				GROUP_NAME + IPostProcessor.SEPARATOR + GROUP_DETAIL);
		d.setProperty(ApexDatastoreAnalysisHierarchy.PROPERTY_SEARCH_TEMPLATE,
				GROUP_DETAIL_TYPE + PepperSerializationHelper.MAP_KEY_VALUE_SEPARATOR + CCY);

		d.setProperty(ApexDatastoreAnalysisHierarchy.PROPERTY_PIVOT_ID, pivotId);
	}
}

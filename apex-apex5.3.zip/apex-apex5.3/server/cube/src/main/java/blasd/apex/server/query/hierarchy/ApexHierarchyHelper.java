/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.hierarchy;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.NavigableSet;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Strings;
import com.google.common.collect.Sets;
import com.google.common.collect.Streams;
import com.quartetfs.biz.pivot.IActivePivot;
import com.quartetfs.biz.pivot.IMultiVersionActivePivot;
import com.quartetfs.biz.pivot.context.IAsOfEpoch;
import com.quartetfs.biz.pivot.context.IContext;
import com.quartetfs.biz.pivot.context.IContextValue;
import com.quartetfs.biz.pivot.cube.dimension.IDimension.DimensionType;
import com.quartetfs.biz.pivot.cube.hierarchy.IAnalysisHierarchy;
import com.quartetfs.biz.pivot.cube.hierarchy.IAnalysisHierarchyInfo;
import com.quartetfs.biz.pivot.cube.hierarchy.IHierarchy;
import com.quartetfs.biz.pivot.cube.hierarchy.IHierarchyInfo;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevel;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevelInfo;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevelInfo.ClassificationType;
import com.quartetfs.biz.pivot.cube.hierarchy.IMember;
import com.quartetfs.biz.pivot.cube.hierarchy.IMultiVersionHierarchy;
import com.quartetfs.biz.pivot.cube.hierarchy.IOlapElement;
import com.quartetfs.biz.pivot.cube.hierarchy.axis.IAxisHierarchy;
import com.quartetfs.biz.pivot.cube.hierarchy.axis.IAxisMember;
import com.quartetfs.biz.pivot.cube.hierarchy.axis.IMultiVersionAxisHierarchy;
import com.quartetfs.biz.pivot.cube.hierarchy.impl.HierarchiesUtil;
import com.quartetfs.biz.pivot.cube.hierarchy.measures.IMeasureHierarchy;
import com.quartetfs.biz.pivot.postprocessing.IPostProcessor;

import blasd.apex.server.config.cube.ApexHierarchyBuilder;
import blasd.apex.server.config.cube.ApexLevelBuilder;
import blasd.apex.server.query.location.ApexLocationHelper;

/**
 * 
 * @author Benoit Lacelle
 * 
 */
public class ApexHierarchyHelper {
	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexHierarchyHelper.class);

	public static final String ALL = ClassificationType.ALL.toString();

	public static final String LEVEL_SEPARATOR = ApexHierarchyBuilder.LEVEL_SEPARATOR;

	public static final int SIZE_HIER_AT_DIM = "h@d".split(LEVEL_SEPARATOR).length;
	public static final int SIZE_LEVEL_AT_HIER = "l@h".split(LEVEL_SEPARATOR).length;
	public static final int SIZE_LEVEL_AT_HIER_DIM = "l@h@d".split(LEVEL_SEPARATOR).length;
	public static final int SIZE_LEVEL_ALONE = "l".split(LEVEL_SEPARATOR).length;

	protected ApexHierarchyHelper() {
		// hidden
	}

	/**
	 * 
	 * @param hierarchy
	 * @return true if the input {@link IHierarchy} is an {@link IAnalysisHierarchy}
	 */
	public static boolean isAnalysisHierarchy(IHierarchy hierarchy) {
		for (ILevel level : hierarchy.getLevels()) {
			if (level.getLevelInfo().getClassificationType().isAnalysis()) {
				return true;
			}
		}

		return false;
	}

	/**
	 * 
	 * @param hierarchyInfo
	 * @return true if the input {@link IHierarchy} is an {@link IAnalysisHierarchyInfo}
	 */
	public static boolean isAnalysisHierarchy(IHierarchyInfo hierarchyInfo) {
		if (hierarchyInfo instanceof IAnalysisHierarchyInfo) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Like {@link HierarchiesUtil#extractHierarchies(List)} but returns a generic {@link List}.
	 * 
	 * Beware this method will request for {@link IAsOfEpoch} {@link IContextValue}, which may fail for {@link IContext}
	 * restriction reasons.
	 */
	public static List<? extends IHierarchyInfo> extractAxisHierarchiesInfo(IActivePivot pivot) {
		List<? extends IHierarchy> hierarchies = pivot.getHierarchies();

		return extractAxisHierarchiesInfo(hierarchies);
	}

	public static List<? extends IHierarchyInfo> extractAxisHierarchiesInfo(IMultiVersionActivePivot pivot) {
		// BEWARE not to use .getLatestVersion else getHierarchies will require
		// the IActivePivotContext to be ready
		List<? extends IMultiVersionHierarchy> hierarchies = pivot.getHierarchies();

		return extractAxisHierarchiesInfo(hierarchies);
	}

	public static List<? extends IHierarchyInfo> extractAxisHierarchiesInfo(List<? extends IHierarchy> hierarchies) {
		return filterAxisHierarchies(hierarchies).stream()
				.map(IHierarchy::getHierarchyInfo)
				.collect(Collectors.toList());
	}

	/**
	 * 
	 * @param hierarchies
	 * @return IApexHierarchyInfo which gives access to the underlying ILevelInfo
	 */
	public static List<? extends IApexAxisHierarchyInfo> extractApexAxisHierarchiesInfo(
			List<? extends IHierarchy> hierarchies) {
		return filterAxisHierarchies(hierarchies).stream()
				.map(h -> ApexHierarchyInfo.makeFromLevels(h.getHierarchyInfo(), h.getLevels()))
				.collect(Collectors.toList());
	}

	public static <T extends IHierarchyInfo> List<T> filterAxisHierarchyInfo(List<T> rawHierarchies) {
		// We can handle any type of OlapElement by checking its name
		if (isMeasureHierarchy(rawHierarchies.get(0))) {
			// Skip the measure hierarchy
			return rawHierarchies.subList(1, rawHierarchies.size());
		} else {
			// The raw hierarchies appears to be clean
			return rawHierarchies;
		}
	}

	public static <H extends IHierarchy,
			T extends IAxisHierarchy> List<T> filterAxisHierarchies(List<H> rawHierarchies) {
		List<? extends IHierarchy> rawAxisHierarchies;

		if (isMeasureHierarchy(rawHierarchies.get(0).getHierarchyInfo())) {
			// Skip the measure hierarchy
			rawAxisHierarchies = rawHierarchies.subList(1, rawHierarchies.size());
		} else {
			// The raw hierarchies appears to be clean
			rawAxisHierarchies = rawHierarchies;
		}

		return rawAxisHierarchies.stream().map(h -> (T) h).collect(Collectors.toList());
	}

	public static <T extends IMultiVersionAxisHierarchy> List<T> filterMultiVersionAxisHierarchies(
			List<? extends IMultiVersionHierarchy> rawHierarchies) {
		return filterAxisHierarchies(rawHierarchies);
	}

	public static boolean isMeasureHierarchy(IHierarchyInfo hierarchyInfo) {
		return hierarchyInfo.getDimensionInfo().getDimensionType() == DimensionType.MEASURE;
	}

	/**
	 * We can not use {@link IHierarchyInfo} as it does not hold a reference to the {@link ILevelInfo}
	 * 
	 * @param hierarchy
	 * @return
	 */
	public static boolean isAllMembersEnabled(IHierarchy hierarchy) {
		return hierarchy.getLevels().get(0).getLevelInfo().getClassificationType() == ClassificationType.ALL;
	}

	public static boolean isSlicing(IHierarchy hierarchy) {
		return !isAllMembersEnabled(hierarchy);
	}

	public static boolean isSlicing(IActivePivot pivot, IHierarchyInfo hierarchy) {
		return isSlicing(pivot.getHierarchies(), hierarchy);
	}

	public static boolean isSlicing(List<? extends IHierarchy> hierarchies, IHierarchyInfo hierarchy) {
		if (isMeasureHierarchy(hierarchies.get(0).getHierarchyInfo())) {
			return isSlicing(hierarchies.get(hierarchy.getOrdinal()));
		} else {
			// The measure hierarchy has been filtered out
			return isSlicing(hierarchies.get(hierarchy.getOrdinal() - 1));
		}
	}

	public static List<? extends ILevelInfo> extractNotAllMemberLevelInfo(IHierarchy hierarchy) {
		boolean firstIsAllMember = isAllMembersEnabled(hierarchy);

		List<ILevelInfo> levelsInfo = new ArrayList<>();

		int firstIndex;

		if (firstIsAllMember) {
			firstIndex = 1;
		} else {
			firstIndex = 0;
		}

		List<? extends ILevel> levels = hierarchy.getLevels();
		for (int i = firstIndex; i < levels.size(); i++) {
			levelsInfo.add(levels.get(i).getLevelInfo());
		}

		return levelsInfo;
	}

	/**
	 * 
	 * @param findHierarchy
	 * @param levelDepth
	 *            the depth of the targeted {@link ILevel}
	 * @return the {@link String} identifying the {@link ILevel} with a format like
	 *         levelName@hierarchyName@dimensionName
	 */
	public static String levelName(IHierarchy hierarchy, int levelDepth) {
		return levelName(hierarchy.getLevels().get(levelDepth).getLevelInfo());
	}

	public static String levelName(IActivePivot pivot, IHierarchyInfo hierarchy, int levelDepth) {
		return levelName(pivot.getHierarchies().get(hierarchy.getOrdinal()), levelDepth);
	}

	// TODO: should be named levelId
	public static String levelName(ILevelInfo levelInfo) {
		IHierarchyInfo hierarchyInfo = levelInfo.getHierarchyInfo();
		return levelName(hierarchyInfo.getDimensionInfo().getName(), hierarchyInfo.getName(), levelInfo.getName());
	}

	public static String hierarchyName(IHierarchyInfo hierarchyInfo) {
		return hierarchyName(hierarchyInfo.getDimensionInfo().getName(), hierarchyInfo.getName());
	}

	public static String hierarchyName(String dimensionName, String hierarchyName) {
		return ApexHierarchyBuilder.hierarchyName(dimensionName, hierarchyName);
	}

	public static String levelName(String hierarchyName, String levelName) {
		return ApexLevelBuilder.levelName(hierarchyName, levelName);
	}

	public static String levelName(String dimensionName, String hierarchyName, String levelName) {
		return ApexLevelBuilder.levelName(dimensionName, hierarchyName, levelName);
	}

	/**
	 * 
	 * @param pivot
	 * @param dimensionName
	 *            null if we should return all IHierarchy
	 * @return a List of IHierarchy, matching the dimensionName if provided
	 */
	public static List<? extends IAxisHierarchy> filterAxisHierarchiesInDimension(
			List<? extends IHierarchy> rawHierarchies,
			String dimensionName) {
		if (dimensionName == null) {
			// Accept all
			return filterAxisHierarchies(rawHierarchies);
		} else {
			List<IAxisHierarchy> filtered = new ArrayList<>();

			for (IHierarchy h : rawHierarchies) {
				if (h.getHierarchyInfo().getDimensionInfo().getName().equals(dimensionName)) {
					filtered.add((IAxisHierarchy) h);
				}
			}

			return filtered;
		}

	}

	/**
	 * 
	 * @param pivot
	 * @param dimensionName
	 * @param hierarchyNameOrIndex
	 *            the hierarchy name or its index (measures is not available and '0' for the first hierarchy)
	 * @return
	 */
	public static IAxisHierarchy findAxisHierarchy(List<? extends IHierarchy> hierarchies,
			String dimensionName,
			String hierarchyNameOrIndex) {
		IAxisHierarchy h = findAxisHierarchyNoFail(hierarchies, dimensionName, hierarchyNameOrIndex);

		if (h == null) {
			Set<String> orderedHierarchyNames =
					getSortedNames(filterAxisHierarchiesInDimension(hierarchies, dimensionName));

			throw new RuntimeException("There is no axis-hierarchy named: " + hierarchyNameOrIndex
					+ ". In dimension="
					+ dimensionName
					+ " Hierarchies: "
					+ orderedHierarchyNames);
		} else {
			return h;
		}
	}

	public static Set<String> getSortedNames(Iterable<? extends IOlapElement> olapElements) {
		// As we materialize the TreeSet, we do not keep a reference to any
		// IActivePivotVersion
		return Sets.newTreeSet(getNames(olapElements));
	}

	public static List<? extends String> getNames(Iterable<? extends IOlapElement> olapElements) {
		// As we materialize the TreeSet, we do not keep a reference to any
		// IActivePivotVersion
		return Streams.stream(olapElements).map(IOlapElement::getName).collect(Collectors.toList());
	}

	protected static IAxisHierarchy findAxisHierarchyNoFail(IActivePivot pivot,
			String dimensionName,
			String hierarchyName) {
		return findAxisHierarchyNoFail(pivot.getHierarchies(), dimensionName, hierarchyName);
	}

	public static int findAxisHierarchyIndex(List<? extends IHierarchy> axisHierarchies,
			String dimensionName,
			String hierarchyName) {
		if (IMeasureHierarchy.MEASURE_HIERARCHY.equals(hierarchyName)) {
			throw new RuntimeException(IMeasureHierarchy.MEASURE_HIERARCHY + " is not an IAxisHierarchy");
		}

		// Search a match for hierarchyName given dimensionName constrain
		for (int i = 0; i < axisHierarchies.size(); i++) {
			IHierarchy h = axisHierarchies.get(i);
			if (dimensionName != null && !dimensionName.equals(h.getHierarchyInfo().getDimensionInfo().getName())) {
				continue;
			}

			if (h.getName().equals(hierarchyName)) {
				return i;
			}
		}

		// Try to find from its ordinal
		if (dimensionName == null && hierarchyName != null) {
			try {
				int asInt = Integer.parseInt(hierarchyName);

				if (isMeasureHierarchy(axisHierarchies.get(0).getHierarchyInfo())) {
					if (asInt >= axisHierarchies.size()) {
						throw new RuntimeException(
								asInt + " is higher than the last hierarchy index: " + axisHierarchies.size());
					} else {
						// Skip the measure hierarchy: shift index=0 to ordinal=1
						return asInt + 1;
					}
				} else {
					// The measure hierarchy has been extracted-out: the hierarchy with ordinal 1 is as index 0: -1
					return asInt;
				}
			} catch (NumberFormatException e) {
				// Not an ordinal
				LOGGER.trace("{} is not an ordinal", hierarchyName);
			}
		}

		if (dimensionName == null && hierarchyName != null) {
			// Try with hierarchyName as dimension name
			List<? extends IAxisHierarchy> hierarchyInDimension =
					filterAxisHierarchiesInDimension(axisHierarchies, hierarchyName);

			if (hierarchyInDimension.size() == 1) {
				return findAxisHierarchyIndex(axisHierarchies, dimensionName, hierarchyInDimension.get(0).getName());
			}
		}

		return -1;
	}

	public static IAxisHierarchy findAxisHierarchyNoFail(List<? extends IHierarchy> hierarchies,
			String dimensionName,
			String hierarchyName) {
		Objects.requireNonNull(hierarchyName, "hierarchyName can not be null");
		if (IMeasureHierarchy.MEASURE_HIERARCHY.equals(hierarchyName)) {
			throw new RuntimeException(IMeasureHierarchy.MEASURE_HIERARCHY + " is not an IAxisHierarchy");
		}

		int hierarchyIndex = findAxisHierarchyIndex(hierarchies, dimensionName, hierarchyName);

		if (hierarchyIndex == -1) {
			return null;
		} else {
			return (IAxisHierarchy) hierarchies.get(hierarchyIndex);
		}
	}

	public static IAxisHierarchy findAxisHierarchy(List<? extends IHierarchy> hierarchies,
			String hierarchyNameAtDimensionName) {
		if (hierarchyNameAtDimensionName == null || hierarchyNameAtDimensionName.isEmpty()) {
			throw new RuntimeException(
					"Argument is empty. It should be like 'hierarchyName' or 'hierarchyName@dimensionName'");
		}

		String[] splitted = hierarchyNameAtDimensionName.split(LEVEL_SEPARATOR, SIZE_HIER_AT_DIM);

		String dimensionName;
		String hierarchyName;
		if (splitted.length == 1) {
			// We express hierarchyName: we assume the hierarchyName
			// is equals to the dimensionName
			hierarchyName = splitted[0];
			dimensionName = null;
		} else if (splitted.length == SIZE_HIER_AT_DIM) {
			hierarchyName = splitted[0];
			dimensionName = splitted[1];
		} else {
			throw new RuntimeException(
					hierarchyNameAtDimensionName + " should be like 'hierarchyName' or 'hierarchyName@dimensionName'");
		}

		return findAxisHierarchy(hierarchies, dimensionName, hierarchyName);
	}

	/**
	 * 
	 * @param hierarchies
	 *            the hierarchies of the cube
	 * @param dimensionName
	 * @param hierarchyName
	 * @param levelName
	 * @return an {@link ILevel}
	 */
	public static ILevel findLevel(List<? extends IHierarchy> hierarchies,
			String dimensionName,
			String hierarchyName,
			String levelName) {
		List<? extends IAxisHierarchy> hierarchyInDimension =
				filterAxisHierarchiesInDimension(hierarchies, dimensionName);

		if (dimensionName == null && hierarchyName == null && levelName == null) {
			if (hierarchyInDimension.size() == 1 && hierarchyInDimension.get(0).getLevels().size() == 1) {
				hierarchyInDimension.get(0).getLevels().get(0);
			} else {
				throw new IllegalArgumentException("We need at least one not-null constrain");
			}
		}

		if (hierarchyName == null) {
			// Find an ILevel with given name in all hierarchies

			ILevel spot = null;
			// TODO: throw if several matching levels
			for (IAxisHierarchy hierarchy : hierarchyInDimension) {
				ILevel l = findLevelNoFail(hierarchy, levelName);

				if (l != null) {
					if (spot == null) {
						spot = l;
					} else {
						throw new IllegalArgumentException("There is multiple levels matching levelName=" + levelName
								+ " hierarchyName="
								+ hierarchyName
								+ " dimensionName="
								+ dimensionName
								+ "(hierarchies: "
								+ Arrays.asList(levelName(l.getLevelInfo()), levelName(spot.getLevelInfo()))
								+ ")");
					}
				}
			}

			if (spot != null) {
				return spot;
			}

			// Found nothing
			if (levelName == null) {
				if (hierarchyInDimension.size() == 1) {
					return getFirstInterestingLevel(hierarchyInDimension.get(0));
				} else {
					// levelName and hierarchyName null
					throw failLevelInHierarchy(null, levelName);
				}
			} else {
				// We have no hierarchyName: use the levelName as hierarchyName and return the first interesting level
				assert hierarchyName == null;
				IHierarchy hierarchy = findAxisHierarchyNoFail(hierarchyInDimension, null, levelName);
				if (hierarchy != null) {
					// The levelName matched a hierarchy: returned the first interested level
					return getFirstInterestingLevel(hierarchy);
				} else {
					// We have no hierarchyName and the levelName matches no hierarchy
					if (hierarchyInDimension.size() == 1) {
						// We have a single hierarchy filtered by dimensions: consider it is the relevant hierarchy:
						// however, the levelName can not match anything as it has not matched previously
						// return getFirstInterestingLevel(hierarchyInDimension.get(0));
						throw failLevelInHierarchy(null, levelName);
					} else {
						throw failLevelInHierarchy(null, levelName);
					}
				}
			}
		} else {
			IHierarchy hierarchy = findAxisHierarchyNoFail(hierarchyInDimension, null, hierarchyName);

			if (hierarchy == null) {
				throw failHierarchyInDimension(hierarchies, null, levelName);
			} else {
				if (levelName == null) {
					// No constrain on level: return the first interesting level
					return getFirstInterestingLevel(hierarchy);
				} else {
					ILevel l = findLevelNoFail(hierarchy, levelName);

					if (l == null) {
						// no matching level
						throw failLevelInHierarchy(hierarchy, levelName);
					} else {
						return l;
					}
				}
			}
		}
	}

	private static IllegalArgumentException failHierarchyInDimension(List<? extends IHierarchy> hierarchies,
			String dimensionName,
			String hierarchyName) {
		String msgPrefix = "Found no hierarchy named  " + hierarchyName;

		if (Strings.isNullOrEmpty(dimensionName)) {
			throw new IllegalArgumentException(msgPrefix + ", hierarchies are " + getSortedNames(hierarchies));
		} else {
			List<? extends IAxisHierarchy> hierarchyInDimension =
					filterAxisHierarchiesInDimension(hierarchies, dimensionName);

			throw new IllegalArgumentException(msgPrefix + ". For dimensionFilter="
					+ dimensionName
					+ ", hierarchies are "
					+ getSortedNames(hierarchyInDimension));
		}
	}

	/**
	 * 
	 * @param hierarchy
	 * @return the first {@link ILevel} if the {@link IHierarchy} is slicing, else the second {@link ILevel}
	 */
	public static ILevel getFirstInterestingLevel(IHierarchy hierarchy) {
		return getInterestingLevels(hierarchy).get(0);
	}

	public static ILevel getDeepestLevel(IHierarchy hierarchy) {
		return hierarchy.getLevels().get(hierarchy.getLevels().size() - 1);
	}

	/**
	 * 
	 * @param hierarchy
	 * @return the level after omitting the optional ALL level
	 */
	public static List<? extends ILevel> getInterestingLevels(IHierarchy hierarchy) {
		List<? extends ILevel> allLevels = hierarchy.getLevels();
		if (ApexHierarchyHelper.isSlicing(hierarchy)) {
			return allLevels;
		} else {
			return allLevels.subList(1, allLevels.size());
		}
	}

	protected static IllegalArgumentException failLevelInHierarchy(IHierarchy hierarchy, String levelName) {
		String hierarchyName;
		NavigableSet<String> levels;
		if (hierarchy == null) {
			hierarchyName = "(All hierarchies)";
			levels = new TreeSet<>(Arrays.asList("(All levels)"));
		} else {
			hierarchyName = hierarchy.getName();
			levels = new TreeSet<>(hierarchy.getLevels().stream().map(ILevel::getName).collect(Collectors.toList()));
		}

		throw new IllegalArgumentException("In hierarchy " + hierarchyName
				+ ", there is no level named: "
				+ levelName
				+ ". Availables are: "
				+ levels);
	}

	protected static ILevel findLevelNoFail(IHierarchy hierarchy, String levelName) {
		for (ILevel l : hierarchy.getLevels()) {
			if (l.getName().equals(levelName)) {
				return l;
			}
		}

		return null;
	}

	/**
	 * 
	 * @param pivot
	 * @param levelNameAtHierarchyNameAtDimensionName
	 * @return the {@link ILevel} given an expression like 'levelName@dimensionName' or
	 *         'levelName@hierarchyName@dimensionName'
	 */
	public static ILevel findLevel(List<? extends IHierarchy> hierarchies,
			String levelNameAtHierarchyNameAtDimensionName) {
		if (levelNameAtHierarchyNameAtDimensionName == null || levelNameAtHierarchyNameAtDimensionName.isEmpty()) {
			throw new RuntimeException(
					"Argument is empty. It should be like 'levelName@dimensionName' or 'levelName@hierarchyName@dimensionName'");
		}

		// Limiting to 3 @ enables having @ in the dimension name
		String[] splitted = levelNameAtHierarchyNameAtDimensionName.split("@", SIZE_LEVEL_AT_HIER_DIM);

		if (splitted.length > 0 && splitted[splitted.length - 1].isEmpty()) {
			// The last element ends by @ (e.g. 'Country @'): we need to remove
			// the empty levelName as @ as actually in the dimension name
			splitted = Arrays.copyOf(splitted, splitted.length - 1);
			splitted[splitted.length - 1] = splitted[splitted.length - 1] + "@";
		}

		String dimensionName;
		String hierarchyName;
		String levelName;
		if (splitted.length == SIZE_LEVEL_ALONE) {
			levelName = splitted[0];
			hierarchyName = null;
			dimensionName = null;
		} else if (splitted.length == SIZE_LEVEL_AT_HIER) {
			levelName = splitted[0];
			hierarchyName = splitted[1];
			dimensionName = null;
		} else if (splitted.length == SIZE_LEVEL_AT_HIER_DIM) {
			levelName = splitted[0];
			hierarchyName = splitted[1];
			dimensionName = splitted[2];
		} else {
			throw new RuntimeException(levelNameAtHierarchyNameAtDimensionName
					+ " should be like 'levelName' or 'levelName@hierarchyName' or 'levelName@hierarchyName@dimensionName'");
		}

		return findLevel(hierarchies, dimensionName, hierarchyName, levelName);
	}

	public static List<ILevel> findLevels(List<? extends IHierarchy> hierarchies,
			String levelNameAtHierarchyNameAtDimensionNameComa) {
		if (levelNameAtHierarchyNameAtDimensionNameComa == null
				|| levelNameAtHierarchyNameAtDimensionNameComa.isEmpty()) {
			throw new RuntimeException(
					"Argument is empty. It should be like 'levelName1,levelName2' or 'levelName1@dimensionName1,levelName2@dimensionName2' or"
							+ "'levelName1@hierarchyName1@dimensionName1,levelName2@hierarchyName2@dimensionName2'");
		}

		String[] splitted = levelNameAtHierarchyNameAtDimensionNameComa.split(IPostProcessor.SEPARATOR);

		List<ILevel> found = new ArrayList<>();

		for (String oneLevelDes : splitted) {
			found.add(findLevel(hierarchies, oneLevelDes));
		}

		return found;
	}

	public static IAxisHierarchy getAxisHierarchy(List<? extends IHierarchy> hierarchies, ILevelInfo levelInfo) {
		return getAxisHierarchy(hierarchies, levelInfo.getHierarchyInfo());
	}

	public static IAxisHierarchy getAxisHierarchy(List<? extends IHierarchy> hierarchies,
			IHierarchyInfo hierarchyInfo) {
		int index;
		if (isMeasureHierarchy(hierarchies.get(0).getHierarchyInfo())) {
			index = hierarchyInfo.getOrdinal();
		} else {
			// ordinal=1 is at index=0
			index = hierarchyInfo.getOrdinal() - 1;
		}

		return (IAxisHierarchy) hierarchies.get(index);
	}

	public static Optional<?> convertToDiscriminator(List<? extends IHierarchy> hierarchies,
			ILevelInfo levelInfo,
			Object stringOrObject) {
		if (stringOrObject instanceof Collection<?>) {
			List<Object> discriminators = new ArrayList<>();

			for (Object oneStringOrObject : (Collection<?>) stringOrObject) {
				Optional<?> optionalDiscriminator = convertToDiscriminator(hierarchies, levelInfo, oneStringOrObject);

				if (optionalDiscriminator.isPresent()) {
					discriminators.add(optionalDiscriminator.get());
				} else {
					LOGGER.debug("We found no member for {}", oneStringOrObject);
				}
			}

			if (discriminators.isEmpty()) {
				return Optional.empty();
			} else {
				return Optional.of(discriminators);
			}
		} else if (stringOrObject instanceof String) {
			String asCharSequence = (String) stringOrObject;

			IAxisHierarchy hierarchy = ApexHierarchyHelper.getAxisHierarchy(hierarchies, levelInfo);

			String[] searchPath = new String[levelInfo.getOrdinal() + 1];
			searchPath[levelInfo.getOrdinal()] = asCharSequence;
			List<? extends IAxisMember> matchingMembers = hierarchy.retrieveMembers(searchPath);

			if (matchingMembers.isEmpty()) {
				return Optional.empty();
			} else {
				return Optional.of(matchingMembers.get(0).getDiscriminator());
			}
		} else {
			// Keep as Object
			return Optional.ofNullable(stringOrObject);
		}
	}

	/**
	 * 
	 * @param hierarchy
	 * @param pathTemplate
	 * @param withAllMember
	 *            if false, we expect the template not to express AllMember and the output pathes will not express
	 *            allMember
	 * @return
	 */
	public static Set<? extends List<?>> getHierarchyPathes(IAxisHierarchy hierarchy,
			List<?> pathTemplate,
			boolean withAllMember) {
		Set<List<?>> pathes = new HashSet<>();

		boolean isSlicing = ApexLocationHelper.isSlicingHierarchy(hierarchy);

		List<? extends IMember> members;
		{
			Object[] memberTemplate;
			if (isSlicing || withAllMember) {
				memberTemplate = pathTemplate.toArray();
			} else {
				// The template is missing AllMember and the hierarchy is not slicing
				int pathLength = pathTemplate.size();
				memberTemplate = new Object[pathLength + 1];

				// Add AllMember for the first level
				memberTemplate[0] = ILevel.ALLMEMBER;

				// Copy the whole path
				System.arraycopy(pathTemplate.toArray(), 0, memberTemplate, 1, pathLength);
			}
			members = hierarchy.retrieveMembers(memberTemplate);
		}

		// Each matching AxisMember is a potential groupPath
		for (IMember member : members) {
			if (member instanceof IAxisMember) {
				Object[] path = ((IAxisMember) member).getObjectPath();

				if (!isSlicing && !withAllMember && path.length >= 1) {
					// We must not express the AllMember coordinates
					path = Arrays.copyOfRange(path, 1, path.length);
				}

				pathes.add(Arrays.asList(path));
			}
		}

		return pathes;
	}

	/**
	 * 
	 * @param axisHierarchy
	 * @param levelOrdinal
	 * @return the discriminator valid for given level. Beware a discrminator may appear with different parent (e.g. as
	 *         January in 2015/January and 2016/January)
	 */
	public static Set<?> getLevelDiscriminators(IAxisHierarchy axisHierarchy, int levelOrdinal) {
		List<? extends IAxisMember> members = axisHierarchy.retrieveMembers(levelOrdinal);

		Set<Object> coordinates = new HashSet<>();
		for (IAxisMember member : members) {
			coordinates.add(member.getDiscriminator());
		}

		return coordinates;
	}
}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.debug;

import java.util.Map;

import com.google.common.annotations.Beta;
import com.google.common.collect.ImmutableMap;
import com.quartetfs.biz.pivot.context.ContextValueTranslationException;
import com.quartetfs.biz.pivot.context.IContextValueTranslator;
import com.quartetfs.biz.pivot.context.impl.MultipleContextValueTranslator;
import com.quartetfs.biz.pivot.context.impl.StringMapRepositoryAdapter;
import com.quartetfs.fwk.QuartetPluginValue;

/**
 * A context value to activate some debug details
 * 
 * @author Benoit Lacelle
 *
 */
@Beta
@QuartetPluginValue(intf = IContextValueTranslator.class)
public class ApexDebugContextValueTranslator extends MultipleContextValueTranslator<IApexDebugContextValue> {
	private static final long serialVersionUID = 8938506201906719539L;

	public static final String CXT_VALUE_NAME = "apex_metadata";
	public static final String CXT_VALUE_DEBUG = ".debug";
	public static final String CXT_VALUE_MEMORY = ".queryMemoryLimit";

	public ApexDebugContextValueTranslator() {
		super(CXT_VALUE_NAME);
	}

	protected ApexDebugContextValueTranslator(String key) {
		super(key);
	}

	@Override
	public Class<IApexDebugContextValue> getContextInterface() {
		return IApexDebugContextValue.class;
	}

	@Override
	public String key() {
		return CXT_VALUE_NAME;
	}

	@Override
	public IApexDebugContextValue decode(Map<String, String> repository) throws ContextValueTranslationException {
		StringMapRepositoryAdapter codec = new StringMapRepositoryAdapter(this.key, repository);

		Boolean isDebugging = codec.getBoolean(CXT_VALUE_DEBUG);
		if (isDebugging == null) {
			// Not set: not debug
			isDebugging = false;
		}

		Long queryMemoryLimit = codec.getLong(CXT_VALUE_MEMORY);
		if (queryMemoryLimit == null) {
			// Not set: no limit
			queryMemoryLimit = 0L;
		}

		return new ApexDebugContextValue(isDebugging, queryMemoryLimit);
	}

	@Override
	public void encode(IApexDebugContextValue paramC, Map<String, String> repository) {
		StringMapRepositoryAdapter codec = new StringMapRepositoryAdapter(this.key, repository);
		if (paramC.isDebugging()) {
			codec.putInRepository(CXT_VALUE_DEBUG, paramC.isDebugging());
		}
		if (paramC.getQueryMemoryLimit() > 0) {
			codec.putInRepository(CXT_VALUE_MEMORY, paramC.getQueryMemoryLimit());
		}
	}

	@Override
	public Map<String, String> getAvailableProperties() {
		return ImmutableMap.of(CXT_VALUE_NAME + CXT_VALUE_DEBUG,
				IContextValueTranslator.BOOL_VALUE,
				CXT_VALUE_NAME + CXT_VALUE_MEMORY,
				IContextValueTranslator.LONG_VALUE);
	}

}

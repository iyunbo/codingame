/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.hierarchy;

import com.google.common.annotations.Beta;
import com.quartetfs.fwk.ordering.IComparator;

/**
 * This {@link IComparator} demonstrate a correct implementation for a bucket comparator. There is a lot of traps which
 * could lead to inconsistent hierarchies because of inconsistent comparator
 * 
 * @author Benoit Lacelle
 *
 */
// TODO: Improve resilience (e.g. handle 'aD', 'N/A', 3)
@Beta
public class ApexBucketComparator implements IComparator<Object> {
	private static final long serialVersionUID = -8729321323484158821L;

	enum Bucket {
		D(1), W(7), M(30), Y(365);

		private final int nbDays;

		Bucket(int nbDays) {
			this.nbDays = nbDays;
		}
	}

	protected int asDays(String bucket) {
		return Integer.parseInt(bucket.substring(0, bucket.length() - 1)) * getBucket(bucket).nbDays;
	}

	protected Bucket getBucket(String bucket) {
		// We handle 'd' and 'D' for days
		return Bucket.valueOf(getStringForBucketType(bucket).toUpperCase());
	}

	protected String getStringForBucketType(String bucket) {
		return bucket.substring(bucket.length() - 1);
	}

	@Override
	public String getType() {
		return "ApexMaturity";
	}

	@Override
	public int compare(Object left, Object right) {
		if (!(left instanceof String)) {
			throw new IllegalArgumentException("TODO");
		} else if (!(right instanceof String)) {
			throw new IllegalArgumentException("TODO");
		}

		String leftAsString = left.toString();
		String rightAsString = right.toString();

		int daysLeft = asDays(leftAsString);
		int daysRight = asDays(rightAsString);

		if (daysLeft != daysRight) {
			return daysLeft - daysRight;
		}

		// Same number of days: compare by bucket
		Bucket bucketLeft = getBucket(leftAsString);
		Bucket bucketRight = getBucket(rightAsString);

		if (bucketLeft.ordinal() != bucketRight.ordinal()) {
			return bucketLeft.ordinal() - bucketRight.ordinal();
		}

		// Same bucket: compare lexicographically
		return getStringForBucketType(leftAsString).compareTo(getStringForBucketType(rightAsString));
	}

	/**
	 * 
	 * @param left
	 * @param right
	 * @return true if the 2 inputs are equivalent in term of days, even if the object are not equals
	 */
	public boolean equivalent(Object left, Object right) {
		if (!(left instanceof String)) {
			throw new IllegalArgumentException("TODO");
		} else if (!(right instanceof String)) {
			throw new IllegalArgumentException("TODO");
		}

		int daysLeft = asDays(left.toString());
		int daysRight = asDays(right.toString());

		return daysLeft == daysRight;
	}

}

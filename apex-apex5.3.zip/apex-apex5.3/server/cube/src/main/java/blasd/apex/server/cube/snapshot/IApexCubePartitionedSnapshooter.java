/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.cube.snapshot;

import blasd.apex.server.datastore.listener.IApexAccumulatedSelectionListener;

/**
 * Extends IApexCubeSnapshooter so that queries on the underlying cube are partitioned. It prevents running very large
 * queries but introduced some inconsistencies in the returned results as all partitions are streams to the listener
 * 
 * @author Benoit Lacelle
 *
 * @param <T>
 * @param <U>
 */
public interface IApexCubePartitionedSnapshooter<T, U> extends IApexCubeSnapshooter<T> {

	/**
	 * 
	 * @return the {@link IApexAccumulatedSelectionListener} which should be notified to tell when to update
	 *         IApexCubePartitionedSnapshooter
	 */
	IPartitionGetAggregatesQueriesProvider<T, U, IApexCubePartitionedSnapshooter<T, U>> getPartitionGAQProvider();

	/**
	 * 
	 * @return how many partitions have been recomputed
	 */
	long flushPendingPartitions();

}

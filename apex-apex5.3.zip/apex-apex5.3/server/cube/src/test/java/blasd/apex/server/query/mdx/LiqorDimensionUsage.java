/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.mdx;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;

import org.joda.time.LocalDateTime;
import org.joda.time.format.DateTimeFormat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Charsets;
import com.google.common.base.Joiner;
import com.google.common.base.Splitter;
import com.google.common.io.Files;

import cormoran.pepper.io.PepperFileHelper;

/**
 * This class enables providing some details about hierarchy usage from files holding MDX queries. it will typically
 * report when given hierarchy has been used for last time
 * 
 * @author Benoit Lacelle
 *
 */
public class LiqorDimensionUsage {

	protected static final Logger LOGGER = LoggerFactory.getLogger(LiqorDimensionUsage.class);

	public static void main(String[] args) throws IOException {
		final Map<List<String>, LocalDateTime> hierarchyToLatest = new HashMap<>();

		String folderWithQueries = "D:\\blacelle112212\\Liqor\\Queries";
		folderWithQueries = "C:\\HOMEWARE\\Save_blacelle112212_20170811\\Liqor\\Issue\\2017-11-08 Query Usage\\Queries";
		try {
			String finalFolderWithQueries = folderWithQueries + "\\";
			Arrays.asList("Degas", "Barry", "Krieger", "Lautrec", "Sterling")
					.stream()
					.map(machine -> Paths.get(finalFolderWithQueries + machine).toFile())
					.filter(File::isDirectory)
					.flatMap(topFolder -> Arrays.stream(topFolder.list((dir, name) -> true))
							.map(file -> new File(topFolder, file)))
					.forEach(fullFile -> processOneFile(hierarchyToLatest, fullFile));
		} finally {
			for (Entry<List<String>, LocalDateTime> entry : hierarchyToLatest.entrySet()) {
				String pivot = entry.getKey().get(0);
				String h = entry.getKey().get(1);
				// String l = entry.getKey().get(2);

				LOGGER.info('|' + Joiner.on('|').join(pivot.replace('|', '_'), h.replace('|', '_'), entry.getValue()));
			}
		}
	}

	private static void processOneFile(final Map<List<String>, LocalDateTime> hierarchyToLatest, File fullFile) {
		LOGGER.info("Parsing file " + fullFile);
		try {
			Files.readLines(fullFile, Charsets.UTF_8)
					.parallelStream()
					.forEach(line -> processOneLine(hierarchyToLatest, line));
		} catch (IOException e) {
			LOGGER.warn("Issue", e);
		}
	}

	private static void processOneLine(final Map<List<String>, LocalDateTime> hierarchyToLatest, String line) {
		if (line.length() == 0) {
			return;
		}
		List<String> asList = Splitter.on((char) 9247).splitToList(line);

		if (asList.size() <= 5) {
			System.out.println("Not enough columns in " + asList);
			return;
		}

		String mdx = asList.get(5);

		if (!ApexMdxHelper.isSelectMdx(mdx)) {
			LOGGER.trace("Skip DT queries");
			return;
		}

		LocalDateTime date = LocalDateTime.parse(asList.get(0), DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss.SSS"));

		Optional<String> pivotId = ApexMdxHelper.extractCubeName(mdx);

		if (pivotId.isPresent()) {

			final Set<List<String>> currentMdxHierarchyToLatest = new HashSet<>();

			ApexMdxHelper.extractCoordinates(mdx).asMap().keySet().forEach(h -> {
				List<String> dToH = Arrays.asList(pivotId.get(), h);
				currentMdxHierarchyToLatest.add(dToH);
			});

			if (currentMdxHierarchyToLatest.size() > 30) {
				LOGGER.info("Do not record usage from MDX expressing too many hierarchies: {} {}",
						currentMdxHierarchyToLatest.size(),
						mdx);
			} else {
				currentMdxHierarchyToLatest.forEach(dToH -> {
					if (!hierarchyToLatest.containsKey(dToH) || hierarchyToLatest.get(dToH).isBefore(date)) {
						hierarchyToLatest.put(dToH, date);
					}
				});
			}
		} else {
			LOGGER.warn("No pivotId in {}", PepperFileHelper.cleanWhitespaces(mdx));
		}
	}
}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.spring.autonomy;

import java.util.Arrays;

import org.junit.BeforeClass;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.core.userdetails.UserDetailsService;

import com.qfs.content.service.IContentService;
import com.qfs.content.service.IPrefixedContentService;
import com.qfs.desc.IDatastoreSchemaDescription;
import com.qfs.desc.IStoreDescription;
import com.qfs.desc.impl.DatastoreSchemaDescription;
import com.qfs.desc.impl.StoreDescriptionBuilder;
import com.qfs.pivot.content.IActivePivotContentService;
import com.qfs.store.IDatastore;
import com.qfs.store.build.impl.DatastoreBuilder;
import com.quartetfs.biz.pivot.definitions.IActivePivotManagerDescription;

import blasd.apex.server.config.spring.ApexActivePivotSpringConfig;
import blasd.apex.server.registry.ApexRegistrySpringConfig;
import blasd.apex.server.test.IApexTestConstants;
import blasd.apex.server.test.pivot.ApexActivePivotLicenseHelper;

/**
 * 
 * @author Benoit Lacelle
 * 
 */
public class TestApexActivePivotConfigAutonomy implements IApexTestConstants {
	@BeforeClass
	public static void ensureLicense() {
		ApexActivePivotLicenseHelper.ensureLicenseWithEnv();
	}

	public static IActivePivotContentService mockAPContentService() {
		IActivePivotContentService apContentService = Mockito.mock(IActivePivotContentService.class);

		// Requited by DynamicActivePivotContentServiceMBean in AP5.4.2
		Mockito.when(apContentService.withRootPrivileges()).thenReturn(apContentService);

		// Requited by DynamicActivePivotContentServiceMBean in AP5.5
		IPrefixedContentService underlying = Mockito.mock(IPrefixedContentService.class);
		Mockito.when(apContentService.getContentService()).thenReturn(underlying);

		// Requited by DynamicActivePivotContentServiceMBean in AP5.5
		IContentService contentService = Mockito.mock(IContentService.class);
		Mockito.when(underlying.getUnderlying()).thenReturn(contentService);
		Mockito.when(underlying.withRootPrivileges()).thenReturn(underlying);

		Mockito.when(contentService.withRootPrivileges()).thenReturn(contentService);

		return apContentService;
	}

	@Configuration
	public static class ApexActivePivotConfigComplement {

		// AP5.7 Introduced the need of a bean of type IDatastoreSchemaDescription
		@Bean
		public IDatastoreSchemaDescription datastoreSchemaDescription() {
			IStoreDescription storeDescription =
					new StoreDescriptionBuilder().withStoreName(MAIN_STORE).withField(CCY).asKeyField().build();

			return new DatastoreSchemaDescription(Arrays.asList(storeDescription), null);
		}

		// Since AP5.6, ActivePivotServicesConfig introduces CopperService which requires an IDatastore and not only an
		// IReadableDatastore
		// For some reason, we mean at least an alias to 'datastore'
		@Bean(name = { "datastore" })
		public IDatastore someDatastore(IDatastoreSchemaDescription datastoreSchemaDescription) {
			return new DatastoreBuilder().setSchemaDescription(datastoreSchemaDescription).build();
		}

		@Bean
		public IActivePivotManagerDescription activePivotManagerDescription() {
			IActivePivotManagerDescription desc = Mockito.mock(IActivePivotManagerDescription.class);

			Mockito.when(desc.getName()).thenReturn(MAIN_SCHEMA);

			return desc;
		}

		@Bean
		public IActivePivotContentService activePivotContentService() {
			return mockAPContentService();
		}

		@Bean
		public UserDetailsService userDetailsService() {
			return Mockito.mock(UserDetailsService.class);
		}
	}

	@Test
	public void testApexActivePivotConfig() {
		try (AnnotationConfigApplicationContext context =
				new AnnotationConfigApplicationContext(ApexRegistrySpringConfig.class,
						ApexActivePivotConfigComplement.class,
						ApexActivePivotSpringConfig.class)) {

		}
	}
}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.cube.snapshot;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.codahale.metrics.Timer;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Sets;
import com.google.common.eventbus.EventBus;
import com.qfs.desc.IDatastoreSchemaDescription;
import com.qfs.desc.IStoreDescription;
import com.qfs.literal.ILiteralType;
import com.qfs.store.IDatastore;
import com.quartetfs.biz.pivot.IActivePivotManager;
import com.quartetfs.biz.pivot.IMultiVersionActivePivot;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevelInfo;
import com.quartetfs.biz.pivot.definitions.IActivePivotDescription;
import com.quartetfs.biz.pivot.definitions.IActivePivotManagerDescription;
import com.quartetfs.biz.pivot.definitions.IActivePivotSchemaInstanceDescription;

import blasd.apex.server.datastore.search.ApexSearchBuilder;
import blasd.apex.server.datastore.test.ApexTestDatastoreHelper;
import blasd.apex.server.datastore.transaction.ApexTransactionHelper;
import blasd.apex.server.query.hierarchy.ApexHierarchyHelper;
import blasd.apex.server.test.IApexTestConstants;
import blasd.apex.server.test.pivot.ApexActivePivotDescriptionHelper;
import blasd.apex.server.test.pivot.ApexActivePivotLicenseHelper;
import blasd.apex.server.test.pivot.ApexTestActivePivotHelper;
import blasd.apex.server.test.registry.ApexTestRegistryHelper;

public class TestApexCubeSnapshooter implements IApexTestConstants {
	@BeforeClass
	public static void loadLicense() {
		ApexActivePivotLicenseHelper.ensureLicenseWithEnv();
	}

	@Test
	public void testSnapshotter() {
		ApexTestRegistryHelper.resetClassInRegistry();

		IStoreDescription baseStoreDescription =
				ApexTestDatastoreHelper.createStoreDescription(MAIN_STORE, COUNTRY_CCY_DELTA_DESC);

		IActivePivotDescription baseCubeDescription =
				ApexTestDatastoreHelper.createCubeDescription(baseStoreDescription);

		IActivePivotSchemaInstanceDescription baseSchema = ApexActivePivotDescriptionHelper.makeSchemaDescription(
				MAIN_SCHEMA,
				baseStoreDescription,
				Arrays.asList(
						ApexActivePivotDescriptionHelper.makeActivePivotDescription(MAIN_CUBE, baseCubeDescription)));

		IStoreDescription snapshotStoreDescription = ApexTestDatastoreHelper.createStoreDescription(SECONDARY_STORE,
				ImmutableMap.of(COUNTRY, ILiteralType.STRING, DELTA_SUM, ILiteralType.DOUBLE));

		IActivePivotManagerDescription apManagerDesc =
				ApexActivePivotDescriptionHelper.makeManagerDescription(Arrays.asList(baseSchema));

		IDatastoreSchemaDescription datastoreDescription = ApexTestDatastoreHelper
				.prepareDescription(Arrays.asList(baseStoreDescription, snapshotStoreDescription));

		IActivePivotManager apManager =
				ApexTestActivePivotHelper.buildCubeOverDatastore(datastoreDescription, apManagerDesc);

		ApexTestActivePivotHelper.initAndStartActivePivotManager(apManager);

		final IDatastore datastore = (IDatastore) apManager.getDatastore();

		IMultiVersionActivePivot multiVersionCube = apManager.getActivePivots().get(MAIN_CUBE);

		final ILevelInfo countryLevel =
				ApexHierarchyHelper.findLevel(multiVersionCube.getHierarchies(), COUNTRY).getLevelInfo();

		PartitionGetAggregatesQueriesProvider provider =
				new PartitionGetAggregatesQueriesProvider(countryLevel, Sets.newHashSet(DELTA_SUM));

		ILevelInfo ccyLevel = ApexHierarchyHelper.findLevel(multiVersionCube.getHierarchies(), CCY).getLevelInfo();
		AApexCubeSnapshooter<Map<? extends ILevelInfo, ?>> snapshooter =
				new AApexCubeSnapshooter<Map<? extends ILevelInfo, ?>>(new EventBus()::post,
						multiVersionCube,
						provider,
						Arrays.asList(countryLevel, ccyLevel),
						new Timer()) {

					@Override
					protected void publishPartition(Set<? extends Map<? extends ILevelInfo, ?>> partitionIds,
							Stream<? extends Map<String, ?>> asRows) {
						Set<Map<String, ?>> asString = AApexCubeSnapshooter.convertToTarget(this, partitionIds);

						ApexTransactionHelper.addRemoveWhere(datastore.getTransactionManager(),
								SECONDARY_STORE,
								asRows,
								asString.stream());
					}

					@Override
					protected String getTargetColumnName(ILevelInfo levelInfo) {
						if (levelInfo.equals(countryLevel)) {
							return COUNTRY;
						} else {
							return super.getTargetColumnName(levelInfo);
						}
					}

				};

		// Add a first row for a single country
		ApexTransactionHelper.addOne(datastore.getTransactionManager(),
				MAIN_STORE,
				ImmutableMap.of(COUNTRY, FRANCE, CCY, EUR, DELTA, 1.2F));

		snapshooter.snapshot(Collections.emptyMap());

		{
			List<? extends Map<String, Object>> targetStoreContent =
					ApexSearchBuilder.search(datastore, SECONDARY_STORE).asFullMapInList();
			Assert.assertEquals(1, targetStoreContent.size());
			Assert.assertEquals(2, targetStoreContent.get(0).size());
			Assert.assertEquals(FRANCE, targetStoreContent.get(0).get(COUNTRY));
			Assert.assertEquals(1.2D, (Double) targetStoreContent.get(0).get(DELTA_SUM), 0.0001D);
		}

		// Add second row for same country
		ApexTransactionHelper.addOne(datastore.getTransactionManager(),
				MAIN_STORE,
				ImmutableMap.of(COUNTRY, FRANCE, CCY, EUR, DELTA, 1.3F));

		snapshooter.snapshot(Collections.emptyMap());

		{
			List<? extends Map<String, Object>> targetStoreContent =
					ApexSearchBuilder.search(datastore, SECONDARY_STORE).asFullMapInList();
			Assert.assertEquals(1, targetStoreContent.size());
			Assert.assertEquals(2, targetStoreContent.get(0).size());
			Assert.assertEquals(FRANCE, targetStoreContent.get(0).get(COUNTRY));
			Assert.assertEquals(2.5D, (Double) targetStoreContent.get(0).get(DELTA_SUM), 0.0001D);
		}

		// Add third row for same country
		ApexTransactionHelper.addOne(datastore.getTransactionManager(),
				MAIN_STORE,
				ImmutableMap.of(COUNTRY, FRANCE, CCY, EUR, DELTA, 1.5F));
		// Add first row for another country
		ApexTransactionHelper.addOne(datastore.getTransactionManager(),
				MAIN_STORE,
				ImmutableMap.of(COUNTRY, USA, CCY, USA, DELTA, 1.7F));

		snapshooter.snapshot(Collections.emptyMap());

		{
			Map<?, Map<String, Object>> targetStoreContent = ApexSearchBuilder.search(datastore, SECONDARY_STORE)
					.asFullMapInList()
					.stream()
					.collect(Collectors.toMap(m -> m.get(COUNTRY), m -> m));
			Assert.assertEquals(2, targetStoreContent.size());

			Assert.assertEquals(2, targetStoreContent.get(FRANCE).size());
			Assert.assertEquals(FRANCE, targetStoreContent.get(FRANCE).get(COUNTRY));
			Assert.assertEquals(4.0D, (Double) targetStoreContent.get(FRANCE).get(DELTA_SUM), 0.0001D);

			Assert.assertEquals(2, targetStoreContent.get(USA).size());
			Assert.assertEquals(USA, targetStoreContent.get(USA).get(COUNTRY));
			Assert.assertEquals(1.7D, (Double) targetStoreContent.get(USA).get(DELTA_SUM), 0.0001D);
		}
	}
}

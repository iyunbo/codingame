/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.test.pivot;

import java.util.Arrays;

import org.junit.Assert;
import org.junit.Test;

import com.qfs.desc.IDatastoreSchemaDescription;
import com.qfs.desc.IStoreDescription;
import com.qfs.desc.impl.ReferenceDescription;
import com.qfs.store.selection.impl.SelectionField;
import com.quartetfs.biz.pivot.definitions.ISelectionDescription;

import blasd.apex.server.datastore.test.ApexTestDatastoreHelper;
import blasd.apex.server.test.IApexTestConstants;

public class TestApexActivePivotDescriptionHelper implements IApexTestConstants {
	@Test
	public void testSelectionWithConsecutiveReferences() {
		IStoreDescription mainStore = ApexTestDatastoreHelper.createStoreDescription(MAIN_STORE, CCY_DAYS_DESC);

		IStoreDescription enrichmentStore =
				ApexTestDatastoreHelper.createStoreDescription(ENRICHMENT_STORE, CCY_DAYS_DESC);

		IStoreDescription further_enrichmentStore =
				ApexTestDatastoreHelper.createStoreDescription("further_" + ENRICHMENT_STORE, CCY_DAYS_DESC);

		IDatastoreSchemaDescription datastoreSchema = ApexTestDatastoreHelper.prepareDescription(
				Arrays.asList(mainStore, enrichmentStore, further_enrichmentStore),
				Arrays.asList(
						ReferenceDescription.builder()
								.fromStore(MAIN_STORE)
								.toStore(ENRICHMENT_STORE)
								.withName("1-2")
								.withMapping(CCY, CCY)
								.build(),
						ReferenceDescription.builder()
								.fromStore(ENRICHMENT_STORE)
								.toStore(further_enrichmentStore.getName())
								.withName("2-3")
								.withMapping(CCY, CCY)
								.build()));

		ISelectionDescription selection =
				ApexActivePivotDescriptionHelper.makeSelectionDescription(datastoreSchema, MAIN_STORE);

		Assert.assertEquals(6, selection.getFields().size());

		Assert.assertEquals(new SelectionField(CCY, CCY), selection.getFields().get(0));
		Assert.assertEquals(new SelectionField(DAYS, DAYS), selection.getFields().get(1));

		Assert.assertEquals(new SelectionField("1-2_" + CCY, "1-2/" + CCY), selection.getFields().get(2));
		Assert.assertEquals(new SelectionField("1-2_" + DAYS, "1-2/" + DAYS), selection.getFields().get(3));

		Assert.assertEquals(new SelectionField("1-2_2-3_" + CCY, "1-2/2-3/" + CCY), selection.getFields().get(4));
		Assert.assertEquals(new SelectionField("1-2_2-3_" + DAYS, "1-2/2-3/" + DAYS), selection.getFields().get(5));
	}
}

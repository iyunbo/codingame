/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;

import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mockito.Mockito;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.qfs.multiversion.IHeadInfo;
import com.qfs.store.IDatastore;
import com.quartetfs.biz.pivot.IActivePivotManager;
import com.quartetfs.biz.pivot.IActivePivotSession;
import com.quartetfs.biz.pivot.IActivePivotVersion;
import com.quartetfs.biz.pivot.ICatalog;
import com.quartetfs.biz.pivot.ILocation;
import com.quartetfs.biz.pivot.IMultiVersionActivePivot;
import com.quartetfs.biz.pivot.cellset.ICellSet;
import com.quartetfs.biz.pivot.context.IActivePivotContext;
import com.quartetfs.biz.pivot.context.impl.QueriesTimeLimit;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevel;
import com.quartetfs.biz.pivot.definitions.IActivePivotDescription;
import com.quartetfs.biz.pivot.query.IGetAggregatesQuery;
import com.quartetfs.biz.pivot.query.IMDXQuery;
import com.quartetfs.biz.pivot.query.impl.ActivePivotSyncActionQuery;
import com.quartetfs.biz.pivot.query.impl.ActivePivotSyncUtils;
import com.quartetfs.biz.pivot.query.impl.ActivePivotSyncUtils.IAction;
import com.quartetfs.biz.pivot.query.impl.GetAggregatesQuery;
import com.quartetfs.biz.pivot.query.impl.QueryMonitoring;
import com.quartetfs.biz.pivot.query.impl.StreamEventProcessingQuery;
import com.quartetfs.biz.xmla.discovery.impl.IPivotDiscoveryHandler;
import com.quartetfs.fwk.query.IQuery;
import com.quartetfs.fwk.query.QueryException;
import com.quartetfs.fwk.query.UnsupportedQueryException;
import com.quartetfs.pivot.mdx.MdxException;
import com.quartetfs.pivot.mdx.impl.BasicSelectExecutor;

import blasd.apex.server.config.cube.ApexCubeBuilder;
import blasd.apex.server.datastore.transaction.ApexTransactionHelper;
import blasd.apex.server.location.ApexLocationBuilder;
import blasd.apex.server.query.hierarchy.ApexHierarchyHelper;
import blasd.apex.server.query.location.ApexLocationHelper;
import blasd.apex.server.registry.ApexRegistryHelper;
import blasd.apex.server.test.IApexTestConstants;
import blasd.apex.server.test.pivot.ApexActivePivotLicenseHelper;
import blasd.apex.server.test.pivot.ApexTestActivePivotHelper;

public class TestApexQueryCubeHelper implements IApexTestConstants {
	@BeforeClass
	public static void loadLicense() {
		ApexActivePivotLicenseHelper.ensureLicenseWithEnv();
	}

	@Before
	public void before() {
		// Needed to be able to query
		ApexRegistryHelper.initApexRegistry();
	}

	@Test
	public void testExecuteActionContextuallyAppliesTimeout() throws Exception {
		IActivePivotDescription cubeDescription = ApexCubeBuilder.newDescription()
				.addHierarchyAndLevels(COUNTRY, CITY)
				.getCubeBuilder()
				.addAggregatedMeasure(DELTA, SUM)
				.getCubeBuilder()
				.getActivePivotDescription();

		final IActivePivotManager apManager =
				ApexTestActivePivotHelper.makeActivePivotManager(MAIN_CUBE, cubeDescription);
		IMultiVersionActivePivot pivot = apManager.getActivePivots().values().iterator().next();

		final int pauseMillis = 1500;
		final int pauseSecond = pauseMillis / 1000;

		long start = System.currentTimeMillis();

		try {
			ApexQueryCubeHelper.executeContextually(pivot.getHead(),
					Collections.singleton(new QueriesTimeLimit(pauseSecond)),
					new ActivePivotSyncUtils.ANoArgAction() {

						@Override
						protected void execute(IActivePivotSession paramIActivePivotSession) {
							try {
								Thread.sleep(pauseMillis);
							} catch (InterruptedException e) {
								throw new RuntimeException(e);
							}
						}
					});
			Assert.fail("We should fail with a TimeOutException");
		} catch (RuntimeException e) {
			long time = System.currentTimeMillis() - start;

			// Check we waited at least the pause
			Assert.assertTrue(time >= pauseSecond);

			// but not much more
			Assert.assertTrue(time <= pauseMillis + 100);
		}
	}

	@Test
	public void testExecuteActionContextuallyRunsOnSingleVersion() throws Exception {
		// RETURNS_DEEP_STUBS for IContext
		IMultiVersionActivePivot pivot = Mockito.mock(IMultiVersionActivePivot.class, Mockito.RETURNS_DEEP_STUBS);

		final IActivePivotVersion latest = Mockito.mock(IActivePivotVersion.class);
		final IActivePivotContext context = Mockito.mock(IActivePivotContext.class);

		Mockito.when(pivot.getHead()).thenReturn(latest);
		Mockito.when(latest.getContext()).thenReturn(context);

		Mockito.when(latest.execute(Mockito.any())).thenAnswer(invocation -> {
			if (invocation.getArgument(0) instanceof ActivePivotSyncActionQuery) {
				IActivePivotSession paramIActivePivotSession = Mockito.mock(IActivePivotSession.class);

				Mockito.when(paramIActivePivotSession.getActivePivot()).thenReturn(latest);

				ActivePivotSyncActionQuery<?, ?> query =
						(ActivePivotSyncActionQuery<?, ?>) invocation.getArguments()[0];
				query.getAction().execute(null, paramIActivePivotSession, null);
			} else {

			}

			return null;
		});

		IGetAggregatesQuery query = new GetAggregatesQuery();
		ApexQueryCubeHelper.executeContextually(pivot, Collections.emptyList(), query);

		Mockito.verify(pivot, Mockito.never()).execute(query);
		Mockito.verify(latest).execute(query);
	}

	@Test
	public void testQueryPartition() {
		IActivePivotDescription cubeDescription = ApexCubeBuilder.newDescription()
				.addHierarchyAndLevels(COUNTRY, CITY)
				.getCubeBuilder()
				.addAggregatedMeasure(DELTA, SUM)
				.getCubeBuilder()
				.getActivePivotDescription();

		final IActivePivotManager apManager =
				ApexTestActivePivotHelper.makeActivePivotManager(MAIN_CUBE, cubeDescription);
		IMultiVersionActivePivot pivot = apManager.getActivePivots().values().iterator().next();

		// Make sure we have enough data for splitting
		int nbCountry = 100;
		for (int i = 0; i < nbCountry; i++) {
			ApexTestActivePivotHelper.contributeSimpleFact(apManager, MAIN_CUBE, i);
		}

		Iterable<? extends ILocation> locations =
				ApexQueryCubeHelper.partitionLocation(ApexLocationBuilder.on(pivot.getHead()).wildcard(COUNTRY).build(),
						ApexHierarchyHelper.findAxisHierarchy(pivot.getHead().getHierarchies(), null, COUNTRY),
						2);

		Assert.assertEquals(nbCountry / 2, Iterables.size(locations));

		ICellSet cellSet = ApexQueryCubeHelper.executeGetAggregates(pivot.getHead(), locations, DELTA_SUM);
		Assert.assertEquals(nbCountry, cellSet.getLocationCount());
	}

	@Test
	public void testQueryPartitionSecondLevel() {
		IActivePivotDescription cubeDescription = ApexCubeBuilder.newDescription()
				.addHierarchyAndLevels(COUNTRY, CITY)
				.getCubeBuilder()
				.addAggregatedMeasure(DELTA, SUM)
				.getCubeBuilder()
				.getActivePivotDescription();

		final IActivePivotManager apManager =
				ApexTestActivePivotHelper.makeActivePivotManager(MAIN_CUBE, cubeDescription);

		final String baseStore = ApexDrillthroughHelper.findBaseStore(apManager, MAIN_CUBE);
		final IDatastore datastore = (IDatastore) apManager.getDatastore();

		List<Map<String, Object>> entriesToAdd = new ArrayList<>();

		// Make sure we have enough data for splitting
		int nbCountry = 5;
		for (int i = 0; i < nbCountry; i++) {
			// A single country on the first level, and many cities on the
			// seconds level
			Map<String, Object> someEntry = ApexTestActivePivotHelper.makeRandomEntry(datastore, baseStore, (double) i);
			// Make sure there is a single country
			someEntry.put(COUNTRY, "SingleCountry_" + (i % 3));
			someEntry.put(CITY, CITY + "_" + i);
			entriesToAdd.add(someEntry);
		}
		ApexTransactionHelper.add(datastore.getTransactionManager(), MAIN_CUBE, entriesToAdd);

		IMultiVersionActivePivot mvPivot = apManager.getActivePivots().values().iterator().next();
		IActivePivotVersion pivot = mvPivot.getHead();

		// Partition on cities an ILocation expressed only up to country
		ILevel countryLevel = ApexHierarchyHelper.findLevel(pivot.getHierarchies(), COUNTRY);
		ILevel cityLevel = ApexHierarchyHelper.findLevel(pivot.getHierarchies(), CITY);
		{
			Iterable<? extends ILocation> locations =
					ApexQueryCubeHelper.partitionLocation(ApexLocationBuilder.on(pivot).wildcard(COUNTRY).build(),
							ApexHierarchyHelper.getAxisHierarchy(pivot.getHierarchies(), cityLevel.getLevelInfo()),
							cityLevel.getOrdinal(),
							2);

			// There is 3 countries: first query 1 and 2, second query 3
			Assert.assertEquals(2L, Iterables.size(locations));
			Assert.assertEquals(ImmutableSet.of("SingleCountry_0", "SingleCountry_1"),
					ApexLocationHelper.getCoordinate(Lists.newArrayList(locations).get(0), countryLevel));
			Assert.assertEquals("SingleCountry_2",
					ApexLocationHelper.getCoordinate(Lists.newArrayList(locations).get(1), countryLevel));
		}

		{
			Iterable<? extends ILocation> locations =
					ApexQueryCubeHelper.partitionLocation(ApexLocationBuilder.on(pivot).wildcard(CITY).build(),
							ApexHierarchyHelper.getAxisHierarchy(pivot.getHierarchies(), cityLevel.getLevelInfo()),
							2);

			Assert.assertEquals(3L, Iterables.size(locations));

			Assert.assertEquals("SingleCountry_0",
					ApexLocationHelper.getCoordinate(Lists.newArrayList(locations).get(0), countryLevel));
			Assert.assertEquals(ImmutableSet.of("City_3", "City_0"),
					ApexLocationHelper.getCoordinate(Lists.newArrayList(locations).get(0), cityLevel));

			Assert.assertEquals("SingleCountry_1",
					ApexLocationHelper.getCoordinate(Lists.newArrayList(locations).get(1), countryLevel));
			Assert.assertEquals(ImmutableSet.of("City_4", "City_1"),
					ApexLocationHelper.getCoordinate(Lists.newArrayList(locations).get(1), cityLevel));

			Assert.assertEquals("SingleCountry_2",
					ApexLocationHelper.getCoordinate(Lists.newArrayList(locations).get(2), countryLevel));
			Assert.assertEquals("City_2",
					ApexLocationHelper.getCoordinate(Lists.newArrayList(locations).get(2), cityLevel));

			ICellSet cellSet = ApexQueryCubeHelper.executeGetAggregates(pivot, locations, DELTA_SUM);
			Assert.assertEquals(nbCountry, cellSet.getLocationCount());
		}

		{
			Set<String> oneCityEach2Cities = new HashSet<>();
			for (int i = 0; i < nbCountry; i++) {
				if (i % 2 == 0) {
					oneCityEach2Cities.add(CITY + "_" + i);
				}
			}
			Assert.assertEquals(3L, oneCityEach2Cities.size());

			Iterable<? extends ILocation> locations = ApexQueryCubeHelper.partitionLocation(
					ApexLocationBuilder.on(pivot).filter(CITY, oneCityEach2Cities).build(),
					ApexHierarchyHelper.getAxisHierarchy(pivot.getHierarchies(), cityLevel.getLevelInfo()),
					2);

			Assert.assertEquals(3l, Iterables.size(locations));

			Assert.assertEquals("SingleCountry_0",
					ApexLocationHelper.getCoordinate(Lists.newArrayList(locations).get(0), countryLevel));
			Assert.assertEquals("City_0",
					ApexLocationHelper.getCoordinate(Lists.newArrayList(locations).get(0), cityLevel));

			Assert.assertEquals("SingleCountry_1",
					ApexLocationHelper.getCoordinate(Lists.newArrayList(locations).get(1), countryLevel));
			Assert.assertEquals("City_4",
					ApexLocationHelper.getCoordinate(Lists.newArrayList(locations).get(1), cityLevel));

			Assert.assertEquals("SingleCountry_2",
					ApexLocationHelper.getCoordinate(Lists.newArrayList(locations).get(2), countryLevel));
			Assert.assertEquals("City_2",
					ApexLocationHelper.getCoordinate(Lists.newArrayList(locations).get(2), cityLevel));

			ICellSet cellSet = ApexQueryCubeHelper.executeGetAggregates(pivot, locations, DELTA_SUM);

			Assert.assertEquals(oneCityEach2Cities.size(), cellSet.getLocationCount());
		}
	}

	@Test
	public void testQueryPartitionSecondLevelWithSameChildDifferentParis() {
		IActivePivotDescription cubeDescription = ApexCubeBuilder.newDescription()
				.addHierarchyAndLevels(COUNTRY, CITY)
				.getCubeBuilder()
				.addAggregatedMeasure(DELTA, SUM)
				.getCubeBuilder()
				.getActivePivotDescription();

		final IActivePivotManager apManager =
				ApexTestActivePivotHelper.makeActivePivotManager(MAIN_CUBE, cubeDescription);

		final IDatastore datastore = (IDatastore) apManager.getDatastore();

		ApexTransactionHelper
				.addOne(datastore.getTransactionManager(), MAIN_CUBE, ImmutableMap.of(COUNTRY, FRANCE, CITY, PARIS));
		ApexTransactionHelper
				.addOne(datastore.getTransactionManager(), MAIN_CUBE, ImmutableMap.of(COUNTRY, USA, CITY, PARIS));

		IMultiVersionActivePivot mvPivot = apManager.getActivePivots().values().iterator().next();
		IActivePivotVersion pivot = mvPivot.getHead();

		// Partition on cities an ILocation expressed only up to country
		ILevel countryLevel = ApexHierarchyHelper.findLevel(pivot.getHierarchies(), COUNTRY);
		ILevel cityLevel = ApexHierarchyHelper.findLevel(pivot.getHierarchies(), CITY);

		// Partition size =1
		{
			Iterable<? extends ILocation> locations = ApexQueryCubeHelper.partitionLocation(
					ApexLocationBuilder.on(pivot).wildcard(COUNTRY).filter(cityLevel.getLevelInfo(), PARIS).build(),
					ApexHierarchyHelper.getAxisHierarchy(pivot.getHierarchies(), cityLevel.getLevelInfo()),
					cityLevel.getOrdinal(),
					1);

			// There is 3 countries: first query 1 and 2, second query 3
			Assert.assertEquals(2L, Iterables.size(locations));
			Assert.assertEquals(FRANCE,
					ApexLocationHelper.getCoordinate(Lists.newArrayList(locations).get(0), countryLevel));
			Assert.assertEquals(USA,
					ApexLocationHelper.getCoordinate(Lists.newArrayList(locations).get(1), countryLevel));
		}

		// Partition size =2
		{
			Iterable<? extends ILocation> locations = ApexQueryCubeHelper.partitionLocation(
					ApexLocationBuilder.on(pivot).wildcard(COUNTRY).filter(cityLevel.getLevelInfo(), PARIS).build(),
					ApexHierarchyHelper.getAxisHierarchy(pivot.getHierarchies(), cityLevel.getLevelInfo()),
					cityLevel.getOrdinal(),
					2);

			// There is 3 countries: first query 1 and 2, second query 3
			Assert.assertEquals(1L, Iterables.size(locations));
			Assert.assertEquals(ImmutableSet.of(FRANCE, USA),
					ApexLocationHelper.getCoordinate(Lists.newArrayList(locations).get(0), countryLevel));
		}
	}

	@Test
	public void testQueryPartitionMultipleCollectionConstain() {
		IActivePivotDescription cubeDescription = ApexCubeBuilder.newDescription()
				.addHierarchyAndLevels(COUNTRY, CITY)
				.getCubeBuilder()
				.addAggregatedMeasure(DELTA, SUM)
				.getCubeBuilder()
				.getActivePivotDescription();

		final IActivePivotManager apManager =
				ApexTestActivePivotHelper.makeActivePivotManager(MAIN_CUBE, cubeDescription);

		final IDatastore datastore = (IDatastore) apManager.getDatastore();

		ApexTransactionHelper
				.addOne(datastore.getTransactionManager(), MAIN_CUBE, ImmutableMap.of(COUNTRY, FRANCE, CITY, PARIS));
		ApexTransactionHelper
				.addOne(datastore.getTransactionManager(), MAIN_CUBE, ImmutableMap.of(COUNTRY, FRANCE, CITY, NEW_YORK));
		ApexTransactionHelper
				.addOne(datastore.getTransactionManager(), MAIN_CUBE, ImmutableMap.of(COUNTRY, USA, CITY, TORONTO));
		ApexTransactionHelper
				.addOne(datastore.getTransactionManager(), MAIN_CUBE, ImmutableMap.of(COUNTRY, USA, CITY, NEW_YORK));

		IMultiVersionActivePivot mvPivot = apManager.getActivePivots().values().iterator().next();
		IActivePivotVersion pivot = mvPivot.getHead();

		// Partition on cities an ILocation expressed only up to country
		ILevel cityLevel = ApexHierarchyHelper.findLevel(pivot.getHierarchies(), CITY);

		// Partition size =1
		{
			Iterable<? extends ILocation> locations = ApexQueryCubeHelper.partitionLocation(
					ApexLocationBuilder.on(pivot)
							.filter(COUNTRY, ImmutableSet.of(FRANCE, USA))
							.filter(cityLevel.getLevelInfo(), ImmutableSet.of(PARIS, NEW_YORK))
							.build(),
					ApexHierarchyHelper.getAxisHierarchy(pivot.getHierarchies(), cityLevel.getLevelInfo()),
					cityLevel.getOrdinal(),
					1);

			Assert.assertEquals(3L, Iterables.size(locations));
			Assert.assertArrayEquals(new Object[] { ILevel.ALLMEMBER, FRANCE, PARIS },
					ApexLocationHelper.getPath(Lists.newArrayList(locations).get(0), cityLevel.getLevelInfo()));

			Assert.assertArrayEquals(new Object[] { ILevel.ALLMEMBER, FRANCE, NEW_YORK },
					ApexLocationHelper.getPath(Lists.newArrayList(locations).get(1), cityLevel.getLevelInfo()));

			Assert.assertArrayEquals(new Object[] { ILevel.ALLMEMBER, USA, NEW_YORK },
					ApexLocationHelper.getPath(Lists.newArrayList(locations).get(2), cityLevel.getLevelInfo()));
		}
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testExtractMdx() throws MdxException, UnsupportedQueryException, QueryException {
		ICatalog catalog = Mockito.mock(ICatalog.class);

		IMultiVersionActivePivot pivot = Mockito.mock(IMultiVersionActivePivot.class);
		Mockito.when(catalog.getActivePivot("CubeName")).thenReturn(pivot);

		IActivePivotVersion pivotVersion = Mockito.mock(IActivePivotVersion.class);
		Mockito.when(pivot.getHead()).thenReturn(pivotVersion);

		{
			IHeadInfo<IActivePivotVersion> headInfo = Mockito.mock(IHeadInfo.class);
			Mockito.doReturn(Collections.singletonMap("someBranchName", headInfo)).when(pivot).getHeads();
			Mockito.when(headInfo.getVersion()).thenReturn(pivotVersion);
		}

		final AtomicReference<IQuery<?>> queryRef = new AtomicReference<>();

		Mockito.when(pivotVersion.execute(Mockito.any(IQuery.class))).thenAnswer(invocation -> {
			IQuery<?> query = invocation.getArgument(0);
			queryRef.set(query);

			return null;
		});

		String mdx = "SELECT FROM [CubeName] WHERE [Measures].[contributors.COUNT]";
		BasicSelectExecutor executor = new BasicSelectExecutor(catalog, mdx, new Properties());

		executor.execute();

		IQuery<?> query = queryRef.get();
		Assert.assertNotNull(query);

		final AtomicReference<String> detectedMdx = new AtomicReference<>();

		ApexQueryCubeHelper.dispatchQuery(query, new IApexQueryHandler() {

			@Override
			public void onOtherQueryDone(IQuery<?> query) {
				Assert.fail();
			}

			@Override
			public void onMDXQuery(IMDXQuery query) {
				detectedMdx.set(query.getContent());
			}

			@Override
			public void onGetAggregatesQuery(IGetAggregatesQuery query) {
				Assert.fail();
			}

			@Override
			public void onDiscoveryQuery(IQuery<?> query, Class<? extends IPivotDiscoveryHandler> handlerClass) {
				Assert.fail();
			}

			@Override
			public void onStreamEventProcessingQuery(StreamEventProcessingQuery<?> query) {
				Assert.fail();
			}

			@Override
			public void onActionQueryDone(IAction<?, ?> action) {
				Assert.fail();
			}
		});

		Assert.assertEquals(mdx, detectedMdx.get());
	}

	@Test
	public void testExecuteContextually() throws UnsupportedQueryException, QueryException {
		IActivePivotDescription cubeDescription = ApexCubeBuilder.newDescription()
				.addHierarchyAndLevels(COUNTRY, CITY)
				.getCubeBuilder()
				.addAggregatedMeasure(DELTA, SUM)
				.getCubeBuilder()
				.getActivePivotDescription();

		final IActivePivotManager apManager =
				ApexTestActivePivotHelper.makeActivePivotManager(MAIN_CUBE, cubeDescription);
		IMultiVersionActivePivot pivot = apManager.getActivePivots().values().iterator().next();

		ApexTestActivePivotHelper.contributeSimpleFact(apManager, MAIN_CUBE, 0);

		IActivePivotVersion pivotVersion = pivot.getHead();
		ILocation location = ApexLocationBuilder.on(pivot).build();

		GetAggregatesQuery gaq = new GetAggregatesQuery(Arrays.asList(location), Arrays.asList(DELTA_SUM));

		gaq.setContextValues(Arrays.asList(new QueryMonitoring()));

		ICellSet cellSet = ApexQueryCubeHelper.executeQuery(pivotVersion, gaq);

		Assert.assertEquals(1, cellSet.getLocationCount());
	}
}

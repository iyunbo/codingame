/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.subcube;

import java.util.Arrays;
import java.util.List;
import java.util.Set;

import org.assertj.core.api.Assertions;
import org.joda.time.LocalDate;
import org.junit.Assert;
import org.junit.Test;

import com.quartetfs.fwk.filtering.impl.EqualCondition;
import com.quartetfs.fwk.filtering.impl.OrCondition;

public class TestApexSubCubeConfigurer {
	@Test
	public void testSubCubeOnSecondLevel() {
		ApexSubCubeConfigurer configurer = new ApexSubCubeConfigurer(null);

		LocalDate today = new LocalDate();
		configurer
				.grantPath("dimension", "hierarchy", Arrays.asList(null, "Some Member", Arrays.asList("Youpi"), today));

		Set<List<?>> pathes = configurer.getSubCubeProperties().getGrantedMembers("dimension", "hierarchy");
		Assert.assertEquals(1, pathes.size());
		Assert.assertEquals(Arrays.asList(null,
				"Some Member",
				new OrCondition(Arrays.asList(new EqualCondition("Youpi"))),
				new EqualCondition(today)), pathes.iterator().next());
	}

	@Test
	public void testGranted() {
		Assert.assertTrue(ApexSubCubeConfigurer.makeGrantedSubCube().isAccessGranted());
		Assertions.assertThat(ApexSubCubeConfigurer.makeGrantedSubCube().getRestrictedHierarchies()).isEmpty();
	}

	@Test
	public void testMakeUnauthorized() {
		Assert.assertFalse(ApexSubCubeConfigurer.makeUnauthorizedSubCube().isAccessGranted());
	}
}

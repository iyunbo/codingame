/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.location;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.quartetfs.biz.pivot.ILocation;
import com.quartetfs.biz.pivot.context.subcube.ISubCubeProperties;
import com.quartetfs.biz.pivot.impl.Location;

public class TestApexLocationAcceptor {
	// This can happen in the context of a distributed cube (TODO: in which case exactly?)
	@Test
	public void testAcceptLocation_EmptyHierarchyNames_emptyLocation() {
		// Consider an empty location
		ILocation location = new Location();

		// Could be empty on an empty cube?
		List<String> hierarchyNames = Collections.emptyList();

		ApexLocationAcceptor.acceptLocation(location,
				Collections.emptyList(),
				hierarchyNames,
				(hierarchyName, levelDepth, coordinate) -> Assert.fail("Should not be called"));
	}

	@Test
	public void testAcceptLocation_EmptyHierarchyNames_nonEmptyLocation() {
		// Consider an empty location
		ILocation location = new Location(new Object[][] { new Object[] { "singleHierarchyFirstLevelCoordinate" } });

		// Could be empty on an empty cube?
		List<String> hierarchyNames = Collections.emptyList();

		ApexLocationAcceptor.acceptLocation(location,
				Collections.emptyList(),
				hierarchyNames,
				(hierarchyName, levelDepth, coordinate) -> {
					Assert.assertEquals("0", hierarchyName);
					Assert.assertEquals(0, levelDepth);
					Assert.assertEquals("singleHierarchyFirstLevelCoordinate", coordinate);
				});
	}

	@Test
	public void testAcceptLocation_NullHierarchyNames_nonEmptyLocation() {
		// Consider an empty location
		ILocation location = new Location(new Object[][] { new Object[] { "singleHierarchyFirstLevelCoordinate" } });

		// Could be empty on an empty cube?
		List<String> hierarchyNames = null;

		ApexLocationAcceptor.acceptLocation(location,
				Collections.emptyList(),
				hierarchyNames,
				(hierarchyName, levelDepth, coordinate) -> {
					Assert.assertEquals("0", hierarchyName);
					Assert.assertEquals(0, levelDepth);
					Assert.assertEquals("singleHierarchyFirstLevelCoordinate", coordinate);
				});
	}

	@Test
	public void testAcceptLocationWithoutAnyHierarchy() {
		// Consider an empty location
		ILocation location = new Location();

		ApexLocationAcceptor.acceptLocation(location, (l, hIndex) -> Assert.fail("Should not be called"));
	}

	@Test
	public void testAcceptLocation_nullSubCube() {
		// Consider an empty location
		ILocation location = new Location(new Object[][] { new Object[] { "singleHierarchyFirstLevelCoordinate" } });

		List<String> hierarchyNames = Arrays.asList("hName");

		ISubCubeProperties subCubeProperties = null;
		ApexLocationAcceptor.acceptLocation(location,
				subCubeProperties,
				hierarchyNames,
				(hierarchyName, levelDepth, coordinate) -> {
					Assert.assertEquals("hName", hierarchyName);
					Assert.assertEquals(0, levelDepth);
					Assert.assertEquals("singleHierarchyFirstLevelCoordinate", coordinate);
				});
	}
}

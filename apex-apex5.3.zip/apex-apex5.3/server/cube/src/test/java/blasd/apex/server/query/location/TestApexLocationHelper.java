/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.location;

import java.util.Arrays;
import java.util.Collections;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.google.common.collect.ImmutableMap;
import com.qfs.security.impl.SpringSecurityFacade;
import com.quartetfs.biz.pivot.ILocation;
import com.quartetfs.biz.pivot.IMultiVersionActivePivot;
import com.quartetfs.biz.pivot.context.subcube.impl.SubCubeProperties;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevel;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevelInfo;
import com.quartetfs.biz.pivot.cube.hierarchy.impl.HierarchiesUtil;
import com.quartetfs.biz.pivot.definitions.IActivePivotDescription;
import com.quartetfs.biz.pivot.impl.Location;

import blasd.apex.server.config.cube.ApexCubeBuilder;
import blasd.apex.server.location.ApexLocationBuilder;
import blasd.apex.server.query.hierarchy.ApexHierarchyHelper;
import blasd.apex.server.test.IApexTestConstants;
import blasd.apex.server.test.pivot.ApexTestActivePivotHelper;
import blasd.apex.server.test.registry.ApexTestRegistryHelper;
import gnu.trove.map.TObjectIntMap;

public class TestApexLocationHelper implements IApexTestConstants {

	public static IMultiVersionActivePivot simpleCcyCountryPivot() {
		return ApexTestActivePivotHelper.makeCcyCountryAsOfDateActivePivot(MAIN_CUBE);
	}

	@BeforeClass
	public static void beforeClass() {
		// We compare to default ILocation.toString: get rid of
		// ApexShortLocationFormatter
		// Registry.setContributionProvider(new DefaultContributionProvider());

		// Needed for ActivePivotBase
		ApexTestRegistryHelper.resetClassInRegistry(SpringSecurityFacade.class);
	}

	@Test
	public void testGetCoordinate() {
		IMultiVersionActivePivot pivot = simpleCcyCountryPivot();

		ILocation l = ApexLocationBuilder.on(pivot).build();

		ILevel countryLevel = ApexHierarchyHelper.findLevel(pivot.getHierarchies(), COUNTRY_LEV);

		Assert.assertEquals(-1, ApexLocationHelper.checkDeepEnough(l, countryLevel.getLevelInfo()));
	}

	@Test
	public void testSetCoordinate() {
		IMultiVersionActivePivot pivot = simpleCcyCountryPivot();

		ILocation l = ApexLocationBuilder.on(pivot).build();

		ILevel countryLevel = ApexHierarchyHelper.findLevel(pivot.getHierarchies(), COUNTRY_LEV);

		ILocation newLocation = ApexLocationHelper.setCoordinates(l, countryLevel, USA, true);
		Assert.assertEquals(USA, ApexLocationHelper.getCoordinate(newLocation, countryLevel));
	}

	@Test
	public void testSetCoordinateOnSlicing() {
		IMultiVersionActivePivot pivot = ApexTestActivePivotHelper.makeCcyCountryAsOfDateActivePivot(MAIN_CUBE);

		ILocation l = ApexLocationBuilder.on(pivot).build();

		ILevel asOfDateLevel = ApexHierarchyHelper.findLevel(pivot.getHierarchies(), ASOFDATE);

		Assert.assertEquals(0, ApexLocationHelper.checkDeepEnough(l, asOfDateLevel.getLevelInfo()));
		Assert.assertEquals(null, ApexLocationHelper.getCoordinate(l, asOfDateLevel));

		ILocation setDate = ApexLocationHelper.setCoordinates(l, asOfDateLevel, "SomeDate", false);
		Assert.assertEquals("SomeDate", ApexLocationHelper.getCoordinate(setDate, asOfDateLevel));
	}

	@Test
	public void testSetCoordinateMap() {
		IMultiVersionActivePivot pivot = simpleCcyCountryPivot();

		ILocation l = ApexLocationBuilder.on(pivot).build();

		ILevelInfo countryLevel = ApexHierarchyHelper.findLevel(pivot.getHierarchies(), COUNTRY_LEV).getLevelInfo();

		ILocation newLocation = ApexLocationHelper.setCoordinates(l, Collections.singletonMap(countryLevel, USA), true);
		Assert.assertEquals(USA, ApexLocationHelper.getCoordinate(newLocation, countryLevel));
	}

	@Test
	public void testSetCoordinateAlreadySet() {
		IMultiVersionActivePivot pivot = simpleCcyCountryPivot();

		ILevelInfo countryLevel = ApexHierarchyHelper.findLevel(pivot.getHierarchies(), COUNTRY_LEV).getLevelInfo();

		ILocation l = ApexLocationBuilder.on(pivot).filter(countryLevel, USA).build();

		// Check we stick to the same location if not modified
		Assert.assertSame(l, ApexLocationHelper.setCoordinates(l, countryLevel, USA, true));
	}

	@Test
	public void testSetCoordinateMap2() {
		IMultiVersionActivePivot pivot = simpleCcyCountryPivot();

		ILocation l = ApexLocationBuilder.on(pivot).build();

		ILevelInfo countryLevel = ApexHierarchyHelper.findLevel(pivot.getHierarchies(), COUNTRY_LEV).getLevelInfo();

		ILocation newLocation = ApexLocationHelper.setCoordinates(l, Collections.singletonMap(countryLevel, USA), true);
		Assert.assertEquals(USA, ApexLocationHelper.getCoordinate(newLocation, countryLevel));
	}

	@Test
	public void testSetCoordinateOn2LevelsSameHierarchy() {
		IMultiVersionActivePivot pivot = simpleCcyCountryPivot();

		ILocation location =
				ApexLocationBuilder.on(pivot).filter(ImmutableMap.of(COUNTRY, FRANCE, CITY, PARIS)).build();

		ILevel countryLevel = ApexHierarchyHelper.findLevel(pivot.getHierarchies(), COUNTRY_LEV);

		// Check we succeeded having 2 coordinates on the same level
		Assert.assertArrayEquals(new Object[] { ILevel.ALLMEMBER, FRANCE, PARIS },
				ApexLocationHelper.getPath(location, countryLevel.getHierarchyInfo()));
	}

	@Test
	public void testSetCoordinateOn2LevelsSameHierarchyInverseLevelOrder() {
		IMultiVersionActivePivot pivot = simpleCcyCountryPivot();

		ILocation location =
				ApexLocationBuilder.on(pivot).filter(ImmutableMap.of(CITY, PARIS, COUNTRY, FRANCE)).build();

		ILevel countryLevel = ApexHierarchyHelper.findLevel(pivot.getHierarchies(), COUNTRY_LEV);

		// Check we succeeded having 2 coordinates on the same level
		Assert.assertArrayEquals(new Object[] { ILevel.ALLMEMBER, FRANCE, PARIS },
				ApexLocationHelper.getPath(location, countryLevel.getHierarchyInfo()));
	}

	@Test
	public void testBulkSetCoordinate() {
		IMultiVersionActivePivot pivot = simpleCcyCountryPivot();

		ILocation l = ApexLocationBuilder.on(pivot).build();

		ILevelInfo countryLevel = ApexHierarchyHelper.findLevel(pivot.getHierarchies(), COUNTRY_LEV).getLevelInfo();

		ILocation newLocation = ApexLocationHelper.setCoordinates(l, Collections.singletonMap(countryLevel, USA), true);
		Assert.assertEquals(USA, ApexLocationHelper.getCoordinate(newLocation, countryLevel));
	}

	@Test
	public void testRetrieveExpressedLevelsFromDimension() {
		IMultiVersionActivePivot pivot = simpleCcyCountryPivot();

		ILocation location = new Location("AllMember|AllMember\\USA");

		TObjectIntMap<String> expressedLevels = ApexLocationHelper.retrieveExpressedLevels(location,
				null,
				ApexHierarchyHelper.getNames(ApexHierarchyHelper.extractAxisHierarchiesInfo(pivot)));
		Assert.assertEquals(1, expressedLevels.size());
		Assert.assertEquals(1, expressedLevels.get(COUNTRY_HIE));
	}

	@Test
	public void testRetrieveExpressedLevelsFromDimensionFromLatestVersion() {
		IMultiVersionActivePivot pivot = simpleCcyCountryPivot();

		ILocation location = new Location("AllMember|AllMember\\US");

		TObjectIntMap<String> expressedLevels = ApexLocationHelper.retrieveExpressedLevels(location,
				null,
				ApexHierarchyHelper.getNames(ApexHierarchyHelper.extractAxisHierarchiesInfo(pivot.getHierarchies())));
		Assert.assertEquals(1, expressedLevels.size());
		Assert.assertEquals(1, expressedLevels.get(COUNTRY_HIE));
	}

	@Test
	public void testRetrieveExpressedLevelsFromSubcube() {
		IMultiVersionActivePivot pivot = simpleCcyCountryPivot();

		ILocation location = ApexLocationBuilder.on(pivot).build();
		SubCubeProperties subCube = new SubCubeProperties(true);
		subCube.grantMembers(COUNTRY_HIE, COUNTRY_HIE, Arrays.asList(ILevel.ALLMEMBER, USA));

		TObjectIntMap<String> expressedLevels = ApexLocationHelper.retrieveExpressedLevels(location,
				subCube,
				ApexHierarchyHelper.getNames(HierarchiesUtil.getHierarchyInfo(pivot.getHierarchies())));
		Assert.assertEquals(1, expressedLevels.size());
		Assert.assertEquals(1, expressedLevels.get(COUNTRY_HIE));
	}

	@Test
	public void testRetrieveExpressedLevelsFromLocationAndSubcube() {
		IMultiVersionActivePivot pivot = simpleCcyCountryPivot();

		// Check SubCube deeper than location
		{
			ILocation location = new Location("AllMember|AllMember\\USA");
			SubCubeProperties subCube = new SubCubeProperties(true);
			subCube.grantMembers(COUNTRY_HIE, COUNTRY_HIE, Arrays.asList(ILevel.ALLMEMBER, USA, "NewYork"));

			TObjectIntMap<String> expressedLevels = ApexLocationHelper.retrieveExpressedLevels(location,
					subCube,
					ApexHierarchyHelper.getNames(HierarchiesUtil.getHierarchyInfo(pivot.getHierarchies())));
			Assert.assertEquals(1, expressedLevels.size());
			Assert.assertEquals(2, expressedLevels.get(COUNTRY_HIE));
		}

		// Check ILocation deeper than subcube
		{
			ILocation location = new Location("AllMember|AllMember\\US\\NewYork");
			SubCubeProperties subCube = new SubCubeProperties(true);
			subCube.grantMembers(COUNTRY_HIE, COUNTRY_HIE, Arrays.asList(ILevel.ALLMEMBER, USA));

			TObjectIntMap<String> expressedLevels = ApexLocationHelper.retrieveExpressedLevels(location,
					subCube,
					ApexHierarchyHelper.getNames(HierarchiesUtil.getHierarchyInfo(pivot.getHierarchies())));
			Assert.assertEquals(1, expressedLevels.size());
			Assert.assertEquals(2, expressedLevels.get(COUNTRY_HIE));
		}
	}

	@Test
	public void testGetLevelDepth() {
		IMultiVersionActivePivot pivot = simpleCcyCountryPivot();

		Assert.assertEquals(1,
				ApexLocationHelper.getLevelDepth(new Location("AllMember|AllMember"),
						ApexHierarchyHelper.findAxisHierarchy(pivot.getHierarchies(), COUNTRY_HIE)));
		Assert.assertEquals(2,
				ApexLocationHelper.getLevelDepth(new Location("AllMember|AllMember\\US"),
						ApexHierarchyHelper.findAxisHierarchy(pivot.getHierarchies(), COUNTRY_HIE)));
		Assert.assertEquals(3,
				ApexLocationHelper.getLevelDepth(new Location("AllMember|AllMember\\US\\NewYork"),
						ApexHierarchyHelper.findAxisHierarchy(pivot.getHierarchies(), COUNTRY_HIE)));
	}

	@Test
	public void testFindHierarchyWithOrdinal() {
		IMultiVersionActivePivot pivot = simpleCcyCountryPivot();

		// Check the IHierarchy with index 0 has the name of the first
		// dimension
		Assert.assertEquals(CCY, ApexHierarchyHelper.findAxisHierarchy(pivot.getHierarchies(), null, "0").getName());
	}

	@Test
	public void testDrillDown() {
		IMultiVersionActivePivot pivot = simpleCcyCountryPivot();

		ILocation location = ApexLocationBuilder.on(pivot).build();
		ILocation drillDownedLocation = ApexLocationHelper.drillUpOrDown(location,
				ApexHierarchyHelper.findLevel(pivot.getHierarchies(), COUNTRY_LEV).getLevelInfo());

		Assert.assertEquals(ApexLocationBuilder.on(pivot).wildcard(COUNTRY).build(), drillDownedLocation);
	}

	@Test
	public void testFindLevelWithAtInLevel() throws Exception {
		IActivePivotDescription activePivotDescription = ApexCubeBuilder.newDescription()
				.addHierarchyAndLevels("levelWithAt@")
				.getCubeBuilder()
				.getActivePivotDescription();

		IMultiVersionActivePivot pivot = ApexTestActivePivotHelper.makeActivePivot(MAIN_CUBE, activePivotDescription);

		Assert.assertEquals("levelWithAt@",
				ApexHierarchyHelper.findLevel(pivot.getHierarchies(), "levelWithAt@", "levelWithAt@", "levelWithAt@")
						.getName());
	}

	@Test
	public void testFindLevelWithAtInDImension() throws Exception {
		IActivePivotDescription activePivotDescription = ApexCubeBuilder.newDescription()
				.getOrAddDimension("DimensionWithAt@")
				.addHierarchyAndLevels("someField")
				.getCubeBuilder()
				.getActivePivotDescription();

		IMultiVersionActivePivot pivot = ApexTestActivePivotHelper.makeActivePivot(MAIN_CUBE, activePivotDescription);

		Assert.assertEquals("someField",
				ApexHierarchyHelper.findLevel(pivot.getHierarchies(), "DimensionWithAt@", "someField", "someField")
						.getName());

		// This works as we have too may @
		Assert.assertEquals("someField",
				ApexHierarchyHelper.findLevel(pivot.getHierarchies(), "someField@someField@DimensionWithAt@")
						.getName());
	}

	@Test
	public void testFindLevel_ProvideOnlyLevel() {
		IActivePivotDescription activePivotDescription = ApexCubeBuilder.newActivePivotDescripion()
				.getOrAddDimension("dimensionName")
				.getOrAddAxisHierarchy("hierarchyName")
				.appendLevel("levelName")
				.getCubeBuilder()
				.getActivePivotDescription();

		IMultiVersionActivePivot pivot = ApexTestActivePivotHelper.makeActivePivot(MAIN_CUBE, activePivotDescription);

		Assert.assertEquals("levelName",
				ApexHierarchyHelper.findLevel(pivot.getHierarchies(), null, null, "levelName").getName());
	}

	@Test(expected = IllegalArgumentException.class)
	public void testFindLevel_LevelDoesNotExist() {
		IActivePivotDescription activePivotDescription = ApexCubeBuilder.newActivePivotDescripion()
				.addHierarchyAndLevels("someField")
				.getCubeBuilder()
				.getActivePivotDescription();

		IMultiVersionActivePivot pivot = ApexTestActivePivotHelper.makeActivePivot(MAIN_CUBE, activePivotDescription);

		ApexHierarchyHelper.findLevel(pivot.getHierarchies(), "unknown");
	}

	@Test(expected = IllegalArgumentException.class)
	public void testFindLevel_HierarchyDoesNotExist() {
		IActivePivotDescription activePivotDescription = ApexCubeBuilder.newActivePivotDescripion()
				.addHierarchyAndLevels("someField")
				.getCubeBuilder()
				.getActivePivotDescription();

		IMultiVersionActivePivot pivot = ApexTestActivePivotHelper.makeActivePivot(MAIN_CUBE, activePivotDescription);

		ApexHierarchyHelper.findLevel(pivot.getHierarchies(), null, "unknown", "someField");
	}
}

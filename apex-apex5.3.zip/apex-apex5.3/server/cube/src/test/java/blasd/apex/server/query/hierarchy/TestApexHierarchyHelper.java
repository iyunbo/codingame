/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.hierarchy;

import java.util.Collections;
import java.util.List;
import java.util.Properties;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.qfs.agg.impl.SumFunction;
import com.qfs.security.impl.SpringSecurityFacade;
import com.quartetfs.biz.pivot.IMultiVersionActivePivot;
import com.quartetfs.biz.pivot.cube.hierarchy.IHierarchy;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevel;
import com.quartetfs.biz.pivot.cube.hierarchy.IMultiVersionHierarchy;
import com.quartetfs.biz.pivot.cube.hierarchy.axis.IAxisHierarchy;
import com.quartetfs.biz.pivot.definitions.IActivePivotDescription;
import com.quartetfs.biz.pivot.definitions.IAxisHierarchyDescription;
import com.quartetfs.biz.pivot.definitions.impl.AxisDimensionDescription;
import com.quartetfs.biz.pivot.definitions.impl.AxisHierarchyDescription;

import blasd.apex.server.config.cube.ApexCubeBuilder;
import blasd.apex.server.query.dimension.AnalysisTestHierarchy;
import blasd.apex.server.query.location.TestApexLocationHelper;
import blasd.apex.server.test.IApexTestConstants;
import blasd.apex.server.test.pivot.ApexTestActivePivotHelper;
import blasd.apex.server.test.registry.ApexTestRegistryHelper;

public class TestApexHierarchyHelper implements IApexTestConstants {
	protected static final Logger LOGGER = LoggerFactory.getLogger(TestApexHierarchyHelper.class);

	@BeforeClass
	public static void initRegistry() {
		ApexTestRegistryHelper.resetClassInRegistry(SpringSecurityFacade.class);
	}

	@Test
	public void testLevelName() throws Exception {
		IMultiVersionActivePivot pivot = ApexTestActivePivotHelper.makeCcyCountryAsOfDateActivePivot(MAIN_CUBE);

		ILevel cityLevel = ApexHierarchyHelper.findLevel(pivot.getHierarchies(), CITY);

		Assert.assertEquals("City@COUNTRY_Hie@COUNTRY_Dim", ApexHierarchyHelper.levelName(cityLevel.getLevelInfo()));
		Assert.assertEquals("City@COUNTRY_Hie@COUNTRY_Dim",
				ApexHierarchyHelper.levelName(
						ApexHierarchyHelper.getAxisHierarchy(pivot.getHierarchies(), cityLevel.getLevelInfo()),
						2));

		Assert.assertEquals("City@COUNTRY_Hie", ApexHierarchyHelper.levelName(COUNTRY_HIE, CITY));
		Assert.assertEquals("City@COUNTRY_Hie@COUNTRY_Dim",
				ApexHierarchyHelper.levelName(COUNTRY_DIM, COUNTRY_HIE, CITY));
	}

	@Test
	public void testLevelNameNotUnique() throws Exception {
		String otherHierarchyHoldingCity = "other" + COUNTRY;
		IActivePivotDescription twoCitiesDesc = ApexCubeBuilder.cloneActivePivotDescripion(CCY_COUNTRY_CITY_DELTA_SUM)
				.addHierarchyAndLevels(otherHierarchyHoldingCity, CITY)
				.getCubeBuilder()
				.getActivePivotDescription();

		IMultiVersionActivePivot pivot = ApexTestActivePivotHelper.makeActivePivot(MAIN_CUBE, twoCitiesDesc);

		try {
			ApexHierarchyHelper.findLevel(pivot.getHierarchies(), CITY);
			Assert.fail("Should reject ambiguity");
		} catch (IllegalArgumentException e) {
			// Ensure the message holds the 2 parent hierarchies
			Assert.assertTrue(e.getMessage().contains(COUNTRY));
			Assert.assertTrue(e.getMessage().contains(otherHierarchyHoldingCity));
		}
	}

	@Test
	public void testLevelNameEndingWithAt() {
		String nameEndingWithAt = "Country @";

		IActivePivotDescription apDesc = ApexCubeBuilder.newDescription()
				.addHierarchyAndLevels(CCY)
				.getCubeBuilder()
				.getOrAddDimension(nameEndingWithAt)
				.addHierarchyAndLevels(nameEndingWithAt)
				.getCubeBuilder()
				.addAggregatedMeasure(DELTA, SumFunction.PLUGIN_KEY)
				.getCubeBuilder()
				.getActivePivotDescription();

		IMultiVersionActivePivot pivot = ApexTestActivePivotHelper.makeActivePivot(MAIN_CUBE, apDesc);

		ILevel cityLevel = ApexHierarchyHelper.findLevel(pivot.getHierarchies(), nameEndingWithAt);

		Assert.assertEquals(nameEndingWithAt + "@" + nameEndingWithAt + "@" + nameEndingWithAt,
				ApexHierarchyHelper.levelName(cityLevel.getLevelInfo()));
	}

	@Test
	public void testGetDefaultDiscriminator() throws Exception {
		ApexTestRegistryHelper.addClassInRegistry(AnalysisTestHierarchy.class);

		IActivePivotDescription apDesc = ASOFDATE_CCY_COUNTRY_CITY_DELTA_SUM.clone();

		int analsyisHierarchyIndex = 4;
		{
			IAxisHierarchyDescription hierarchyDescription = new AxisHierarchyDescription("TestAnalysisHierarchy");
			hierarchyDescription.setPluginKey(AnalysisTestHierarchy.PLUGIN_KEY);

			hierarchyDescription.setProperties(new Properties());
			hierarchyDescription.setAllMembersEnabled(true);

			apDesc.getAxisDimensions()
					.getValues()
					.add(new AxisDimensionDescription("TestAnalysisHierarchy",
							Collections.singletonList(hierarchyDescription)));

		}

		final IMultiVersionActivePivot pivot = ApexTestActivePivotHelper.makeActivePivot(MAIN_CUBE, apDesc);

		IHierarchy hierarchy = pivot.getHierarchies().get(analsyisHierarchyIndex);

		Assert.assertTrue(ApexHierarchyHelper.isAnalysisHierarchy(hierarchy));
	}

	@Test
	public void testFindHierarchies() throws Exception {
		IMultiVersionActivePivot pivot = ApexTestActivePivotHelper.makeCcyCountryAsOfDateActivePivot(MAIN_CUBE);

		Assert.assertEquals(1,
				ApexHierarchyHelper.filterAxisHierarchiesInDimension(pivot.getHierarchies(), COUNTRY_DIM).size());
	}

	@Test
	public void testFindHierarchy() throws Exception {
		IMultiVersionActivePivot pivot = TestApexLocationHelper.simpleCcyCountryPivot();

		Assert.assertEquals(COUNTRY_HIE,
				ApexHierarchyHelper.findAxisHierarchy(pivot.getHierarchies(), COUNTRY_HIE).getName());
		Assert.assertEquals(COUNTRY_HIE,
				ApexHierarchyHelper.findAxisHierarchy(pivot.getHierarchies(), COUNTRY_HIE_FULL).getName());
	}

	@Test
	public void testFindHierarchyOrdinal() throws Exception {
		IMultiVersionActivePivot pivot = TestApexLocationHelper.simpleCcyCountryPivot();

		List<? extends IMultiVersionHierarchy> allHierarchies = pivot.getHierarchies();
		Assert.assertEquals(COUNTRY_HIE,
				ApexHierarchyHelper.findAxisHierarchyNoFail(allHierarchies, null, COUNTRY_HIE).getName());

		// -1 to skip measure, -1 as lastIndex
		String nbAxisHierarchy = Integer.toString(allHierarchies.size() - 1 - 1);
		// Index=0 -> CCY
		Assert.assertEquals(CCY, ApexHierarchyHelper.findAxisHierarchyNoFail(allHierarchies, null, "0").getName());
		Assert.assertEquals(ASOFDATE,
				ApexHierarchyHelper.findAxisHierarchyNoFail(allHierarchies, null, nbAxisHierarchy).getName());

		// Index=0 -> CCY even if we got rid of the measure hierarchy
		List<? extends IAxisHierarchy> axisHierarchies =
				ApexHierarchyHelper.filterAxisHierarchies(pivot.getHierarchies());
		Assert.assertEquals(CCY, ApexHierarchyHelper.findAxisHierarchyNoFail(axisHierarchies, null, "0").getName());
		Assert.assertEquals(ASOFDATE,
				ApexHierarchyHelper.findAxisHierarchyNoFail(axisHierarchies, null, nbAxisHierarchy).getName());
	}

	@Test
	public void testFindLevels() throws Exception {
		IMultiVersionActivePivot pivot = ApexTestActivePivotHelper.makeCcyCountryAsOfDateActivePivot(MAIN_CUBE);

		// Give level and hierarchy
		Assert.assertEquals(COUNTRY, ApexHierarchyHelper.findLevel(pivot.getHierarchies(), COUNTRY_LEV).getName());
		Assert.assertEquals(COUNTRY_HIE,
				ApexHierarchyHelper.findLevel(pivot.getHierarchies(), COUNTRY_LEV).getHierarchyInfo().getName());
		Assert.assertEquals(1, ApexHierarchyHelper.findLevels(pivot.getHierarchies(), COUNTRY_LEV).size());

		// Give level, hierarchy and dimension
		Assert.assertEquals(COUNTRY, ApexHierarchyHelper.findLevel(pivot.getHierarchies(), COUTNRY_LEV_FULL).getName());
		Assert.assertEquals(COUNTRY_HIE,
				ApexHierarchyHelper.findLevel(pivot.getHierarchies(), COUTNRY_LEV_FULL).getHierarchyInfo().getName());
		Assert.assertEquals(1, ApexHierarchyHelper.findLevels(pivot.getHierarchies(), COUTNRY_LEV_FULL).size());

		// Give only the level name
		Assert.assertEquals(CITY, ApexHierarchyHelper.findLevel(pivot.getHierarchies(), CITY).getName());

		// Give only the hierarchy name: it should select the first interesting
		// level
		// 1: Slicing
		Assert.assertEquals(COUNTRY, ApexHierarchyHelper.findLevel(pivot.getHierarchies(), COUNTRY_HIE).getName());
		// 2: Not Slicing
		Assert.assertEquals(CCY, ApexHierarchyHelper.findLevel(pivot.getHierarchies(), CCY).getName());

		// Give only the dimension name: it should select the first interesting
		// level of the unique hierarchy
		// 1: Slicing
		Assert.assertEquals(COUNTRY, ApexHierarchyHelper.findLevel(pivot.getHierarchies(), COUNTRY_DIM).getName());
	}

	@Test
	public void testFindLevel_Ambiguity() throws Exception {
		IActivePivotDescription cubeDescription = ApexCubeBuilder.newDescription()
				.addHierarchyAndLevels("levelName")
				.setName("hierarchy1")
				.addHierarchyAndLevels("levelName")
				.setName("hierarchy2")
				.getCubeBuilder()
				.getActivePivotDescription();

		IMultiVersionActivePivot pivot = ApexTestActivePivotHelper.makeActivePivot(MAIN_CUBE, cubeDescription);

		Assert.assertEquals("hierarchy1",
				ApexHierarchyHelper.findLevel(pivot.getHierarchies(), "levelName@hierarchy1")
						.getHierarchyInfo()
						.getName());
		Assert.assertEquals("hierarchy2",
				ApexHierarchyHelper.findLevel(pivot.getHierarchies(), "levelName@hierarchy2")
						.getHierarchyInfo()
						.getName());

		try {
			ApexHierarchyHelper.findLevel(pivot.getHierarchies(), "levelName").getHierarchyInfo();
			Assert.fail("Should throw on ambiguities");
		} catch (IllegalArgumentException e) {
			LOGGER.trace("Expected", e);
		}
	}
}

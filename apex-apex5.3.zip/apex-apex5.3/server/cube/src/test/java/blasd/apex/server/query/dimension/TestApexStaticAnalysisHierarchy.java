/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.dimension;

import org.joda.time.LocalDate;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.google.common.collect.ImmutableSet;
import com.qfs.agg.impl.SumFunction;
import com.qfs.security.impl.SpringSecurityFacade;
import com.quartetfs.biz.pivot.IActivePivotManager;
import com.quartetfs.biz.pivot.IMultiVersionActivePivot;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevel;
import com.quartetfs.biz.pivot.cube.hierarchy.IMultiVersionHierarchy;
import com.quartetfs.biz.pivot.cube.hierarchy.axis.IAxisHierarchy;
import com.quartetfs.biz.pivot.cube.hierarchy.axis.IAxisMember;
import com.quartetfs.fwk.AgentException;

import blasd.apex.server.config.cube.ApexCubeBuilder;
import blasd.apex.server.config.cube.IApexCubeBuilder;
import blasd.apex.server.query.hierarchy.ApexHierarchyHelper;
import blasd.apex.server.query.postprocessor.basic.IdentityPostProcessor;
import blasd.apex.server.test.IApexTestConstants;
import blasd.apex.server.test.pivot.ApexTestActivePivotHelper;
import blasd.apex.server.test.registry.ApexTestRegistryHelper;

public class TestApexStaticAnalysisHierarchy implements IApexTestConstants {

	@BeforeClass
	public static void setUpRegistry() {
		ApexTestRegistryHelper.resetClassInRegistry(IdentityPostProcessor.class,
				ApexStaticAnalysisHierarchy.class,
				SpringSecurityFacade.class);
	}

	@Test
	public void testOnEmptyPathButNotConfigured() throws AgentException {
		IApexCubeBuilder description = ApexCubeBuilder.newDescription();

		ApexStaticAnalysisHierarchyBuilder staticBuilder =
				new ApexStaticAnalysisHierarchyBuilder(description, "analysis");

		// We set levelNames but no path: this is an error we should add the
		// empty
		staticBuilder.setLevelNames("FirstLevel");

		description.addAggregatedMeasure(DELTA, SumFunction.PLUGIN_KEY);

		IActivePivotManager pivotmanager =
				ApexTestActivePivotHelper.makeActivePivotManager(MAIN_CUBE, description.getActivePivotDescription());

		// Add some facts to build the Analysis hierarchy
		ApexTestActivePivotHelper.contributeSimpleFact(pivotmanager, MAIN_CUBE);

		IMultiVersionActivePivot pivot = pivotmanager.getActivePivots().values().iterator().next();
		Assert.assertEquals(1, pivot.getHierarchies().get(1).retrieveMembers(0).size());
		Assert.assertEquals(ApexStaticAnalysisHierarchy.DEFAULT_EMPTY_MEMBER,
				((IAxisMember) pivot.getHierarchies().get(1).retrieveMembers(0).get(0)).getDiscriminator());
	}

	@Test
	public void testOnEmptyPath() throws AgentException {
		IApexCubeBuilder description = ApexCubeBuilder.newDescription();

		ApexStaticAnalysisHierarchyBuilder staticBuilder =
				new ApexStaticAnalysisHierarchyBuilder(description, "analysis");

		// We set levelNames but no path: this is an error we should add the
		// empty
		staticBuilder.setDefaultEmptyPath("EmptyElement");

		description.addAggregatedMeasure(DELTA, SumFunction.PLUGIN_KEY);

		IActivePivotManager pivotmanager =
				ApexTestActivePivotHelper.makeActivePivotManager(MAIN_CUBE, description.getActivePivotDescription());

		// Add some facts to build the Analysis hierarchy
		ApexTestActivePivotHelper.contributeSimpleFact(pivotmanager, MAIN_CUBE);

		IMultiVersionActivePivot pivot = pivotmanager.getActivePivots().values().iterator().next();
		Assert.assertEquals(1, pivot.getHierarchies().get(1).retrieveMembers(0).size());
		Assert.assertEquals("EmptyElement",
				((IAxisMember) pivot.getHierarchies().get(1).retrieveMembers(0).get(0)).getDiscriminator());
	}

	@Test
	public void testOnEmptyPathWithAllMember() throws AgentException {
		IApexCubeBuilder description = ApexCubeBuilder.newDescription();

		ApexStaticAnalysisHierarchyBuilder staticBuilder =
				new ApexStaticAnalysisHierarchyBuilder(description, "analysis");

		// Set AllMember
		staticBuilder.getDecorated().withAllMember();

		staticBuilder.setDefaultEmptyPath("EmptyElement");
		staticBuilder.setLevelNames("AnalysisLevel");

		description.addAggregatedMeasure(DELTA, SumFunction.PLUGIN_KEY);

		IActivePivotManager pivotmanager =
				ApexTestActivePivotHelper.makeActivePivotManager(MAIN_CUBE, description.getActivePivotDescription());

		// Add some facts to build the Analysis hierarchy
		ApexTestActivePivotHelper.contributeSimpleFact(pivotmanager, MAIN_CUBE);

		IMultiVersionActivePivot pivot = pivotmanager.getActivePivots().values().iterator().next();
		IMultiVersionHierarchy firstHierarchy = pivot.getHierarchies().get(1);
		Assert.assertEquals(1, firstHierarchy.retrieveMembers(0).size());
		Assert.assertEquals(ILevel.ALLMEMBER,
				((IAxisMember) firstHierarchy.retrieveMembers(0).get(0)).getDiscriminator());
		Assert.assertEquals("EmptyElement",
				((IAxisMember) firstHierarchy.retrieveMembers(1).get(0)).getDiscriminator());
	}

	@Test
	public void testPathWithObject() throws AgentException {
		IApexCubeBuilder description = ApexCubeBuilder.newDescription();

		ApexStaticAnalysisHierarchyBuilder staticBuilder =
				new ApexStaticAnalysisHierarchyBuilder(description, "analysis");

		staticBuilder.addPath(new LocalDate());

		description.addAggregatedMeasure(DELTA, SumFunction.PLUGIN_KEY);

		IActivePivotManager pivotmanager =
				ApexTestActivePivotHelper.makeActivePivotManager(MAIN_CUBE, description.getActivePivotDescription());

		// Add some facts to build the Analysis hierarchy
		ApexTestActivePivotHelper.contributeSimpleFact(pivotmanager, MAIN_CUBE);

		IMultiVersionActivePivot pivot = pivotmanager.getActivePivots().get(MAIN_CUBE);
		IMultiVersionHierarchy asOfHierarchy = pivot.getHierarchies().get(1);
		Assert.assertEquals(1, asOfHierarchy.retrieveMembers(0).size());
		Assert.assertEquals(ImmutableSet.of(new LocalDate()),
				ApexHierarchyHelper.getLevelDiscriminators((IAxisHierarchy) pivot.getHierarchies().get(1), 0));
	}

	@Test
	public void testAddAnalysisHierarchyWithBuilder() {
		IApexCubeBuilder description = ApexCubeBuilder.newDescription();
		ApexStaticAnalysisHierarchyBuilder decomposerH =
				description.addAnalysisHierarchy("analysis", ApexStaticAnalysisHierarchyBuilder::new);

		Assert.assertEquals(ApexStaticAnalysisHierarchy.PLUGIN_KEY, decomposerH.getDescription().getPluginKey());
	}
}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.location;

import org.junit.Assert;
import org.junit.Test;

import com.qfs.security.impl.SpringSecurityFacade;
import com.quartetfs.biz.pivot.IActivePivotVersion;
import com.quartetfs.biz.pivot.ILocation;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevel;

import blasd.apex.server.location.ApexLocationBuilder;
import blasd.apex.server.query.hierarchy.ApexHierarchyHelper;
import blasd.apex.server.test.IApexTestConstants;
import blasd.apex.server.test.registry.ApexTestRegistryHelper;

public class TestApexLocationBuilder implements IApexTestConstants {
	@Test
	public void testSingleWildcard() throws Exception {
		ApexTestRegistryHelper.resetClassInRegistry(SpringSecurityFacade.class);

		IActivePivotVersion pivot = TestApexLocationHelper.simpleCcyCountryPivot().getHead();

		ILocation l = ApexLocationBuilder.on(pivot).wildcard(CCY).build();
		Assert.assertNull(
				ApexLocationHelper.getCoordinate(l, ApexHierarchyHelper.findLevel(pivot.getHierarchies(), CCY)));
	}

	@Test
	public void testTwoWildcards() throws Exception {
		ApexTestRegistryHelper.resetClassInRegistry(SpringSecurityFacade.class);

		IActivePivotVersion pivot = TestApexLocationHelper.simpleCcyCountryPivot().getHead();

		ILocation l = ApexLocationBuilder.on(pivot).wildcard(CCY, COUNTRY).build();
		Assert.assertNull(
				ApexLocationHelper.getCoordinate(l, ApexHierarchyHelper.findLevel(pivot.getHierarchies(), CCY)));
		Assert.assertNull(
				ApexLocationHelper.getCoordinate(l, ApexHierarchyHelper.findLevel(pivot.getHierarchies(), COUNTRY)));
	}

	@Test
	public void testFilterThenWildcard() throws Exception {
		ApexTestRegistryHelper.resetClassInRegistry(SpringSecurityFacade.class);

		IActivePivotVersion pivot = TestApexLocationHelper.simpleCcyCountryPivot().getHead();

		ILocation l = ApexLocationBuilder.on(pivot).filter(CCY, EUR).wildcard(CCY, COUNTRY).build();
		Assert.assertEquals(EUR,
				ApexLocationHelper.getCoordinate(l, ApexHierarchyHelper.findLevel(pivot.getHierarchies(), CCY)));
	}

	@Test(expected = RuntimeException.class)
	public void testFilterUnkownLevel() throws Exception {
		ApexTestRegistryHelper.resetClassInRegistry(SpringSecurityFacade.class);

		IActivePivotVersion pivot = TestApexLocationHelper.simpleCcyCountryPivot().getHead();

		ApexLocationBuilder.on(pivot).filter("Unknown", EUR).build();
	}

	@Test
	public void testFromHierarchies() throws Exception {
		ApexTestRegistryHelper.resetClassInRegistry(SpringSecurityFacade.class);

		IActivePivotVersion pivot = TestApexLocationHelper.simpleCcyCountryPivot().getHead();

		ILocation l = ApexLocationBuilder.on(pivot.getHierarchies()).build();
		Assert.assertEquals(ILevel.ALLMEMBER, l.getCoordinate(0, 0));
		Assert.assertEquals(ILevel.ALLMEMBER, l.getCoordinate(1, 0));

		// AsOfDate is slicing
		Assert.assertEquals(null, l.getCoordinate(2, 0));
	}
}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.drillthrough;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.google.common.collect.ImmutableMap;
import com.quartetfs.biz.pivot.IActivePivotManager;
import com.quartetfs.biz.pivot.IMultiVersionActivePivot;
import com.quartetfs.biz.pivot.context.drillthrough.IDrillthroughRow;
import com.quartetfs.biz.pivot.cube.hierarchy.measures.IMeasureHierarchy;
import com.quartetfs.biz.pivot.definitions.IActivePivotDescription;
import com.quartetfs.biz.pivot.postprocessing.impl.ParentValuePostProcessor;
import com.quartetfs.biz.pivot.postprocessing.impl.PreviousValuePostProcessor;
import com.quartetfs.biz.pivot.postprocessing.impl.Stream2PositionPostProcessor;
import com.quartetfs.biz.pivot.query.aggregates.impl.TimeLineHandler;

import blasd.apex.server.config.cube.ApexCubeBuilder;
import blasd.apex.server.datastore.transaction.ApexTransactionHelper;
import blasd.apex.server.location.ApexLocationBuilder;
import blasd.apex.server.query.ApexQueryCubeHelper;
import blasd.apex.server.test.IApexTestConstants;
import blasd.apex.server.test.pivot.ApexTestActivePivotHelper;
import blasd.apex.server.test.registry.ApexTestRegistryHelper;

public class TestApexLocationInterpreter implements IApexTestConstants {
	@Test
	public void testStream2Position() {
		ApexTestRegistryHelper.resetClassInRegistry(TimeLineHandler.class, ApexDrillthroughExecutor.class);

		IActivePivotDescription activePivotDescription = ApexCubeBuilder.newActivePivotDescripion()
				// Wire Apex drillthrough executor
				.setDrillthroughQueryExecutorQuery(ApexDrillthroughExecutor.PLUGIN_KEY)
				.addHierarchyAndLevels(DAYS)
				.getCubeBuilder()
				.addPostProcessedMeasure("stream2position", Stream2PositionPostProcessor.PLUGIN_KEY)
				.configurePostProcessor(c -> {
					// We cumulate 'contributors.COUNT'
					c.setProperty(Stream2PositionPostProcessor.STREAM_MEASURE_PROPERTY, IMeasureHierarchy.COUNT_ID);
					// Along DAYS
					c.setProperty(Stream2PositionPostProcessor.TIME_HIERARCHY_PROPERTY, DAYS);
				})
				.getCubeBuilder()
				.getActivePivotDescription();
		IActivePivotManager manager =
				ApexTestActivePivotHelper.makeActivePivotManager(MAIN_CUBE, activePivotDescription);

		ApexTransactionHelper.addOne(manager, MAIN_CUBE, ImmutableMap.of(DAYS, 1));
		ApexTransactionHelper.addOne(manager, MAIN_CUBE, ImmutableMap.of(DAYS, 3));
		ApexTransactionHelper.addOne(manager, MAIN_CUBE, ImmutableMap.of(DAYS, 7));

		IMultiVersionActivePivot cube = manager.getActivePivots().get(MAIN_CUBE);
		List<IDrillthroughRow> output = ApexQueryCubeHelper.executeQuery(cube.getHead(),
				ApexQueryCubeHelper.makeDrillthrough("stream2position",
						ApexLocationBuilder.on(cube).filter(DAYS, 3).build()));

		// We should retrieve the facts for DAYS before 3, including 3
		// However, the way Stream2Position is implemented, we prefetch all parent aggregates: we actually retrieve all
		// DAYS
		Assert.assertEquals(3, output.size());
		Assert.assertEquals(1, output.get(0).getContent().length);
		Assert.assertEquals("1", output.get(0).getContent()[0]);
		Assert.assertEquals(1, output.get(1).getContent().length);
		Assert.assertEquals("3", output.get(1).getContent()[0]);
		Assert.assertEquals(1, output.get(2).getContent().length);
		Assert.assertEquals("7", output.get(2).getContent()[0]);
	}

	@Test
	public void testPreviousValue() {
		ApexTestRegistryHelper.resetClassInRegistry(TimeLineHandler.class, ApexDrillthroughExecutor.class);

		IActivePivotDescription activePivotDescription = ApexCubeBuilder.newActivePivotDescripion()
				// Wire Apex drillthrough executor
				.setDrillthroughQueryExecutorQuery(ApexDrillthroughExecutor.PLUGIN_KEY)
				.addHierarchyAndLevels(DAYS)
				.getCubeBuilder()
				.addPostProcessedMeasure("previousValue", PreviousValuePostProcessor.PLUGIN_KEY)
				.configurePostProcessor(c -> {
					// We cumulate 'contributors.COUNT'
					c.setProperty(PreviousValuePostProcessor.STREAM_MEASURE_PROPERTY, IMeasureHierarchy.COUNT_ID);
					// Along DAYS
					c.setProperty(PreviousValuePostProcessor.TIME_HIERARCHY_PROPERTY, DAYS);
				})
				.getCubeBuilder()
				.getActivePivotDescription();
		IActivePivotManager manager =
				ApexTestActivePivotHelper.makeActivePivotManager(MAIN_CUBE, activePivotDescription);

		ApexTransactionHelper.addOne(manager, MAIN_CUBE, ImmutableMap.of(DAYS, 1));
		ApexTransactionHelper.addOne(manager, MAIN_CUBE, ImmutableMap.of(DAYS, 3));
		ApexTransactionHelper.addOne(manager, MAIN_CUBE, ImmutableMap.of(DAYS, 7));

		IMultiVersionActivePivot cube = manager.getActivePivots().get(MAIN_CUBE);
		List<IDrillthroughRow> output = ApexQueryCubeHelper.executeQuery(cube.getHead(),
				ApexQueryCubeHelper.makeDrillthrough("previousValue",
						ApexLocationBuilder.on(cube).filter(DAYS, 3).build()));

		// We should retrieve the facts for DAYS before 3, including 3
		// However, the way Stream2Position is implemented, we prefetch all parent aggregates: we actually retrieve all
		// DAYS
		Assert.assertEquals(3, output.size());
		Assert.assertEquals(1, output.get(0).getContent().length);
		Assert.assertEquals("1", output.get(0).getContent()[0]);
		Assert.assertEquals(1, output.get(1).getContent().length);
		Assert.assertEquals("3", output.get(1).getContent()[0]);
		Assert.assertEquals(1, output.get(2).getContent().length);
		Assert.assertEquals("7", output.get(2).getContent()[0]);
	}

	@Test
	public void testParentValue() {
		ApexTestRegistryHelper.resetClassInRegistry(TimeLineHandler.class, ApexDrillthroughExecutor.class);

		IActivePivotDescription activePivotDescription = ApexCubeBuilder.newActivePivotDescripion()
				// Wire Apex drillthrough executor
				.setDrillthroughQueryExecutorQuery(ApexDrillthroughExecutor.PLUGIN_KEY)
				.addHierarchyAndLevels(COUNTRY, CITY)
				.getCubeBuilder()
				.addPostProcessedMeasure("parentValue", ParentValuePostProcessor.PLUGIN_KEY)
				.configurePostProcessor(c -> {
					// We should return the parent at the COUNTRY level
					c.setProperty(ParentValuePostProcessor.PARENT_HIERARCHIES, COUNTRY);

					c.setUnderlyingMeasures(IMeasureHierarchy.COUNT_ID);
				})
				.getCubeBuilder()
				.getActivePivotDescription();
		IActivePivotManager manager =
				ApexTestActivePivotHelper.makeActivePivotManager(MAIN_CUBE, activePivotDescription);

		ApexTransactionHelper.addOne(manager, MAIN_CUBE, ImmutableMap.of(COUNTRY, FRANCE, CITY, PARIS));
		ApexTransactionHelper.addOne(manager, MAIN_CUBE, ImmutableMap.of(COUNTRY, FRANCE, CITY, NICE));
		ApexTransactionHelper.addOne(manager, MAIN_CUBE, ImmutableMap.of(COUNTRY, USA, CITY, NEW_YORK));

		IMultiVersionActivePivot cube = manager.getActivePivots().get(MAIN_CUBE);

		// We query Paris: should return France
		List<IDrillthroughRow> output = ApexQueryCubeHelper.executeQuery(cube.getHead(),
				ApexQueryCubeHelper.makeDrillthrough("parentValue",
						ApexLocationBuilder.on(cube).filter(COUNTRY, FRANCE).filter(CITY, PARIS).build()));

		// We should retrieve the facts for DAYS before 3, including 3
		// However, the way Stream2Position is implemented, we prefetch all parent aggregates: we actually retrieve all
		// DAYS
		Assert.assertEquals(2, output.size());
		{
			Object[] firstRow = output.get(0).getContent();
			Assert.assertEquals(2, firstRow.length);
			Assert.assertEquals(FRANCE, firstRow[0]);
			Assert.assertEquals(PARIS, firstRow[1]);
		}
		{
			Object[] secondRow = output.get(1).getContent();
			Assert.assertEquals(2, secondRow.length);
			Assert.assertEquals(FRANCE, secondRow[0]);
			Assert.assertEquals(NICE, secondRow[1]);
		}
	}
}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.test.pivot;

import org.junit.Assert;
import org.junit.Test;

import com.google.common.collect.ImmutableMap;
import com.qfs.agg.impl.MaxAppendOnlyFunction;
import com.qfs.store.Types;
import com.qfs.store.record.IByteRecordFormat;
import com.quartetfs.biz.pivot.IActivePivotManager;
import com.quartetfs.biz.pivot.definitions.IAggregatedMeasureDescription;
import com.quartetfs.fwk.IAgent.State;

import blasd.apex.server.test.IApexTestConstants;

public class TestApexTestActivePivotHelper implements IApexTestConstants {
	@Test
	public void test_LiteralTypeIsAggregationFunction() {
		IActivePivotManager apManager = ApexTestActivePivotHelper.buildCubeOverDatastore(MAIN_CUBE,
				ImmutableMap.of(CCY, STRING, DELTA, MaxAppendOnlyFunction.KEY));
		Assert.assertEquals(State.NONE, apManager.getStatus());

		ApexTestActivePivotHelper.initAndStartActivePivotManager(apManager);
		Assert.assertEquals(State.STARTED, apManager.getStatus());

		// Check DOUBLE has been guessed as ILiteralType
		{
			IByteRecordFormat recordFormat =
					apManager.getDatastore().getSchemaMetadata().getStoreMetadata(0).getStoreFormat().getRecordFormat();
			int deltaDatatype = recordFormat.getType(recordFormat.getFieldIndex(DELTA));
			Assert.assertEquals(DOUBLE, Types.getContentTypeString(deltaDatatype));
		}

		// Check the custom aggregation function had been wired
		{
			IAggregatedMeasureDescription measure = apManager.getActivePivots()
					.get(MAIN_CUBE)
					.getDescription()
					.getMeasuresDescription()
					.getAggregatedMeasuresDescription()
					.get(0);
			Assert.assertEquals(MaxAppendOnlyFunction.KEY, measure.getPreProcessedAggregation());
		}
	}

	@Test
	public void testStart() {
		IActivePivotManager apManager = ApexTestActivePivotHelper.buildCubeOverDatastore(MAIN_CUBE,
				ImmutableMap.of(CCY, STRING, DELTA, DOUBLE));
		Assert.assertEquals(State.NONE, apManager.getStatus());

		ApexTestActivePivotHelper.initAndStartActivePivotManager(apManager);
		Assert.assertEquals(State.STARTED, apManager.getStatus());
	}

	@Test
	public void testMultipleStart() {
		IActivePivotManager apManager =
				ApexTestActivePivotHelper.buildCubeOverDatastore(MAIN_CUBE, ImmutableMap.of(CCY, STRING, DELTA, SUM));
		Assert.assertEquals(State.NONE, apManager.getStatus());

		// Check we handle starting several times
		ApexTestActivePivotHelper.initAndStartActivePivotManager(apManager);
		ApexTestActivePivotHelper.initAndStartActivePivotManager(apManager);
		Assert.assertEquals(State.STARTED, apManager.getStatus());
	}
}

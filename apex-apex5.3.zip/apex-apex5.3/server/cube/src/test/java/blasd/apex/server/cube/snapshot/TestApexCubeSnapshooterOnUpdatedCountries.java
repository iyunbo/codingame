/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.cube.snapshot;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.joda.time.LocalDateTime;
import org.junit.Assert;
import org.junit.Test;

import com.codahale.metrics.Timer;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Sets;
import com.google.common.eventbus.EventBus;
import com.qfs.literal.ILiteralType;
import com.qfs.store.IDatastore;
import com.quartetfs.biz.pivot.IActivePivotManager;
import com.quartetfs.biz.pivot.IMultiVersionActivePivot;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevelInfo;

import blasd.apex.server.datastore.transaction.ApexTransactionHelper;
import blasd.apex.server.query.hierarchy.ApexHierarchyHelper;
import blasd.apex.server.test.IApexTestConstants;
import blasd.apex.server.test.pivot.ApexTestActivePivotHelper;
import blasd.apex.server.test.registry.ApexTestRegistryHelper;

/**
 * Test the integration of the cube snapshotter with an ApexAccumulatingSelectionListener
 * 
 * @author Benoit Lacelle
 *
 */
public class TestApexCubeSnapshooterOnUpdatedCountries implements IApexTestConstants {
	private static class PublishResult {
		protected final Set<? extends Map<?, ?>> partitionIds;
		protected final List<? extends Map<String, ?>> asRows;

		public PublishResult(Set<? extends Map<?, ?>> partitionIds, List<? extends Map<String, ?>> asRows) {
			this.partitionIds = partitionIds;
			this.asRows = asRows;
		}

	}

	@Test
	public void testQueryOnUpdatePartitions() {
		ApexTestRegistryHelper.resetClassInRegistry();

		IActivePivotManager apManager = ApexTestActivePivotHelper.buildCubeOverDatastore(MAIN_SCHEMA,
				MAIN_CUBE,
				MAIN_STORE,
				ImmutableMap.of(COUNTRY, ILiteralType.STRING, DELTA, ILiteralType.DOUBLE));

		ApexTestActivePivotHelper.initAndStartActivePivotManager(apManager);

		IMultiVersionActivePivot multiVersionCube = apManager.getActivePivots().get(MAIN_CUBE);

		final ILevelInfo countryLevel =
				ApexHierarchyHelper.findLevel(multiVersionCube.getHierarchies(), COUNTRY).getLevelInfo();

		final List<PublishResult> published = new CopyOnWriteArrayList<>();

		PartitionGetAggregatesQueriesProvider provider =
				new PartitionGetAggregatesQueriesProvider(countryLevel, Sets.newHashSet(DELTA_SUM));

		AApexCubeSnapshooter<Map<? extends ILevelInfo, ?>> snapshooter =
				new AApexCubeSnapshooter<Map<? extends ILevelInfo, ?>>(new EventBus()::post,
						multiVersionCube,
						provider,
						Arrays.asList(countryLevel),
						new Timer()) {

					@Override
					protected void publishPartition(Set<? extends Map<? extends ILevelInfo, ?>> partitionIds,
							Stream<? extends Map<String, ?>> asRows) {
						published.add(new PublishResult(partitionIds, asRows.collect(Collectors.toList())));
					}

					@Override
					protected String getTargetColumnName(ILevelInfo levelInfo) {
						if (levelInfo.equals(countryLevel)) {
							return COUNTRY;
						} else {
							return super.getTargetColumnName(levelInfo);
						}
					}

				};

		// We accept up to 2 updated countries before switching to "RecomputeAll"
		{
			AApexCubeSnapshooter.registerAsBaseStoreListener(apManager, snapshooter, provider, 2);
		}

		IDatastore datastore = (IDatastore) apManager.getDatastore();

		{
			// Add a first row for a single country
			ApexTransactionHelper
					.addOne(apManager, MAIN_STORE, ImmutableMap.of(COUNTRY, FRANCE, CCY, EUR, DELTA, 1.2F));

			Assert.assertFalse(provider.getAndResetRecomputeAll());
			checkDetectedPartitions(ImmutableSet.of(FRANCE), provider);
		}

		{
			// Add second row for same country
			ApexTransactionHelper
					.addOne(apManager, MAIN_STORE, ImmutableMap.of(COUNTRY, FRANCE, CCY, EUR, DELTA, 1.3F));

			// Add another country in second transaction
			ApexTransactionHelper.addOne(apManager, MAIN_STORE, ImmutableMap.of(COUNTRY, USA, CCY, EUR, DELTA, 1.3F));

			Assert.assertFalse(provider.getAndResetRecomputeAll());
			checkDetectedPartitions(ImmutableSet.of(FRANCE, USA), provider);
		}

		{
			// Add two countries in same transaction
			ApexTransactionHelper.add(datastore.getTransactionManager(),
					MAIN_STORE,
					Arrays.asList(ImmutableMap.of(COUNTRY, FRANCE, CCY, EUR, DELTA, 1.3F),
							ImmutableMap.of(COUNTRY, USA, CCY, EUR, DELTA, 1.3F)));

			Assert.assertFalse(provider.getAndResetRecomputeAll());
			checkDetectedPartitions(ImmutableSet.of(FRANCE, USA), provider);
		}

		{
			// Add same country several in same transaction
			ApexTransactionHelper.add(datastore.getTransactionManager(),
					MAIN_STORE,
					Arrays.asList(ImmutableMap.of(COUNTRY, FRANCE, CCY, EUR, DELTA, 1.2F),
							ImmutableMap.of(COUNTRY, FRANCE, CCY, EUR, DELTA, 1.3F),
							ImmutableMap.of(COUNTRY, FRANCE, CCY, EUR, DELTA, 1.4F)));

			Assert.assertFalse(provider.getAndResetRecomputeAll());
			checkDetectedPartitions(ImmutableSet.of(FRANCE), provider);
		}

		{
			// Add three countries in same transaction: overflow
			ApexTransactionHelper.add(datastore.getTransactionManager(),
					MAIN_STORE,
					Arrays.asList(ImmutableMap.of(COUNTRY, FRANCE, CCY, EUR, DELTA, 1.3F),
							ImmutableMap.of(COUNTRY, USA, CCY, EUR, DELTA, 1.3F),
							ImmutableMap.of(COUNTRY, CANADA, CCY, EUR, DELTA, 1.3F)));

			Assert.assertTrue(provider.getAndResetRecomputeAll());
			// Overflow: we keep no specific country
			checkDetectedPartitions(ImmutableSet.of(), provider);
		}

		{
			// Add 2 countries in same transaction: do not overflow as we have no limit for now
			ApexTransactionHelper.add(datastore.getTransactionManager(),
					MAIN_STORE,
					Arrays.asList(ImmutableMap.of(COUNTRY, FRANCE, CCY, EUR, DELTA, 1.3F),
							ImmutableMap.of(COUNTRY, USA, CCY, EUR, DELTA, 1.3F)));
			ApexTransactionHelper.add(datastore.getTransactionManager(),
					MAIN_STORE,
					Arrays.asList(ImmutableMap.of(COUNTRY, CANADA, CCY, EUR, DELTA, 1.3F)));

			Assert.assertFalse(provider.getAndResetRecomputeAll());
			checkDetectedPartitions(ImmutableSet.of(FRANCE, CANADA, USA), provider);
		}
	}

	protected void checkDetectedPartitions(Set<?> partitionIds, PartitionGetAggregatesQueriesProvider provider) {
		Map<List<?>, LocalDateTime> partitionToFirstDate = provider.getAndResetPartitions();

		Set<List<?>> partitionsToCheckAsList = new HashSet<>();
		for (Object p : partitionIds) {
			partitionsToCheckAsList.add(Arrays.asList(p));
		}

		Assert.assertEquals(partitionsToCheckAsList, partitionToFirstDate.keySet());
	}

	@Test
	public void testCheckDateForImpactedPartitions() throws InterruptedException {
		ApexTestRegistryHelper.resetClassInRegistry();

		IActivePivotManager apManager = ApexTestActivePivotHelper.buildCubeOverDatastore(MAIN_SCHEMA,
				MAIN_CUBE,
				MAIN_STORE,
				ImmutableMap.of(COUNTRY, ILiteralType.STRING, DELTA, ILiteralType.DOUBLE));

		ApexTestActivePivotHelper.initAndStartActivePivotManager(apManager);

		IMultiVersionActivePivot multiVersionCube = apManager.getActivePivots().get(MAIN_CUBE);

		final ILevelInfo countryLevel =
				ApexHierarchyHelper.findLevel(multiVersionCube.getHierarchies(), COUNTRY).getLevelInfo();

		final List<PublishResult> published = new CopyOnWriteArrayList<>();

		PartitionGetAggregatesQueriesProvider provider =
				new PartitionGetAggregatesQueriesProvider(countryLevel, Sets.newHashSet(DELTA_SUM));

		AApexCubeSnapshooter<Map<? extends ILevelInfo, ?>> snapshooter =
				new AApexCubeSnapshooter<Map<? extends ILevelInfo, ?>>(new EventBus()::post,
						multiVersionCube,
						provider,
						Arrays.asList(countryLevel),
						new Timer()) {

					@Override
					protected void publishPartition(Set<? extends Map<? extends ILevelInfo, ?>> partitionIds,
							Stream<? extends Map<String, ?>> asRows) {
						published.add(new PublishResult(partitionIds, asRows.collect(Collectors.toList())));
					}

					@Override
					protected String getTargetColumnName(ILevelInfo levelInfo) {
						if (levelInfo.equals(countryLevel)) {
							return COUNTRY;
						} else {
							return super.getTargetColumnName(levelInfo);
						}
					}

				};

		// We accept up to 2 updated countries before switching to "RecomputeAll"
		{
			AApexCubeSnapshooter.registerAsBaseStoreListener(apManager, snapshooter, provider, 2);
		}

		{
			// Add a row in France
			ApexTransactionHelper
					.addOne(apManager, MAIN_STORE, ImmutableMap.of(COUNTRY, FRANCE, CCY, EUR, DELTA, 1.3F));

			// Ensure some time flows
			Thread.sleep(10);

			// Add a row in USA
			ApexTransactionHelper.addOne(apManager, MAIN_STORE, ImmutableMap.of(COUNTRY, USA, CCY, EUR, DELTA, 1.3F));

			// Ensure some time flows
			Thread.sleep(10);

			// Update again France: we should stick to the old date
			ApexTransactionHelper
					.addOne(apManager, MAIN_STORE, ImmutableMap.of(COUNTRY, FRANCE, CCY, EUR, DELTA, 1.4F));

			Map<List<?>, LocalDateTime> pendingPartitions = provider.getAndResetPartitions();

			LocalDateTime franceDate = pendingPartitions.get(Arrays.asList(FRANCE));
			LocalDateTime usaDate = pendingPartitions.get(Arrays.asList(USA));

			// Check we have 2 different dates
			Assert.assertTrue(franceDate.isBefore(usaDate));
		}
	}

	@Test
	public void testFlushImpactedPartitions() throws InterruptedException {
		ApexTestRegistryHelper.resetClassInRegistry();

		IActivePivotManager apManager = ApexTestActivePivotHelper.buildCubeOverDatastore(MAIN_SCHEMA,
				MAIN_CUBE,
				MAIN_STORE,
				ImmutableMap.of(COUNTRY, ILiteralType.STRING, DELTA, ILiteralType.DOUBLE));

		ApexTestActivePivotHelper.initAndStartActivePivotManager(apManager);

		IMultiVersionActivePivot multiVersionCube = apManager.getActivePivots().get(MAIN_CUBE);

		final ILevelInfo countryLevel =
				ApexHierarchyHelper.findLevel(multiVersionCube.getHierarchies(), COUNTRY).getLevelInfo();

		final List<PublishResult> published = new CopyOnWriteArrayList<>();

		PartitionGetAggregatesQueriesProvider provider =
				new PartitionGetAggregatesQueriesProvider(countryLevel, Sets.newHashSet(DELTA_SUM));

		AApexCubeSnapshooter<Map<? extends ILevelInfo, ?>> snapshooter =
				new AApexCubeSnapshooter<Map<? extends ILevelInfo, ?>>(new EventBus()::post,
						multiVersionCube,
						provider,
						Arrays.asList(countryLevel),
						new Timer()) {

					@Override
					protected void publishPartition(Set<? extends Map<? extends ILevelInfo, ?>> partitionIds,
							Stream<? extends Map<String, ?>> asRows) {
						published.add(new PublishResult(partitionIds, asRows.collect(Collectors.toList())));
					}

					@Override
					protected String getTargetColumnName(ILevelInfo levelInfo) {
						if (levelInfo.equals(countryLevel)) {
							return COUNTRY;
						} else {
							return super.getTargetColumnName(levelInfo);
						}
					}

				};

		// We accept up to 2 updated countries before switching to "RecomputeAll"
		{
			AApexCubeSnapshooter.registerAsBaseStoreListener(apManager, snapshooter, provider, 2);
		}

		IDatastore datastore = (IDatastore) apManager.getDatastore();

		{
			// Add a row in France
			ApexTransactionHelper
					.addOne(apManager, MAIN_STORE, ImmutableMap.of(COUNTRY, FRANCE, CCY, EUR, DELTA, 1.3F));

			long nbPartitions = snapshooter.flushPendingPartitions();

			// We recomputed France
			Assert.assertEquals(1, nbPartitions);

			Assert.assertEquals(ImmutableSet.of(ImmutableMap.of(countryLevel, FRANCE)), published.get(0).partitionIds);
			List<? extends Map<String, ?>> rows = published.get(0).asRows;

			Assert.assertEquals(1, rows.size());
			Map<String, ?> singleRow = rows.get(0);
			Assert.assertEquals(FRANCE, singleRow.get(COUNTRY));
			Assert.assertEquals(1.30D, (Double) singleRow.get(DELTA_SUM), 0.01D);
		}
	}
}

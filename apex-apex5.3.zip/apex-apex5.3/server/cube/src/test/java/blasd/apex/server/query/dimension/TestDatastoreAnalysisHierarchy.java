/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.dimension;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.awaitility.Awaitility;
import org.hamcrest.core.IsEqual;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.google.common.base.Suppliers;
import com.qfs.desc.IStoreDescription;
import com.qfs.security.impl.SpringSecurityFacade;
import com.qfs.store.IDatastore;
import com.qfs.store.transaction.ITransactionManager;
import com.quartetfs.biz.pivot.IActivePivotManager;
import com.quartetfs.biz.pivot.IMultiVersionActivePivot;
import com.quartetfs.biz.pivot.cube.hierarchy.IHierarchy;
import com.quartetfs.biz.pivot.cube.hierarchy.IMember;
import com.quartetfs.biz.pivot.cube.hierarchy.IMultiVersionHierarchy;
import com.quartetfs.biz.pivot.definitions.IActivePivotDescription;
import com.quartetfs.biz.pivot.definitions.IActivePivotManagerDescription;
import com.quartetfs.biz.pivot.postprocessing.IPostProcessor;
import com.quartetfs.fwk.AgentException;
import com.quartetfs.fwk.types.impl.ExtendedPluginInjector;

import blasd.apex.server.config.cube.ApexCubeBuilder;
import blasd.apex.server.config.cube.IApexCubeBuilder;
import blasd.apex.server.config.cube.IApexHierarchyBuilder;
import blasd.apex.server.datastore.test.ApexTestDatastoreHelper;
import blasd.apex.server.datastore.transaction.ApexTransactionHelper;
import blasd.apex.server.query.dimension.test.DatastoreAnalysisHierarchyTestHelper;
import blasd.apex.server.query.dimension.test.IDatastoreAnalysisHierarchyTestHelper;
import blasd.apex.server.query.hierarchy.ApexHierarchyHelper;
import blasd.apex.server.query.memory.ApexActivePivotManagerBuilderHelper;
import blasd.apex.server.query.postprocessor.basic.IdentityPostProcessor;
import blasd.apex.server.test.pivot.ApexActivePivotLicenseHelper;
import blasd.apex.server.test.pivot.ApexTestActivePivotHelper;
import blasd.apex.server.test.registry.ApexTestRegistryHelper;
import cormoran.pepper.io.PepperSerializationHelper;

public class TestDatastoreAnalysisHierarchy implements IDatastoreAnalysisHierarchyTestHelper {

	@BeforeClass
	public static void loadLicense() {
		ApexActivePivotLicenseHelper.ensureLicenseWithEnv();
	}

	@BeforeClass
	public static void setUpRegistry() {
		ApexTestRegistryHelper.resetClassInRegistry(IdentityPostProcessor.class,
				ApexDatastoreAnalysisHierarchy.class,
				SpringSecurityFacade.class);
	}

	@Test
	public void testDetectNewMembers() throws AgentException {
		IStoreDescription adStoreDescription =
				DatastoreAnalysisHierarchyTestHelper.getGroupNameTypeDetailStoreDescription();
		IStoreDescription baseStoreDescription =
				ApexTestDatastoreHelper.createStoreDescription(MAIN_STORE, CCY_FX_DESC);

		IDatastore datastore = ApexTestDatastoreHelper.buildApexDatastore(baseStoreDescription, adStoreDescription);

		IActivePivotDescription description = ApexCubeBuilder.newDescription().getActivePivotDescription();

		DatastoreAnalysisHierarchyTestHelper.addCountryGroupAnalysisHierarchy(MAIN_CUBE, description);

		IActivePivotManagerDescription activePivotManagerDescription = ApexTestActivePivotHelper
				.makeActivePivotManagerDescription(MAIN_SCHEMA, MAIN_CUBE, description, baseStoreDescription);

		IActivePivotManager apManager = ApexActivePivotManagerBuilderHelper
				.makeActivePivotManager(datastore, null, activePivotManagerDescription);

		ExtendedPluginInjector.inject(IMultiVersionHierarchy.class,
				ApexDatastoreAnalysisHierarchy.PLUGIN_KEY,
				Suppliers.ofInstance(apManager));

		ApexTestActivePivotHelper.initAndStartActivePivotManager(apManager);

		// Insert some data in the store
		{
			Random r = new Random(0);
			List<Map<String, Object>> toInsert = new ArrayList<>();

			for (int i = 0; i < NB_COUNTRY; i++) {
				Map<String, Object> oneToInsert = new HashMap<>();
				oneToInsert.put(GROUP_NAME, "GROUP_COUNTRY_" + r.nextInt(NB_COUNTRY_GROUP));
				oneToInsert.put(GROUP_DETAIL, "COUNTRY_" + r.nextInt(NB_COUNTRY));
				oneToInsert.put(GROUP_DETAIL_TYPE, COUNTRY);

				toInsert.add(oneToInsert);
			}

			ITransactionManager transactionManager = ((IDatastore) apManager.getDatastore()).getTransactionManager();
			ApexTransactionHelper.add(transactionManager, GROUP_STORE_NAME, toInsert.stream());
		}

		Awaitility.await().untilAtomic(ApexDatastoreAnalysisHierarchy.REBUILD_ACTIVE, IsEqual.equalTo(0));

		IMultiVersionActivePivot cube = apManager.getActivePivots().get(MAIN_CUBE);
		IHierarchy countryGroupDim =
				ApexHierarchyHelper.findAxisHierarchy(cube.getHierarchies(), COUNTRY_GROUP_DIM, COUNTRY_GROUP_DIM);

		{
			// The dimension has been updated with the new pathes
			List<? extends IMember> members = countryGroupDim.retrieveMembers(countryGroupDim.getLevels().size() - 1);

			// This count is not precise as we generated pathes pseudo-randomly.
			// It should be slightly under NB_COUNTRY
			Assert.assertEquals(NB_COUNTRY - 3, members.size());
		}
	}

	@Test
	public void testMissingPivotIdProperty() throws AgentException {
		IStoreDescription adStoreDescription =
				DatastoreAnalysisHierarchyTestHelper.getGroupNameTypeDetailStoreDescription();
		IStoreDescription baseStoreDescription =
				ApexTestDatastoreHelper.createStoreDescription(MAIN_STORE, CCY_FX_DESC);

		IDatastore datastore = ApexTestDatastoreHelper.buildApexDatastore(adStoreDescription, baseStoreDescription);

		IActivePivotDescription description = ApexCubeBuilder.newDescription().getActivePivotDescription();

		IApexCubeBuilder builder = ApexCubeBuilder.editDescription(description);

		// Configure AnalysisDimension WITHOUT PROPERTY_PIVOT_ID
		{
			IApexHierarchyBuilder d =
					builder.addAnalysisHierarchy(COUNTRY_GROUP_DIM, ApexDatastoreAnalysisHierarchy.PLUGIN_KEY)
							.withAllMember();

			d.setProperty(ApexDatastoreAnalysisHierarchy.PROPERTY_STORE_NAME, GROUP_STORE_NAME);
			d.setProperty(ApexDatastoreAnalysisHierarchy.PROPERTY_COLUMN_NAMES,
					GROUP_NAME + IPostProcessor.SEPARATOR + GROUP_DETAIL);
			d.setProperty(ApexDatastoreAnalysisHierarchy.PROPERTY_SEARCH_TEMPLATE,
					GROUP_DETAIL_TYPE + PepperSerializationHelper.MAP_KEY_VALUE_SEPARATOR + COUNTRY);

			// PROPERTY_PIVOT_ID is missing
			// d.setProperty(ApexDatastoreAnalysisHierarchy.PROPERTY_PIVOT_ID,
			// MAIN_CUBE);
		}

		IActivePivotManager apManager = ApexActivePivotManagerBuilderHelper.makeActivePivotManager(datastore,
				null,
				ApexTestActivePivotHelper
						.makeActivePivotManagerDescription(MAIN_SCHEMA, MAIN_CUBE, description, baseStoreDescription));

		ExtendedPluginInjector.inject(IMultiVersionHierarchy.class,
				ApexDatastoreAnalysisHierarchy.PLUGIN_KEY,
				Suppliers.ofInstance(apManager));

		try {
			ApexTestActivePivotHelper.initAndStartActivePivotManager(apManager);

			// We decided to log in WARN as the analysis dimension won't be
			// rebuilt automatically
			// Assert.fail("Should detect lack of PROPERTY_PIVOT_ID");
		} catch (RuntimeException e) {
			Assert.assertNotNull(e);
		}
	}
}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.mdx;

import java.util.Arrays;

import org.junit.Assert;
import org.junit.Test;

import com.google.common.collect.ListMultimap;

public class TestApexMdxHelper {

	@Test
	public void testMakeMDXCrossJoinQueryOneHierarchy() {
		String mdx = ApexMdxHelper.makeCrossJoinMdxQuery("MainCube", Arrays.asList("CCY"));

		Assert.assertEquals("SELECT NON EMPTY [CCY].Members ON ROWS, [Measures].Members ON COLUMNS FROM [MainCube]",
				mdx);
	}

	@Test
	public void testMakeMDXCrossJoinQuery() {
		String mdx = ApexMdxHelper.makeCrossJoinMdxQuery("MainCube", Arrays.asList("CCY", "COUNTRY"));

		Assert.assertEquals(
				"SELECT NON EMPTY CrossJoin([CCY].Members,[COUNTRY].Members) ON ROWS, [Measures].Members ON COLUMNS FROM [MainCube]",
				mdx);
	}

	@Test
	public void testMakeCrossJoinMDX() {
		String mdx = ApexMdxHelper.makeCrossJoinMdxQuery("cubeName", Arrays.asList("h1", "h2 with space"));

		Assert.assertEquals(
				"SELECT NON EMPTY CrossJoin([h1].Members,[h2 with space].Members) ON ROWS, [Measures].Members ON COLUMNS FROM [cubeName]",
				mdx);
	}

	@Test
	public void testMakeCrossJoinSingleHierarchy() {
		String mdx = ApexMdxHelper.makeCrossJoinMdxQuery("cubeName", Arrays.asList("h1"));

		Assert.assertEquals("SELECT NON EMPTY [h1].Members ON ROWS, [Measures].Members ON COLUMNS FROM [cubeName]",
				mdx);
	}

	@Test
	public void testMakeCrossJoinSingleHierarchyAlreadyBracketed() {
		String mdx = ApexMdxHelper.makeCrossJoinMdxQuery("cubeName", Arrays.asList("[h1]"));

		Assert.assertEquals("SELECT NON EMPTY [h1].Members ON ROWS, [Measures].Members ON COLUMNS FROM [cubeName]",
				mdx);
	}

	@Test
	public void testExtractMeasureName() {
		String mdx = "SELECT FROM [Cube] WHERE [Measures].[contributors.COUNT]";
		ListMultimap<String, String> coordinates = ApexMdxHelper.extractCoordinates(mdx);

		// Assert.assertEquals(1, coordinates.size());
		Assert.assertEquals(Arrays.asList("[contributors.COUNT]"), coordinates.get("[Measures]"));
	}

	@Test
	public void testInjectMeasureName() {
		String mdx = "SELECT FROM [Cube] WHERE [Measures].[contributors.COUNT]";
		ListMultimap<String, String> coordinates = ApexMdxHelper.extractCoordinates(mdx);

		coordinates.get("[Measures]").set(0, "[otherMeasure]");

		String modifiedMdx = ApexMdxHelper.applyCoordinates(mdx, coordinates);

		String expectedMdx = "SELECT FROM [Cube] WHERE [Measures].[otherMeasure]";
		Assert.assertEquals(expectedMdx, modifiedMdx);
	}

	@Test
	public void testExtractCubeName() {
		String mdx = "SELECT FROM [Cube] WHERE [Measures].[contributors.COUNT]";
		Assert.assertEquals("Cube", ApexMdxHelper.extractCubeName(mdx).get());
	}

	@Test
	public void testIsSelect() {
		String mdx = "SELECT FROM [Cube] WHERE [Measures].[contributors.COUNT]";
		Assert.assertTrue(ApexMdxHelper.isSelectMdx(mdx));
	}

	@Test
	public void testIsNotSelect() {
		String mdx =
				"CREATE SESSION MEMBER [Liquidity Aggregates].[Measures].[test] AS CoalesceEmpty([Securities].[Cusip],0)";
		Assert.assertFalse(ApexMdxHelper.isSelectMdx(mdx));
	}

	@Test
	public void testChangeDate() {
		String mdx = "[dName2].[hName2].[lName].[2016-07-04] ... [dName2].[hName2].[lName].[2016-07-04]";

		ListMultimap<String, String> coordinates = ApexMdxHelper.extractCoordinates(mdx);

		ApexMdxHelper.replaceCoordinate(coordinates, "[dName2].[hName2]", "[lName].[otherDate]");

		// coordinates.get("[dName2].[hName2]").set(0, "[lName].[otherDate]");

		String modifiedMdx = ApexMdxHelper.applyCoordinates(mdx, coordinates);

		String expectedMdx = "[dName2].[hName2].[lName].[otherDate] ... [dName2].[hName2].[lName].[otherDate]";
		Assert.assertEquals(expectedMdx, modifiedMdx);
	}

	@Test
	public void testExtractDrillDown() {
		String mdx =
				"SELECT NON EMPTY Hierarchize( DrilldownMember( DrilldownLevel( [DimName].[HName].[ALL].[AllMember] ), "
						+ " [DimName].[HName].[ALL].[AllMember].[Coordinate]  ) ) ON ROWS"
						+ " FROM [Cube] WHERE [Measures].[contributors.COUNT]";
		ListMultimap<String, String> coordinates = ApexMdxHelper.extractCoordinates(mdx);

		// Assert.assertEquals(2, coordinates.keySet().size());
		Assert.assertEquals(Arrays.asList("[contributors.COUNT]"), coordinates.get("[Measures]"));
		// Assert.assertEquals(Arrays.asList("[HName].[ALL].[AllMember]", "[HName].[ALL].[AllMember].[Coordinate]"),
		// coordinates.get("[DimName]"));
		Assert.assertEquals(Arrays.asList("[ALL].[AllMember]", "[ALL].[AllMember].[Coordinate]"),
				coordinates.get("[DimName].[HName]"));
	}

	@Test
	public void testExtractDrillDownSecondLevel() {
		String mdx = "[DimName].[HName].[ALL].[AllMember].[Value1].[Value2]";
		ListMultimap<String, String> coordinates = ApexMdxHelper.extractCoordinates(mdx);

		Assert.assertEquals(1, coordinates.size());
		Assert.assertEquals(Arrays.asList("[ALL].[AllMember].[Value1].[Value2]"), coordinates.get("[DimName].[HName]"));
	}

	@Test
	public void testExtractSecondLevelWithoutPath() {
		String mdx = "[DimName].[HName].[Value2]";
		ListMultimap<String, String> coordinates = ApexMdxHelper.extractCoordinates(mdx);

		// Assert.assertEquals(1, coordinates.size());
		Assert.assertEquals(Arrays.asList("[Value2]"), coordinates.get("[DimName].[HName]"));
	}

	@Test
	public void testVariousCasesForSameHierarchy() {
		String mdx =
				"[DimName].[HName].[Value2] ... [HName].[Value2] ... [DimName].[Value2] ... [HName].[Value1].[Value2]";
		ListMultimap<String, String> coordinates = ApexMdxHelper.extractCoordinates(mdx);

		// Assert.assertEquals(1, coordinates.size());
		Assert.assertEquals(Arrays.asList("[Value2]"), coordinates.get("[DimName].[HName]"));
	}

	@Test
	public void testNormalizeMdx() {
		String mdx =
				"[HName].Members \r [DimName].[HName] \n [DimName].[HName].[Value1] \r\n\t [DimName].[HName].[ALL].[Youp2].[Value3]   "
						+ " [DimName].[HName].[Value1]";
		String normalized = ApexMdxHelper.normalizeMdx(mdx);

		// Only 1 whitespace
		// One path appears twice
		Assert.assertEquals(
				"[HName].Members [DimName].[HName] [DimName].[HName].%0% [DimName].[HName].%1% [DimName].[HName].%0%",
				normalized);
	}
}

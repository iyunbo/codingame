/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.manager;

import java.util.Arrays;
import java.util.Collections;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;

import com.google.common.collect.ImmutableMap;
import com.qfs.desc.IDatastoreSchemaDescription;
import com.qfs.desc.IReferenceDescription;
import com.qfs.desc.IStoreDescription;
import com.qfs.security.impl.SpringSecurityFacade;
import com.quartetfs.biz.pivot.IActivePivotManager;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevel;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevelInfo;
import com.quartetfs.biz.pivot.definitions.IActivePivotDescription;
import com.quartetfs.biz.pivot.definitions.IActivePivotManagerDescription;
import com.quartetfs.fwk.AgentException;

import blasd.apex.server.config.description.ApexDescriptionHelper;
import blasd.apex.server.datastore.test.ApexTestDatastoreHelper;
import blasd.apex.server.query.ApexDrillthroughHelper;
import blasd.apex.server.query.hierarchy.ApexHierarchyHelper;
import blasd.apex.server.query.location.ApexLocationHelper;
import blasd.apex.server.test.IApexTestConstants;
import blasd.apex.server.test.pivot.ApexActivePivotDescriptionHelper;
import blasd.apex.server.test.pivot.ApexTestActivePivotHelper;
import blasd.apex.server.test.registry.ApexTestRegistryHelper;

public class TestApexDrillthroughHelper implements IApexTestConstants {

	@Test
	public void testFindLevelForColumn() throws AgentException {
		// For ActivePivotBase
		ApexTestRegistryHelper.resetClassInRegistry(SpringSecurityFacade.class);

		IActivePivotManager apManager = ApexTestActivePivotHelper.buildCubeOverDatastore(MAIN_SCHEMA,
				MAIN_CUBE,
				MAIN_STORE,
				COUNTRY_CCY_DELTA_DESC,
				Arrays.asList(CCY, COUNTRY));
		ApexTestActivePivotHelper.initAndStartActivePivotManager(apManager);

		ILevel firstLevel = ApexDrillthroughHelper.findLevelForDatastoreColumn(CCY, MAIN_STORE, apManager, MAIN_CUBE);

		Assert.assertNotNull(firstLevel);

		ILevel secondLevel =
				ApexDrillthroughHelper.findLevelForDatastoreColumn(COUNTRY, MAIN_STORE, apManager, MAIN_CUBE);

		Assert.assertNotNull(secondLevel);
	}

	@Test
	public void testFindFieldForLevel() throws AgentException {
		// For ActivePivotBase
		ApexTestRegistryHelper.resetClassInRegistry(SpringSecurityFacade.class);

		IActivePivotManager apManager = ApexTestActivePivotHelper.buildCubeOverDatastore(MAIN_SCHEMA,
				MAIN_CUBE,
				MAIN_STORE,
				COUNTRY_CCY_DELTA_DESC,
				Arrays.asList(CCY, COUNTRY));
		ApexTestActivePivotHelper.initAndStartActivePivotManager(apManager);

		String firstLevel = ApexDrillthroughHelper.findFieldPathForLevel(CCY, null, MAIN_CUBE, apManager);

		Assert.assertEquals(CCY, firstLevel);
	}

	@Test
	public void testFindReferencedFieldForLevel() throws AgentException {
		// For ActivePivotBase
		ApexTestRegistryHelper.resetClassInRegistry(SpringSecurityFacade.class);

		IActivePivotManager apManager;
		IReferenceDescription reference;
		{
			IStoreDescription mainStoreDescription =
					ApexTestDatastoreHelper.createStoreDescription(MAIN_STORE, CCY_FX_DESC);
			IStoreDescription enrichStoreDescription =
					ApexTestDatastoreHelper.createStoreDescription(ENRICHMENT_STORE, COUNTRY_CCY_DESC, CCY);

			reference = ApexDescriptionHelper.makeReference(MAIN_STORE, ENRICHMENT_STORE, CCY, CCY);
			IDatastoreSchemaDescription description = ApexTestDatastoreHelper.prepareDescription(
					Arrays.asList(mainStoreDescription, enrichStoreDescription),
					Arrays.asList(reference));

			IActivePivotDescription cubeDescription =
					ApexTestDatastoreHelper.createCubeDescription(description, MAIN_STORE);

			IActivePivotManagerDescription apManagerDescription =
					ApexActivePivotDescriptionHelper.makeManagerDescription(MAIN_SCHEMA,
							description,
							MAIN_STORE,
							Collections.singletonList(ApexActivePivotDescriptionHelper
									.makeActivePivotDescription(MAIN_CUBE, cubeDescription)));

			apManager = ApexTestActivePivotHelper.buildCubeOverDatastore(description, apManagerDescription);
		}

		ApexTestActivePivotHelper.initAndStartActivePivotManager(apManager);

		String firstLevel = ApexDrillthroughHelper.findFieldPathForLevel(CCY, null, MAIN_CUBE, apManager);
		Assert.assertEquals(CCY, firstLevel);

		String referencedLevel = ApexDrillthroughHelper.findFieldPathForLevel(ApexTestDatastoreHelper
				.makeFieldName(reference.getName(), COUNTRY), null, MAIN_CUBE, apManager);
		Assert.assertEquals("MainStore(CCY)->EnrichmentStore(CCY)/COUNTRY", referencedLevel);
	}

	@Test
	public void testConvertStringToObject() throws AgentException {
		// For ActivePivotBase
		ApexTestRegistryHelper.resetClassInRegistry(SpringSecurityFacade.class);

		IActivePivotManager apManager =
				ApexTestActivePivotHelper.buildCubeOverDatastore(MAIN_SCHEMA, MAIN_CUBE, MAIN_STORE, CCY_DAYS_DESC);
		ApexTestActivePivotHelper.initAndStartActivePivotManager(apManager);

		ILevelInfo daysLevel =
				ApexHierarchyHelper.findLevel(apManager.getActivePivots().get(MAIN_CUBE).getHierarchies(), DAYS)
						.getLevelInfo();

		// Some valid String
		{
			Map<ILevelInfo, Object> firstLevel =
					ApexLocationHelper.convertToObject(apManager, MAIN_CUBE, ImmutableMap.of(DAYS, "1"));

			Assert.assertEquals(1, firstLevel.get(daysLevel));
		}

		// Some invalid String
		{
			Map<ILevelInfo, Object> firstLevel =
					ApexLocationHelper.convertToObject(apManager, MAIN_CUBE, ImmutableMap.of(DAYS, "1"));

			Assert.assertEquals(1, firstLevel.get(daysLevel));
		}

		// A Collection String
		{
			Map<ILevelInfo, Object> firstLevel =
					ApexLocationHelper.convertToObject(apManager, MAIN_CUBE, ImmutableMap.of(DAYS, Arrays.asList("1")));

			Assert.assertEquals(Collections.singletonList(1), firstLevel.get(daysLevel));
		}
	}
}

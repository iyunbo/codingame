/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.location;

import java.util.Map;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.google.common.collect.ImmutableMap;
import com.qfs.security.impl.SpringSecurityFacade;
import com.quartetfs.biz.pivot.ILocation;
import com.quartetfs.biz.pivot.IMultiVersionActivePivot;
import com.quartetfs.biz.pivot.definitions.IActivePivotDescription;
import com.quartetfs.biz.pivot.impl.Location;

import blasd.apex.server.config.cube.ApexCubeBuilder;
import blasd.apex.server.test.IApexTestConstants;
import blasd.apex.server.test.pivot.ApexTestActivePivotHelper;
import blasd.apex.server.test.registry.ApexTestRegistryHelper;

public class TestApexShortLocationFormatter implements IApexTestConstants {

	@Before
	public void before() {
		// Needed for ActivePivotBase
		ApexTestRegistryHelper.resetClassInRegistry(SpringSecurityFacade.class);
	}

	protected void checkShortLocation(IMultiVersionActivePivot pivot,
			String inputLocation,
			String expectedShortLocation) {
		ILocation asLocation;
		if (inputLocation == null) {
			asLocation = null;
		} else {
			asLocation = new Location(inputLocation);
		}

		Assert.assertEquals(expectedShortLocation, new ApexShortLocationFormatter().format(asLocation));

		if (pivot != null) {
			ILocation locationFromShortString =
					ApexShortLocationFormatter.locationFromString(pivot, expectedShortLocation);
			Assert.assertEquals(asLocation, locationFromShortString);
		}
	}

	@Before
	@After
	public void clean() {
		ApexShortLocationFormatter.HIERARCHY_CARDINALITY_TO_NAMES.clear();
		ApexShortLocationFormatter.NB_DIMENSION_WITH_SEVERAL_PIVOT.clear();
	}

	@Test
	public void testNull() {
		checkShortLocation(null, null, "null");
	}

	@Test
	public void testAllMemberLocation() {
		checkShortLocation(null, "AllMember|AllMember", "");
	}

	@Test
	public void testEURFranceLocation() {
		ApexShortLocationFormatter.clearRegistered();
		// No pivot has been registered: each hierarchy is described by its
		// index
		checkShortLocation(null, "AllMember\\EUR|AllMember\\France", "0:AllMember\\EUR|1:AllMember\\France");
	}

	protected IMultiVersionActivePivot makeNewPivot() {
		return makeNewPivot(MAIN_CUBE);
	}

	protected IMultiVersionActivePivot makeNewPivot(String cubeName) {
		return ApexTestActivePivotHelper.makeCcyCountryAsOfDateActivePivotManager(cubeName)
				.getActivePivots()
				.get(cubeName);
	}

	@Test
	public void testEURFranceLocationWithPivot() {
		IMultiVersionActivePivot pivot = makeNewPivot();
		ApexShortLocationFormatter.registerActivePivot(pivot);

		// Test deveral expressed IHierarchies
		checkShortLocation(pivot,
				"AllMember\\EUR|AllMember\\France|[*]",
				CCY + ":AllMember\\EUR|" + COUNTRY_HIE + ":AllMember\\France|AsOfDate:[*]");
	}

	@Test
	public void testFranceParisLocationWithPivot() {
		IMultiVersionActivePivot pivot = makeNewPivot();
		ApexShortLocationFormatter.registerActivePivot(pivot);

		// Test a IHierarchy with several levels
		checkShortLocation(pivot,
				"AllMember|AllMember\\France\\Paris|[*]",
				COUNTRY_HIE + ":AllMember\\France\\Paris|AsOfDate:[*]");
	}

	@Test
	public void testInvalidLocation() {
		IMultiVersionActivePivot pivot = makeNewPivot();
		ApexShortLocationFormatter.registerActivePivot(pivot);

		// Test several expressed IHierarchies
		try {
			ApexShortLocationFormatter.locationFromString(pivot, "NotALocationNiceString");
			Assert.fail();
		} catch (RuntimeException e) {
			// Exceptions like ArrayIndexOutOfBounds are not very helpful
			Assert.assertTrue(e instanceof IllegalArgumentException);
		}
	}

	// Several cubes with same number of hierarchies, but hierarchies has same
	// name
	@Test
	public void testMultiPivotSameDimensionnames() {
		IMultiVersionActivePivot pivot1 = makeNewPivot(MAIN_CUBE + 1);
		ApexShortLocationFormatter.registerActivePivot(pivot1);
		IMultiVersionActivePivot pivot2 = makeNewPivot(MAIN_CUBE + 2);
		ApexShortLocationFormatter.registerActivePivot(pivot2);

		// It works with both pivot
		checkShortLocation(pivot1,
				"AllMember|AllMember\\France\\Paris|[*]",
				COUNTRY_HIE + ":AllMember\\France\\Paris|AsOfDate:[*]");
		checkShortLocation(pivot2,
				"AllMember|AllMember\\France\\Paris|[*]",
				COUNTRY_HIE + ":AllMember\\France\\Paris|AsOfDate:[*]");
	}

	@Test
	public void testMultiPivotDifferentDimensionNames() {
		// First cube has asofDate named asOfDate1
		IActivePivotDescription cubeDesc1 = ApexCubeBuilder.cloneActivePivotDescripion(CCY_COUNTRY_CITY_DELTA_SUM)
				.addHierarchyAndLevels(ASOFDATE + 1)
				.setSlicing()
				.getCubeBuilder()
				.getActivePivotDescription();
		IMultiVersionActivePivot pivot1 = ApexTestActivePivotHelper.makeActivePivot(MAIN_CUBE + 1, cubeDesc1);

		// First cube has asofDate named asOfDate2
		IActivePivotDescription cubeDesc2 = ApexCubeBuilder.cloneActivePivotDescripion(CCY_COUNTRY_CITY_DELTA_SUM)
				.addHierarchyAndLevels(ASOFDATE + 2)
				.setSlicing()
				.getCubeBuilder()
				.getActivePivotDescription();
		IMultiVersionActivePivot pivot2 = ApexTestActivePivotHelper.makeActivePivot(MAIN_CUBE + 2, cubeDesc2);

		ApexShortLocationFormatter.clearRegistered();
		ApexShortLocationFormatter.registerActivePivot(pivot1);
		ApexShortLocationFormatter.registerActivePivot(pivot2);

		// It works with both pivot
		checkShortLocation(pivot1, "AllMember|AllMember\\France\\Paris|[*]", "1:AllMember\\France\\Paris|2:[*]");
		checkShortLocation(pivot2, "AllMember|AllMember\\France\\Paris|[*]", "1:AllMember\\France\\Paris|2:[*]");
	}

	// TODO
	@Ignore
	@Test
	public void testParseLocationFromQueryPlan() {
		// The format is: hierarchyName@dimensionName:levelName=Coordinate

		String locationAsString = "As Of Date MRE@MRE Post Processing:asOfDate=2015-09-30,"
				+ "Countervaluated Currency@MRE Post Processing:Countervaluated Currency=EUR,"
				+ "TECH_indicatorL2RCode@TECH:indicatorL2RCode=[1, 338, 61, 60],"
				+ "Pricer View - Currency Origin@Pricing:currencyId=[*],"
				+ "CDSSplitMode@Pricing:CDSSplitMode=[true, false],"
				+ "Fx RefSet Eligible@Pricing:refset=[*],"
				+ "Global Currency Class@Pricing:CURRENCY_CLASS=[*],"
				+ "Deal - Counterpart@Deal:stock_COUNTERPARTYMNEMO=[*],"
				+ "Deal - Global Maturity@Deal:globalDealMaturity=[*]";

		throw new RuntimeException("TODO " + locationAsString);
	}

	@Test
	public void testHierarchyToIndexToString() {
		Map<String, Integer> asMap = ImmutableMap.of(ASOFDATE, 0, COUNTRY_HIE, 1);

		String asString = ApexShortLocationFormatter.locationFromDepth(asMap);
		Assert.assertEquals("AsOfDate:[*]|COUNTRY_Hie:[*]\\[*]", asString);
	}

	@Test
	public void testHierarchyToIndexToStringIsSorted() {
		// Give a Map where hierarchy names are reversed
		Map<String, Integer> asMap = ImmutableMap.of(COUNTRY_HIE, 1, ASOFDATE, 0);

		// toString is sorted by hierarchy
		String asString = ApexShortLocationFormatter.locationFromDepth(asMap);
		Assert.assertEquals("AsOfDate:[*]|COUNTRY_Hie:[*]\\[*]", asString);
	}
}

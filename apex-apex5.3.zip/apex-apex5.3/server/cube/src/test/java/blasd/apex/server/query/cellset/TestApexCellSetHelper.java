/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.cellset;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import java.util.TreeMap;

import org.junit.Assert;
import org.junit.Test;

import com.google.common.collect.ImmutableMap;
import com.quartetfs.biz.pivot.cube.hierarchy.measures.IMeasureHierarchy;

import blasd.apex.server.test.IApexTestConstants;

public class TestApexCellSetHelper implements IApexTestConstants {

	public static Map<String, List<String>> ccyEur = ImmutableMap.of(CCY, Arrays.asList(EUR));

	@Test
	public void testUpdateCellSet() {
		List<NavigableMap<String, List<?>>> cellSet = new ArrayList<>();

		// New Cell
		String m1 = "measureName1";
		String v1 = "measureValue1";
		{
			ApexCellSetHelper.setValue(cellSet,
					new TreeMap<>(ImmutableMap.of(CCY,
							Arrays.asList(EUR),
							IMeasureHierarchy.MEASURE_HIERARCHY,
							Arrays.asList(Arrays.asList(m1), Arrays.asList(v1)))));

			Assert.assertEquals(v1, ApexCellSetHelper.extractValues(cellSet, m1, ccyEur));
		}

		// New Measure to existing cell
		String m2 = "measureName2";
		String v2 = "measureValue2";
		{
			ApexCellSetHelper.setValue(cellSet,
					new TreeMap<>(ImmutableMap.of(CCY,
							Arrays.asList(EUR),
							IMeasureHierarchy.MEASURE_HIERARCHY,
							Arrays.asList(Arrays.asList(m2), Arrays.asList(v2)))));

			Assert.assertEquals(v2, ApexCellSetHelper.extractValues(cellSet, m2, ccyEur));
		}

		// Update measure value to existing cell
		String v3 = "measureValue3";
		{
			ApexCellSetHelper.setValue(cellSet,
					new TreeMap<>(ImmutableMap.of(CCY,
							Arrays.asList(EUR),
							IMeasureHierarchy.MEASURE_HIERARCHY,
							Arrays.asList(Arrays.asList(m1), Arrays.asList(v3)))));

			Assert.assertEquals(v3, ApexCellSetHelper.extractValues(cellSet, m1, ccyEur));
		}
	}

	// The same coordinate is associated to 2 measures in 2 different cells (typically when extracted from a CellSetDTO)
	@Test
	public void testExtractValuesOnSplittedMeasures() {
		List<NavigableMap<String, List<?>>> cellSet = new ArrayList<>();

		// The same
		String m1 = "measureName1";
		String v1 = "measureValue1";
		cellSet.add(new TreeMap<>(ImmutableMap.of(IMeasureHierarchy.MEASURE_HIERARCHY,
				Arrays.asList(Arrays.asList(m1), Arrays.asList(v1)))));

		String m2 = "measureName2";
		String v2 = "measureValue2";
		cellSet.add(new TreeMap<>(ImmutableMap.of(IMeasureHierarchy.MEASURE_HIERARCHY,
				Arrays.asList(Arrays.asList(m2), Arrays.asList(v2)))));

		Assert.assertEquals(v1, ApexCellSetHelper.extractValues(cellSet, m1, ImmutableMap.of()));
		Assert.assertEquals(v2, ApexCellSetHelper.extractValues(cellSet, m2, ImmutableMap.of()));
	}

	@Test
	public void testUpdateWithLessCoordinates() {
		List<NavigableMap<String, List<?>>> cellSet = new ArrayList<>();

		// New Cell for France-EUR
		String m1 = "measureName1";
		String v1 = "measureValue1";
		Map<String, List<String>> ccyEurCountryFrance =
				ImmutableMap.of(CCY, Arrays.asList(EUR), COUNTRY, Arrays.asList(FRANCE));
		{
			ApexCellSetHelper.setValue(cellSet,
					new TreeMap<>(ImmutableMap.of(CCY,
							Arrays.asList(EUR),
							COUNTRY,
							Arrays.asList(FRANCE),
							IMeasureHierarchy.MEASURE_HIERARCHY,
							Arrays.asList(Arrays.asList(m1), Arrays.asList(v1)))));

			Assert.assertEquals(v1, ApexCellSetHelper.extractValues(cellSet, m1, ccyEurCountryFrance));
		}

		// New cell EUR
		String v2 = "measureValue2";
		{
			ApexCellSetHelper.setValue(cellSet,
					new TreeMap<>(ImmutableMap.of(CCY,
							Arrays.asList(EUR),
							IMeasureHierarchy.MEASURE_HIERARCHY,
							Arrays.asList(Arrays.asList(m1), Arrays.asList(v2)))));

			Assert.assertEquals(v1, ApexCellSetHelper.extractValues(cellSet, m1, ccyEurCountryFrance));
			Assert.assertEquals(v2, ApexCellSetHelper.extractValues(cellSet, m1, ccyEur));
		}

		// New cell No coordinate but Measure
		String v3 = "measureValue3";
		{
			ApexCellSetHelper.setValue(cellSet,
					new TreeMap<>(ImmutableMap.of(IMeasureHierarchy.MEASURE_HIERARCHY,
							Arrays.asList(Arrays.asList(m1), Arrays.asList(v3)))));

			Assert.assertEquals(v1, ApexCellSetHelper.extractValues(cellSet, m1, ccyEurCountryFrance));
			Assert.assertEquals(v2, ApexCellSetHelper.extractValues(cellSet, m1, ccyEur));
			Assert.assertEquals(v3,
					ApexCellSetHelper.extractValues(cellSet,
							m1,
							ImmutableMap.of(IMeasureHierarchy.MEASURE_HIERARCHY, Arrays.asList())));
		}
	}

	@Test
	public void testMissingMeasures() {
		List<NavigableMap<String, List<?>>> cellSet = new ArrayList<>();

		ImmutableMap<String, List<?>> coordinate = ImmutableMap.of("hName", Arrays.asList("value"));
		cellSet.add(new TreeMap<>(coordinate));

		// This is a bad map as there is no measure. For resilience purposes, we return null
		Assert.assertNull(ApexCellSetHelper.extractValue(coordinate, "someMeasure"));
		Assert.assertNull(ApexCellSetHelper.extractValues(cellSet, "someMeasure", coordinate));
	}

	@Test
	public void testMissingMeasuresMultiCoordinated() {
		List<NavigableMap<String, List<?>>> cellSet = new ArrayList<>();

		ImmutableMap<String, List<?>> coordinate1 = ImmutableMap.of("hName", Arrays.asList("value1"));
		cellSet.add(new TreeMap<>(coordinate1));
		ImmutableMap<String, List<?>> coordinate2 = ImmutableMap.<String, List<?>>builder()
				.putAll(coordinate1)
				.put(IMeasureHierarchy.MEASURE_HIERARCHY,
						Arrays.asList(Arrays.asList("measureName"), Arrays.asList("measureValue")))
				.build();
		cellSet.add(new TreeMap<>(coordinate2));

		// This is a bad map as there is no measure. For resilience purposes, we return null
		Assert.assertNull(ApexCellSetHelper.extractValue(coordinate1, "someMeasure"));
		Assert.assertNull(ApexCellSetHelper.extractValues(cellSet, "someMeasure", coordinate1));
	}
}

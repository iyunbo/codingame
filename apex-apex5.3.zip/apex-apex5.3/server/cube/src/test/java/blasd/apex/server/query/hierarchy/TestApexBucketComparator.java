/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.hierarchy;

import org.junit.Assert;
import org.junit.Test;

public class TestApexBucketComparator {
	ApexBucketComparator comparator = new ApexBucketComparator();

	private void compare(int expected, String left, String right) {
		Assert.assertEquals(expected, comparator.compare(left, right));
		Assert.assertEquals(-1 * expected, comparator.compare(right, left));

		if (expected == 0) {
			Assert.assertEquals(left, right);
			Assert.assertEquals(right, left);
		} else {
			Assert.assertNotEquals(left, right);
			Assert.assertNotEquals(right, left);
		}
	}

	@Test
	public void testCompare_1D3M() {
		compare(-89, "1D", "3M");
	}

	@Test
	public void testCompare_3D1M() {
		compare(-27, "3D", "1M");
	}

	@Test
	public void testCompare_60D1M() {
		compare(30, "60D", "1M");
	}

	@Test
	public void testCompare_30D1M_EdgeCase() {
		compare(-2, "30D", "1M");
		comparator.equivalent("30D", "1M");
	}

	@Test
	public void testCompare_12D12d_EdgeCase() {
		// 'D' - 'd' == -32
		compare(-32, "12D", "12d");
		comparator.equivalent("12D", "12d");
	}
}

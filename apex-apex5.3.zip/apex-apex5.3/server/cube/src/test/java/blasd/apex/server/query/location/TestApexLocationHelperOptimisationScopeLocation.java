/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.location;

import java.util.Collections;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.qfs.dic.IWritableDictionary;
import com.quartetfs.biz.pivot.IActivePivotVersion;
import com.quartetfs.biz.pivot.ILocation;
import com.quartetfs.biz.pivot.ILocationFormatter;
import com.quartetfs.biz.pivot.IMultiVersionActivePivot;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevelInfo;
import com.quartetfs.biz.pivot.cube.provider.IHierarchicalMapping;
import com.quartetfs.biz.pivot.impl.ImmutableSubPointLocation;
import com.quartetfs.biz.pivot.impl.LocationFormatter;
import com.quartetfs.biz.pivot.impl.ModifiedLocation;
import com.quartetfs.biz.pivot.impl.SubLocation;
import com.quartetfs.biz.pivot.query.aggregates.IScopeLocation;
import com.quartetfs.biz.pivot.query.aggregates.impl.ScopeLocation;

import blasd.apex.server.location.ApexLocationBuilder;
import blasd.apex.server.query.hierarchy.ApexHierarchyHelper;
import blasd.apex.server.test.IApexTestConstants;

public class TestApexLocationHelperOptimisationScopeLocation implements IApexTestConstants {

	// Prevent race-condition in LocationUtil.locationFormatter
	public static final ILocationFormatter DEFAULT_FORMATTER = new LocationFormatter();

	public static IMultiVersionActivePivot simpleCcyCountryPivot() {
		return TestApexLocationHelper.simpleCcyCountryPivot();
	}

	@BeforeClass
	public static void beforeClass() {
		TestApexLocationHelper.beforeClass();
	}

	@Test
	public void testSetCoordinateDrillDownScopeLocation() throws Exception {
		IActivePivotVersion pivot = simpleCcyCountryPivot().getHead();

		ILocation l = ApexLocationBuilder.on(pivot).build();

		IHierarchicalMapping hm = pivot.getAggregateProvider().getHierarchicalMapping();
		IScopeLocation scopeLocation = new ScopeLocation(l, hm);

		ILevelInfo countryLevel = ApexHierarchyHelper.findLevel(pivot.getHierarchies(), COUNTRY_LEV).getLevelInfo();

		ILocation modified =
				ApexLocationHelper.setCoordinates(scopeLocation, Collections.singletonMap(countryLevel, USA), true);
		Assert.assertTrue(modified instanceof ModifiedLocation);
		Assert.assertEquals("AllMember|AllMember\\USA|[*]", DEFAULT_FORMATTER.format(modified));
	}

	// We set Country on Country=* and reduceIfDeeper=false
	@Test
	public void testSetCoordinateSetBottomCoordinateNoReduceScopeLocation() throws Exception {
		IActivePivotVersion pivot = simpleCcyCountryPivot().getHead();

		ILevelInfo countryLevel = ApexHierarchyHelper.findLevel(pivot.getHierarchies(), COUNTRY).getLevelInfo();
		ILevelInfo asOfLevel = ApexHierarchyHelper.findLevel(pivot.getHierarchies(), ASOFDATE).getLevelInfo();

		IHierarchicalMapping hm = pivot.getAggregateProvider().getHierarchicalMapping();

		// We need the coordinates to exist to have a SubLocation produced
		((IWritableDictionary<Object>) ApexLocationHelper.getDictionary(hm, countryLevel)).map(FRANCE);
		((IWritableDictionary<Object>) ApexLocationHelper.getDictionary(hm, asOfLevel)).map(TODAY);
		ILocation l = ApexLocationBuilder.on(pivot).filter(ASOFDATE, TODAY).wildcard(COUNTRY).build();

		IScopeLocation scopeLocation = new ScopeLocation(l, hm);

		ILocation modified = ApexLocationHelper.setCoordinates(scopeLocation, countryLevel, FRANCE, false);
		// In AP5.5, IScopeLocaiton can produce IPointLocation only
		Assert.assertTrue(modified instanceof ImmutableSubPointLocation);
		Assert.assertEquals("AllMember|AllMember\\France|" + TODAY, DEFAULT_FORMATTER.format(modified));
	}

	// We set City on Country=*/City=* and reduceIfDeeper=true
	@Test
	public void testSetCoordinateSetBottomCoordinateReduceScopeLocation() throws Exception {
		IActivePivotVersion pivot = simpleCcyCountryPivot().getHead();

		ILocation l = ApexLocationBuilder.on(pivot).wildcard(CITY).build();

		IHierarchicalMapping hm = pivot.getAggregateProvider().getHierarchicalMapping();
		IScopeLocation scopeLocation = new ScopeLocation(l, hm);

		ILevelInfo cityLevel = ApexHierarchyHelper.findLevel(pivot.getHierarchies(), CITY_LEV).getLevelInfo();

		ILocation modified = ApexLocationHelper.setCoordinates(scopeLocation, cityLevel, PARIS, true);
		// In AP5.5, IScopeLocation can produce IPointLocation only
		Assert.assertFalse(modified instanceof SubLocation);
		Assert.assertEquals("AllMember|AllMember\\[*]\\Paris|[*]", DEFAULT_FORMATTER.format(modified));
	}

	// We set USA on Country=*/City=* and reduceIfDeeper=true
	@Test
	public void testSetCoordinateSetUpCoordinateReduceScopeLocation() throws Exception {
		IActivePivotVersion pivot = simpleCcyCountryPivot().getHead();

		ILocation l = ApexLocationBuilder.on(pivot).wildcard(CITY).build();

		IHierarchicalMapping hm = pivot.getAggregateProvider().getHierarchicalMapping();
		IScopeLocation scopeLocation = new ScopeLocation(l, hm);

		ILevelInfo countryLevel = ApexHierarchyHelper.findLevel(pivot.getHierarchies(), COUNTRY_LEV).getLevelInfo();

		ILocation modified = ApexLocationHelper.setCoordinates(scopeLocation, countryLevel, USA, true);
		Assert.assertTrue(modified instanceof ModifiedLocation);
		Assert.assertEquals("AllMember|AllMember\\USA|[*]", DEFAULT_FORMATTER.format(modified));
	}

	// We set USA on Country=*/City=* and reduceIfDeeper=false
	@Test
	public void testSetCoordinateSetUpCoordinateNoReduceScopeLocation() throws Exception {
		IActivePivotVersion pivot = simpleCcyCountryPivot().getHead();

		ILocation l = ApexLocationBuilder.on(pivot).wildcard(CITY).build();

		IHierarchicalMapping hm = pivot.getAggregateProvider().getHierarchicalMapping();
		IScopeLocation scopeLocation = new ScopeLocation(l, hm);

		ILevelInfo countryLevel = ApexHierarchyHelper.findLevel(pivot.getHierarchies(), COUNTRY_LEV).getLevelInfo();

		ILocation modified = ApexLocationHelper.setCoordinates(scopeLocation, countryLevel, USA, false);
		// In AP5.5, IScopeLocaiton can produce IPointLocation only
		Assert.assertFalse(modified instanceof SubLocation);
		Assert.assertEquals("AllMember|AllMember\\USA\\[*]|[*]", DEFAULT_FORMATTER.format(modified));
	}

	// We set USA on Country=*/City=* and reduceIfDeeper=false
	@Test
	public void testSetCoordinateScopeLocationNotWildcarded() throws Exception {
		IActivePivotVersion pivot = simpleCcyCountryPivot().getHead();

		ILocation l = ApexLocationBuilder.on(pivot).wildcard(CITY).build();

		IHierarchicalMapping hm = pivot.getAggregateProvider().getHierarchicalMapping();
		IScopeLocation scopeLocation = new ScopeLocation(l, hm);

		ILevelInfo asOfDateLevel = ApexHierarchyHelper.findLevel(pivot.getHierarchies(), ASOFDATE).getLevelInfo();

		ILocation modified = ApexLocationHelper.setCoordinates(scopeLocation, asOfDateLevel, TODAY, false);

		// In AP5.5, IScopeLocaiton can produce IPointLocation only
		Assert.assertFalse(modified instanceof SubLocation);
		Assert.assertEquals("AllMember|AllMember\\[*]\\[*]|" + TODAY, DEFAULT_FORMATTER.format(modified));
	}

	// We build a scope over a location without wildcards
	@Test
	public void testSetCoordinatePointScopeLocation() throws Exception {
		IActivePivotVersion pivot = simpleCcyCountryPivot().getHead();

		ILocation l = ApexLocationBuilder.on(pivot).filter(ASOFDATE, TODAY).build();
		Assert.assertFalse(l.isRange());

		IHierarchicalMapping hm = pivot.getAggregateProvider().getHierarchicalMapping();
		IScopeLocation scopeLocation = new ScopeLocation(l, hm);

		ILevelInfo asOfDateLevel = ApexHierarchyHelper.findLevel(pivot.getHierarchies(), ASOFDATE).getLevelInfo();

		ILocation modified = ApexLocationHelper.setCoordinates(scopeLocation, asOfDateLevel, TODAY, false);
		Assert.assertTrue(modified instanceof ScopeLocation);
		Assert.assertEquals("AllMember|AllMember|" + TODAY, DEFAULT_FORMATTER.format(modified));
	}
}

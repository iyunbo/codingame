/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.dimension;

import java.util.Collection;
import java.util.Collections;

import com.quartetfs.biz.pivot.cube.hierarchy.IAnalysisHierarchy;
import com.quartetfs.biz.pivot.cube.hierarchy.IAnalysisHierarchyInfo;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevel;
import com.quartetfs.biz.pivot.cube.hierarchy.IMultiVersionHierarchy;
import com.quartetfs.biz.pivot.cube.hierarchy.axis.impl.AAnalysisHierarchy;
import com.quartetfs.fwk.QuartetExtendedPluginValue;

/**
 * A trivial {@link IAnalysisHierarchy} for test purposes
 * 
 * @author Benoit Lacelle
 *
 */
@QuartetExtendedPluginValue(intf = IMultiVersionHierarchy.class, key = AnalysisTestHierarchy.PLUGIN_KEY)
public class AnalysisTestHierarchy extends AAnalysisHierarchy {
	private static final long serialVersionUID = 6536951212836671570L;

	public static final String PLUGIN_KEY = "TEST_ANALYSIS";

	public AnalysisTestHierarchy(IAnalysisHierarchyInfo info) {
		super(info);
	}

	@Override
	public Collection<Object[]> buildDiscriminatorPaths() {
		return Collections.singletonList(new Object[] { ILevel.ALLMEMBER, ILevel.ALLMEMBER });
	}

	@Override
	public int getLevelsCount() {
		return 2;
	}

	@Override
	public String getType() {
		return PLUGIN_KEY;
	}

}

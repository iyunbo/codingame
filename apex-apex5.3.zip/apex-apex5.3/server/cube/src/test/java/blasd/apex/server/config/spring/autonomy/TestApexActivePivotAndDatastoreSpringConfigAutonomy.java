/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.spring.autonomy;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.core.userdetails.UserDetailsService;

import com.codahale.metrics.MetricRegistry;
import com.qfs.desc.IDatastoreSchemaDescription;
import com.qfs.pivot.content.IActivePivotContentService;
import com.qfs.server.cfg.IDatastoreConfig;
import com.qfs.store.IDatastore;
import com.quartetfs.biz.pivot.definitions.IActivePivotManagerDescription;

import blasd.apex.server.config.spring.ApexActivePivotSpringConfig;
import blasd.apex.server.config.spring.ApexDatastoreSpringConfig;
import blasd.apex.server.config.spring.ApexFakeActivePivotConfig;
import blasd.apex.server.registry.ApexRegistrySpringConfig;
import blasd.apex.server.test.IApexTestConstants;
import blasd.apex.server.test.pivot.ApexActivePivotLicenseHelper;

/**
 * 
 * @author Benoit Lacelle
 * 
 */
public class TestApexActivePivotAndDatastoreSpringConfigAutonomy implements IApexTestConstants {
	@BeforeClass
	public static void ensureLicense() {
		ApexActivePivotLicenseHelper.ensureLicenseWithEnv();
	}

	@Configuration
	public static class ApexActivePivotAndDatastoreSpringConfigComplement {

		@Bean
		public IActivePivotContentService activePivotContentService() {
			return TestApexActivePivotConfigAutonomy.mockAPContentService();
		}

		@Bean
		public IActivePivotManagerDescription activePivotManagerDescription() {
			IActivePivotManagerDescription desc = Mockito.mock(IActivePivotManagerDescription.class);

			Mockito.when(desc.getName()).thenReturn(MAIN_SCHEMA);

			return desc;
		}

		@Bean
		public UserDetailsService userDetailsService() {
			return Mockito.mock(UserDetailsService.class);
		}

		@Bean
		public IDatastoreSchemaDescription datastoreSchemaDescription() {
			return Mockito.mock(IDatastoreSchemaDescription.class);
		}

		@Bean
		public MetricRegistry metricRegistry() {
			return new MetricRegistry();
		}
	}

	@Test
	public void testApexActivePivotAndDatastoreConfig() {
		try (AnnotationConfigApplicationContext context =
				new AnnotationConfigApplicationContext(ApexRegistrySpringConfig.class,
						ApexActivePivotAndDatastoreSpringConfigComplement.class,
						ApexActivePivotSpringConfig.class,
						ApexDatastoreSpringConfig.class,
						ApexFakeActivePivotConfig.class)) {
			Assert.assertNotNull(context.getBean(IDatastore.class));

			// ApexFakeActivePivotConfig may require the datastore bean to be specifically named
			IDatastoreConfig datastoreConfig = context.getBean(IDatastoreConfig.class);
			Assert.assertNotNull(datastoreConfig.datastore());
		}
	}
}

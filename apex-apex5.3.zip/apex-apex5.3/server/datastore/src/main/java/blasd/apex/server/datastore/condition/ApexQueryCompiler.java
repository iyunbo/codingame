/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.datastore.condition;

import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedResource;

import com.google.common.annotations.VisibleForTesting;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Sets;
import com.qfs.condition.ICondition;
import com.qfs.condition.impl.BaseConditions;
import com.qfs.store.IDatastore;
import com.qfs.store.IDatastoreSchema;
import com.qfs.store.IStoreMetadata;
import com.qfs.store.impl.ReadableDatastore;
import com.qfs.store.part.IPartitionSelector;
import com.qfs.store.part.impl.SkipNonePartitionSelector;
import com.qfs.store.query.ICompiledQuery;
import com.qfs.store.query.ICursorFactory;
import com.qfs.store.query.IQuery.IOuterReferencePolicy;
import com.qfs.store.query.IQueryVisitor;
import com.qfs.store.query.IRecordQuery;
import com.qfs.store.query.condition.ICompiledOperation;
import com.qfs.store.query.impl.CompiledFilterPreviousResult;
import com.qfs.store.query.impl.CompiledQuery;
import com.qfs.store.query.impl.CompiledQuerySpy;
import com.qfs.store.query.impl.CompiledStoreSearch;
import com.qfs.store.query.impl.ConditionCursorFactory;
import com.qfs.store.query.impl.QueryCompiler;
import com.qfs.store.query.impl.QueryRunner;
import com.qfs.store.query.plan.ICompiledPartitionOperation;
import com.qfs.store.query.plan.ICompiledQueryPlan;
import com.qfs.store.query.plan.ICompiledReferenceOperation;
import com.qfs.store.query.plan.IQueryPlanner;
import com.qfs.store.query.plan.condition.impl.ConditionParser;
import com.qfs.store.query.plan.impl.ACompiledIndexOperation;
import com.qfs.store.query.plan.impl.AIndexMultipleCompiledOperation;
import com.qfs.store.query.plan.impl.ConditionScanCompiledOperation;
import com.qfs.store.query.plan.impl.FieldLookupCompiledOperation;
import com.qfs.store.query.plan.impl.FieldLookupCompiledOperationSpy;
import com.qfs.store.query.plan.impl.ReturnAllPartitionCompiledOperation;

import blasd.apex.server.datastore.ApexDatastore;
import blasd.apex.toggle.ApexToggler;
import cormoran.pepper.jmx.PepperJMXHelper;
import cormoran.pepper.logging.PepperLogHelper;
import cormoran.pepper.memory.IPepperMemoryConstants;
import gnu.trove.list.TIntList;

/**
 * A DEBUG breakpoint in {@link #visit(IRecordQuery)} enables to understand slow queries
 * 
 * @author Benoit Lacelle
 * 
 */
@ManagedResource
public class ApexQueryCompiler extends QueryCompiler {

	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexQueryCompiler.class);

	/**
	 * May be useful in tests to confirm no slow queries are happening
	 */
	@VisibleForTesting
	protected static final AtomicLong TOTAL_SLOW_QUERIES = new AtomicLong();
	/**
	 * May be useful in tests to confirm no slow queries are happening
	 */
	@VisibleForTesting
	protected static final AtomicLong TOTAL_QUERIES = new AtomicLong();

	protected final AtomicLong nbSlowQuery = new AtomicLong();

	protected final BlockingQueue<String> latestSlowQuery = new LinkedBlockingQueue<>(100);

	protected final Set<List<Object>> reportedFieldLookup = Sets.newConcurrentHashSet();
	protected final Set<List<Object>> reportedPartitionSelector = Sets.newConcurrentHashSet();

	protected final Set<String> reportedUnknownOperation = Sets.newConcurrentHashSet();

	public ApexQueryCompiler(IQueryPlanner queryPlanner, IDatastoreSchema<?, ?> schema) {
		super(queryPlanner, schema);
	}

	@ManagedAttribute
	public long getNbSlowQuery() {
		return nbSlowQuery.get();
	}

	@ManagedAttribute
	public List<String> getLatestSlowQuery() {
		return PepperJMXHelper.convertToJMXList(latestSlowQuery);
	}

	@Override
	protected ConditionParser createConditionParser(IDatastoreSchema<?, ?> schema,
			IStoreMetadata baseStore,
			ICondition condition,
			IOuterReferencePolicy outerReferences) {
		if (ApexToggler.useApexConditionParser()) {
			return new ApexConditionParser(schema, baseStore, condition, outerReferences);
		} else {
			return super.createConditionParser(schema, baseStore, condition, outerReferences);
		}
	}

	public ICompiledQuery visitNoCheck(IRecordQuery recordQuery) {
		return super.visit(recordQuery);
	}

	@Override
	public ICompiledQuery visit(IRecordQuery recordQuery) {
		// Some logs are provided by the core with
		// FINER for com.qfs.store.query.impl.QueryCompiler
		ICompiledQuery compiledQuery = visitNoCheck(recordQuery);

		try {
			if (compiledQuery instanceof CompiledQuery) {
				CompiledQuery rawCompiledQuery = (CompiledQuery) compiledQuery;

				reportAboutPotentialSlowQueries(rawCompiledQuery);
			}
		} catch (RuntimeException e) {
			LOGGER.warn("Issue when checking for slow queries indexes on " + recordQuery, e);
		}

		return compiledQuery;
	}

	/**
	 * We detect slow queries to make them available through the JConsole
	 * 
	 * @param compiledQuery
	 */
	protected void reportAboutPotentialSlowQueries(CompiledQuery compiledQuery) {
		if (compiledQuery.getOriginatingQuery().getCondition().equals(BaseConditions.False())) {
			// We consider FALSE condition is not a slow query
			return;
		}

		AtomicBoolean mayBeSlowOperation = new AtomicBoolean();
		AtomicBoolean hasIndexesOperation = new AtomicBoolean();

		IRecordQuery recordQuery = compiledQuery.getOriginatingQuery();

		String storeName = recordQuery.getStoreName();
		IStoreMetadata metadata = schema.getStore(storeName).getMetadata();

		ICompiledQueryPlan plan = CompiledQuerySpy.getPlan(compiledQuery);

		checkPlan(mayBeSlowOperation, hasIndexesOperation, compiledQuery);

		IPartitionSelector partitionSelector =
				checkPartitions(compiledQuery, mayBeSlowOperation, hasIndexesOperation, recordQuery, metadata);

		ICursorFactory cursorFactor = CompiledQuerySpy.getCursorFactory(compiledQuery);

		checkCursorFactory(mayBeSlowOperation, recordQuery, cursorFactor);

		if (mayBeSlowOperation.get() && !hasIndexesOperation.get()) {
			LOGGER.trace(
					"Potentially slow RecordQuery: {} with partitionSelector={}, cursorFactory={}, compiledQueryPlan={}",
					recordQuery,
					partitionSelector,
					cursorFactor,
					plan);

			nbSlowQuery.incrementAndGet();
			long totalSlow = TOTAL_SLOW_QUERIES.incrementAndGet();

			// This switch is used for breakpoints
			if (BaseConditions.True().equals(recordQuery.getCondition())
					|| BaseConditions.False().equals(recordQuery.getCondition())) {
				LOGGER.trace("Trivial");
			} else {
				LOGGER.trace("Not trivial");
			}

			if (Long.bitCount(totalSlow) == 1) {
				// We are a power of two: report the slow query. This way, if we encounter many slow queries, we have
				// report only a small subset
				LOGGER.info("Slow query #{} is {}",
						totalSlow,
						PepperLogHelper.getFirstChars(recordQuery, IPepperMemoryConstants.KB_INT));
			}

			if (latestSlowQuery.remainingCapacity() == 0) {
				// Concurrency does not guarantee current thread query
				// will
				// be registered. No big deal
				latestSlowQuery.poll();
			}

			// Keep String to prevent maintaining an IDatastoreVersion in memory
			// May fail because of race-conditions. Not an issue as it is used only for monitoring
			if (!latestSlowQuery.offer(recordQuery.toString())) {
				LOGGER.trace("Race-condition preventing adding {} in latestSlowQueries", recordQuery);
			}
		} else {
			TOTAL_QUERIES.incrementAndGet();
		}
	}

	private void checkCursorFactory(AtomicBoolean mayBeSlowOperation,
			IRecordQuery recordQuery,
			ICursorFactory cursorFactor) {
		if (cursorFactor instanceof ConditionCursorFactory) {
			// TODO: ICompiledConditionInstance could express less
			// conditions than recordQuery.getCondition() which could
			// put
			// some of its sub-conditions in the tree
			mayBeSlowOperation.set(true);
			LOGGER.debug("{} encountered on {}", cursorFactor.getClass(), recordQuery);
		}
	}

	private IPartitionSelector checkPartitions(CompiledQuery compiledQuery,
			AtomicBoolean mayBeSlowOperation,
			AtomicBoolean hasIndexesOperation,
			IRecordQuery recordQuery,
			IStoreMetadata metadata) {
		IPartitionSelector partitionSelector = compiledQuery.getPartitionSelector();

		// cardinality == 1 -> ConstantPartitionning
		// cardinality == 0 -> IdentityFunction
		int cardinality = metadata.getPartitioning().getCardinality();

		if (partitionSelector instanceof SkipNonePartitionSelector && cardinality != 1) {
			if (hasIndexesOperation.get()) {
				LOGGER.trace("SkipNonePartitionSelector is slow but we have at least one index: {}",
						partitionSelector.getClass(),
						recordQuery);
			} else {
				// Slow as we work on all partitions
				mayBeSlowOperation.set(true);

				List<Object> asList = ImmutableList
						.of(partitionSelector.getClass(), recordQuery.getStoreName(), recordQuery.getSelectedFields());
				if (reportedPartitionSelector.add(asList)) {
					LOGGER.debug("{} encountered on {}", partitionSelector.getClass(), recordQuery);
				} else {
					LOGGER.trace("{} encountered on {}", partitionSelector.getClass(), recordQuery);
				}
			}
		}
		return partitionSelector;
	}

	public void checkPlan(AtomicBoolean mayBeSlowOperation,
			AtomicBoolean hasIndexesOperation,
			CompiledQuery compiledQuery) {
		ICompiledQueryPlan plan = CompiledQuerySpy.getPlan(compiledQuery);
		IRecordQuery recordQuery = compiledQuery.getOriginatingQuery();

		String storeName = recordQuery.getStoreName();
		IStoreMetadata metadata = schema.getStore(storeName).getMetadata();

		for (ICompiledOperation compiledOperation : plan) {
			if (compiledOperation instanceof CompiledStoreSearch) {
				CompiledStoreSearch compiledStoreSearch = (CompiledStoreSearch) compiledOperation;
				Collection<ICompiledPartitionOperation> operations =
						CompiledQuerySpy.getCompiledOperations(compiledStoreSearch);

				TIntList path = CompiledQuerySpy.getPath(compiledStoreSearch);

				for (ICompiledPartitionOperation operation : operations) {
					if (operation instanceof ConditionScanCompiledOperation) {
						// Slow as we need to full-scan
						mayBeSlowOperation.set(true);
						LOGGER.debug("{} encountered on {}", operation.getClass(), storeName);
					} else if (operation instanceof FieldLookupCompiledOperation) {
						// Slow as we need to full-scan
						mayBeSlowOperation.set(true);

						// ConditionParser.parseStoreConditions(IQueryStoreTree,
						// Entry<ITreeStoreNode,
						// IQueriedStore>)
						int fieldIndex =
								FieldLookupCompiledOperationSpy.fieldIndex((FieldLookupCompiledOperation) operation);

						String fieldName;
						if (path.isEmpty()) {
							fieldName = metadata.getStoreFormat().getRecordFormat().getFieldName(fieldIndex);

							reportFieldLookup(operation, storeName, fieldName);

						} else {
							LOGGER.debug("{} encountered on some referenced field for {}",
									operation.getClass(),
									recordQuery);
						}
						// String fieldName =
						// compiledQuery.getUndictionarizer().getUndictionarizeFormat().getFieldName(fieldIndex);
					} else if (operation instanceof ReturnAllPartitionCompiledOperation) {
						// Slow as we need to full-scan
						mayBeSlowOperation.set(true);
						LOGGER.debug("{} encountered on {}", operation.getClass(), storeName);
					} else if (operation instanceof ACompiledIndexOperation) {
						hasIndexesOperation.set(true);
					} else if (operation instanceof AIndexMultipleCompiledOperation) {
						hasIndexesOperation.set(true);
					} else if (operation instanceof ICompiledReferenceOperation) {
						// We consider ICompiledReferenceOperation is some kind of indexed
						// TODO: Confirm this assumption, add a unit-test specific for this case
						hasIndexesOperation.set(true);
					} else {
						mayBeSlowOperation.set(true);

						if (reportedUnknownOperation.add(operation.getClass().getName())) {
							LOGGER.warn("Unknown kind of operation: {}", operation);
						}
					}
				}
			} else if (compiledOperation instanceof CompiledFilterPreviousResult) {
				LOGGER.trace("Filter previous: {}", compiledOperation);
			} else {
				LOGGER.warn("Unknown ICompiledOperation: {}", compiledOperation);
			}

		}
	}

	protected void reportFieldLookup(ICompiledPartitionOperation operation, String storeName, String fieldName) {
		List<Object> asList = ImmutableList.of(operation.getClass(), storeName, fieldName);

		if (reportedFieldLookup.add(asList)) {
			LOGGER.debug("{} encountered on {}.{}", operation.getClass(), storeName, fieldName);
		} else {
			LOGGER.trace("{} encountered on {}.{}", operation.getClass(), storeName, fieldName);
		}
	}

	@VisibleForTesting
	public static ApexQueryCompiler makeFromDatastore(IDatastore datastore) {
		return new ApexQueryCompiler(QueryRunner.DEFAULT_QUERY_PLANNER, ((ReadableDatastore) datastore).getSchema());
	}

	@VisibleForTesting
	public static Optional<ApexQueryCompiler> getApexCompiler(IDatastore datastore) {
		IQueryVisitor<ICompiledQuery> compiler =
				((IApexQueryManager) ((ApexDatastore) datastore).getHead().getQueryManager()).getQueryCompiler();

		if (compiler instanceof ApexQueryCompiler) {
			return Optional.of((ApexQueryCompiler) compiler);
		} else {
			return Optional.empty();
		}

	}
}

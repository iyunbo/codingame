/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.datastore.search;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.google.common.base.Suppliers;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.qfs.condition.ICondition;
import com.qfs.condition.impl.BaseConditions;
import com.qfs.dic.IDictionary;
import com.qfs.dic.ISchemaDictionaryProvider;
import com.qfs.store.IDatastoreSchemaMetadata;
import com.qfs.store.query.ICompiledQuery;
import com.qfs.store.query.IDictionaryCursor;
import com.qfs.store.query.IQueryRunner;
import com.qfs.store.query.IRecordQuery;
import com.qfs.store.query.condition.impl.RecordQuery;
import com.qfs.store.query.impl.AQueryRunnerSpy;
import com.qfs.store.record.IRecordFormat;
import com.qfs.store.record.IRecordReader;
import com.qfs.store.record.impl.RecordFormat;

import blasd.apex.server.datastore.ApexDatastoreHelper;
import blasd.apex.server.datastore.condition.ApexConditionHelper;
import blasd.apex.server.datastore.search.ApexSearchBuilder.ApexDatastoreQueryPreparator;

/**
 * The main class preparing an IDatastore query
 * 
 * @author Benoit Lacelle
 *
 */
public class ApexDatastoreQueryBuilder implements OutputFields, OptionalParameters, QueryIsReady, PreparedQueryIsReady {

	protected final Supplier<? extends IQueryRunner> queryRunner;
	protected final String storeName;

	// By default, we query all available rows
	protected int rowsLimit = ApexDatastoreHelper.NO_LIMIT;

	protected List<? extends String> fields;

	// By default, we search for matching rows
	protected boolean distinct = false;

	protected Function<IRecordReader, ?> singleFieldOfType = null;

	// By default, we match all rows
	protected ICondition condition = BaseConditions.TRUE;

	protected boolean parallel = false;

	protected com.google.common.base.Supplier<HasCursor> computed = Suppliers.memoize(() -> compile());

	public ApexDatastoreQueryBuilder(Supplier<? extends IQueryRunner> queryRunner, String storeName) {
		this.queryRunner = queryRunner;
		this.storeName = storeName;
	}

	@Override
	public ApexDatastoreQueryBuilder limit(int rowsLimit) {
		this.rowsLimit = rowsLimit;
		return this;
	}

	@Override
	public ApexDatastoreQueryBuilder where(String key, Object value) {
		this.condition = ApexConditionHelper.convertToCondition(key, value);
		return this;
	}

	@Override
	public ApexDatastoreQueryBuilder where(String key, Object value, String key2, Object value2) {
		this.condition = ApexConditionHelper.convertToCondition(ImmutableMap.of(key, value, key2, value2));
		return this;
	}

	@Override
	public ApexDatastoreQueryBuilder where(String key,
			Object value,
			String key2,
			Object value2,
			String key3,
			Object value3) {
		this.condition =
				ApexConditionHelper.convertToCondition(ImmutableMap.of(key, value, key2, value2, key3, value3));
		return this;
	}

	@Override
	public ApexDatastoreQueryBuilder where(ICondition condition) {
		this.condition = condition;
		return this;
	}

	@Override
	public ApexDatastoreQueryBuilder where(Map<? extends String, ?> condition) {
		this.condition = ApexConditionHelper.convertToCondition(condition);
		return this;
	}

	@Override
	public PreparedQueryIsReady prepareWhere(Map<? extends String, ?> conditionMap) {
		this.condition = ApexConditionHelper.convertToPreparedCondition(conditionMap);
		return this;
	}

	@Override
	public PreparedQueryIsReady prepareWhere(ICondition preparedCondition) {
		this.condition = preparedCondition;
		return this;
	}

	@Override
	public ApexDatastoreQueryBuilder selectKeyFields() {
		this.fields = getSchemaMetadata().getKeyFields(storeName);
		return this;
	}

	private IDatastoreSchemaMetadata getSchemaMetadata() {
		return AQueryRunnerSpy.getSchema(queryRunner.get()).getMetadata();
	}

	@Override
	public ApexDatastoreQueryBuilder selectStoreFields() {
		this.fields = getSchemaMetadata().getFields(storeName);
		return this;
	}

	@Override
	public ApexDatastoreQueryBuilder selectReachableFields() {
		this.fields = ApexDatastoreHelper.getAllAccessibleFields(getSchemaMetadata(), storeName);
		return this;
	}

	@Override
	public ApexDatastoreQueryBuilder select(Iterable<? extends String> fields) {
		if (fields == null) {
			// Requested no field: request all store fields by default
			return selectStoreFields();
		} else {
			this.fields = ImmutableList.copyOf(fields);
			return this;
		}
	}

	@Override
	public ApexDatastoreQueryBuilder select(String... fields) {
		if (fields == null) {
			// Requested no field: request all store fields by default
			return selectStoreFields();
		} else {
			this.fields = ImmutableList.copyOf(fields);
			return this;
		}
	}

	@Override
	public IRecordQuery asQuery() {
		prepareFields();

		return new RecordQuery(storeName, condition, Collections.unmodifiableList(fields), rowsLimit);
	}

	protected void prepareFields() {
		if (fields == null) {
			// Requested no field: request all store fields by default
			selectStoreFields();
		}
	}

	protected HasCursor compile() {
		if (distinct) {
			prepareFields();

			if (fields.size() != 1) {
				throw new RuntimeException("Distinct can be used only with a single output fields: " + fields);
			} else if (!BaseConditions.TRUE.equals(condition)) {
				throw new RuntimeException("Distinct can be used only without any condition: " + condition);
			} else {
				String fieldName = fields.get(0);
				if (ApexDatastoreHelper.isDictionarized(getSchemaMetadata(), storeName, fieldName)) {
					// TODO: Is there a chance of seeing a value defined in
					// another store in case this field is shared through
					// stores?
					IDictionary<?> dictionary = getDictionary(storeName, fields.get(0));

					return new DictionaryHasCursor(dictionary, fieldName);
				} else {
					Set<Object> values = ApexSearchBuilder.searchWithQueryRunner(queryRunner, storeName)
							.select(fieldName)
							.parallelStream()
							.map(rr -> rr.read(0))
							.collect(Collectors.toSet());

					IRecordFormat format = new RecordFormat(new String[] { fieldName }, 0);

					return new AHasCursor() {

						@Override
						public IDictionaryCursor asCursor() {
							throw new UnsupportedOperationException("TODO");
						}

						@Override
						public void withAcceptor(IApexPartitionedResultAcceptor partitionedResultAcceptor) {
							throw new UnsupportedOperationException("TODO");
						}

						@Override
						public Stream<? extends IRecordReader> stream() {
							return values.stream().map(v -> new ApexArrayObjectRecordReader(format, v));
						}

						@Override
						public Stream<? extends IRecordReader> parallelStream() {
							return values.parallelStream().map(v -> new ApexArrayObjectRecordReader(format, v));
						}
					};
				}
			}
		} else {
			IRecordQuery query = asQuery();

			return ApexSearchBuilder.searchWithQueryRunner(queryRunner, query);
		}
	}

	protected IDictionary<?> getDictionary(String storeName, String fieldName) {
		ISchemaDictionaryProvider dictionaries = AQueryRunnerSpy.getSchema(queryRunner.get()).getDictionaries();
		return ApexDatastoreHelper.getDictionary(dictionaries, storeName, fieldName);
	}

	@Override
	public IsPrepared<HasCursor> prebuild() {
		IRecordQuery query = asQuery();

		// We pay the compilation price right away as any query is compiled
		// before being executed
		ICompiledQuery compiledQuery = ApexSearchBuilder.compile(queryRunner.get(), query);

		return new ApexDatastoreQueryPreparator(queryRunner, compiledQuery, parallel);
	}

	protected IQueryRunner getQueryRunner() {
		return queryRunner.get();
	}

	@Override
	public IsPrepared<Optional<IRecordReader>> prepareByKey() {
		if (fields == null) {
			// Requested no field: request all store fields by default
			selectStoreFields();
		}

		return new ApexDatastoreByKeyQueryPreparator(queryRunner, storeName, fields);
	}

	@Override
	public Optional<IRecordReader> getByKey(Object... keyValues) {
		return prepareByKey().match(keyValues);
	}

	@Override
	public Optional<IRecordReader> getByKeyIndexes(int... keyIndexes) {
		return prepareByKey().matchIndexes(keyIndexes);
	}

	@Override
	public Stream<? extends IRecordReader> parallelStream() {
		// Return a fast and reliable Stream
		return computed.get().parallelStream();
	}

	@Override
	public Optional<? extends IRecordReader> asSingleEntry() {
		return computed.get().asSingleEntry();
	}

	@Override
	public QueryIsReady distinct() {
		distinct = true;

		return this;
	}

	@Override
	public QueryIsReady parallel() {
		parallel = true;
		return this;
	}

	@Override
	public IDictionaryCursor asCursor() {
		return computed.get().asCursor();
	}

	@Override
	public Stream<? extends IRecordReader> stream() {
		return computed.get().stream();
	}

	@Override
	public List<? extends Map<String, Object>> asFullMapInList() {
		return computed.get().asFullMapInList();
	}

	@Override
	public void withAcceptor(IApexPartitionedResultAcceptor partitionedResultAcceptor) {
		computed.get().withAcceptor(partitionedResultAcceptor);
	}
}
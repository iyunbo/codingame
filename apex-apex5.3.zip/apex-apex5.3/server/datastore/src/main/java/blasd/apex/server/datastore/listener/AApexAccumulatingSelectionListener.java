/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.datastore.listener;

import java.lang.ref.SoftReference;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Function;
import com.google.common.collect.Iterables;
import com.google.common.collect.Maps;
import com.qfs.condition.impl.BaseConditions;
import com.qfs.store.IDatastoreVersion;
import com.qfs.store.IReadableDatastore;
import com.qfs.store.query.condition.impl.RecordQuery;
import com.qfs.store.record.IRecordBlock;
import com.qfs.store.record.IRecordReader;
import com.qfs.store.record.impl.DictionaryRecordReader;
import com.qfs.store.record.impl.Records;
import com.qfs.store.record.impl.Records.IDictionaryProvider;
import com.qfs.store.selection.ISelection;
import com.qfs.store.selection.ISelectionListener;
import com.qfs.store.transaction.ITransactionInformation;

import blasd.apex.server.datastore.ApexDatastore;
import blasd.apex.server.datastore.dictionary.ApexQueryDictionaryProvider;

/**
 * This {@link ISelectionListener} enables the access to the whole data which has been commited on each transaction.
 * 
 * @author Benoit Lacelle
 * 
 */
public abstract class AApexAccumulatingSelectionListener<T> implements IAccumulatingSelectionListener<T> {
	protected final Logger lOGGER = LoggerFactory.getLogger(this.getClass());

	/**
	 * The IRecordBlock are used through the loading and cleaned before transactionCommitted: we have to convert them to
	 * transient plain tuples
	 */
	protected final int capacity;

	protected final AtomicBoolean currentTransactionIsHuge = new AtomicBoolean();
	protected final AtomicInteger currentTransactionSize = new AtomicInteger();

	protected final Collection<T> added;
	protected final Collection<T> deleted;
	protected final Collection<Map.Entry<T, T>> updated;

	protected final List<IApexAccumulatedSelectionListener<T>> listeners = new CopyOnWriteArrayList<>();

	protected final ISelection selection;

	// In unit-tests, it seems to prevent the datastore from being GCed if not stopped
	protected final SoftReference<Records.IDictionaryProvider> dictionaries;

	public AApexAccumulatingSelectionListener(int queueCapacity, IReadableDatastore datastore, ISelection selection) {
		this.selection = selection;

		// We make a fake RecordQuery for the purpose of re-using
		// QueryDictionaryProvider
		RecordQuery fakeQuery = new RecordQuery(selection.getBaseStore(),
				BaseConditions.TRUE,
				ApexDatastore.extractFieldExpressions(selection.getFields()));
		this.dictionaries = new SoftReference<>(ApexQueryDictionaryProvider.fromQuery(fakeQuery, datastore));

		capacity = queueCapacity;

		added = new LinkedBlockingQueue<>(queueCapacity);
		deleted = new LinkedBlockingQueue<>(queueCapacity);
		updated = new LinkedBlockingQueue<>(queueCapacity);
	}

	@Override
	public void registerListener(IApexAccumulatedSelectionListener<T> listener) {
		listeners.add(listener);
	}

	@Override
	public void unregisterListener(IApexAccumulatedSelectionListener<T> listener) {
		listeners.remove(listener);
	}

	protected void cleanState() {
		currentTransactionIsHuge.set(false);
		currentTransactionSize.set(0);
		clearAccumulatedData();
	}

	protected synchronized void clearAccumulatedData() {
		added.clear();
		deleted.clear();
		updated.clear();
	}

	@Override
	public void transactionStarted(IDatastoreVersion version, ITransactionInformation transactionInformation) {
		cleanState();

		for (IApexAccumulatedSelectionListener<T> listener : listeners) {
			listener.transactionStarted(version, transactionInformation);
		}
	}

	@Override
	public void recordsAdded(int partitionId, IRecordBlock<IRecordReader> records) {
		// For performance, it is important to work locally instead of publishing directly in a shared data-structure
		Collection<T> buffer = makeBuffer();

		boolean overflow = transferTo(records, buffer, added);
		appendInMainQueue(added, buffer, overflow);
	}

	@Override
	public void recordsDeleted(int partitionId, IRecordBlock<IRecordReader> records) {
		Collection<T> buffer = makeBuffer();

		boolean overflow = transferTo(records, buffer, deleted);
		appendInMainQueue(deleted, buffer, overflow);
	}

	@Override
	public void partitionDropped(int partitionId, List<int[]> arg1, IRecordBlock<IRecordReader> records) {
		Collection<T> buffer = makeBuffer();
		boolean overflow = transferTo(records, buffer, deleted);
		appendInMainQueue(deleted, buffer, overflow);
	}

	protected <S> boolean appendInMainQueue(Collection<S> mainQueue,
			Collection<? extends S> acceptedEntries,
			boolean alreadyOverflow) {
		if (alreadyOverflow) {
			// We designed the code this way to limit the number of places calling .switchToHugeTransaction
			switchToHugeTransaction();
			return true;
		} else {
			synchronized (mainQueue) {
				// Keep new entries after previous entries
				Set<S> drained = new LinkedHashSet<>(mainQueue);

				drained.addAll(acceptedEntries);
				acceptedEntries.clear();

				if (drained.size() > capacity) {
					lOGGER.info(
							"We switchToHugeTransaction as main={} + acceptedEntries={} led to unionSize={} which is above {}",
							mainQueue.size(),
							acceptedEntries.size(),
							drained.size(),
							capacity);
					switchToHugeTransaction();
					return true;
				} else {
					mainQueue.clear();
					mainQueue.addAll(drained);
					return false;
				}
			}
		}
	}

	/**
	 * 
	 * @param records
	 * @param partitionBuffer
	 * @return true if we overflow
	 */
	protected boolean transferTo(IRecordBlock<IRecordReader> records,
			Collection<T> partitionBuffer,
			Collection<T> mainQueue) {
		int fieldCount = records.getRecordFormat().getFieldCount();

		// This is expected not to be called often. Typically once per
		// partition
		DictionaryRecordReader dictionaryRecordReader = getDictionaryRecordReader(records);

		boolean tooBig = false;
		for (IRecordReader recordReader : records) {
			T tuple = convertToTuple(dictionaryRecordReader, fieldCount, recordReader);
			if (failedOfferingToQueue(tuple, partitionBuffer, mainQueue)) {
				tooBig = true;
				break;
			} else if (currentTransactionIsHuge.get()) {
				partitionBuffer.clear();
				break;
			}
		}

		// Flush the buffer
		tooBig = appendInMainQueue(mainQueue, partitionBuffer, tooBig);

		return tooBig;
	}

	/**
	 * @return true if failure because too big
	 */
	protected <S> boolean failedOfferingToQueue(S offered, Collection<S> buffer, Collection<S> mainQueue) {
		if (buffer.size() < capacity) {
			// Add in current partition buffer
			buffer.add(offered);

			// Not too big
			return false;
		} else {
			// Current partition buffer is full: flush to mainQueue
			boolean failed = appendInMainQueue(mainQueue, buffer, false);

			if (!failed) {
				// We success
				assert buffer.isEmpty();
				buffer.add(offered);
			}

			return failed;
		}
	}

	protected void switchToHugeTransaction() {
		if (currentTransactionIsHuge.compareAndSet(false, true)) {
			clearAccumulatedData();
			lOGGER.info("We consider a huge transaction for {}", this);
		} else {
			lOGGER.debug("Fast skip");
		}
	}

	protected T convertToTuple(DictionaryRecordReader dictionaryRecordReader,
			int fieldCount,
			IRecordReader recordReader) {
		Object[] tuple = new Object[fieldCount];

		dictionaryRecordReader.setRawRecord(recordReader);

		dictionaryRecordReader.transfer(tuple);

		return convertToObject(tuple);
	}

	protected abstract T convertToObject(Object[] tuple);

	protected DictionaryRecordReader getDictionaryRecordReader(IRecordBlock<IRecordReader> records) {
		IDictionaryProvider dicProvider = dictionaries.get();
		if (dicProvider == null) {
			throw new RuntimeException("The IDatastore has been GCed: probably in a unit-test already closed");
		}

		return new DictionaryRecordReader(records.getRecordFormat(), dicProvider);
	}

	protected <S> Collection<S> makeBuffer() {
		return new HashSet<>();
	}

	@Override
	public void recordsUpdated(int partitionId,
			IRecordBlock<IRecordReader> oldValues,
			IRecordBlock<IRecordReader> newValues) {
		int fieldCount = oldValues.getRecordFormat().getFieldCount();

		// TODO: cache this a way or another
		DictionaryRecordReader dictionaryRecordReader = getDictionaryRecordReader(oldValues);

		Iterator<IRecordReader> oldIterator = oldValues.iterator();
		Iterator<IRecordReader> newIterator = newValues.iterator();

		Collection<Map.Entry<T, T>> partitionBuffer = makeBuffer();

		boolean tooBig = false;
		while (oldIterator.hasNext() && newIterator.hasNext()) {
			T oldTuple = convertToTuple(dictionaryRecordReader, fieldCount, oldIterator.next());
			T newTuple = convertToTuple(dictionaryRecordReader, fieldCount, newIterator.next());

			if (failedOfferingToQueue(Maps.immutableEntry(oldTuple, newTuple), partitionBuffer, updated)) {
				tooBig = true;
				break;
			} else if (currentTransactionIsHuge.get()) {
				partitionBuffer.clear();
				break;
			}
		}

		if (oldIterator.hasNext() || newIterator.hasNext()) {
			lOGGER.warn("There is not the same number of old and new in an update.");
		}

		// Flush the buffer
		appendInMainQueue(updated, partitionBuffer, tooBig);
	}

	@Override
	public void transactionCommitted(IDatastoreVersion version) {
		for (IApexAccumulatedSelectionListener<T> listener : listeners) {
			if (currentTransactionIsHuge.get()) {
				listener.transactionCommittedWithTooManyEntries(version);
			} else {
				listener.transactionCommitted(version, selection.getBaseStore(), added, deleted, updated);
			}
		}

		cleanState();
	}

	@Override
	public void transactionRolledBack() {
		for (IApexAccumulatedSelectionListener<? extends T> listener : listeners) {
			listener.transactionRolledBack();
		}

		cleanState();
	}

	@Override
	public String toString() {
		return this.getClass() + " [capacity="
				+ capacity
				+ ", currentTransactionIsHuge="
				+ currentTransactionIsHuge
				+ ", currentTransactionSize="
				+ currentTransactionSize
				+ ", selection="
				+ selection
				+ "]";
	}

	public static Map<String, ?> convertToMap(List<? extends String> keys, Object[] input) {
		// TODO: should we prefer a Map implementation relying on 2 arrays?
		Map<String, Object> asMap = new HashMap<>();

		for (int i = 0; i < keys.size(); i++) {
			asMap.put(keys.get(i), input[i]);
		}

		return asMap;
	}

	public static Map<String, ?> convertToMap(List<? extends String> keys, List<?> input) {
		// TODO: should we prefer a Map implementation relying on 2 arrays?
		Map<String, Object> asMap = new HashMap<>();

		for (int i = 0; i < keys.size(); i++) {
			asMap.put(keys.get(i), input.get(i));
		}

		return asMap;
	}

	public static Iterable<? extends Map<String, ?>> convertArrayToMap(List<? extends String> keys,
			Iterable<? extends Object[]> values) {
		// Using a lambda leads to compilation issue with eclipse javac
		return Iterables.transform(values, new Function<Object[], Map<String, ?>>() {
			@Override
			public Map<String, ?> apply(Object[] input) {
				return convertToMap(keys, input);
			}
		});
	}

	public static Iterable<? extends Map<String, ?>> convertListToMap(final List<? extends String> keys,
			Iterable<? extends List<?>> values) {
		return Iterables.transform(values, input -> convertToMap(keys, input));
	}

	public static Iterable<Map.Entry<? extends Map<String, ?>, ? extends Map<String, ?>>> convertPairListToMap(
			final List<? extends String> keys,
			Iterable<Entry<List<?>, List<?>>> updatedOldToNew) {
		return Iterables.transform(updatedOldToNew, input -> {
			Map<String, ?> oldItem = convertToMap(keys, input.getKey());
			Map<String, ?> newItem = convertToMap(keys, input.getValue());
			return Maps.immutableEntry(oldItem, newItem);
		});
	}

}

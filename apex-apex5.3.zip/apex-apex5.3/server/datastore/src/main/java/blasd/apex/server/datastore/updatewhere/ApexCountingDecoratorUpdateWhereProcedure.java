/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.datastore.updatewhere;

import java.util.concurrent.atomic.AtomicLong;

import com.qfs.chunk.IArrayReader;
import com.qfs.chunk.IArrayWriter;
import com.qfs.store.record.IRecordFormat;
import com.qfs.store.transaction.ITransactionManager.IUpdateWhereProcedure;

import blasd.apex.server.loading.transaction.IApexCountingUpdateWhereProcedure;

/**
 * Decorate a {@link IUpdateWhereProcedure} tocount the number of impacted rows
 * 
 * @author Benoit Lacelle
 *
 */
public class ApexCountingDecoratorUpdateWhereProcedure implements IApexCountingUpdateWhereProcedure {

	private static final long serialVersionUID = -4021676177769819521L;

	protected final AtomicLong nbRowsUpdated;
	protected final IUpdateWhereProcedure toDecorate;
	protected final boolean hasReferencedFields;

	public ApexCountingDecoratorUpdateWhereProcedure(AtomicLong nbRowsUpdated,
			IUpdateWhereProcedure toDecorate,
			boolean hasReferencedFields) {
		this.nbRowsUpdated = nbRowsUpdated;
		this.toDecorate = toDecorate;
		this.hasReferencedFields = hasReferencedFields;
	}

	public IUpdateWhereProcedure getDecorated() {
		return toDecorate;
	}

	@Override
	public void init(IRecordFormat selectionFormat, IRecordFormat storeFormat) {
		toDecorate.init(selectionFormat, storeFormat);
	}

	@Override
	public void execute(IArrayReader arrayReader, IArrayWriter writableArray) {
		nbRowsUpdated.incrementAndGet();

		toDecorate.execute(arrayReader, writableArray);
	}

	@Override
	public long getNbUpdatedRow() {
		return nbRowsUpdated.get();
	}

	@Override
	public boolean getHasReferencedFields() {
		return hasReferencedFields;
	}
}

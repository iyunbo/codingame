/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.datastore;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.function.Supplier;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.annotations.Beta;
import com.google.common.base.Joiner;
import com.google.common.base.Splitter;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import com.qfs.dic.IDictionary;
import com.qfs.dic.ISchemaDictionaryProvider;
import com.qfs.store.IDatastore;
import com.qfs.store.IDatastoreSchemaMetadata;
import com.qfs.store.IDatastoreSchemaVersion;
import com.qfs.store.IDatastoreVersion;
import com.qfs.store.IDictionaryManager;
import com.qfs.store.IReadableDatastore;
import com.qfs.store.IStoreFormat;
import com.qfs.store.IStoreMetadata;
import com.qfs.store.Types;
import com.qfs.store.impl.SchemaHelper;
import com.qfs.store.impl.StoreUtils;
import com.qfs.store.query.IRecordQuery;
import com.qfs.store.query.impl.DatastoreQueryHelper;
import com.qfs.store.record.IByteRecordFormat;
import com.qfs.store.record.IRecordFormat;
import com.qfs.util.impl.InterruptionUtil;
import com.quartetfs.fwk.Registry;
import com.quartetfs.fwk.format.IParser;

import blasd.apex.server.datastore.updatewhere.IApexUpdateWhereProcedureWrapper;
import cormoran.pepper.io.PepperSerializationHelper;

/**
 * Extends {@link DatastoreQueryHelper}
 * 
 * @author Benoit Lacelle
 * 
 */
public class ApexDatastoreHelper {

	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexDatastoreHelper.class);

	/**
	 * This {@link Map} can be used as a pattern matching all rows
	 */
	public static final Map<String, ?> MATCH_ALL = Collections.emptyMap();

	/**
	 * This int can be used when you want to retrieve an unlimited number of rows
	 */
	public static final int NO_LIMIT = IRecordQuery.NO_SIZE_LIMIT;

	// This will sysout details when a search occurs and returned nothing (which
	// is quite often not expected).
	// Keep NOT final so that it can be updated without restarting the JVM
	public static boolean debugEmptySearch = false;

	protected ApexDatastoreHelper() {
		// hidden
	}

	public static List<? extends String> getFields(IReadableDatastore datastore, String storeName) {
		return getFields(datastore.getSchemaMetadata(), storeName);
	}

	public static List<? extends String> getFields(IDatastoreVersion datastore, String storeName) {
		return getFields(datastore.getSchema().getMetadata(), storeName);
	}

	/**
	 * 
	 * @return the {@link List} of field defined in given store
	 * @see StoreUtils#getFields(IDatastore, String)
	 * 
	 * @deprecated Much simplified with AP5.6
	 */
	@Deprecated
	public static List<? extends String> getFields(IDatastoreSchemaMetadata datastoreMetadata, String storeName) {
		return datastoreMetadata.getFields(storeName);
	}

	public static List<? extends String> getKeyFields(IReadableDatastore datastore, String storeName) {
		return getKeyFields(datastore.getSchemaMetadata(), storeName);
	}

	public static List<? extends String> getKeyFields(IDatastoreVersion datastore, String storeName) {
		return getKeyFields(datastore.getSchema().getMetadata(), storeName);
	}

	/**
	 * 
	 * @param datastoreMetadata
	 * @param storeName
	 * @return the list of key fields for given store
	 * @deprecated much simplified with AP5.6
	 */
	@Deprecated
	public static List<? extends String> getKeyFields(IDatastoreSchemaMetadata datastoreMetadata, String storeName) {
		return datastoreMetadata.getKeyFields(storeName);
	}

	public static List<? extends String> getAllAccessibleFields(IReadableDatastore datastore, String storeName) {
		return getAllAccessibleFields(datastore.getHead().getSchema(), storeName);
	}

	public static List<? extends String> getAllAccessibleFields(IDatastoreVersion datastore, String storeName) {
		return getAllAccessibleFields(datastore.getSchema(), storeName);
	}

	public static List<? extends String> getAllAccessibleFields(IDatastoreSchemaVersion datastoreSchemaVersion,
			String store) {
		return getAllAccessibleFields(datastoreSchemaVersion.getMetadata(), store);
	}

	/**
	 * 
	 * @param queryRunner
	 * @param store
	 * @return the {@link List} of fields defined in given store and through its joined stores
	 */
	public static List<? extends String> getAllAccessibleFields(IDatastoreSchemaMetadata datastoreSchemaMetadata,
			String store) {
		return DatastoreQueryHelper.getAllFields(datastoreSchemaMetadata.getStoreGraph(), store);
	}

	/**
	 * 
	 * @param storeFormat
	 * @param tuple
	 * @return an Object[] mapping to this tuple
	 * 
	 * @see DatastoreQueryHelper#getByKey(IReadableDatastore, String, Object[], String...)
	 */
	public static Object[] buildKeyTuple(IReadableDatastore datastore,
			String storeName,
			Map<? extends String, ?> tuple) {
		return buildKeyTuple(datastore.getSchemaMetadata().getStoreMetadata(storeName).getStoreFormat(), tuple);
	}

	public static Object[] buildKeyTuple(IDatastoreVersion datastoreVersion,
			String storeName,
			Map<? extends String, ?> tuple) {
		return buildKeyTuple(datastoreVersion.getSchema().getMetadata().getStoreMetadata(storeName).getStoreFormat(),
				tuple);
	}

	public static Object[] buildKeyTuple(IStoreFormat storeFormat, Map<? extends String, ?> tuple) {
		IByteRecordFormat keyFormat = storeFormat.getRecordFormat();

		int[] keyFieldsIdx = storeFormat.getKeyFields();
		int keySize = keyFieldsIdx.length;

		Object[] keyTuple = new Object[keySize];
		for (int i = 0; i < keySize; ++i) {
			keyTuple[i] = tuple.get(keyFormat.getFieldName(keyFieldsIdx[i]));
		}

		return keyTuple;
	}

	public static Object[] buildKeyTuple(IReadableDatastore datastore, String storeName, Object[] tuple) {
		return buildKeyTuple(datastore.getSchemaMetadata().getStoreMetadata(storeName).getStoreFormat(), tuple);
	}

	public static Object[] buildKeyTuple(IDatastoreVersion datastoreVersion, String storeName, Object[] tuple) {
		return buildKeyTuple(datastoreVersion.getSchema().getMetadata().getStoreMetadata(storeName).getStoreFormat(),
				tuple);
	}

	public static Object[] buildKeyTuple(IStoreFormat storeFormat, Object[] tuple) {
		int[] keyFieldsIdx = storeFormat.getKeyFields();
		int keySize = keyFieldsIdx.length;

		if (keySize == 0) {
			throw new UnsupportedOperationException("WihoutKeyFields store: " + storeFormat.getStoreName());
		} else {
			return buildKeyTuple(keyFieldsIdx, tuple);
		}
	}

	public static Object[] buildKeyTuple(int[] keyFieldsIndexes, Object[] tuple) {
		int keySize = keyFieldsIndexes.length;

		Object[] keyTuple = new Object[keySize];
		for (int i = 0; i < keySize; ++i) {
			keyTuple[i] = tuple[keyFieldsIndexes[i]];
		}

		return keyTuple;
	}

	/**
	 * 
	 * @param storeName
	 * @param template
	 * @return a {@link Map} when input {@link String} has been converted to the relevant Object given the
	 *         {@link IReadableDatastore} Field configuration
	 */
	public static Map<String, Object> convertFromStringToObject(IDatastoreSchemaMetadata schemaMetadata,
			String storeName,
			Map<? extends String, ?> template) {

		if (template == null) {
			return null;
		} else {
			// Maintain the order
			ImmutableMap.Builder<String, Object> convertedTemplate = ImmutableMap.builder();

			for (Entry<? extends String, ?> entry : template.entrySet()) {
				String path = entry.getKey();

				Object value = entry.getValue();
				Object valueAsObject = convertFieldValueToObject(schemaMetadata, storeName, path, value);
				convertedTemplate.put(path, valueAsObject);
			}

			return convertedTemplate.build();
		}
	}

	// Convert each Collection item from String to Object
	// This might not the correct behavior if we receive a Collection of Collection. But this case may never
	// occur and this may still be the correct behavior
	public static boolean isConvertable(Object stringOrObject) {
		return stringOrObject instanceof String || stringOrObject instanceof Collection<?>;
	}

	public static Object convertFieldValueToObject(IDatastoreSchemaMetadata schemaMetadata,
			String baseStore,
			String fieldPath,
			Object stringOrObject) {
		return convertFieldValueToObject(stringOrObject,
				() -> getParser(schemaMetadata, baseStore, splitFieldPath(fieldPath)));
	}

	public static Object convertFieldValueToObject(Object stringOrObject, Supplier<IParser<?>> parser) {
		if (stringOrObject == null) {
			return null;
		} else if (stringOrObject instanceof CharSequence) {
			CharSequence asCharSequence = (CharSequence) stringOrObject;

			int isCollection = StringUtils.indexOf(asCharSequence, PepperSerializationHelper.COLLECTION_SEPARATOR);

			if (isCollection >= 0) {
				// The String seems to be splittable: split the CharSequence and try toconvert it to objects
				return convertFieldValueToObject(
						Splitter.on(PepperSerializationHelper.COLLECTION_SEPARATOR).split(asCharSequence),
						parser);
			} else {
				try {
					return parser.get().parse(asCharSequence);
				} catch (RuntimeException e) {
					throw new RuntimeException(
							"We encountered an issue while parsing " + stringOrObject + " with parser " + parser,
							e);
				}
			}
		} else if (stringOrObject instanceof Iterable<?>) {
			// To not wrap in a Set to prevent paying the performance overhead

			Collection<Object> convertedCollection;

			if (stringOrObject instanceof Collection<?>) {
				convertedCollection = new ArrayList<>(((Collection<?>) stringOrObject).size());
			} else {
				convertedCollection = new ArrayList<>();
			}

			Iterable<?> rawCollection = (Iterable<?>) stringOrObject;

			// Process each item independently
			for (Object item : rawCollection) {
				Object itemAsObject = convertFieldValueToObject(item, parser);
				convertedCollection.add(itemAsObject);
			}
			return convertedCollection;
		} else {
			// Keep as object
			return stringOrObject;
		}
	}

	// We may split a lot of different ,
	// private static final ConcurrentMap<String, List<String>> SPLITED_PATHES_CACHE = new ConcurrentHashMap<>();

	public static List<String> splitFieldPath(String joinedPath) {
		int firstIndex = joinedPath.indexOf(IApexUpdateWhereProcedureWrapper.PROPERTY_SEPARATOR);

		if (firstIndex == -1) {
			// In most cases, we have not a single path (as we refers a field of base store)
			return Collections.singletonList(joinedPath.trim());
		} else {
			// This can be much slower because we build a new List
			return Splitter.on(IApexUpdateWhereProcedureWrapper.PROPERTY_SEPARATOR)
					.trimResults()
					.splitToList(joinedPath);
		}
	}

	public static String joinFieldPath(Iterable<? extends String> prefixes, String... rest) {
		Iterable<String> all = ImmutableList.<String>builder().addAll(prefixes).addAll(Arrays.asList(rest)).build();
		return Joiner.on(IApexUpdateWhereProcedureWrapper.PROPERTY_SEPARATOR).join(all);
	}

	public static String joinFieldPath(String first, String... rest) {
		return joinFieldPath(Lists.asList(first, rest));
	}

	public static String getTargetStoreField(List<? extends String> path) {
		return SchemaHelper.getField(Collections.unmodifiableList(path));
	}

	@Beta
	public static IStoreMetadata getTargetStore(IDatastoreSchemaMetadata schemaMetadata,
			String baseStore,
			String... fieldPath) {
		IStoreMetadata targetStore = SchemaHelper.getStoreMetadata(schemaMetadata, baseStore, fieldPath);
		if (targetStore == null) {
			throw new IllegalArgumentException("Incorrect path " + Arrays.asList(fieldPath)
					+ ": "
					+ SchemaHelper.explainPathError(schemaMetadata, baseStore, fieldPath));

		}
		return targetStore;
	}

	@Beta
	public static IStoreMetadata getTargetStore(IDatastoreSchemaMetadata schemaMetadata,
			String baseStore,
			List<? extends String> fieldPath) {
		if (fieldPath.isEmpty()) {
			throw new RuntimeException("Invalid empty path for " + baseStore);
		} else if (fieldPath.size() == 1) {
			return getTargetStore(schemaMetadata, baseStore, fieldPath.get(0));
		} else {
			return getTargetStore(schemaMetadata, baseStore, fieldPath.toArray(new String[0]));
		}
	}

	/**
	 * Similar to {@link SchemaHelper#getField(List)}
	 * 
	 * @return the last element of given list, as it represents the field/column of given path
	 */
	public static <T> T getTargetColumn(List<T> chain) {
		if (chain.isEmpty()) {
			throw new IllegalArgumentException("We expect at least 1 element");
		}
		return chain.get(chain.size() - 1);
	}

	public static IParser<?> getParser(IDatastoreSchemaMetadata schemaMetadata,
			String baseStore,
			List<String> fieldPath) {
		IStoreMetadata store = getTargetStore(schemaMetadata, baseStore, fieldPath);

		String fieldName = getTargetColumn(fieldPath);
		String parserKey = store.getParserPlugins().get(fieldName);
		IParser<?> parser = Registry.getPlugin(IParser.class).valueOf(parserKey);

		if (parser == null) {
			throw new RuntimeException("There is no IParser for key=" + parserKey);
		} else {
			return parser;
		}
	}

	public static IParser<?> getParser(IDatastoreSchemaMetadata schemaMetadata,
			String baseStore,
			String firstFieldPath,
			String... moreFieldPathes) {
		return getParser(schemaMetadata, baseStore, Lists.asList(firstFieldPath, moreFieldPathes));
	}

	public static boolean allStoresAreEmpty(IReadableDatastore datastore) {
		IDatastoreVersion latestVersion = datastore.getHead();
		for (String storeName : datastore.getHead().getSchema().getMetadata().getStoreNames()) {
			if (getSize(latestVersion, storeName) > 0) {
				// At least one line has been loaded
				return false;
			}
		}

		return true;
	}

	/**
	 * @param datastore
	 * @param storeName
	 * @return the number of rows in given store
	 */
	public static long getSize(IDatastoreVersion datastore, String storeName) {
		long rawSize = StoreUtils.getSize(datastore, storeName);

		if (rawSize < 0) {
			// Sometimes, AP reports a size of -1 as some partitions size have not been computed properly
			LOGGER.debug("ActivePivot reported a store={} size of {}", storeName, rawSize);
			rawSize = 0;
		}

		return rawSize;
	}

	public static boolean isEmpty(IDatastoreVersion datastoreVersion, String storeName) {
		return getSize(datastoreVersion, storeName) == 0;
	}

	public static int getFieldIndex(IReadableDatastore datastore, String storeName, String fieldName) {
		return getFieldIndex(datastore.getSchemaMetadata(), storeName, fieldName);
	}

	/**
	 * @deprecated much simpler with AP5.6
	 */
	@Deprecated
	public static int getFieldIndex(IDatastoreSchemaMetadata datastoreMetadata, String storeName, String fieldName) {
		return datastoreMetadata.getFieldIndex(storeName, fieldName);
	}

	/**
	 * @deprecated much simpler with AP5.6
	 */
	@Deprecated
	public static int getFieldIndex(IStoreMetadata storeMetadata, String fieldName) {
		return storeMetadata.getFieldIndex(fieldName);
	}

	/**
	 * @deprecated no interest
	 */
	@Deprecated
	public static int getFieldIndex(IRecordFormat recordFormat, String fieldName) {
		return recordFormat.getFieldIndex(fieldName);
	}

	public static int[] getFieldIndexes(IDatastoreSchemaMetadata datastoreMetadata,
			String storeName,
			Collection<? extends String> fieldNames) {
		return getFieldIndexes(datastoreMetadata.getStoreMetadata(storeName).getStoreFormat().getRecordFormat(),
				fieldNames);
	}

	public static int[] getFieldIndexes(IRecordFormat recordFormat, Collection<? extends String> fieldNames) {
		return fieldNames.stream().mapToInt(fieldName -> recordFormat.getFieldIndex(fieldName)).toArray();
	}

	public static Object[] getDefaultValues(IReadableDatastore datastore,
			String storeName,
			Collection<? extends String> fieldNames) {
		return getDefaultValues(datastore.getSchemaMetadata(), datastore.getDictionaries(), storeName, fieldNames);
	}

	public static Object[] getDefaultValues(IDatastoreSchemaMetadata datastoreMetadata,
			ISchemaDictionaryProvider dictionaryProvider,
			String storeName,
			Collection<? extends String> fieldNames) {
		IStoreMetadata storeMetadata = datastoreMetadata.getStoreMetadata(storeName);
		IRecordFormat recordFormat = storeMetadata.getStoreFormat().getRecordFormat();

		return fieldNames.stream()
				.map(fieldName -> getDefaultValue(dictionaryProvider, storeMetadata, recordFormat, fieldName))
				.toArray();
	}

	public static Object getDefaultValue(IReadableDatastore datastore, String storeName, String fieldName) {
		return getDefaultValue(datastore.getSchemaMetadata(), datastore.getDictionaries(), storeName, fieldName);
	}

	public static Object getDefaultValue(IDatastoreSchemaMetadata datastoreMetadata,
			ISchemaDictionaryProvider dictionaryProvider,
			String storeName,
			String fieldName) {
		IStoreMetadata storeMetadata = datastoreMetadata.getStoreMetadata(storeName);
		IRecordFormat recordFormat = storeMetadata.getStoreFormat().getRecordFormat();

		return getDefaultValue(dictionaryProvider, storeMetadata, recordFormat, fieldName);
	}

	public static Object getDefaultValue(ISchemaDictionaryProvider dictionaryProvider,
			IStoreMetadata storeMetadata,
			IRecordFormat recordFormat,
			String fieldName) {
		int index = getFieldIndex(recordFormat, fieldName);

		if (index == -1) {
			throw new RuntimeException("There is no field named " + fieldName + " in " + storeMetadata.getName());
		}

		int fieldType = recordFormat.getType(index);

		Object rawDefaultValue = recordFormat.getDefault(index);

		if (Types.isDictionary(fieldType) && rawDefaultValue instanceof Integer) {
			IDictionary<Object> dictionary = dictionaryProvider.getDictionary(storeMetadata.getId(), index);
			return dictionary.read((int) rawDefaultValue);
		} else {
			return rawDefaultValue;
		}
	}

	public static boolean isDictionarized(IDatastoreSchemaMetadata datastoreMetadata,
			String storeName,
			String fieldName) {
		IStoreMetadata storeMetadata = datastoreMetadata.getStoreMetadata(storeName);
		int fieldIndex = getFieldIndex(storeMetadata, fieldName);
		int fieldType = storeMetadata.getStoreFormat().getRecordFormat().getType(fieldIndex);
		return Types.isDictionary(fieldType);
	}

	public static IDictionary<?> getDictionary(IReadableDatastore datastore, String storeName, String fieldName) {
		return getDictionary(datastore.getDictionaries(), storeName, fieldName);
	}

	public static IDictionary<?> getDictionary(IDatastoreVersion datastoreVersion, String storeName, String fieldName) {
		return getDictionary(datastoreVersion.getSchema().getDictionaries(), storeName, fieldName);
	}

	public static IDictionary<?> getDictionary(ISchemaDictionaryProvider dictionaryProvider,
			String storeName,
			String fieldName) {
		try {
			return dictionaryProvider.getDictionary(storeName, fieldName);
		} catch (ArrayIndexOutOfBoundsException e) {
			throw new IllegalArgumentException("There is no field named " + fieldName + " in " + storeName, e);
		}
	}

	/**
	 * @deprecated rely on core API
	 */
	@Deprecated
	public static IDictionary<?> getDictionary(ISchemaDictionaryProvider dictionaryProvider, int storeId, int fieldId) {
		return dictionaryProvider.getDictionary(storeId, fieldId);
	}

	/**
	 * @deprecated rely on core API
	 */
	@Deprecated
	public static IDictionary<?> getDictionary(IDictionaryManager dictionaryProvider,
			String storeName,
			String fieldName) {
		return dictionaryProvider.getFieldDictionary(storeName, fieldName);
	}

	public static IDictionary<?> getPathDictionary(IDatastoreSchemaMetadata metadata,
			ISchemaDictionaryProvider dictionaryProvider,
			String baseStore,
			String flatPath) {
		List<String> path = splitFieldPath(flatPath);

		IStoreMetadata store = getTargetStore(metadata, baseStore, path);

		String fieldName = getTargetColumn(path);

		return Optional.ofNullable(store).map(s -> {
			int fieldId = getFieldIndex(store, fieldName);

			return getDictionary(dictionaryProvider, store.getId(), fieldId);
		}).orElse(null);
	}

	/**
	 * Throw if current query has been executing for longer than the IQueryTimeOut
	 */
	public static void checkInterruption(String name) {
		InterruptionUtil.checkInterruption(name);
	}

	public static List<?> convertFieldValueToObject(List<IParser<?>> parsers,
			List<? extends CharSequence> tupleOfText) {

		List<Object> parsed = new ArrayList<>(tupleOfText.size());
		for (int i = 0; i < tupleOfText.size(); i++) {
			IParser<?> parser = parsers.get(i);
			parsed.add(ApexDatastoreHelper.convertFieldValueToObject(tupleOfText.get(i), () -> parser));
		}

		return parsed;
	}

}

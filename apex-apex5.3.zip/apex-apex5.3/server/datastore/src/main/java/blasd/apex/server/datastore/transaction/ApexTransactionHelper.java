/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.datastore.transaction;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.function.LongConsumer;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.codahale.metrics.Meter;
import com.codahale.metrics.Metered;
import com.google.common.annotations.Beta;
import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Function;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Iterators;
import com.google.common.collect.Lists;
import com.google.common.collect.Streams;
import com.google.common.util.concurrent.ListeningExecutorService;
import com.qfs.condition.ICondition;
import com.qfs.condition.impl.BaseConditions;
import com.qfs.store.IDatastore;
import com.qfs.store.IDatastoreSchemaMetadata;
import com.qfs.store.IStoreFormat;
import com.qfs.store.record.IWritableByteRecordBlock;
import com.qfs.store.record.impl.AppendOnlyRecordBlock;
import com.qfs.store.selection.ISelection;
import com.qfs.store.transaction.DatastoreTransactionException;
import com.qfs.store.transaction.IDatastoreSchemaTransactionInformation;
import com.qfs.store.transaction.ITransactionManager;
import com.qfs.store.transaction.ITransactionManager.IUpdateWhereProcedure;
import com.quartetfs.biz.pivot.IActivePivotManager;
import com.quartetfs.biz.pivot.IActivePivotVersion;

import blasd.apex.server.datastore.condition.ApexConditionHelper;
import blasd.apex.server.datastore.updatewhere.IApexUpdateWhereProcedureWrapper;
import cormoran.pepper.thread.PepperExecutorsHelper;

/**
 * Helper for executing {@link IDatastore} transactions
 * 
 * @author Benoit Lacelle
 *
 */
public class ApexTransactionHelper {

	/**
	 * This factor is used when targeting a duration given past durations (e.g. if we target an operation to last 20
	 * seconds, and past durations let us feel we could query 50 conditions to last 20 seconds, then we will actually
	 * query 50/10=5 conditions )
	 */
	private static final int STREAM_RATIO_FOR_TARGET = 10;

	@Deprecated
	public static final ICondition EVERYWHERE = BaseConditions.TRUE;

	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexTransactionHelper.class);

	protected static final int WAIT_BETWEEN_RETRY_MS = 100;
	protected static final ListeningExecutorService AWAIT_NOTIFICATIONS =
			PepperExecutorsHelper.newSingleThreadExecutor("Apex-AwaitNotif");

	protected ApexTransactionHelper() {
		// hidden
	}

	/**
	 * This method enables executing given consumer over the transactionId. The implementation is safe give ActivePivot
	 * transaction management, especially regarding transaction issues.
	 * 
	 * The consumer may request to cancel softly current transaction (i.e. rollback without throwing exception or
	 * logging warn/error stacks) by calling ApexInTransactionHelper#cancelCurrentTransaction()
	 * 
	 * There should be an equivalent method introduced in ActivePivot5.6
	 * 
	 * @param transactionManager
	 * @param storeIds
	 * @param transactionIdConsumer
	 * @return
	 */
	public static IDatastoreSchemaTransactionInformation executeInTransaction(ITransactionManager transactionManager,
			int[] storeIds,
			LongConsumer transactionIdConsumer) {
		// TODO This is a started work to use the core API introduced with AP5.6, but the move is not straight-forward
		// String[] storeNames;
		// if (storeIds.length == 0) {
		// storeNames = transactionManager.getMetadata().getStoreNames().toArray(new String[0]);
		// } else {
		// storeNames = Arrays.stream(storeIds)
		// .mapToObj(storeId -> transactionManager.getMetadata().getStoreMetadata(storeId).getName())
		// .toArray(String[]::new);
		// }
		//
		// return transactionManager.performInTransaction(openedTransaction -> {
		// openedTransaction.forceCommit();
		// }, e -> {
		// }, storeNames).get();

		if (storeIds == null) {
			storeIds = new int[0];
		}

		final long transactionId;
		try {
			LOGGER.trace("Before startTransaction on stores ids={}", Arrays.toString(storeIds));
			if (storeIds.length == 0) {
				transactionId = transactionManager.startTransaction();
			} else {
				transactionId = transactionManager.startTransaction(storeIds);
			}
			LOGGER.trace("After startTransaction on stores ids={}", Arrays.toString(storeIds));
		} catch (DatastoreTransactionException | RuntimeException e) {
			// No need to roll-back
			throw new RuntimeException(e);
		}

		if (transactionIdConsumer == null) {
			LOGGER.trace("Do an empty transaction on stores ids={}", Arrays.toString(storeIds));
		} else {
			try {
				transactionIdConsumer.accept(transactionId);
			} catch (RollbackTransactionSilently e) {
				behaveOnTransactionException(e, transactionManager, false);

				// We have been requested to roll-back without considering it is an issue
				return null;
			} catch (RuntimeException e) {
				behaveOnTransactionException(e, transactionManager, true);
			} catch (Error e) {
				behaveOnTransactionException(e, transactionManager, true);
			}
		}
		try {
			LOGGER.trace("Before commitTransaction on stores ids={}", Arrays.toString(storeIds));
			return transactionManager.commitTransaction();
		} catch (DatastoreTransactionException | RuntimeException e) {
			// No need to roll-back
			throw new RuntimeException(e);
		} finally {
			LOGGER.trace("After commitTransaction on stores ids={}", Arrays.toString(storeIds));
		}
	}

	/**
	 * @deprecated Use .executeInTransaction
	 */
	@Deprecated
	public static IDatastoreSchemaTransactionInformation doExecuteInTransaction(ITransactionManager transactionManager,
			Runnable runnable,
			String firstStores,
			String... moreStores) {
		return executeInTransaction(transactionManager, Lists.asList(firstStores, moreStores), runnable);
	}

	public static IDatastoreSchemaTransactionInformation executeInTransaction(ITransactionManager transactionManager,
			Runnable runnable,
			String firstStores,
			String... moreStores) {
		return executeInTransaction(transactionManager, Lists.asList(firstStores, moreStores), runnable);
	}

	/**
	 * @deprecated There is already a .executeInTransaction(tm, storeNames, Runnable)
	 */
	@Deprecated
	public static IDatastoreSchemaTransactionInformation executeInTransaction(ITransactionManager transactionManager,
			Runnable runnable,
			Collection<String> storeNames) {
		int[] storeIds = getStoreIds(transactionManager.getMetadata(), storeNames);

		return executeInTransaction(transactionManager, storeIds, transactionId -> runnable.run());
	}

	/**
	 * As it is very sensible to recover from a failed transaction, we prefer to hold a nice logic in a reusable method.
	 * 
	 * For instance, even if the {@link Throwable} is an {@link Error}, we prefer to rollback.
	 * 
	 * In any-case, we prefer to re-throw a {@link RuntimeException} instead of just logging
	 */
	public static void behaveOnTransactionException(Throwable e, ITransactionManager transactionManager) {
		// By default, a rollback is an unexpected behavior; rethrow the source exception
		behaveOnTransactionException(e, transactionManager, true);
	}

	public static void behaveOnTransactionException(Throwable e,
			ITransactionManager transactionManager,
			boolean rethrow) {
		// Need to rollback
		long rollbackId;
		try {
			rollbackId = transactionManager.rollbackTransaction();
		} catch (DatastoreTransactionException | RuntimeException | Error e2) {
			RuntimeException severeException = new IllegalStateException("Rollback FAILED", e2);

			// Remember the original Exception
			severeException.addSuppressed(e);

			throw severeException;
		}
		if (rethrow) {
			throw new IllegalStateException("Rollback SUCCEEDED: id=" + rollbackId, e);
		}
	}

	/**
	 * Insert a bunch of data in a single Transaction
	 * 
	 * @param querryRunner
	 * @param storeToData
	 *            a {@link Map} from a storeName to a {@link List} of {@link Map} to insert in given store
	 * 
	 * @deprecated Prefer {@link Stream}
	 */
	@Deprecated
	public static IDatastoreSchemaTransactionInformation add(ITransactionManager transactionManager,
			Map<String, ? extends Iterable<?>> storeToData) {
		return addOrRemove(transactionManager, storeToData, false);
	}

	public static IDatastoreSchemaTransactionInformation add(ITransactionManager transactionManager,
			String storeName,
			Collection<?> toAdd) {
		return add(transactionManager, storeName, toAdd.stream());
	}

	public static IDatastoreSchemaTransactionInformation add(ITransactionManager transactionManager,
			String storeName,
			Collection<?> toAdd,
			String storeName2,
			Collection<?> toAdd2) {
		return addStreams(transactionManager, ImmutableMap.of(storeName, toAdd.stream(), storeName2, toAdd2.stream()));
	}

	public static IDatastoreSchemaTransactionInformation add(ITransactionManager transactionManager,
			String storeName,
			Collection<?> toAdd,
			String storeName2,
			Collection<?> toAdd2,
			String storeName3,
			Collection<?> toAdd3) {
		return addStreams(transactionManager,
				ImmutableMap.of(storeName, toAdd.stream(), storeName2, toAdd2.stream(), storeName3, toAdd3.stream()));
	}

	/**
	 * Insert a bunch of data in a single Transaction
	 * 
	 * @param querryRunner
	 * @param storeToData
	 *            a {@link Map} from a storeName to a {@link Stream} of objects to insert in given store
	 */
	public static IDatastoreSchemaTransactionInformation addStreams(ITransactionManager transactionManager,
			Map<String, ? extends Stream<?>> storeToData) {
		// Do the push in a single transaction
		return executeInTransaction(transactionManager,
				storeToData.keySet(),
				() -> ApexInTransactionHelper.addStreamsInTransaction(transactionManager, storeToData));
	}

	public static IDatastoreSchemaTransactionInformation add(ITransactionManager transactionManager,
			String storeName,
			Iterable<?> toAdd) {
		return add(transactionManager, Collections.singletonMap(storeName, toAdd));
	}

	public static IDatastoreSchemaTransactionInformation add(ITransactionManager transactionManager,
			String storeName,
			Iterator<?> toAdd) {
		Stream<?> targetStream = Streams.stream(toAdd);
		return add(transactionManager, storeName, targetStream);
	}

	public static IDatastoreSchemaTransactionInformation add(ITransactionManager transactionManager,
			String storeName,
			Stream<?> toAdd) {
		return addOrRemove(transactionManager, storeName, toAdd, false);
	}

	/**
	 * Simplify tests by submitting directly to an IActivePivotManager
	 */
	@VisibleForTesting
	public static IDatastoreSchemaTransactionInformation addOne(IActivePivotManager apManager,
			String storeName,
			Object oneToAdd) {
		IDatastore datastore = (IDatastore) apManager.getDatastore();
		return addOne(datastore.getTransactionManager(), storeName, oneToAdd);
	}

	public static IDatastoreSchemaTransactionInformation addOne(ITransactionManager transactionManager,
			String storeName,
			Object oneToAdd) {
		if (oneToAdd instanceof Iterable<?>) {
			throw new IllegalArgumentException("Do NOT push an Iterable with addOne");
		} else if (oneToAdd instanceof Iterator<?>) {
			throw new IllegalArgumentException("Do NOT push an Iterator with addOne");
		}
		return add(transactionManager, storeName, Collections.singleton(oneToAdd));
	}

	/**
	 * @deprecated Prefer {@link Stream}
	 */
	@Deprecated
	public static IDatastoreSchemaTransactionInformation addOrRemove(ITransactionManager transactionManager,
			Map<String, ? extends Iterable<?>> storeToData,
			boolean doRemove) {
		Runnable pushDataRunnable =
				ApexInTransactionHelper.prepareAddOrRemove(transactionManager, storeToData, doRemove);

		// Do the push in a single transaction
		return executeInTransaction(transactionManager, storeToData.keySet(), pushDataRunnable);
	}

	/**
	 * @deprecated Call .toAdd or .toRemove
	 */
	@Deprecated
	public static IDatastoreSchemaTransactionInformation addOrRemove(ITransactionManager transactionManager,
			String storeName,
			Iterator<?> toAdd,
			boolean doRemove) {
		return addOrRemove(transactionManager, storeName, Streams.stream(toAdd), doRemove);
	}

	/**
	 * @deprecated Call .toAdd or .toRemove
	 */
	@Deprecated
	@Beta
	public static IDatastoreSchemaTransactionInformation addOrRemove(ITransactionManager transactionManager,
			String storeName,
			Stream<?> toAdd,
			boolean doRemove) {
		Runnable pushDataRunnable =
				ApexInTransactionHelper.prepareAddOrRemove(transactionManager, storeName, toAdd, doRemove);

		// Do the push in a single transaction
		return executeInTransaction(transactionManager, Collections.singleton(storeName), pushDataRunnable);
	}

	/**
	 * Remove all entries from givens store
	 * 
	 * @param querryRunner
	 * @param storeName
	 */
	public static void removeAll(ITransactionManager transactionManager, String storeName) {
		removeWhere(transactionManager, storeName, BaseConditions.TRUE);
	}

	public static IDatastoreSchemaTransactionInformation removeWhere(ITransactionManager transactionManager,
			String storeName,
			Map<? extends String, ?> template) {
		return executeInTransaction(transactionManager,
				ImmutableSet.of(storeName),
				() -> ApexInTransactionHelper.removeInTransaction(transactionManager, storeName, template));
	}

	public static IDatastoreSchemaTransactionInformation removeWhere(ITransactionManager transactionManager,
			String storeName,
			ICondition condition) {
		return executeInTransaction(transactionManager,
				ImmutableSet.of(storeName),
				() -> ApexInTransactionHelper.removeInTransaction(transactionManager, storeName, condition));
	}

	public static IDatastoreSchemaTransactionInformation removeWhere(ITransactionManager transactionManager,
			String storeName,
			Stream<?> toRemove) {
		return executeInTransaction(transactionManager,
				ImmutableSet.of(storeName),
				() -> ApexInTransactionHelper.removeInTransaction(transactionManager, storeName, toRemove));
	}

	/**
	 * 
	 * @param querryRunner
	 * @param condition
	 *            an {@link ICondition} to apply on all stores
	 * @return the transaction result where all stores have been removed the data matching the condition
	 */
	public static IDatastoreSchemaTransactionInformation removeStoresWhere(ITransactionManager transactionManager,
			Collection<? extends String> storeNames,
			ICondition condition) {
		Stream<Runnable> actions = storeNames.stream()
				.map(storeName -> () -> ApexInTransactionHelper
						.removeInTransaction(transactionManager, storeName, condition));

		return executeInTransaction(transactionManager, storeNames, actions);
	}

	public static IDatastoreSchemaTransactionInformation removeStoresWhere(ITransactionManager transactionManager,
			Collection<? extends String> storeNames,
			Map<String, ?> condition) {
		return removeStoresWhere(transactionManager, storeNames, ApexConditionHelper.convertToCondition(condition));
	}

	/**
	 * Demonstrate the workflow of a transaction. It also demonstrates when a rollback is needed or not.
	 * 
	 * One may consider using {@link IDatastore#edit(com.qfs.store.transaction.IEditInstructions)}
	 */
	public static IDatastoreSchemaTransactionInformation executeInTransaction(ITransactionManager transactionManager,
			Collection<? extends String> storeNames,
			Runnable firstRunnable,
			Runnable... otherRunnables) {
		Stream<Runnable> runnables = Lists.asList(firstRunnable, otherRunnables).stream();
		int[] storeIds = getStoreIds(transactionManager.getMetadata(), storeNames);
		return executeInTransaction(transactionManager, storeIds, transactionId -> runnables.forEach(Runnable::run));
	}

	public static IDatastoreSchemaTransactionInformation executeInTransaction(ITransactionManager transactionManager,
			Collection<? extends String> stores,
			Stream<? extends Runnable> runnables) {
		return executeInTransaction(transactionManager, stores, () -> {
			if (runnables == null) {
				LOGGER.debug("We submit a transaction without any runnable");
			} else {
				runnables.forEach(Runnable::run);
			}
		});
	}

	public static IDatastoreSchemaTransactionInformation doEmptyTransaction(ITransactionManager transactionManager,
			Set<? extends String> storeNames) {
		return executeInTransaction(transactionManager, storeNames, () -> LOGGER.debug("No-Op transaction"));
	}

	public static IDatastoreSchemaTransactionInformation updateWhere(ITransactionManager transactionManager,
			IApexUpdateWhereProcedureWrapper apexUpdateWhereProcedure) {
		Set<String> stores = Collections.singleton(apexUpdateWhereProcedure.getSelection().getBaseStore());
		return executeInTransaction(transactionManager,
				stores,
				() -> ApexInTransactionHelper.executeUpdateWhere(transactionManager,
						apexUpdateWhereProcedure.getSelection(),
						apexUpdateWhereProcedure.getCondition(),
						apexUpdateWhereProcedure.getUpdateWhere()));
	}

	/**
	 * API Simplification by throwing only unchecked exception
	 * 
	 * @deprecated see ApexInTransactionHelper
	 */
	@Deprecated
	public static void executeUpdateWhere(ITransactionManager transactionManager,
			ISelection selection,
			ICondition condition,
			IUpdateWhereProcedure updateWhere) {
		ApexInTransactionHelper.executeUpdateWhere(transactionManager, selection, condition, updateWhere);
	}

	public static Collection<Map<String, ?>> transformFilterNull(List<? extends Map<String, Object>> batch,
			Function<Map<String, ?>, Map<String, ?>> function) {
		// As the function is applied lazily, Iterating on the filtered
		// Collection would apply the Function on each .hasNext and .next call:
		// we prefer to materialize the Collection once and for all
		return batch.stream().map(function).filter(Objects::nonNull).collect(Collectors.toList());
	}

	public static IDatastoreSchemaTransactionInformation addRemoveWhere(ITransactionManager transactionManager,
			String storeName,
			Stream<?> toAdd,
			Stream<? extends Map<? extends String, ?>> templatesToRemove) {
		Stream<? extends Runnable> runnables = ApexInTransactionHelper
				.prepareAddAndRemoveWhere(transactionManager, storeName, toAdd, templatesToRemove);
		return executeInTransaction(transactionManager, Collections.singleton(storeName), runnables);
	}

	public static IDatastoreSchemaTransactionInformation addRemoveWhere(ITransactionManager transactionManager,
			String storeName,
			Iterator<?> toAdd,
			Iterator<? extends Map<? extends String, ?>> templatesToRemove) {
		return addRemoveWhere(transactionManager, storeName, Streams.stream(toAdd), Streams.stream(templatesToRemove));
	}

	public static IDatastoreSchemaTransactionInformation addRemoveWhere(ITransactionManager transactionManager,
			String storeName,
			Iterable<?> toAdd,
			Iterable<? extends Map<? extends String, ?>> templateToRemove) {
		return addRemoveWhere(transactionManager, storeName, toAdd.iterator(), templateToRemove.iterator());
	}

	/**
	 * Process the runnable asynchronously when the {@link IActivePivotVersion} notifications are done. The
	 * {@link Runnable} is runned asynchronously even if the {@link IActivePivotVersion} notifications are already done
	 * 
	 * @param activePivotVersion
	 * @param runnable
	 */
	public static void awaitNotifications(IActivePivotVersion activePivotVersion, Runnable runnable) {
		AWAIT_NOTIFICATIONS.execute(() -> {
			try {
				// Wait up to 100 ms
				activePivotVersion.awaitNotifications(WAIT_BETWEEN_RETRY_MS);
			} catch (TimeoutException e) {
				// We need more time: let another awaitNotification to be
				// processed and retry this one later
				awaitNotifications(activePivotVersion, runnable);

				// Leave current try
				return;
			}

			// Execute the action as we successfully awaited for the
			// notification
			if (runnable != null) {
				runnable.run();
			}
		});
	}

	// TODO: this method could not require an ITransactionManager
	@Beta
	public static IWritableByteRecordBlock transformToRecords(ITransactionManager transactionManager,
			IStoreFormat storeFormat,
			boolean toRemove,
			Collection<? extends Object[]> enriched) {
		IWritableByteRecordBlock block = new AppendOnlyRecordBlock(enriched.size(), storeFormat.getRecordFormat());
		transactionManager.transformToRecords(storeFormat, false, enriched, block, 0);
		return block;
	}

	/**
	 * As updateWhere can be slow, we sometimes want to split a Stream of conditions to be updated not necessarily in a
	 * single transaction
	 * 
	 * @param transactionManager
	 * @param selection
	 * @param updateWhere
	 * @param conditionsToUpdate
	 * @param timeForEachTransaction
	 * @param timeUnit
	 * @return how many transaction have been executed
	 */
	@Beta
	public static long streamUpdateWhere(ITransactionManager transactionManager,
			ISelection selection,
			IUpdateWhereProcedure updateWhere,
			Stream<ICondition> conditionsToUpdate,
			int timeForEachTransaction,
			TimeUnit timeUnit) {
		Iterator<ICondition> iterator = conditionsToUpdate.iterator();

		final Meter timer = new Meter();

		long nbTransactions = 0;

		// Continue as long as we have items to insert
		while (iterator.hasNext()) {
			try {
				long targetMaxInMillis = timeUnit.toMillis(timeForEachTransaction);

				// Apply the updateWhere on a subset of rows
				Set<String> oneStore = Collections.singleton(selection.getBaseStore());
				executeInTransaction(transactionManager,
						oneStore,
						() -> {
							// Register the clock to prevent the transaction to last too long
							long currentTransaction = System.currentTimeMillis();

							// Iterate until we have nothing to insert
							while (iterator.hasNext()) {
								// Let's compute how many conditions should be processed given previous statistics and
								// target
								// transaction time
								int nbConditions = computeNbConditions(targetMaxInMillis, timer);

								if (nbConditions == 0) {
									// For any reason, we have been requested not to push anything: leave the
									// transaction
									break;
								} else {
									// Count how many conditions are about to be processed
									timer.mark(nbConditions);
								}

								List<ICondition> nextCondition = new ArrayList<>();
								Iterators.addAll(nextCondition, Iterators.limit(iterator, nbConditions));

								LOGGER.debug("About to process {} items for {} on {}",
										nextCondition.size(),
										updateWhere);

								ApexInTransactionHelper.executeUpdateWhere(transactionManager,
										selection,
										BaseConditions.Or(nextCondition),
										updateWhere);
								if (System.currentTimeMillis() - currentTransaction > targetMaxInMillis) {
									LOGGER.debug("Stop current transaction as it lasted enough");
									break;
								}
							}
						});
			} finally {
				nbTransactions++;
			}
		}

		return nbTransactions;
	}

	protected static int computeNbConditions(long targetMaxInMillis, Metered metered) {
		if (targetMaxInMillis < 0) {
			// Negative target time: try not-to-split
			return Integer.MAX_VALUE;
		} else if (targetMaxInMillis == 0) {
			// Target time == 0: try to make transaction as small as possible
			return 1;
		} else if (targetMaxInMillis == Long.MAX_VALUE) {
			// Target time == Infinite: try to make transaction as big as possible
			return Integer.MAX_VALUE;
		} else if (metered.getCount() <= 0) {
			// First iteration: handle a single transaction
			return 1;
		} else {
			double meanRatePerSecond = metered.getMeanRate();

			double meanRatePerMillis = meanRatePerSecond / (double) TimeUnit.SECONDS.toMillis(1);

			// How many condition to hold 10% of the target transaction time
			int meanFor10Percent = (int) (targetMaxInMillis * meanRatePerMillis) / STREAM_RATIO_FOR_TARGET;

			// Ensure we add at least one item
			if (meanFor10Percent == 0) {
				// Transactions are very slow: handle at least one
				meanFor10Percent = 1;
			}

			return meanFor10Percent;
		}
	}

	public static int[] getStoreIds(IDatastoreSchemaMetadata metadata, Collection<? extends String> storeNames) {
		if (storeNames == null) {
			return new int[0];
		}

		// Prevent considering twice the same storeName
		return storeNames.stream().distinct().mapToInt(s -> metadata.getStoreId(s)).toArray();
	}
}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.datastore.test;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.stream.IntStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.annotations.Beta;
import com.google.common.base.Strings;
import com.google.common.collect.BiMap;
import com.google.common.collect.ImmutableBiMap;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Lists;
import com.google.common.collect.ObjectArrays;
import com.google.common.eventbus.EventBus;
import com.google.common.primitives.Ints;
import com.qfs.agg.IAggregationFunction;
import com.qfs.agg.impl.SumFunction;
import com.qfs.desc.IDatastoreSchemaDescription;
import com.qfs.desc.IDatastoreSchemaDescriptionPostProcessor;
import com.qfs.desc.IFieldDescription;
import com.qfs.desc.IReferenceDescription;
import com.qfs.desc.IStoreDescription;
import com.qfs.desc.IStoreDescriptionBuilder.ICanBuild;
import com.qfs.desc.IStoreDescriptionBuilder.IKeyed;
import com.qfs.desc.IStoreDescriptionBuilder.INamed;
import com.qfs.desc.IStoreDescriptionBuilder.IStaticKeyFields;
import com.qfs.desc.IStoreDescriptionBuilder.IUnkeyedTaggable;
import com.qfs.desc.impl.DatastoreSchemaDescription;
import com.qfs.desc.impl.DictionarizeObjectsPostProcessor;
import com.qfs.desc.impl.StoreDescriptionBuilder;
import com.qfs.literal.ILiteralType;
import com.qfs.security.impl.BranchPermissionsManager;
import com.qfs.store.IDatastore;
import com.qfs.store.build.IDatastoreBuilder;
import com.qfs.store.build.IDatastoreBuilder.IBuildableDatastore;
import com.qfs.store.transaction.ITransactionManager;
import com.quartetfs.biz.pivot.definitions.IActivePivotDescription;
import com.quartetfs.biz.pivot.definitions.IAggregatedMeasureDescription;
import com.quartetfs.biz.pivot.definitions.IAxisDimensionDescription;
import com.quartetfs.biz.pivot.definitions.IAxisHierarchyDescription;
import com.quartetfs.biz.pivot.definitions.IAxisLevelDescription;
import com.quartetfs.fwk.Registry;
import com.quartetfs.fwk.types.IPlugin;

import blasd.apex.server.config.cube.ApexCubeBuilder;
import blasd.apex.server.config.cube.IApexCubeBuilder;
import blasd.apex.server.config.description.ApexDescriptionHelper;
import blasd.apex.server.datastore.ApexDatastoreHelper;
import blasd.apex.server.datastore.condition.ApexQueryManagerMonitor;
import blasd.apex.server.datastore.updatewhere.IApexUpdateWhereProcedureWrapper;
import blasd.apex.server.loading.testdata.ApexTestDataGenerator;
import blasd.apex.server.loading.testdata.OneLineTemplate;
import blasd.apex.server.loading.transaction.ApexTuplizerHelper;
import blasd.apex.server.monitoring.loading.ApexDatastoreBuilder;
import blasd.apex.server.monitoring.loading.ApexDuplicateKeyWithinTransactionListener;
import blasd.apex.server.monitoring.loading.ApexTransactionManagerMonitoring;
import blasd.apex.server.test.pivot.ApexActivePivotLicenseHelper;

/**
 * 
 * @author Benoit Lacelle
 * 
 */
public class ApexTestDatastoreHelper {
	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexTestDatastoreHelper.class);

	/**
	 * Used to mark a measure not based over a Double type, even if used as measure
	 */
	public static final String NOT_DOUBLE = "_NotDouble_";

	// see LiteralTypePlugin
	// Registry.getPlugin(ILiteralType.class).valueOf(ILiteralType.DATE).getLiteral()
	@Beta
	public static final String DATE_LITERAL_TYPE = "Date";

	protected ApexTestDatastoreHelper() {
		// hidden
	}

	public static IStoreDescription createStoreDescription(String storeName,
			Map<? extends String, ? extends String> fieldNameToType,
			String... keyFields) {
		return ApexDescriptionHelper.createStoreDescription(storeName, fieldNameToType, keyFields);
	}

	/**
	 * 
	 * @param storeName
	 * @param fieldNameToType
	 *            a field name to a {@link ILiteralType}
	 * @param keyFields
	 * @return
	 */
	public static IStoreDescription createStoreDescription(String storeName,
			Map<? extends String, ? extends String> fieldNameToType,
			List<? extends String> keyFields) {
		return ApexDescriptionHelper.createStoreDescription(storeName, fieldNameToType, keyFields);
	}

	public static IStoreDescription createStoreDescription(String storeName,
			IActivePivotDescription pivotDescription,
			List<? extends String> keyFields) {
		Map<String, String> fieldNameToType = makeColumnTypes(pivotDescription);

		IStoreDescription storeDescription = createStoreDescription(storeName, fieldNameToType, keyFields);

		for (IAggregatedMeasureDescription nativeMeasure : pivotDescription.getMeasuresDescription()
				.getAggregatedMeasuresDescription()) {
			String fieldName = nativeMeasure.getFieldName();

			IFieldDescription field = storeDescription.getField(fieldName);
			ApexDescriptionHelper.upgradeToNullable(field);
		}

		return storeDescription;
	}

	public static IActivePivotDescription createCubeDescription(IStoreDescription storeDescription) {
		IPlugin<ILiteralType> literalTypePlugin = Registry.getPlugin(ILiteralType.class);

		return createCubeDescription(storeDescription,
				ImmutableBiMap.of(SumFunction.PLUGIN_KEY, SumFunction.PLUGIN_KEY),
				ImmutableSet.of(ILiteralType.FLOAT,
						ILiteralType.DOUBLE,
						ILiteralType.FLOAT_ARRAY,
						ILiteralType.DOUBLE_ARRAY),
				ImmutableSet.of(literalTypePlugin.valueOf(ILiteralType.STRING).getLiteral(),
						literalTypePlugin.valueOf(ILiteralType.STRING_ARRAY).getLiteral(),
						literalTypePlugin.valueOf(ILiteralType.OBJECT).getLiteral(),
						literalTypePlugin.valueOf(ILiteralType.OBJECT_ARRAY).getLiteral(),
						literalTypePlugin.valueOf(ILiteralType.DATE).getLiteral()));
	}

	@Beta
	public static IActivePivotDescription createCubeDescription(IStoreDescription storeDescription,
			BiMap<String, String> aggregationFunctionToNiceName,
			Set<String> literalTypesExcludedForLevel,
			Set<String> literalTypesExcludedForMeasure) {
		IApexCubeBuilder cubeBuilder = ApexCubeBuilder.newDescription();

		storeDescription.getFields().forEach(field -> {
			if (niceAsLevel(field) && !literalTypesExcludedForLevel.contains(field.getDataType())) {
				cubeBuilder.addHierarchyAndLevels(field.getName());
			}

			ILiteralType literalType = Registry.getPlugin(ILiteralType.class).valueOf(field.getDataType());

			if (!literalTypesExcludedForMeasure.contains(literalType.getLiteral())) {
				aggregationFunctionToNiceName.forEach((pluginKey, niceName) -> {
					String fullNiceName;
					if (Strings.isNullOrEmpty(niceName)) {
						fullNiceName = field.getName();
					} else {
						// Default naming: fieldName.aggregationPluginKey
						fullNiceName = field.getName() + "." + niceName;
					}

					// Keep all aggregates over the same field in the same folder
					cubeBuilder.addAggregatedMeasure(field.getName(), pluginKey)
							.setName(fullNiceName)
							.setFolder(field.getName());
				});
			}

		});

		return cubeBuilder.getActivePivotDescription();
	}

	@Beta
	private static boolean niceAsLevel(IFieldDescription field) {
		ILiteralType literalType = Registry.getPlugin(ILiteralType.class).valueOf(field.getDataType());

		if (literalType.isArray()) {
			LOGGER.debug("Skip {} as level as it is an array", field.getName());
			return false;
		} else if (field.isNullable() && field.getDefault() == null) {
			LOGGER.debug("Skip {} as level as it nullable with a null default value", field.getName());
			return false;
		} else {
			return true;
		}
	}

	public static IActivePivotDescription createCubeDescription(
			Map<String, String> fieldToLiteralTypeOrAggregationFunction) {
		IApexCubeBuilder cubeBuilder = ApexCubeBuilder.newDescription();

		for (Entry<String, String> field : fieldToLiteralTypeOrAggregationFunction.entrySet()) {
			if (Registry.getPlugin(IAggregationFunction.class).valueOf(field.getValue()) != null) {
				cubeBuilder.addAggregatedMeasure(field.getKey(), field.getValue());
			} else {
				ILiteralType literalType = Registry.getPlugin(ILiteralType.class).valueOf(field.getValue());

				if (niceForSum(literalType)) {
					cubeBuilder.addAggregatedMeasure(field.getKey(), SumFunction.PLUGIN_KEY);
				} else {
					cubeBuilder.addHierarchyAndLevels(field.getKey());
				}
			}
		}

		return cubeBuilder.getActivePivotDescription();
	}

	public static boolean niceForSum(IFieldDescription field) {
		ILiteralType literalType = Registry.getPlugin(ILiteralType.class).valueOf(field.getDataType());
		if (literalType == null) {
			return false;
		} else {
			return niceForSum(literalType);
		}
	}

	public static boolean niceForSum(ILiteralType literalType) {
		if (literalType == null) {
			// Typically happens in the pluginKey was not an ILiteralType pluginKey
			return false;
		} else if (ImmutableSet
				.of(ILiteralType.FLOAT, ILiteralType.DOUBLE, ILiteralType.FLOAT_ARRAY, ILiteralType.DOUBLE_ARRAY)
				.contains(literalType.key().toString())) {
			return true;
		} else {
			return false;
		}
	}

	// TODO: refactor with ApexActivePivotDescriptionHelper.makeSelectionDescription
	public static IActivePivotDescription createCubeDescription(IDatastoreSchemaDescription description,
			String mainStore) {
		IActivePivotDescription cubeDesc =
				createCubeDescription(ApexDescriptionHelper.findStore(mainStore, description.getStoreDescriptions()));

		IApexCubeBuilder cubeBuilder = ApexCubeBuilder.editDescription(cubeDesc);

		for (IReferenceDescription ref : description.getReferenceDescriptions()) {
			if (mainStore.equals(ref.getOwnerStore())) {
				IStoreDescription targetStore =
						ApexDescriptionHelper.findStore(ref.getTargetStore(), description.getStoreDescriptions());

				for (IFieldDescription field : targetStore.getFields()) {
					String fieldName = makeFieldName(ref.getName(), field.getName());

					if (niceForSum(field)) {
						cubeBuilder.addAggregatedMeasure(fieldName, SumFunction.PLUGIN_KEY);
					} else {
						cubeBuilder.addHierarchyAndLevels(fieldName);
					}
				}
			}
		}

		return cubeDesc;
	}

	public static final String makeFieldName(String firstRefOrFieldName, String... rest) {
		return ApexDatastoreHelper.joinFieldPath(firstRefOrFieldName, rest)
				.replace(IApexUpdateWhereProcedureWrapper.PROPERTY_SEPARATOR, '_');
	}

	public static final String makeFieldName(Iterable<? extends String> prefixes, String... rest) {
		return ApexDatastoreHelper.joinFieldPath(prefixes, rest)
				.replace(IApexUpdateWhereProcedureWrapper.PROPERTY_SEPARATOR, '_');
	}

	public static IDatastoreSchemaDescription prepareDescription(
			Collection<? extends IStoreDescription> storeDescriptions,
			Collection<? extends IReferenceDescription> referenceDescriptions) {
		if (referenceDescriptions == null) {
			referenceDescriptions = Collections.emptyList();
		}

		return new DatastoreSchemaDescription(storeDescriptions, referenceDescriptions);
	}

	public static IDatastoreSchemaDescription prepareDescription(
			Collection<? extends IStoreDescription> storeDescriptions,
			IReferenceDescription... refDescriptions) {
		return prepareDescription(storeDescriptions, Arrays.asList(refDescriptions));
	}

	public static int[] makeIncrementedArray(int nbEntries) {
		return IntStream.range(0, nbEntries).toArray();
	}

	public static List<Integer> makeIncrementedList(int nbEntries) {
		return Ints.asList(makeIncrementedArray(nbEntries));
	}

	public static Map<String, String> makeColumnTypes(IActivePivotDescription activePivotDescription) {
		// ApexPOJOStoreConfig expects a LinkedHashMap
		Map<String, String> columnNameToColumnType = new LinkedHashMap<String, String>();

		for (IAxisDimensionDescription d : activePivotDescription.getAxisDimensions().getValues()) {
			for (IAxisLevelDescription l : d.getLevels()) {
				columnNameToColumnType.put(l.getPropertyName(), null);
			}
			for (IAxisHierarchyDescription h : d.getHierarchies()) {
				for (IAxisLevelDescription l : h.getLevels()) {
					columnNameToColumnType.put(l.getPropertyName(), null);
				}
			}
		}

		for (IAggregatedMeasureDescription m : activePivotDescription.getMeasuresDescription()
				.getAggregatedMeasuresDescription()) {
			// Measures: prefer a Double, However, test may want to insert something else: null for Object
			String fieldName = m.getFieldName();

			String literalType;
			if (fieldName.contains(NOT_DOUBLE)) {
				literalType = null;
			} else {
				literalType = ILiteralType.DOUBLE;
			}
			columnNameToColumnType.put(fieldName, literalType);
		}

		return columnNameToColumnType;
	}

	public static ICanBuild loadStoreDescriptionBuilder(IStoreDescription storeDescription) {
		return loadStoreDescriptionBuilder(storeDescription.getName(), storeDescription);
	}

	public static ICanBuild loadStoreDescriptionBuilder(String newName, IStoreDescription storeDescription) {
		StoreDescriptionBuilder sdb = new StoreDescriptionBuilder();
		INamed named = sdb.withStoreName(newName);

		IUnkeyedTaggable withField = null;
		IKeyed keyed = null;

		for (IFieldDescription field : storeDescription.getFields()) {
			withField = named.withField(field.getName(), field.getDataType(), field.getDefault());

			if (storeDescription.getKeyFields().contains(field.getName())) {
				keyed = withField.asKeyField();
			}
		}

		if (withField == null) {
			throw new RuntimeException("There is not a single field in " + storeDescription);
		}

		IStaticKeyFields staticKeyFields;
		if (storeDescription.getKeyFields().isEmpty()) {
			staticKeyFields = withField.withoutKey();
		} else {
			staticKeyFields = null;
		}

		if (keyed == null) {
			return staticKeyFields;
		} else {
			return keyed;
		}
	}

	/**
	 * Build a {@link IDatastore} given a simple set of parameters
	 * 
	 * @param storeName
	 * @param fieldNameToType
	 *            a field name to a {@link ILiteralType}
	 * @param keyFields
	 * @return an {@link IDatastore}
	 */
	public static IDatastore buildApexDatastore(String storeName,
			Map<? extends String, ? extends String> fieldNameToType,
			List<? extends String> keyFields) {
		IStoreDescription sd = createStoreDescription(storeName, fieldNameToType, keyFields);

		return buildApexDatastore(sd);
	}

	public static IDatastore buildApexDatastore(String storeName,
			Map<? extends String, ? extends String> fieldNameToType,
			String... keyFields) {
		return buildApexDatastore(storeName, fieldNameToType, Arrays.asList(keyFields));
	}

	public static IDatastore buildDatastore(IDatastoreBuilder datastoreBuilder,
			Collection<? extends IStoreDescription> storeDescriptions,
			Collection<? extends IReferenceDescription> referenceDescriptions,
			IDatastoreSchemaDescriptionPostProcessor... datastoreSchemaPostProcessor) {
		IDatastoreSchemaDescription schemaDesc = prepareDescription(storeDescriptions, referenceDescriptions);

		return buildDatastore(datastoreBuilder, schemaDesc, datastoreSchemaPostProcessor);
	}

	public static IDatastore buildDatastore(IDatastoreBuilder datastoreBuilder,
			IDatastoreSchemaDescription schemaDesc,
			IDatastoreSchemaDescriptionPostProcessor... datastoreSchemaPostProcessor) {
		// As we are in tests, we can enforce license here
		ApexActivePivotLicenseHelper.ensureLicenseWithEnv();

		IBuildableDatastore builder = datastoreBuilder.setSchemaDescription(schemaDesc);

		if (datastoreSchemaPostProcessor != null) {
			for (IDatastoreSchemaDescriptionPostProcessor pp : datastoreSchemaPostProcessor) {
				builder.addSchemaDescriptionPostProcessors(pp);
			}
		}

		IDatastore datastore = builder.build();

		// We .reset instead of .init as we are in a unit-test
		ApexTuplizerHelper.resetStaticDatastore(datastore.getSchemaMetadata());

		return datastore;
	}

	public static EventBus latestImplicitEventBus = null;

	/**
	 * 
	 * @param schemaDesc
	 * @return an IDatastore with nice default behavior like column dictionarization
	 */
	public static IDatastore buildApexDatastore(IDatastoreSchemaDescription schemaDesc,
			IDatastoreSchemaDescriptionPostProcessor... postProcessors) {
		IDatastoreSchemaDescriptionPostProcessor[] allPostProcessors =
				ObjectArrays.concat(postProcessors, new DictionarizeObjectsPostProcessor());

		EventBus eventBus = new EventBus();

		latestImplicitEventBus = eventBus;
		return buildDatastore(makeDefaultDatastoreBuilder(eventBus), schemaDesc, allPostProcessors);
	}

	public static IDatastore buildApexDatastore(IStoreDescription firstStore,
			IStoreDescription secondStore,
			IReferenceDescription firstReferences,
			IReferenceDescription... moreReferences) {
		return buildApexDatastore(Arrays.asList(firstStore, secondStore),
				Lists.asList(firstReferences, moreReferences));
	}

	public static IDatastore buildApexDatastore(Collection<? extends IStoreDescription> stores,
			Collection<? extends IReferenceDescription> references) {
		// As we are in tests, we can enforce license here
		ApexActivePivotLicenseHelper.ensureLicenseWithEnv();

		return buildApexDatastore(prepareDescription(stores, references));
	}

	public static IDatastore buildApexDatastore(IStoreDescription firstStore, IStoreDescription... otherStores) {
		return buildApexDatastore(Lists.asList(firstStore, otherStores), Collections.emptyList());
	}

	public static void insertRandomData(ITransactionManager transactionManager, String storeName, int nbRows) {
		OneLineTemplate oneLineTemplate = new OneLineTemplate(storeName, null);

		new ApexTestDataGenerator(transactionManager).insertLines(oneLineTemplate, nbRows);
	}

	public static IDatastoreBuilder makeDefaultDatastoreBuilder(EventBus eventBus) {
		ApexDuplicateKeyWithinTransactionListener duplicateListener = new ApexDuplicateKeyWithinTransactionListener();
		ApexTransactionManagerMonitoring transactionMonitoring =
				new ApexTransactionManagerMonitoring(eventBus::post, duplicateListener);

		ApexDatastoreBuilder builder = new ApexDatastoreBuilder(new ApexQueryManagerMonitor(), transactionMonitoring);

		builder.setBranchPermissionsManager(BranchPermissionsManager.forTests());

		return builder;
	}

}

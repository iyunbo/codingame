/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.loading.testdata;

/**
 * The goal of this class is not minimize transient memory. Is it still relevant with latest usage of
 * PrefixModuloStringGenerator?
 * 
 * @author Benoit Lacelle
 *
 */
public class ConcatenatedStrings implements Comparable<ConcatenatedStrings> {
	public static final int STRING_HASH = 31;

	protected final CharSequence prefix;
	protected final long suffix;

	public ConcatenatedStrings(CharSequence prefix, long suffix) {
		this.prefix = prefix;
		this.suffix = suffix;
	}

	@Override
	public String toString() {
		return prefix + Long.toString(suffix);
	}

	@Override
	public int compareTo(ConcatenatedStrings o) {
		return this.toString().compareTo(o.toString());
	}

	@Override
	public int hashCode() {
		int hash = prefix.hashCode();

		String suffixString = Long.toString(suffix);
		for (int i = 0; i < suffixString.length(); i++) {
			hash = STRING_HASH * hash + suffixString.charAt(i);
		}

		return hash;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		ConcatenatedStrings other = (ConcatenatedStrings) obj;
		if (prefix == null) {
			if (other.prefix != null) {
				return false;
			}
		} else if (!prefix.equals(other.prefix) && !prefix.toString().equals(other.prefix.toString())) {
			return false;
		}
		if (suffix != other.suffix) {
			return false;
		}
		return true;
	}

}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.datastore.search;

import java.util.Objects;

import com.qfs.store.record.IRecord;
import com.qfs.store.record.IRecordFormat;

/**
 * An AObjectRecordReader over a simple Object[]
 * 
 * @author Benoit Lacelle
 *
 */
// We add Cloneable because PMD complains. It is anyway brought by IRecordReader
public class ApexArrayObjectRecordReader extends AApexObjectRecordReader implements Cloneable {

	protected final IRecordFormat recordFormat;
	protected final Object[] underlyingArray;

	public ApexArrayObjectRecordReader(IRecordFormat recordFormat, Object... underlyingArray) {
		this.recordFormat = recordFormat;
		this.underlyingArray = underlyingArray;

		Objects.requireNonNull(underlyingArray);
		if (underlyingArray.length != recordFormat.getFieldCount()) {
			throw new RuntimeException("Can not build an array of size=" + underlyingArray.length
					+ " over recordFOrmat with size="
					+ recordFormat.getFieldCount());
		}

		if (underlyingArray.length == 1 && underlyingArray[0] instanceof Object[]) {
			throw new RuntimeException("Can not set an array as single field value");
		}
	}

	@Override
	public Object read(int position) {
		if (position >= 0 && position < underlyingArray.length) {
			return underlyingArray[position];
		} else {
			throw new IllegalArgumentException(position + " should be 0");
		}
	}

	@Override
	public int readInt(int position) {
		return ((Number) read(position)).intValue();
	}

	@Override
	public boolean isNull(int position) {
		return read(position) == null;
	}

	// TODO use super.clone
	@Override
	public IRecord clone() { // NOPMD: TODO
		return new ApexArrayObjectRecordReader(recordFormat, underlyingArray.clone());
	}

	@Override
	public IRecordFormat getFormat() {
		return recordFormat;
	}

}
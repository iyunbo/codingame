/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.datastore.updatewhere;

import java.util.Collection;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedResource;

import com.google.common.collect.Lists;
import com.qfs.chunk.IArrayReader;
import com.qfs.chunk.IArrayWriter;
import com.qfs.condition.ICondition;
import com.qfs.condition.impl.BaseConditions;
import com.qfs.dic.ISchemaDictionaryProvider;
import com.qfs.store.IDatastoreSchemaMetadata;
import com.qfs.store.IReadableDatastore;
import com.qfs.store.record.IRecordFormat;
import com.qfs.store.selection.ISelection;
import com.qfs.store.selection.impl.Selection;
import com.qfs.store.transaction.ITransactionManager.IUpdateWhereProcedure;

import blasd.apex.server.datastore.ApexDatastoreHelper;
import blasd.apex.server.loading.transaction.IApexCountingUpdateWhereProcedure;

/**
 * Helps configuring an {@link IUpdateWhereProcedure}, typically to manage indexes of read and written fields
 * 
 * @author Benoit Lacelle
 *
 */
@ManagedResource
public abstract class AApexSimpleUpdateWhereWrapper
		implements IApexUpdateWhereProcedureWrapper, IApexCountingUpdateWhereProcedure, IHasWrittenFields {
	private static final long serialVersionUID = 7280733220507612127L;

	protected static final Logger LOGGER = LoggerFactory.getLogger(AApexSimpleUpdateWhereWrapper.class);

	protected final AtomicLong nbUpdatedRow = new AtomicLong();
	protected final ICondition condition;

	protected final ISelection selection;

	/**
	 * the index of a field path as defined in ISelection
	 */
	private final AtomicReference<int[]> inputFieldPathIndexes = new AtomicReference<>();

	protected final int[] outputFieldIndexes;
	protected final Object[] outputDefaultValues;

	// TODO: Handle missing fields
	public AApexSimpleUpdateWhereWrapper(IDatastoreSchemaMetadata datastoreMetadata,
			ISchemaDictionaryProvider dictionaryProvider,
			String storeName,
			ICondition condition,
			Collection<? extends String> inputFieldPathes,
			Collection<? extends String> ouputFields) {
		this(new Selection(storeName, inputFieldPathes.toArray(new String[0])),
				condition,
				ApexDatastoreHelper.getFieldIndexes(datastoreMetadata, storeName, ouputFields),
				ApexDatastoreHelper.getDefaultValues(datastoreMetadata, dictionaryProvider, storeName, ouputFields));
	}

	public AApexSimpleUpdateWhereWrapper(IReadableDatastore datastore,
			String storeName,
			Collection<? extends String> inputFieldPathes,
			Collection<? extends String> ouputFields) {
		this(datastore.getSchemaMetadata(),
				datastore.getDictionaries(),
				storeName,
				BaseConditions.TRUE,
				inputFieldPathes,
				ouputFields);
	}

	public AApexSimpleUpdateWhereWrapper(IReadableDatastore datastore,
			String storeName,
			ICondition condition,
			Collection<? extends String> inputFieldPathes,
			Collection<? extends String> ouputFields) {
		this(datastore
				.getSchemaMetadata(), datastore.getDictionaries(), storeName, condition, inputFieldPathes, ouputFields);
	}

	public AApexSimpleUpdateWhereWrapper(ISelection selection,
			ICondition condition,
			int[] outputFieldIndexes,
			Object[] outputDefaultValues) {
		this.selection = selection;
		this.condition = condition;
		this.outputFieldIndexes = outputFieldIndexes;
		this.outputDefaultValues = outputDefaultValues;
	}

	@ManagedAttribute
	@Override
	public boolean getHasReferencedFields() {
		// TODO: compute once and for all?
		return ApexUpdateWhereProcedureWrapper.hasReferencedFields(getSelection());
	}

	@Override
	public ISelection getSelection() {
		return selection;
	}

	@Override
	public ICondition getCondition() {
		return condition;
	}

	@Override
	public IApexCountingUpdateWhereProcedure getUpdateWhere() {
		return this;
	}

	@ManagedAttribute
	@Override
	public long getNbUpdatedRow() {
		return nbUpdatedRow.get();
	}

	@Override
	public void execute(IArrayReader reader, IArrayWriter writer) {
		// Register one more row is updated
		nbUpdatedRow.incrementAndGet();

		// Do the actual update process
		doUpdate(reader, writer);
	}

	/**
	 * 
	 * @param reader
	 *            an {@link IArrayReader} whilding the selected fieldPathes for matching rows
	 * @param writer
	 *            an {@link IArrayWriter} holding the whole row associated to the updated entry
	 */
	protected abstract void doUpdate(IArrayReader reader, IArrayWriter writer);

	@Deprecated
	public void init(IRecordFormat selectionFormat) {
		// We keep this for backward compatibility
		LOGGER.debug("You should rely on .init(selectionFormat, storeFormat)");
	}

	@Override
	public void init(IRecordFormat selectionFormat, IRecordFormat storeFormat) {
		// As .init is called once per partition, one partition must never
		// replace a fulled int[] by an empty int[]
		inputFieldPathIndexes.compareAndSet(null,
				ApexDatastoreHelper.getFieldIndexes(selectionFormat,
						Lists.transform(selection.getFields(), input -> input.getExpression())));

		// We call this method which may have been overridden in custom code
		init(selectionFormat);
	}

	/**
	 * 
	 * @param readFieldPath
	 * @return the index of a field path in the IArrayReader
	 */
	public int getReadFieldIndex(String readFieldPath) {
		int indexInSelected = getRawReadFieldIndex(readFieldPath);

		return getRawReadFieldIndex(indexInSelected);
	}

	protected int getRawReadFieldIndex(String readFieldPath) {
		return Lists.transform(selection.getFields(), input -> input.getExpression()).indexOf(readFieldPath);
	}

	public int getReadFieldIndex(int indexInSelected) {
		return getRawReadFieldIndex(indexInSelected);
	}

	public int getRawReadFieldIndex(int indexInSelected) {
		if (indexInSelected == -1) {
			return -1;
		} else {
			return inputFieldPathIndexes.get()[indexInSelected];
		}
	}

	public int getOutputFieldIndex(IDatastoreSchemaMetadata datastoreMetadata, String fieldName) {
		return datastoreMetadata.getFieldIndex(selection.getBaseStore(), fieldName);
	}

	/**
	 * 
	 * @param indexInSelectedOutput
	 * @return the index in the IArrayWriter of the field in input index in the output fields provided in wrapper
	 *         constructor
	 */
	public int getOutputFieldIndex(int indexInSelectedOutput) {
		return outputFieldIndexes[indexInSelectedOutput];
	}

	/**
	 * @deprecated use .getOutputFieldIndex(int)
	 */
	@Deprecated
	@Override
	public int[] writtenFields() {
		return outputFieldIndexes;
	}

	// https://support.quartetfs.com/jira/browse/APS-7956
	// We manage default values manually as writting null would lead to an NPE
	protected void writeNull(IArrayWriter writableArray, int index) {
		if (index > outputFieldIndexes.length) {
			throw new ArrayIndexOutOfBoundsException(index + " is above max=" + outputFieldIndexes.length);
		}
		writableArray.write(outputFieldIndexes[index], outputDefaultValues[index]);
	}

	@Override
	public String toString() {
		String baseToString = this.getClass().getName() + " on " + getSelection();

		if (!getCondition().equals(BaseConditions.True())) {
			baseToString += " restricted to " + getCondition();
		}

		return baseToString;
	}

	public static AApexSimpleUpdateWhereWrapper makeSimple(IReadableDatastore datastore,
			String storeName,
			Collection<? extends String> inputFieldPathes,
			Collection<? extends String> ouputFields,
			IApexSimpleUpdateWhereRowConsumer rowConsumer) {
		return new AApexSimpleUpdateWhereWrapper(datastore, storeName, inputFieldPathes, ouputFields) {
			private static final long serialVersionUID = 9079968731220091770L;

			@Override
			protected void doUpdate(IArrayReader reader, IArrayWriter writer) {
				rowConsumer.doUpdate(this, reader, writer);
			}
		};
	}
}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.datastore.updatewhere;

import com.qfs.chunk.IArrayReader;
import com.qfs.chunk.IArrayWriter;
import com.qfs.condition.ICondition;
import com.qfs.store.impl.DatastoreUpdateWhere;
import com.qfs.store.record.IRecordFormat;
import com.qfs.store.selection.ISelection;
import com.qfs.store.transaction.ITransactionManager.IUpdateWhereProcedure;
import com.quartetfs.fwk.impl.BaseProperty;

import blasd.apex.server.loading.transaction.IApexCountingUpdateWhereProcedure;

/**
 * Wrap together all the information necessary to run an {@link IUpdateWhereProcedure}
 * 
 * @author Benoit Lacelle
 * @see DatastoreUpdateWhere seems like the not OOP-friendly DatastoreUpdateWhere
 */
public interface IApexUpdateWhereProcedureWrapper {
	char PROPERTY_SEPARATOR = BaseProperty.SEPARATOR.charAt(0);

	/**
	 * In some cases, it may appear necessary to apply on updateWhere for given condition, even if the updateWhere does
	 * nothing. Typically used to enforce triggering continuousUpdateWhere
	 */
	IUpdateWhereProcedure EMPTY_UPDATE_WHERE = new IUpdateWhereProcedure() {
		private static final long serialVersionUID = -2412323554113849188L;

		@Override
		public void init(IRecordFormat selectionFormat, IRecordFormat storeFormat) {
			// Nothing to do
		}

		@Override
		public void execute(IArrayReader paramIArrayReader, IArrayWriter paramIWritableArray) {
			// Nothing to do
		}
	};

	/**
	 * 
	 * @return the {@link ISelection} holding the column to read when matching entries
	 */
	ISelection getSelection();

	/**
	 * 
	 * @return an {@link ICondition} to restrict which rows to update
	 */
	ICondition getCondition();

	/**
	 * 
	 * @return a core {@link IUpdateWhereProcedure} holding the update logic
	 */
	IApexCountingUpdateWhereProcedure getUpdateWhere();

	/**
	 * 
	 * @return how many rows have been considered by this procedure
	 */
	long getNbUpdatedRow();
}

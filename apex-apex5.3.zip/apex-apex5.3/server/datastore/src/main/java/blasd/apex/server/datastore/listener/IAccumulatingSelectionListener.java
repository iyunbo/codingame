/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.datastore.listener;

import com.qfs.store.selection.ISelectionListener;

/**
 * An IAccumulatingSelectionListener listens to transaction on an ISelection, and accumulates impacts. The accumulated
 * impact available to IApexAccumulatedSelectionListener
 * 
 * @author Benoit Lacelle
 * 
 * @see IApexAccumulatedSelectionListener
 *
 * @param <T>
 */
public interface IAccumulatingSelectionListener<T> extends ISelectionListener {

	void registerListener(IApexAccumulatedSelectionListener<T> listener);

	void unregisterListener(IApexAccumulatedSelectionListener<T> listener);

}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.datastore.search;

import java.util.List;

import com.google.common.annotations.Beta;
import com.google.common.base.Supplier;
import com.google.common.base.Suppliers;
import com.qfs.dic.IDictionary;
import com.qfs.store.IDatastoreSchemaVersion;
import com.qfs.store.IStoreFormat;
import com.qfs.store.IStoreMetadata;
import com.qfs.store.IStorePartitionVersion;
import com.qfs.store.IStoreVersion;
import com.qfs.store.impl.SchemaHelper;
import com.qfs.store.record.IRecordFormat;
import com.qfs.store.record.IRecordReader;
import com.qfs.store.record.IWritableRecord;
import com.qfs.store.record.impl.DictionaryRecordReader;
import com.qfs.store.record.impl.Records;
import com.qfs.store.record.impl.Records.IDictionaryProvider;

import gnu.trove.list.TIntList;

/**
 * Enable to make searches directly from the int[] of dictionarized key fields
 * 
 * @author Benoit Lacelle
 * @see CompiledGetByPrimaryIndexQuery
 */
@Beta
public class ApexCompiledGetByPrimitivePrimaryIndexQuery implements IApexCompiledGetByPrimaryIndexQuery {
	protected final Supplier<Records.IDictionaryProvider> primaryKeyDictionaries;
	protected final Records.IDictionaryProvider resultDictionaries;
	protected final int storeId;
	protected final int primaryIndexId;
	protected final IRecordFormat resultFormat;
	protected final IRecordFormat undictionarizedResultFormat;
	protected final int[] selectedFieldIndexes;

	// 2147483647
	private static final int NO_ROW = Integer.MAX_VALUE;

	public ApexCompiledGetByPrimitivePrimaryIndexQuery(final IStoreMetadata store,
			final Records.IDictionaryProvider storeDictionaries,
			final int primaryIndex,
			List<String> selectedFields) {
		if (store.getPrimaryFields().length <= primaryIndex) {
			throw new IllegalArgumentException("Invalid primary index " + primaryIndex);
		}
		this.storeId = store.getId();
		this.resultFormat = SchemaHelper.getFormat(store, selectedFields, selectedFields);

		{
			IDictionary<?>[] resultDics = new IDictionary[selectedFields.size()];
			this.selectedFieldIndexes = new int[selectedFields.size()];
			for (int i = 0; i < resultDics.length; ++i) {
				int fieldId = store.getStoreFormat().getRecordFormat().getFieldIndex(selectedFields.get(i));
				if (fieldId < 0) {
					throw new IllegalArgumentException(
							selectedFields.get(i) + " is not a field of store " + store.getName());
				}
				resultDics[i] = storeDictionaries.getDictionary(fieldId);
				this.selectedFieldIndexes[i] = fieldId;
			}
			this.resultDictionaries = new Records.DictionaryProviderFromArray(resultDics);
		}

		// We lazily load primaryKeyDictionaries as it is not used in .getByIndexes
		primaryKeyDictionaries = Suppliers.memoize(() -> {
			TIntList keyIdx = store.getPrimaryFields()[primaryIndex];
			IDictionary<?>[] resultDics = new IDictionary[keyIdx.size()];
			for (int i = 0; i < resultDics.length; ++i) {
				int fieldId = keyIdx.get(i);
				if (fieldId < 0) {
					throw new IllegalArgumentException("PrimaryIndex #" + primaryIndex + " is not valid: " + keyIdx);
				}
				resultDics[i] = storeDictionaries.getDictionary(fieldId);
			}
			return new Records.DictionaryProviderFromArray(resultDics);

		});
		this.undictionarizedResultFormat = SchemaHelper.undictionarize(this.resultFormat, this.resultDictionaries);
		this.primaryIndexId = primaryIndex;
	}

	@Override
	public IRecordReader run(IDatastoreSchemaVersion schema, int... primitiveKey) {
		IStoreVersion store = schema.getStore(this.storeId);
		IStoreMetadata metadata = store.getMetadata();
		IStoreFormat storeFormat = metadata.getStoreFormat();
		TIntList keyIdx = metadata.getPrimaryFields()[this.primaryIndexId];

		if (keyIdx.size() != primitiveKey.length) {
			throw new IllegalArgumentException("The key does not have the right size, expected " + keyIdx.size()
					+ " was "
					+ primitiveKey.length
					+ ". Keys are: "
					+ schema.getMetadata().getKeyFields(metadata.getName()));
		}

		IWritableRecord keyRecord = storeFormat.getKeyRecordFormat().newRecord();
		for (int i = 0; i < keyIdx.size(); ++i) {
			int f = keyIdx.get(i);

			int v = primitiveKey[i];
			if (v < 0) {
				// We queried with a -1 inside the primary: can not match any row
				return null;
			}

			// Write the primitive
			keyRecord.writeInt(f, v);
		}

		int partition = metadata.getPartitioning().getPartitionId(keyRecord);

		IStorePartitionVersion storePartition = store.getPartition(partition);
		if (storePartition == null) {
			return null;
		}
		int rowIdx = storePartition.getPrimaryIndexes()[this.primaryIndexId].getRow(keyRecord);

		if (rowIdx == NO_ROW) {
			return null;
		}

		IRecordReader r = storePartition.getRecords().read(rowIdx);

		IWritableRecord result = this.resultFormat.newRecord();
		for (int i = 0; i < this.selectedFieldIndexes.length; ++i) {
			int f = this.selectedFieldIndexes[i];
			result.write(i, r.read(f));
		}
		DictionaryRecordReader dr =
				new DictionaryRecordReader(this.undictionarizedResultFormat, this.resultDictionaries);
		dr.setRawRecord(result);

		return dr;
	}

	@Override
	public IRecordReader get(IDatastoreSchemaVersion schema, Object... parameters) {
		int[] indexes = convertToIndexes(parameters);
		return run(schema, indexes);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	protected int[] convertToIndexes(Object[] parameters) {
		IDictionaryProvider dictionaries = primaryKeyDictionaries.get();

		int[] primitives = new int[parameters.length];

		try {
			for (int i = 0; i < parameters.length; i++) {
				Object value = parameters[i];

				// Cast as IDictionary does not accept .get(Object) (unlike Map.get does)
				primitives[i] = ((IDictionary) dictionaries.getDictionary(i)).getPosition(value);
			}

		} catch (ArrayIndexOutOfBoundsException e) {
			throw new IllegalArgumentException(parameters + " seems not a valid primaryKey for storeId=" + storeId);
		}
		return primitives;
	}
}
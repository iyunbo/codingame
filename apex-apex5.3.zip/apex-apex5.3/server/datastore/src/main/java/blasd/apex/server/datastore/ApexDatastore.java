/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.datastore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;

import com.google.common.base.Joiner;
import com.google.common.util.concurrent.ListenableFuture;
import com.qfs.store.IDatastoreVersion;
import com.qfs.store.IMultiVersionDatastoreSchema;
import com.qfs.store.IReadableDatastore;
import com.qfs.store.ISquashableDatastoreSchemaVersion;
import com.qfs.store.impl.Datastore;
import com.qfs.store.log.ILogHandler;
import com.qfs.store.log.impl.LogWriteException;
import com.qfs.store.query.ICompiledQuery;
import com.qfs.store.query.IQueryVisitor;
import com.qfs.store.selection.IContinuousCompositeSelection;
import com.qfs.store.selection.ISelection;
import com.qfs.store.selection.ISelectionField;
import com.qfs.store.transaction.IDatastoreSchemaTransactionManager;
import com.qfs.store.transaction.ITransactionManager;

import blasd.apex.server.datastore.condition.ApexQueryManagerVersion;
import blasd.apex.server.datastore.condition.IApexQueryManagerMonitor;
import blasd.apex.server.loading.transaction.ApexTuplizerHelper;
import blasd.apex.toggle.ApexToggler;
import cormoran.pepper.thread.PepperExecutorsHelper;

/**
 * Use {@link ApexDatastoreVersion} to enable usage of {@link ApexQueryManagerVersion} and {@link IReadableDatastore}
 * search monitoring
 * 
 * @author Benoit Lacelle
 * 
 */
@ManagedResource
public class ApexDatastore extends Datastore {

	protected final IApexQueryManagerMonitor apexQueryMonitor;
	protected final IQueryVisitor<ICompiledQuery> queryCompiler;

	public ApexDatastore(IMultiVersionDatastoreSchema schema,
			ITransactionManager transactionManager,
			IApexQueryManagerMonitor apexQueryMonitor,
			IQueryVisitor<ICompiledQuery> queryCompiler) throws LogWriteException {
		super(schema, transactionManager);

		this.apexQueryMonitor = apexQueryMonitor;
		this.queryCompiler = queryCompiler;
	}

	@Override
	protected ITransactionManager createTransactionManager(IDatastoreSchemaTransactionManager schemaTransactionManager,
			ILogHandler logHandler) {
		throw new UnsupportedOperationException(
				"Deactivated as this method is called in a deactivated parent class constructor");
	}

	@Override
	protected IDatastoreVersion createVersion(ISquashableDatastoreSchemaVersion schemaVersion) {
		if (ApexToggler.useApexDatastoreVersion()) {
			return new ApexDatastoreVersion(this.schema.getHead(), apexQueryMonitor, queryCompiler);
		} else {
			return super.createVersion(schemaVersion);
		}
	}

	@ManagedOperation
	public Map<String, Set<String>> getListeners() {
		Map<String, Set<String>> storeToSelections = new HashMap<>();

		for (IContinuousCompositeSelection listener : getSchema().getListeners()) {
			for (int selectionIndex = 0; selectionIndex < listener.getSelectionCount(); selectionIndex++) {
				ISelection selection = listener.getSelection(selectionIndex);

				if (!storeToSelections.containsKey(selection.getBaseStore())) {
					storeToSelections.put(selection.getBaseStore(), new TreeSet<String>());
				}

				storeToSelections.get(selection.getBaseStore())
						.add(Joiner.on('|').join(extractFieldExpressions(selection.getFields())));
			}
		}

		return storeToSelections;
	}

	public static List<String> extractFieldExpressions(List<? extends ISelectionField> selectionFields) {
		List<String> expressions = new ArrayList<>();

		for (ISelectionField sleection : selectionFields) {
			expressions.add(sleection.getExpression());
		}

		return expressions;
	}

	@Override
	public void stop() {
		// Stopping the datastore may never complete. For instance if a commit is never-completing. We prefer to
		// force-leaving the JVM after a given timeout instead of having a unit-test never finishing
		stopWithTimeout(1, TimeUnit.MINUTES);
	}

	protected void stopWithTimeout(int timeout, TimeUnit unit) {
		ListenableFuture<?> future =
				PepperExecutorsHelper.newSingleThreadExecutor("StopDatastore").submit(() -> super.stop());

		try {
			future.get(timeout, unit);
		} catch (InterruptedException | ExecutionException e) {
			throw new RuntimeException("Failure stopping the datastore", e);
		} catch (TimeoutException e) {
			// We throw to ensure the parent unit test fails
			throw new RuntimeException("The datastore has not stopped after 1 minute", e);
		} finally {
			// We should clear static reference to this datastore right away as we know we will not tuplize anything for
			// it
			// anymore
			ApexTuplizerHelper.clearStaticDatastore();
		}
	}
}

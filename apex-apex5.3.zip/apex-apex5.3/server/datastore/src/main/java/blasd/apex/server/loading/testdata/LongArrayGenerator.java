/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.loading.testdata;

/**
 * IDatastore column generate for long[]
 * 
 * @author Benoit Lacelle
 *
 */
public class LongArrayGenerator implements IColumnarGenerator<long[]> {
	protected final int size;
	protected final int modulo;

	public LongArrayGenerator(int size, int modulo) {
		this.size = size;
		this.modulo = modulo;
	}

	@Override
	public long[] generate(long generationIndex) {
		long[] vector = new long[size];

		for (int i = 0; i < size; i++) {
			vector[i] = generateLong(i, generationIndex);
		}
		// Arrays.fill(vector, );

		return vector;
	}

	protected long generateLong(int i, long generationIndex) {
		return (i + generationIndex) % modulo;
	}
}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.datastore.search;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Supplier;

import com.qfs.store.IDatastoreSchema;
import com.qfs.store.IDatastoreSchemaVersion;
import com.qfs.store.IStoreMetadata;
import com.qfs.store.query.IQueryRunner;
import com.qfs.store.query.impl.AQueryRunnerSpy;
import com.qfs.store.query.impl.QueryRunner;
import com.qfs.store.query.impl.TransactionQueryRunner;
import com.qfs.store.record.IRecordReader;
import com.qfs.store.record.impl.Records;

import blasd.apex.server.datastore.ApexDatastoreHelper;

/**
 * CompiledGetByPrimaryIndexQuery consumed a lot of CPU and memory by relying on SchemaHelper.getFormat
 * 
 * This prepared statement existed before the core DatastoreQueryHelper.createGetByPrimaryIndexQuery(IDatastoreVersion,
 * String, String[], List<String>)
 * 
 * We keep it as it is simpler to use
 * 
 * @author blacelle112212
 *
 */
public class ApexDatastoreByKeyQueryPreparator implements IsPrepared<Optional<IRecordReader>> {
	protected final Supplier<? extends IQueryRunner> queryRunner;
	protected final String storeName;
	protected final IStoreMetadata storeMetadata;

	protected final IApexCompiledGetByPrimaryIndexQuery compiledQuery;
	protected final int keyFieldsSize;

	protected ApexDatastoreByKeyQueryPreparator(Supplier<? extends IQueryRunner> queryRunner,
			String storeName,
			List<? extends String> selectedFields) {
		this.queryRunner = queryRunner;
		this.storeName = storeName;

		IDatastoreSchema<?, ?> schema = AQueryRunnerSpy.getSchema(queryRunner.get());
		storeMetadata = schema.getStore(storeName).getMetadata();
		Records.IDictionaryProvider dictionaries = schema.getDictionaries().getStoreDictionaries(storeName);

		keyFieldsSize = storeMetadata.getStoreFormat().getKeyFields().length;
		if (keyFieldsSize == 0) {
			throw new IllegalArgumentException("The store " + storeName + " has no key field!");
		}

		compiledQuery = new ApexCompiledGetByPrimitivePrimaryIndexQuery(storeMetadata,
				dictionaries,
				0,
				Collections.unmodifiableList(selectedFields));
	}

	protected final class ApexDatastoreByKeyQueryRunner {

		protected final int[] indexes;
		protected final Object[] parameters;

		public ApexDatastoreByKeyQueryRunner(int[] indexes) {
			this.indexes = indexes;
			this.parameters = null;

			checkParameters();
		}

		public ApexDatastoreByKeyQueryRunner(Object[] parameters) {
			this.indexes = null;
			this.parameters = parameters;
		}

		public ApexDatastoreByKeyQueryRunner(Map<? extends String, ?> parameters) {
			this.indexes = null;
			this.parameters = ApexDatastoreHelper.buildKeyTuple(storeMetadata.getStoreFormat(), parameters);
		}

		private void checkParameters() {
			if (parameters != null && keyFieldsSize != parameters.length) {
				throw new IllegalArgumentException("The key does not have the right size, expected " + keyFieldsSize
						+ " was "
						+ parameters.length);
			}
			if (indexes != null && keyFieldsSize != indexes.length) {
				throw new IllegalArgumentException(
						"The key does not have the right size, expected " + keyFieldsSize + " was " + indexes.length);
			}
		}

		public IRecordReader asRecordReader() {
			if (indexes != null) {
				return compiledQuery.run(getDatastoreSchemaVersion(), indexes);
			} else {
				return compiledQuery.get(getDatastoreSchemaVersion(), parameters);
			}
		}

	}

	@Override
	public Optional<IRecordReader> match(Map<? extends String, ?> parameters) {
		ApexDatastoreByKeyQueryRunner runner = new ApexDatastoreByKeyQueryRunner(parameters);

		final IRecordReader recordReader = runner.asRecordReader();

		return optionalFromRecordReader(recordReader);
	}

	public IDatastoreSchemaVersion getDatastoreSchemaVersion() {
		IQueryRunner queryRunner = getQueryRunner();

		if (queryRunner instanceof QueryRunner) {
			return AQueryRunnerSpy.getSchema(((QueryRunner) queryRunner));
		} else if (queryRunner instanceof TransactionQueryRunner) {
			return AQueryRunnerSpy.getSchema(((TransactionQueryRunner) queryRunner)).getHead();
		} else {
			throw new RuntimeException("Not-handlded : " + queryRunner);
		}
	}

	public IQueryRunner getQueryRunner() {
		return queryRunner.get();
	}

	@Override
	public Optional<IRecordReader> match(Object... parameters) {
		ApexDatastoreByKeyQueryRunner runner = new ApexDatastoreByKeyQueryRunner(parameters);

		final IRecordReader recordReader = runner.asRecordReader();

		return optionalFromRecordReader(recordReader);
	}

	@Override
	public Optional<IRecordReader> matchIndexes(int... indexes) {
		ApexDatastoreByKeyQueryRunner runner = new ApexDatastoreByKeyQueryRunner(indexes);

		final IRecordReader recordReader = runner.asRecordReader();

		return optionalFromRecordReader(recordReader);
	}

	protected Optional<IRecordReader> optionalFromRecordReader(final IRecordReader recordReader) {
		if (recordReader == null) {
			// Return null, and not a IRecordReader which would itself
			// return null
			return Optional.empty();
		} else {
			return Optional.of(recordReader);
		}
	}

}
/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.datastore.updatewhere;

import com.qfs.chunk.IArrayWriter;

/**
 * Facilitate the implementation if IArrayWriter proxy by providing default implementations for all methods
 * 
 * @author Benoit Lacelle
 *
 */
public class ArrayWriterDecorator implements IArrayWriter {
	protected final IArrayWriter decorated;

	public ArrayWriterDecorator(IArrayWriter decorated) {
		this.decorated = decorated;
	}

	@Override
	public void write(int index, Object newValue) {
		decorated.write(index, newValue);
	}

	@Override
	public void writeBoolean(int index, boolean newValue) {
		decorated.write(index, newValue);
	}

	@Override
	public void writeInt(int index, int newValue) {
		decorated.write(index, newValue);
	}

	@Override
	public void writeLong(int index, long newValue) {
		decorated.write(index, newValue);
	}

	@Override
	public void writeDouble(int index, double newValue) {
		decorated.write(index, newValue);
	}

	@Override
	public void writeFloat(int index, float newValue) {
		decorated.write(index, newValue);
	}

	@Override
	public void addLong(int index, long newValue) {
		decorated.write(index, newValue);
	}

	@Override
	public void addInt(int index, int newValue) {
		decorated.write(index, newValue);
	}

	@Override
	public void addDouble(int index, double newValue) {
		decorated.write(index, newValue);
	}

	@Override
	public void addFloat(int index, float newValue) {
		decorated.write(index, newValue);
	}

}

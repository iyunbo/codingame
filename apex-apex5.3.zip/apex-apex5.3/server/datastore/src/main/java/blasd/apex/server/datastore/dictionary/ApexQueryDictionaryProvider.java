/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.datastore.dictionary;

import java.util.List;
import java.util.stream.Collectors;

import com.qfs.dic.IDictionary;
import com.qfs.dic.ISchemaDictionaryProvider;
import com.qfs.store.IDatastoreSchemaMetadata;
import com.qfs.store.IDatastoreSchemaVersion;
import com.qfs.store.IReadableDatastore;
import com.qfs.store.IStoreMetadata;
import com.qfs.store.query.IRecordQuery;
import com.qfs.store.record.impl.Records;
import com.qfs.store.record.impl.Records.DictionaryProviderFromArray;
import com.qfs.store.record.impl.Records.IDictionaryProvider;

import blasd.apex.server.datastore.ApexDatastoreHelper;

/**
 * This looks like QueryDictionaryProvider but it will not require an IDatastoreSchemaVersion which will prevent
 * reference an IDatastoreVersion for an object which could be used as a IContinuousSelection, which would have maintain
 * an old version while transactions happened.
 * 
 * It is even more similar to {@link DictionaryProviderFromArray}, as splitting path can be expensing, especially since
 * we could call .getDictionary for each IRecordReader while iterating through a datastore
 * 
 * @author Benoit Lacelle
 *
 */
public class ApexQueryDictionaryProvider implements Records.IDictionaryProvider {
	protected final List<? extends IDictionary<?>> dictionaries;

	public ApexQueryDictionaryProvider(List<? extends IDictionary<?>> dictionaries) {
		this.dictionaries = dictionaries;
	}

	@Override
	public IDictionary<?> getDictionary(int pathIndex) {
		return dictionaries.get(pathIndex);
	}

	public static IDictionary<?> getPathDictionary(IDatastoreSchemaMetadata metadata,
			ISchemaDictionaryProvider dictionaryProvider,
			String baseStore,
			String flatPath) {
		List<String> path = ApexDatastoreHelper.splitFieldPath(flatPath);

		IStoreMetadata store = ApexDatastoreHelper.getTargetStore(metadata, baseStore, path);
		if (store == null) {
			return null;
		}
		String fieldName = ApexDatastoreHelper.getTargetColumn(path);
		int fieldId = store.getFieldIndex(fieldName);

		return dictionaryProvider.getDictionary(store.getId(), fieldId);
	}

	public static IDictionaryProvider fromQuery(IRecordQuery query, IDatastoreSchemaVersion schemaVersion) {
		return fromQuery(query, schemaVersion.getMetadata(), schemaVersion.getDictionaries());
	}

	public static IDictionaryProvider fromQuery(IRecordQuery query, IReadableDatastore datastore) {
		return fromQuery(query, datastore.getSchemaMetadata(), datastore.getDictionaries());
	}

	public static IDictionaryProvider fromQuery(IRecordQuery query,
			IDatastoreSchemaMetadata metadata,
			ISchemaDictionaryProvider dictionaryProvider) {
		List<IDictionary<?>> dictionaries = query.getSelectedFields()
				.stream()
				.map(fieldPath -> getPathDictionary(metadata, dictionaryProvider, query.getStoreName(), fieldPath))
				.collect(Collectors.toList());

		return new ApexQueryDictionaryProvider(dictionaries);
	}
}

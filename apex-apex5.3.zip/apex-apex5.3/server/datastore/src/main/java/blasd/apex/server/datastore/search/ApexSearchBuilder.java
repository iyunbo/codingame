/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.datastore.search;

import java.util.Map;
import java.util.Objects;
import java.util.function.Supplier;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.annotations.Beta;
import com.qfs.store.IDatastoreVersion;
import com.qfs.store.IReadableDatastore;
import com.qfs.store.IStoreMetadata;
import com.qfs.store.query.ICompiledQuery;
import com.qfs.store.query.IQueryRunner;
import com.qfs.store.query.IRecordQuery;
import com.qfs.store.query.impl.AQueryRunner;
import com.qfs.store.query.impl.DatastoreQueryHelper;

import gnu.trove.list.TIntList;
import gnu.trove.list.array.TIntArrayList;

/**
 * In addition to {@link DatastoreQueryHelper}, one can find here:
 * 
 * PreparedStatement for getByKey
 * 
 * Explain for empty-result queries
 * 
 * Easy selection of common set of fields (store fields, available fields, key fields)
 * 
 * Output as HashMap, MappedTuple, transient MappedTuple for low memory footprint
 * 
 * @author Benoit Lacelle
 * 
 */
public class ApexSearchBuilder {
	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexSearchBuilder.class);

	protected ApexSearchBuilder() {
		// hidden
	}

	protected static class ApexDatastoreQueryPreparator implements IsPrepared<HasCursor> {

		protected final Supplier<? extends IQueryRunner> queryRunner;
		protected final ICompiledQuery compiledQuery;
		protected final boolean parallel;

		protected ApexDatastoreQueryPreparator(Supplier<? extends IQueryRunner> queryRunner,
				ICompiledQuery compiledQuery,
				boolean parallel) {
			this.queryRunner = queryRunner;
			this.compiledQuery = compiledQuery;
			this.parallel = parallel;
		}

		public ICompiledQuery asCompiledQuery() {
			return compiledQuery;
		}

		@Override
		public HasCursor match(Map<? extends String, ?> parameters) {
			return new ApexDatastoreMapPreparedQueryRunner(queryRunner, compiledQuery, parallel, parameters);
		}

		@Override
		public HasCursor match(Object... parameters) {
			return new ApexDatastoreArrayPreparedQueryRunner(queryRunner, compiledQuery, parallel, parameters);
		}

		@Override
		public HasCursor matchIndexes(int... indexes) {
			throw new UnsupportedOperationException("TODO: for now, it works only for .getByKey");
		}

	}

	/**
	 * Entry point for searches
	 * 
	 * @param datastore
	 *            a {@link IReadableDatastore}. We will extract the latestVersion each time a query is executed. If we
	 *            consider a prepared query, the version used is the one at time of execution, not compilation
	 * @param storeName
	 * @return
	 */
	public static OutputFields search(final IReadableDatastore datastore, String storeName) {
		Objects.requireNonNull(datastore, "Null datastore");

		return search(datastore::getHead, storeName);
	}

	public static OutputFields search(final IDatastoreVersion datastoreVersion, String storeName) {
		return searchWithQueryRunner(() -> datastoreVersion.getQueryRunner(), storeName);
	}

	public static OutputFields search(Supplier<IDatastoreVersion> datastoreVersion, String storeName) {
		return searchWithQueryRunner(() -> datastoreVersion.get().getQueryRunner(), storeName);
	}

	public static HasCursor search(Supplier<IDatastoreVersion> datastoreVersion, IRecordQuery recordQuery) {
		// We pay the compilation price right away as any query is compiled
		// before being executed
		ICompiledQuery compiledQuery = datastoreVersion.get().getQueryManager().compile(recordQuery);

		// Get the queryRunner lazily as the datastoreVersion may change in the meantime
		return new AApexDatastoreStaticQueryRunner(() -> datastoreVersion.get().getQueryRunner(), compiledQuery);
	}

	public static IsPrepared<HasCursor> prepareSearch(Supplier<? extends IQueryRunner> queryRunner,
			IRecordQuery recordQuery) {
		// We pay the compilation price right away as any query is compiled
		// before being executed
		ICompiledQuery compiledQuery = compile(queryRunner.get(), recordQuery);

		return new ApexDatastoreQueryPreparator(queryRunner, compiledQuery, false);
	}

	public static ApexDatastoreQueryBuilder searchWithQueryRunner(Supplier<? extends IQueryRunner> queryRunner,
			String storeName) {
		return new ApexDatastoreQueryBuilder(queryRunner, storeName);
	}

	public static HasCursor searchWithQueryRunner(Supplier<? extends IQueryRunner> queryRunner,
			IRecordQuery recordQuery) {
		// We pay the compilation price right away as any query is compiled
		// before being executed
		ICompiledQuery compiledQuery = compile(queryRunner.get(), recordQuery);

		return new AApexDatastoreStaticQueryRunner(queryRunner, compiledQuery);
	}

	/**
	 * 
	 * @param datastore
	 * @param storeName
	 * @param fieldNames
	 *            an ordered chain of field names
	 * @return true if there is either a primary index or a secondary index for given fields names
	 */
	@Beta
	public static boolean checkHasIndex(IReadableDatastore datastore,
			String storeName,
			Iterable<? extends String> fieldNames) {
		IStoreMetadata storeMetadata = datastore.getSchemaMetadata().getStoreMetadata(storeName);

		TIntList requestedFields = new TIntArrayList();
		for (String fieldName : fieldNames) {
			requestedFields.add(storeMetadata.getStoreFormat().getRecordFormat().getFieldIndex(fieldName));
		}

		// Do NOT sort, as ActivePivot will not re-order to take advantage of
		// indexes
		// requestedFields.sort();

		{
			TIntList[] indexes = storeMetadata.getPrimaryFields();
			for (TIntList index : indexes) {
				if (index.equals(requestedFields)) {
					return true;
				}
			}
		}
		{
			TIntList[] indexes = storeMetadata.getSecondaryFields();
			for (TIntList index : indexes) {
				if (index.equals(requestedFields)) {
					return true;
				}
			}
		}

		return false;
	}

	public static ICompiledQuery compile(IQueryRunner queryRunner, IRecordQuery query) {
		return ((AQueryRunner<?>) queryRunner).compile(query);
	}
}

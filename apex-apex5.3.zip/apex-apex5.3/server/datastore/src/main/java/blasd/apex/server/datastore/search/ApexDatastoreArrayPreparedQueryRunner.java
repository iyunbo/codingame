/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.datastore.search;

import java.util.Arrays;
import java.util.function.Supplier;

import com.qfs.store.query.ICompiledQuery;
import com.qfs.store.query.IQueryRunner;
import com.qfs.store.query.IQueryRunner.IHasCompiledQuery;
import com.qfs.store.query.IQueryRunner.IHasRunnableQuery;

/**
 * A prepared datastore statements where parameters comes from an array
 * 
 * @author Benoit Lacelle
 *
 */
public class ApexDatastoreArrayPreparedQueryRunner extends AApexDatastoreMaybePreparedQueryRunner {
	protected final Object[] parametersAsArray;

	public ApexDatastoreArrayPreparedQueryRunner(Supplier<? extends IQueryRunner> queryRunner,
			ICompiledQuery compiledQuery,
			boolean parallel,
			Object... parametersAsArray) {
		super(queryRunner, compiledQuery, parallel);

		this.parametersAsArray = parametersAsArray;
	}

	@Override
	protected IHasRunnableQuery makeHasRunnableQuery() {
		IHasCompiledQuery forQuery = getQueryRunner().forQuery(asCompiledQuery());

		Object[] cleanParameters = cleanParameters(parametersAsArray);

		return forQuery.withParameters(cleanParameters);
	}

	protected Object[] cleanParameters(Object[] parametersAsArray) {
		// Lazy init as barely never contains NotConditionWrapper
		Object[] clean = null;

		for (int i = 0; i < parametersAsArray.length; i++) {
			Object original = parametersAsArray[i];
			Object cleaned = ApexDatastoreMapPreparedQueryRunner.cleanParameter(original);

			if (cleaned != original) {
				if (clean == null) {
					// Lazy init
					clean = Arrays.copyOf(parametersAsArray, parametersAsArray.length);
				}

				clean[i] = cleaned;
			}
		}

		if (clean == null) {
			return parametersAsArray;
		} else {
			return clean;
		}
	}
}
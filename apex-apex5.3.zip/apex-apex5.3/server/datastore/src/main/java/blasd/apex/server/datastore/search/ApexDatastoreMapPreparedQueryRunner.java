/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.datastore.search;

import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.function.Supplier;

import com.google.common.collect.Maps;
import com.qfs.store.query.ICompiledQuery;
import com.qfs.store.query.IQueryRunner;
import com.qfs.store.query.IQueryRunner.IHasCompiledQuery;
import com.qfs.store.query.IQueryRunner.IHasRunnableQuery;

import blasd.apex.server.datastore.condition.NotConditionWrapper;

/**
 * A prepared datastore statements where parameters comes from an Map
 * 
 * @author Benoit Lacelle
 *
 */
public class ApexDatastoreMapPreparedQueryRunner extends AApexDatastoreMaybePreparedQueryRunner {
	protected final Map<? extends String, ?> parameters;

	public ApexDatastoreMapPreparedQueryRunner(Supplier<? extends IQueryRunner> queryRunner,
			ICompiledQuery compiledQuery,
			boolean parallel,
			Map<? extends String, ?> parameters) {
		super(queryRunner, compiledQuery, parallel);

		this.parameters = parameters;
	}

	@Override
	protected IHasRunnableQuery makeHasRunnableQuery() {
		IHasCompiledQuery forQuery = queryRunner.get().forQuery(asCompiledQuery());

		Map<String, Object> cleanParameters = cleanParameters(parameters);

		return forQuery.withParameters(cleanParameters);
	}

	public static Object cleanParameter(Object input) {
		if (input instanceof NotConditionWrapper<?>) {
			Object decorated = ((NotConditionWrapper<?>) input).decorated;

			return cleanParameter(decorated);
		} else if (!(input instanceof Collection<?>)) {
			// We forced the template to expect a Collection
			return Collections.singleton(input);
		} else {
			return input;
		}
	}

	protected Map<String, Object> cleanParameters(Map<? extends String, ?> parameters) {
		// unmodifiableMap as withParameters requires not a generic
		// String parameter
		Map<? extends String, Object> transformedMap = Maps.transformValues(parameters, e -> cleanParameter(e));
		return Collections.unmodifiableMap(transformedMap);
	}

}
/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.datastore.transaction;

import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.annotations.Beta;
import com.google.common.annotations.VisibleForTesting;
import com.google.common.collect.Streams;
import com.google.common.util.concurrent.Futures;
import com.qfs.condition.ICondition;
import com.qfs.multiversion.ITransaction;
import com.qfs.store.IDatastoreSchemaMetadata;
import com.qfs.store.NoTransactionException;
import com.qfs.store.record.IKeyRecordFormat;
import com.qfs.store.selection.ISelection;
import com.qfs.store.transaction.DatastoreTransactionException;
import com.qfs.store.transaction.ITransactionManager;
import com.qfs.store.transaction.ITransactionManager.IUpdateWhereProcedure;
import com.qfs.store.transaction.impl.TransactionManager;

import blasd.apex.server.datastore.condition.ApexConditionHelper;
import blasd.apex.server.loading.transaction.ApexTuplizerHelper;
import cormoran.pepper.logging.PepperLogHelper;
import cormoran.pepper.stream.PepperStreamHelper;
import cormoran.pepper.thread.PepperExecutorsHelper;

/**
 * Helps methods for operations to be conducted while a transaction is open. Typically to stream a flow of
 * add/remove/updateWhere
 * 
 * @author Benoit Lacelle
 *
 */
public class ApexInTransactionHelper {

	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexInTransactionHelper.class);

	@VisibleForTesting
	public static final AtomicLong ADD_COUNT = new AtomicLong();

	@VisibleForTesting
	public static final AtomicLong REMOVE_COUNT = new AtomicLong();

	// Work in another pool, to prevent saturating the common-pool which would prevent query execution
	private static final ForkJoinPool SUBMIT_TRANSACTION_POOL =
			PepperExecutorsHelper.newForkJoinPool("Apex-SubmitTransaction");

	// We enable changing this parameter to check through tests behaviors when submitting data on multiple partitions.
	// Do not change it in PROD
	private static int partitionSize = TransactionManager.TUPLES_TRANSFORMATION_SPLIT_SIZE;

	@VisibleForTesting
	public static void debugSetPartitionSize(int partitionSize) {
		ApexInTransactionHelper.partitionSize = partitionSize;
	}

	protected ApexInTransactionHelper() {
		// hidden
	}

	/**
	 * @deprecated Use .add or .remove
	 */
	@Deprecated
	public static void addOrRemoveTuplesInTransaction(ITransactionManager transactionManager,
			String storeName,
			Collection<Object[]> subTuples,
			boolean doRemove) {
		if (subTuples.isEmpty()) {
			LOGGER.trace("Skip empty submission to {}", storeName);
		} else {
			if (doRemove) {
				REMOVE_COUNT.addAndGet(subTuples.size());
				try {
					transactionManager.removeAll(storeName, subTuples);
				} catch (DatastoreTransactionException e) {
					// An issue in .removeAll is generally due to invalid input-data. Still, it may be due to some
					// out-of-memory for instance
					throw new IllegalArgumentException(e);
				}
			} else {
				ADD_COUNT.addAndGet(subTuples.size());
				transactionManager.addAll(storeName, subTuples);
			}
		}
	}

	/**
	 * @deprecated Use .add or .remove
	 */
	@Deprecated
	protected static long doAddOrRemoveInTransaction(ITransactionManager transactionManager,
			String storeName,
			Stream<?> toAdd,
			boolean doRemove) {
		IDatastoreSchemaMetadata schemaMetadata = transactionManager.getMetadata();
		Stream<Object[]> parallelTuplized = toAdd
				// do not force the stream with .parallel() as if we get an ICursor, it would corrupt the stream Tuplize
				// in parallel
				.map(ApexTuplizerHelper.streamTuplizer(schemaMetadata, storeName, doRemove));

		return PepperStreamHelper.consumeByPartition(parallelTuplized,
				queue -> addOrRemoveTuplesInTransaction(transactionManager, storeName, queue, doRemove),
				partitionSize);
	}

	/**
	 * @deprecated Use .add or .remove
	 */
	@Deprecated
	public static long addOrRemoveInTransaction(ITransactionManager transactionManager,
			String storeName,
			Iterator<?> toAdd,
			boolean doRemove) {
		return addOrRemoveInTransaction(transactionManager, storeName, Streams.stream(toAdd), doRemove);
	}

	/**
	 * @deprecated Use .add or .remove
	 */
	@Deprecated
	public static long addOrRemoveInTransaction(ITransactionManager transactionManager,
			String storeName,
			Stream<?> toAdd,
			boolean doRemove) {
		if (toAdd == null) {
			return 0L;
		}

		long nbSubmitted;

		if (toAdd.isParallel()) {
			// transactionManager asynchronously
			// Submit in a dedicated pool as this operation may last a few seconds
			nbSubmitted = Futures.getUnchecked(SUBMIT_TRANSACTION_POOL
					.submit(() -> doAddOrRemoveInTransaction(transactionManager, storeName, toAdd, doRemove)));
		} else {
			// We received a stream not-parallel (typically a raw ICursor)
			nbSubmitted = doAddOrRemoveInTransaction(transactionManager, storeName, toAdd, doRemove);
		}

		return nbSubmitted;
	}

	/**
	 * API Simplification by throwing only unchecked exception
	 */
	public static void executeUpdateWhere(ITransactionManager transactionManager,
			ISelection selection,
			ICondition condition,
			IUpdateWhereProcedure updateWhere) {
		try {
			transactionManager.updateWhere(selection, condition, updateWhere);
		} catch (DatastoreTransactionException e) {
			throw new IllegalArgumentException(
					"Failure on .updateWhere on " + selection.getBaseStore() + ": " + updateWhere,
					e);
		}
	}

	/**
	 * @deprecated Rely on .removeInTransaction
	 */
	@Deprecated
	public static void inTransactionRemoveWhere(ITransactionManager transactionManager,
			String storeName,
			ICondition removeWhere) {
		removeInTransaction(transactionManager, storeName, removeWhere);
	}

	public static Runnable prepareAdd(ITransactionManager transactionManager, String storeName, Stream<?> toAdd) {
		return prepareAddOrRemove(transactionManager, storeName, toAdd, false);
	}

	/**
	 * @deprecated Prefer {@link Stream}
	 */
	@Deprecated
	public static Runnable prepareAdd(ITransactionManager transactionManager,
			Map<String, ? extends Iterable<?>> storeNameToData) {
		return prepareAddOrRemove(transactionManager, storeNameToData, false);
	}

	/**
	 * @deprecated Prefer {@link Stream}
	 */
	@Deprecated
	protected static Runnable prepareAddOrRemove(ITransactionManager transactionManager,
			Map<String, ? extends Iterable<?>> storeNameToData,
			boolean doRemove) {
		Set<String> storeNames = storeNameToData.keySet();

		IDatastoreSchemaMetadata schemaMetadata = transactionManager.getMetadata();

		// Check the set of data is clean
		for (String key : storeNames) {
			if (!schemaMetadata.getStoreNames().contains(key)) {
				throw new RuntimeException(
						key + " is an unknown store name: availables=" + schemaMetadata.getStoreNames());
			}
		}

		// Do the push in a single transaction
		return () -> addOrRemoveInTransaction(transactionManager, storeNameToData, doRemove);
	}

	/**
	 * @deprecated Prefer {@link Stream}
	 */
	public static Runnable prepareAddOrRemove(ITransactionManager transactionManager,
			String storeName,
			Iterator<?> toAdd,
			boolean doRemove) {
		return prepareAddOrRemove(transactionManager, storeName, Streams.stream(toAdd), doRemove);
	}

	/**
	 * @deprecated Use .add or .remove
	 */
	@Deprecated
	@Beta
	public static Runnable prepareAddOrRemove(ITransactionManager transactionManager,
			String storeName,
			Stream<?> toAdd,
			boolean doRemove) {
		IDatastoreSchemaMetadata schemaMetadata = transactionManager.getMetadata();

		// Check the set of data is clean
		if (!schemaMetadata.getStoreNames().contains(storeName)) {
			throw new RuntimeException(
					storeName + " is an unknown store name: availables=" + schemaMetadata.getStoreNames());
		}

		// Do the push in a single transaction
		return () -> addOrRemoveInTransaction(transactionManager, storeName, toAdd, doRemove);
	}

	/**
	 * Push data in the {@link ITransactionManager} assuming we are in an opened {@link ITransaction}
	 * 
	 * @param transactionManager
	 * @param storeNameToData
	 *            a mapping from a store name to an {@link Iterable} of entries to push (add or remove)
	 * @param doRemove
	 *            true if we are submitting entries to remove
	 * 
	 * @deprecated Prefer {@link Stream}
	 */
	@Deprecated
	public static void addOrRemoveInTransaction(ITransactionManager transactionManager,
			Map<String, ? extends Iterable<?>> storeNameToData,
			boolean doRemove) {
		for (Entry<String, ? extends Iterable<?>> storeToEntries : storeNameToData.entrySet()) {
			addOrRemoveInTransaction(transactionManager,
					storeToEntries.getKey(),
					StreamSupport.stream(storeToEntries.getValue().spliterator(), false),
					doRemove);
		}
	}

	/**
	 * Push data in the {@link ITransactionManager} assuming we are in an opened {@link ITransaction}
	 * 
	 * @param transactionManager
	 * @param storeNameToData
	 *            a mapping from a store name to an {@link Stream} of entries to add
	 * 
	 */
	public static void addStreamsInTransaction(ITransactionManager transactionManager,
			Map<String, ? extends Stream<?>> storeNameToData) {
		storeNameToData.forEach((storeName, toAdd) -> addInTransaction(transactionManager, storeName, toAdd));
	}

	@Deprecated
	public static Runnable prepareRemoveWhereRunnable(ITransactionManager transactionManager,
			String storeName,
			Map<? extends String, ?> template) {
		ICondition condition = ApexConditionHelper.convertToCondition(template);

		return prepareRemoveWhereRunnable(transactionManager, storeName, condition);
	}

	/**
	 * One can use BaseConditions.TRUE to remove all entries
	 * 
	 * @param querryRunner
	 * @param storeName
	 * @param condition
	 * @return
	 */
	@Deprecated
	public static Runnable prepareRemoveWhereRunnable(ITransactionManager transactionManager,
			String storeName,
			ICondition condition) {
		return () -> removeInTransaction(transactionManager, storeName, condition);

	}

	/**
	 * @deprecated Prefer {@link Stream}
	 */
	public static Stream<? extends Runnable> prepareAddAndRemoveWhere(ITransactionManager transactionManager,
			String storeName,
			Iterable<?> toAdd,
			Map<? extends String, ?> templateToRemove) {
		return prepareAddAndRemoveWhere(transactionManager,
				storeName,
				Streams.stream(toAdd),
				Streams.stream(Optional.ofNullable(templateToRemove)));
	}

	/**
	 * @deprecated Prefer {@link Stream}
	 */
	@Deprecated
	public static Stream<? extends Runnable> prepareAddAndRemoveWhere(ITransactionManager transactionManager,
			String storeName,
			Iterator<?> toAdd,
			Iterator<? extends Map<? extends String, ?>> templateToRemove) {
		return prepareAddAndRemoveWhere(transactionManager,
				storeName,
				// http://stackoverflow.com/questions/24511052/how-to-convert-an-iterator-to-a-stream
				Streams.stream(toAdd),
				Streams.stream(templateToRemove));
	}

	public static Stream<? extends Runnable> prepareAddAndRemoveWhere(ITransactionManager transactionManager,
			String storeName,
			Stream<?> toAdd,
			Stream<? extends Map<? extends String, ?>> templatesToRemove) {

		// Remove all the data in the store
		Stream<Runnable> toRemove =
				templatesToRemove.map(t -> prepareRemoveWhereRunnable(transactionManager, storeName, t));
		// Add the submitted data
		Runnable toAddRunnable = prepareAddOrRemove(transactionManager, storeName, toAdd, false);

		return Stream.concat(toRemove, Stream.of(toAddRunnable));
	}

	public static long addInTransaction(ITransactionManager transactionManager, String storeName, Stream<?> toAdd) {
		return addOrRemoveInTransaction(transactionManager, storeName, toAdd, false);
	}

	/**
	 * @deprecated Prefer {@link Stream}
	 */
	@Deprecated
	public static long addInTransaction(ITransactionManager transactionManager, String storeName, Iterator<?> toAdd) {
		return addOrRemoveInTransaction(transactionManager, storeName, toAdd, false);
	}

	public static void removeInTransaction(ITransactionManager transactionManager,
			String storeName,
			ICondition condition) {
		try {
			transactionManager.removeWhere(storeName, condition);
		} catch (NoTransactionException | DatastoreTransactionException e) {
			throw new RuntimeException(e);
		}
	}

	public static void removeInTransaction(ITransactionManager transactionManager,
			String storeName,
			Map<? extends String, ?> condition) {
		IKeyRecordFormat keyRecordFormat =
				transactionManager.getMetadata().getStoreMetadata(storeName).getStoreFormat().getKeyRecordFormat();
		// keyRecordFormat may be null if the store is .withoutKeys
		if (keyRecordFormat != null && condition.size() == keyRecordFormat.getFieldCount()) {
			// TODO We may be removed by primary key: it would be better to remove by key than by a .removeWhere
			LOGGER.trace("TODO: handle .removeTuple instead of .removeWhere when possible");
		}
		removeInTransaction(transactionManager, storeName, ApexConditionHelper.convertToCondition(condition));
	}

	/**
	 * This can be used while inside a transaction managed by ApexTransactionHelper. It typically throws a specific
	 * {@link RuntimeException} which will be intercepted to cancel softly (i.e. without rethrowing an exception) the
	 * transaction
	 */
	public static void cancelCurrentTransaction() {
		throw new RollbackTransactionSilently();
	}

	public static <T> Future<T> submit(Callable<T> callable) {
		return SUBMIT_TRANSACTION_POOL.submit(callable);
	}

	public static long removeInTransaction(ITransactionManager transactionManager,
			String storeName,
			Stream<?> toRemove) {
		AtomicLong nbRemoved = new AtomicLong();

		toRemove.forEach(template -> {
			nbRemoved.incrementAndGet();

			if (template instanceof ICondition) {
				removeInTransaction(transactionManager, storeName, (ICondition) template);
			} else if (template instanceof Map<?, ?>) {
				removeInTransaction(transactionManager, storeName, (Map<String, ?>) template);
			} else {
				// Beta behavior
				if (template instanceof Object[]) {
					// This may be a tuple from a search
					try {
						transactionManager.remove(storeName, (Object[]) template);
					} catch (NoTransactionException | DatastoreTransactionException e) {
						throw new RuntimeException(e);
					}
				} else {
					throw new IllegalArgumentException(
							"Can not removeWhere over " + PepperLogHelper.getObjectAndClass(template));
				}
			}
		});

		return nbRemoved.get();
	}

}

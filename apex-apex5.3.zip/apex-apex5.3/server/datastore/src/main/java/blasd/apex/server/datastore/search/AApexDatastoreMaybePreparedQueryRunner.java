/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.datastore.search;

import java.io.Closeable;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Supplier;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.qfs.store.IDatastoreSchema;
import com.qfs.store.query.ICompiledQuery;
import com.qfs.store.query.ICursor;
import com.qfs.store.query.IDictionaryCursor;
import com.qfs.store.query.IPartitionedResultAcceptor;
import com.qfs.store.query.IQueryRunner;
import com.qfs.store.query.IQueryRunner.ICursorRunner;
import com.qfs.store.query.IQueryRunner.IHasRunnableQuery;
import com.qfs.store.query.IRecordQuery;
import com.qfs.store.query.impl.AQueryRunnerSpy;
import com.qfs.store.query.impl.DictionaryCursor;
import com.qfs.store.record.impl.Records;

import blasd.apex.server.datastore.dictionary.ApexQueryDictionaryProvider;

/**
 * Abstraction for a query, which may be templated
 * 
 * @author Benoit Lacelle
 * @see http://support.quartetfs.com/jira/browse/APS-9422
 */
public abstract class AApexDatastoreMaybePreparedQueryRunner extends AHasCursor {

	protected static final Logger LOGGER = LoggerFactory.getLogger(AApexDatastoreMaybePreparedQueryRunner.class);

	protected final Supplier<? extends IQueryRunner> queryRunner;

	protected final ICompiledQuery compiledQuery;

	protected final boolean parallel;

	public AApexDatastoreMaybePreparedQueryRunner(Supplier<? extends IQueryRunner> queryRunner,
			ICompiledQuery compiledQuery,
			boolean parallel) {
		this.queryRunner = queryRunner;
		this.compiledQuery = compiledQuery;
		this.parallel = parallel;
	}

	protected IQueryRunner getQueryRunner() {
		return queryRunner.get();
	}

	public ICompiledQuery asCompiledQuery() {
		return compiledQuery;
	}

	/**
	 * @see http://support.quartetfs.com/jira/browse/APS-9422
	 */
	@Override
	public IDictionaryCursor asCursor() {
		ICursorRunner cursorRunner;

		// Make sure we rely on the compiled query
		if (java.util.concurrent.ForkJoinTask.inForkJoinPool()) {
			// In a ForkJoinPool (e.g. in updateWhere, or in a PostProcessor): we expect a small result
			// http://support.quartetfs.com/jira/browse/APS-9422
			cursorRunner = makeHasRunnableQuery().onCurrentThread();
		} else {
			// In a project thread: might be a big query
			cursorRunner = makeHasRunnableQuery();
		}

		// Make sure we rely on the compiled query
		return cursorRunner.run();
	}

	@Override
	public void withAcceptor(final IApexPartitionedResultAcceptor partitionedResultAcceptor) {
		// This will maintain a reference to a single version for the time of the query: OK
		// IDatastoreSchemaVersion schemaVersion = datastoreVersion.get().getSchema();

		IRecordQuery originatinQuery = asCompiledQuery().getOriginatingQuery();
		IDatastoreSchema<?, ?> schema = AQueryRunnerSpy.getSchema(queryRunner.get());
		final Records.IDictionaryProvider dictionaryProvider =
				ApexQueryDictionaryProvider.fromQuery(originatinQuery, schema.getMetadata(), schema.getDictionaries());

		final AtomicReference<Throwable> firstThrowable = new AtomicReference<>();

		makeHasRunnableQuery().withAcceptor(new IPartitionedResultAcceptor() {

			@Override
			public void onResult(int partitionId, ICursor cursor) throws Throwable {
				if (cursor.hasNext()) {
					// We undictionarize ourselves the cursor
					IDictionaryCursor dicCursor =
							new DictionaryCursor(cursor, dictionaryProvider, cursor.getRecordFormat());
					partitionedResultAcceptor.onResult(partitionId, dicCursor);
				} else {
					LOGGER.debug("There is no result for partition {}", partitionId);
				}
			}

			@Override
			public void completeExceptionally(Throwable throwable) {
				firstThrowable.compareAndSet(null, throwable);
			}

			@Override
			public void complete() throws Throwable {
				if (partitionedResultAcceptor instanceof Closeable) {
					((Closeable) partitionedResultAcceptor).close();
				}
			}
		}).run().awaitCompletion();

		if (firstThrowable.get() != null) {
			// Wrap in RuntimeException for nice stack propagation
			throw new RuntimeException(firstThrowable.get());
		}
	}

	protected abstract IHasRunnableQuery makeHasRunnableQuery();
}
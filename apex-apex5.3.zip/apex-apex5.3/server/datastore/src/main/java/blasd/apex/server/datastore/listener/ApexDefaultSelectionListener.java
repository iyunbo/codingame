/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.datastore.listener;

import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.MoreObjects;
import com.qfs.store.IDatastoreVersion;
import com.qfs.store.record.IRecordBlock;
import com.qfs.store.record.IRecordReader;
import com.qfs.store.selection.ISelectionListener;
import com.qfs.store.transaction.ITransactionInformation;

/**
 * Simplify the usage of {@link ISelectionListener} by introducing no-op as default
 * 
 * @author Benoit Lacelle
 * 
 */
public class ApexDefaultSelectionListener implements IApexSelectionListener {
	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexDefaultSelectionListener.class);

	protected final AtomicInteger nbActiveTransactions = new AtomicInteger();

	protected void acceptAdded(IRecordBlock<IRecordReader> added) {
		// by default, we do nothing
	}

	protected void acceptDeleted(IRecordBlock<IRecordReader> added) {
		// by default, we do nothing
	}

	@Override
	public void partitionDropped(int partitionId, List<int[]> arg1, IRecordBlock<IRecordReader> deleted) {
		// by default, we do nothing
		acceptDeleted(deleted);
	}

	@Override
	public void recordsAdded(int partitionId, IRecordBlock<IRecordReader> added) {
		// by default, we do nothing
		acceptAdded(added);
	}

	@Override
	public void recordsDeleted(int partitionId, IRecordBlock<IRecordReader> deleted) {
		// by default, we do nothing
		acceptDeleted(deleted);
	}

	@Override
	public void recordsUpdated(int partitionId,
			IRecordBlock<IRecordReader> deleted,
			IRecordBlock<IRecordReader> added) {
		// by default, we do nothing
		acceptDeleted(deleted);
		acceptAdded(added);
	}

	@Override
	public void transactionCommitted(IDatastoreVersion datastoreVersion) {
		onTransactionClosed();
	}

	protected void onTransactionClosed() {
		if (nbActiveTransactions.decrementAndGet() < 0) {
			// We missed a startTransaction
			LOGGER.error("Invalid transaction count in {}", this);
			nbActiveTransactions.set(0);
		}
	}

	@Override
	public void transactionRolledBack() {
		onTransactionClosed();
	}

	@Override
	public void transactionStarted(IDatastoreVersion datastoreVersion, ITransactionInformation transactionInformation) {
		// by default, we do nothing
		nbActiveTransactions.incrementAndGet();
	}

	@Override
	public String toString() {
		return MoreObjects.toStringHelper(this).toString();
	}

	@Override
	public boolean isHasPending() {
		// By default, we guess there is no pending tasks
		return false;
	}

	@Override
	public boolean isActive() {
		return nbActiveTransactions.get() > 0;
	}
}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.datastore.updatewhere;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.BiConsumer;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Joiner;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.google.common.collect.Sets.SetView;
import com.google.common.primitives.Ints;
import com.qfs.chunk.IArrayReader;
import com.qfs.chunk.IArrayWriter;
import com.qfs.condition.ICondition;
import com.qfs.condition.impl.BaseConditions;
import com.qfs.store.IDatastoreSchemaMetadata;
import com.qfs.store.IStoreMetadata;
import com.qfs.store.record.IRecordFormat;
import com.qfs.store.selection.ISelection;
import com.qfs.store.selection.ISelectionField;
import com.qfs.store.selection.impl.Selection;
import com.qfs.store.transaction.DatastoreTransactionException;
import com.qfs.store.transaction.ITransactionManager;
import com.qfs.store.transaction.ITransactionManager.IUpdateWhereProcedure;

import blasd.apex.server.datastore.ApexDatastoreHelper;
import blasd.apex.server.loading.testdata.FieldInStoreDTO;

/**
 * Various helper methods for updateWheres. The main one is the registration of a Set of updateWhere by automatically
 * computing the proper order and insertionTime/commitTime status
 * 
 * @author Benoit Lacelle
 *
 */
public class ApexUpdateWhereHelper {
	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexUpdateWhereHelper.class);

	@Deprecated
	public static final int DEFAULT_PRIOTITY = 0;
	public static final int DEFAULT_PRIORITY = DEFAULT_PRIOTITY;

	// If all ITransactionManager.addAll are done synchronously
	// , this should be set to true as insertionTime updateWhere are done
	// synchronously
	public static boolean commitTimeEvenIfNoReferencedFields = false;

	protected ApexUpdateWhereHelper() {
		// hidden
	}

	public static boolean registerContinuousUpdateWhere(String triggerName,
			ITransactionManager transactionManager,
			IApexUpdateWhereProcedureWrapper updateWhere) {
		return registerContinuousUpdateWhere(triggerName, transactionManager, updateWhere, DEFAULT_PRIOTITY);
	}

	/**
	 * @return true if we registered as commit-time. false if we registered as insertion time
	 */
	public static boolean registerContinuousUpdateWhere(String triggerName,
			ITransactionManager transactionManager,
			IApexUpdateWhereProcedureWrapper updateWhere,
			int priority,
			boolean forceCommitTime) {
		if (updateWhere.getUpdateWhere().getHasReferencedFields() || commitTimeEvenIfNoReferencedFields
				|| forceCommitTime) {
			// We have referenced fields: then, this updateWhere needs to be
			// synchronized with entries inserted in the same transaction in
			// the references store
			registerContinuousUpdateWhereCommitTime(triggerName, transactionManager, updateWhere, priority);

			return true;
		} else {
			registerContinuousUpdateWhereAtInsertionTime(triggerName, transactionManager, updateWhere, priority);

			return false;
		}
	}

	public static void registerContinuousUpdateWhereAtInsertionTime(String triggerName,
			ITransactionManager transactionManager,
			IApexUpdateWhereProcedureWrapper updateWhere,
			int priority) {
		// We prefer insertionTime as it is cheaper for ActivePivot
		// than CommitTime updateWhere
		LOGGER.info("Register insertion-time {} with priority {}", triggerName, priority);
		try {
			transactionManager.registerInsertionTimeUpdateWhereTrigger(triggerName,
					priority,
					updateWhere.getSelection(),
					updateWhere.getCondition(),
					updateWhere.getUpdateWhere());
		} catch (DatastoreTransactionException e) {
			throw new RuntimeException(e);
		}
	}

	public static void registerInsertionTimeUpdate(ITransactionManager transactionManager,
			IUpdateWhereProcedure updateWhere,
			String storeName,
			String... fieldNames) {
		// We prefer insertionTime as it is cheaper for ActivePivot
		// than CommitTime updateWhere
		int priority = DEFAULT_PRIORITY;

		Selection selection = new Selection(storeName, fieldNames);
		ICondition condition = BaseConditions.True();
		String triggerName = computeTriggerName(updateWhere, selection, condition);

		LOGGER.info("Register insertion-time {} with priority {}", triggerName, priority);
		try {
			transactionManager
					.registerInsertionTimeUpdateWhereTrigger(triggerName, priority, selection, condition, updateWhere);
		} catch (DatastoreTransactionException e) {
			throw new RuntimeException(e);
		}
	}

	public static void registerContinuousUpdateWhereCommitTime(String triggerName,
			ITransactionManager transactionManager,
			IApexUpdateWhereProcedureWrapper updateWhere,
			int priority) {
		LOGGER.info("Register commit-time {} with priority {}", triggerName, priority);
		try {
			transactionManager.registerCommitTimeUpdateWhereTrigger(triggerName,
					priority,
					updateWhere.getSelection(),
					updateWhere.getCondition(),
					updateWhere.getUpdateWhere());
		} catch (DatastoreTransactionException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * 
	 * @return true if commit time
	 */
	public static boolean registerContinuousUpdateWhere(String triggerName,
			ITransactionManager transactionManager,
			IApexUpdateWhereProcedureWrapper updateWhere,
			int priority) {
		// Do NOT force commitTime
		return registerContinuousUpdateWhere(triggerName, transactionManager, updateWhere, priority, false);
	}

	/**
	 * 
	 * @return true if commitTime
	 */
	public static boolean unregisterContinuousUpdateWhere(ITransactionManager transactionManager,
			IApexUpdateWhereProcedureWrapper updateWhere) {
		return unregisterContinuousUpdateWhere(transactionManager, updateWhere, false);
	}

	public static boolean unregisterContinuousUpdateWhere(ITransactionManager transactionManager,
			IApexUpdateWhereProcedureWrapper updateWhere,
			boolean forceCommitTime) {
		String triggerName = ApexUpdateWhereHelper.computeTriggerName(updateWhere);

		try {
			if (updateWhere.getUpdateWhere().getHasReferencedFields() || commitTimeEvenIfNoReferencedFields
					|| forceCommitTime) {
				transactionManager.unregisterCommitTimeUpdateWhereTrigger(updateWhere.getSelection().getBaseStore(),
						triggerName);
				return true;
			} else {
				transactionManager.unregisterInsertionTimeUpdateWhereTrigger(updateWhere.getSelection().getBaseStore(),
						triggerName);
				return false;
			}
		} catch (DatastoreTransactionException e) {
			throw new RuntimeException(e);
		}
	}

	public static List<? extends String> registerContinuousUpdateWheres(ITransactionManager transactionManager,
			Iterable<? extends IApexUpdateWhereProcedureWrapper> updateWheres) {
		List<String> triggerNames = new ArrayList<>();
		List<IHasWrittenFields> writtenFields = new ArrayList<>();

		boolean forceCommitTime = false;

		for (IApexUpdateWhereProcedureWrapper updateWhere : updateWheres) {
			String triggerName = computeTriggerName(updateWhere);
			triggerNames.add(triggerName);

			if (updateWhere instanceof IHasWrittenFields) {
				writtenFields.add((IHasWrittenFields) updateWhere);
			} else {
				LOGGER.info("{} has no explicit written fields", triggerName);
				boolean commitTime = registerContinuousUpdateWhere(triggerName, transactionManager, updateWhere);

				if (commitTime) {
					forceCommitTime = true;
				}
			}
		}

		// +1 not to interact with updateWHeres registered with default priority
		AtomicInteger priority = new AtomicInteger(DEFAULT_PRIOTITY + 1);

		//
		// TODO: should we restrict ourselves on partitionned fields?
		List<IHasWrittenFields> writePrimaryKey = writtenFields.stream()
				.filter(uw -> ApexUpdateWhereHelper.isOverPrimaryKeyField(transactionManager.getMetadata(), uw))
				.collect(Collectors.toList());

		// We need updateWhere writing on primaryKeys, or especially writing in partitioning fields to be computed at
		// insertion time, else, if done at update-time, it will lead to poor performance beacuse of re-flushing (and
		// mono-threaded insertion if the field is used for partitionning as the field is always on its default value at
		// insertion)
		writePrimaryKey.forEach(updateWhere -> {
			String triggerName = computeTriggerName(updateWhere);
			registerContinuousUpdateWhereAtInsertionTime(triggerName, transactionManager, updateWhere, priority.get());
			priority.incrementAndGet();
		});

		// updateWhere over the primary have been registered: no need to consider them further
		writtenFields.removeAll(writePrimaryKey);

		writtenFields = sortUpdateWheres(writtenFields, transactionManager.getMetadata());

		for (IApexUpdateWhereProcedureWrapper updateWhere : writtenFields) {
			boolean commitTime = registerContinuousUpdateWhere(computeTriggerName(
					updateWhere), transactionManager, updateWhere, priority.get(), forceCommitTime);

			if (commitTime) {
				// This updateWhere is commitTime: we need to enforce dependant
				// updateWhere to be applied after, then also commit-time
				forceCommitTime = true;
			}

			// UpdateWhere are handled in the growing priority order
			priority.incrementAndGet();
		}

		return triggerNames;
	}

	public static boolean isOverPrimaryKeyField(IDatastoreSchemaMetadata metadata, IHasWrittenFields uw) {
		int[] keyFields = metadata.getStoreMetadata(uw.getSelection().getBaseStore()).getStoreFormat().getKeyFields();

		Set<Integer> writtenIndexes = ImmutableSet.copyOf(Ints.asList(uw.writtenFields()));

		// Ensure we are intersecting set of Integer
		return !Sets.<Integer>intersection(writtenIndexes, ImmutableSet.copyOf(Ints.asList(keyFields))).isEmpty();
	}

	public static Set<FieldInStoreDTO> computeIn(IDatastoreSchemaMetadata datastoreMetadata, ISelection selection) {
		String baseStore = selection.getBaseStore();

		Set<FieldInStoreDTO> inFields = new HashSet<>();
		for (ISelectionField inField : selection.getFields()) {
			List<String> inPath = ApexDatastoreHelper.splitFieldPath(inField.getExpression());

			IStoreMetadata targetStore = ApexDatastoreHelper.getTargetStore(datastoreMetadata, baseStore, inPath);
			String fieldName = ApexDatastoreHelper.getTargetStoreField(inPath);

			int fieldIndex = targetStore.getStoreFormat().getRecordFormat().getFieldIndex(fieldName);

			if (fieldIndex < 0) {
				throw new RuntimeException("There is no field named " + fieldName + " in " + targetStore);
			}

			inFields.add(new FieldInStoreDTO(targetStore, fieldIndex));
		}
		return inFields;
	}

	public static Set<FieldInStoreDTO> computeOut(IDatastoreSchemaMetadata datastoreMetadata,
			IHasWrittenFields updateWhere) {
		String baseStore = updateWhere.getSelection().getBaseStore();

		// Try to keep the orderinf so that the algorithm is a bit more determinist
		Set<FieldInStoreDTO> outFields = new LinkedHashSet<>();

		for (int outFieldIndex : updateWhere.writtenFields()) {
			IStoreMetadata storeMetadata = datastoreMetadata.getStoreMetadata(baseStore);
			outFields.add(new FieldInStoreDTO(storeMetadata, outFieldIndex));

			datastoreMetadata.getStoreGraph()
					.getEdgesFrom(baseStore)
					.values()
					.stream()
					.flatMap(Collection::stream)
					.filter(r -> Ints.indexOf(r.getOwnerFields(), outFieldIndex) >= 0)
					.forEach(ref -> {
						LOGGER.debug("As we write on a foreign-key fields, we add all target fields as out fields");
						// TODO: Add recursively all fields
						// datastoreMetadata.getStoreGraph().getReached(ImmutableSet.of(targetStore.getName()));
						IStoreMetadata targetStore = ref.getTargetStoreMetadata();

						int refFieldCount = targetStore.getStoreFormat().getRecordFormat().getFieldCount();

						IntStream.range(0, refFieldCount)
								.forEach(refIndex -> outFields.add(new FieldInStoreDTO(targetStore, refIndex)));
					});

		}
		return outFields;
	}

	public static List<IHasWrittenFields> sortUpdateWheres(Collection<? extends IHasWrittenFields> writtenFields,
			IDatastoreSchemaMetadata datastoreMetadata) {
		// First , we sort based on trigger name in order to have a consistent
		// ordering
		List<IHasWrittenFields> sorted;
		{
			sorted = new ArrayList<>(writtenFields);
			Collections.sort(sorted, (left, right) -> computeTriggerName(left).compareTo(computeTriggerName(right)));
		}

		// Transfer sorted updateWhere to queue
		Queue<IHasWrittenFields> queue = new LinkedBlockingQueue<>(sorted);
		sorted.clear();

		int nbBreakWithoutSuccess = 0;
		tryNextCandidate: while (!queue.isEmpty()) {
			if (nbBreakWithoutSuccess == queue.size()) {
				throw new RuntimeException("There is a cycle between " + queue);
			}

			IHasWrittenFields nextCandidate = queue.poll();

			if (queue.isEmpty()) {
				// This updateWhere is the last one
				sorted.add(nextCandidate);
			} else {
				String leftName = computeTriggerName(nextCandidate);

				Set<FieldInStoreDTO> leftIn = computeIn(datastoreMetadata, nextCandidate.getSelection());
				Set<FieldInStoreDTO> leftOut = computeOut(datastoreMetadata, nextCandidate);

				for (IHasWrittenFields needTobeAfter : queue) {
					String rightName = computeTriggerName(needTobeAfter);
					Set<FieldInStoreDTO> rightIn = computeIn(datastoreMetadata, needTobeAfter.getSelection());
					Set<FieldInStoreDTO> rightOut = computeOut(datastoreMetadata, needTobeAfter);

					SetView<FieldInStoreDTO> leftDependsOnRight = Sets.intersection(leftIn, rightOut);
					SetView<FieldInStoreDTO> rightDependsOnLeft = Sets.intersection(rightIn, leftOut);
					if (leftDependsOnRight.isEmpty()) {
						// Left does NOT depend on Right
						if (rightDependsOnLeft.isEmpty()) {
							// Right does NOT depend on Left
							LOGGER.trace("No dependecy between {} and {}", leftName, rightName);
						} else {
							// Right DOES depend on Left
							// Then we should consider Left first
							// It is OK as left is current candidate
							LOGGER.trace("Because of {}, {} is before {} ", rightDependsOnLeft, leftName, rightName);
						}
					} else {
						// Left DOES depend on Right
						if (rightDependsOnLeft.isEmpty()) {
							// Right does NOT depend on Left
							// Then we should consider Right first
							LOGGER.trace("Because of {}, {} is before {} ", leftDependsOnRight, rightName, leftName);

							// Retry this guy later
							queue.add(nextCandidate);
							nbBreakWithoutSuccess++;
							continue tryNextCandidate;
						} else {
							// Right DOES depend on Left
							// Each one depends on the other
							throw new RuntimeException("because of " + leftDependsOnRight
									+ " and "
									+ rightDependsOnLeft
									+ leftName
									+ " and "
									+ rightName
									+ " dpends on each other");
						}
					}
				}

				sorted.add(nextCandidate);
				nbBreakWithoutSuccess = 0;
			}
		}

		return sorted;
	}

	public static void unregisterContinuousUpdateWheres(ITransactionManager transactionManager,
			List<IApexUpdateWhereProcedureWrapper> updateWheres) {
		List<IHasWrittenFields> writtenFields = new ArrayList<>();

		boolean forceCommitTime = false;

		for (IApexUpdateWhereProcedureWrapper updateWhere : updateWheres) {
			if (updateWhere instanceof IHasWrittenFields) {
				writtenFields.add((IHasWrittenFields) updateWhere);
			} else {
				boolean commitTime = unregisterContinuousUpdateWhere(transactionManager, updateWhere);

				if (commitTime) {
					forceCommitTime = true;
				}
			}
		}

		writtenFields = sortUpdateWheres(writtenFields, transactionManager.getMetadata());

		for (IApexUpdateWhereProcedureWrapper updateWhere : writtenFields) {
			boolean commitTime = unregisterContinuousUpdateWhere(transactionManager, updateWhere, forceCommitTime);

			if (commitTime) {
				// This updateWhere is commitTime: we need to enforce dependant
				// updateWhere to be applied after, then also commit-time
				forceCommitTime = true;
			}
		}
	}

	public static String computeTriggerName(IApexUpdateWhereProcedureWrapper updateWhere) {
		return computeTriggerName(updateWhere.getUpdateWhere(), updateWhere.getSelection(), updateWhere.getCondition());
	}

	public static String computeTriggerName(IUpdateWhereProcedure updateWhere,
			ISelection selection,
			ICondition condition) {
		// TODO: there is a chance 2 different updateWhere has the same
		// .toString
		String fields = Joiner.on('|').join(Lists.transform(selection.getFields(), ISelectionField::getExpression));
		return updateWhere + " based on " + selection.getBaseStore() + " - " + fields + " restricted to " + condition;
	}

	public static IUpdateWhereProcedure fromBiConsumer(BiConsumer<IArrayReader, IArrayWriter> biConsumer) {
		return new IUpdateWhereProcedure() {
			private static final long serialVersionUID = 1L;

			@Override
			public void init(IRecordFormat arg0, IRecordFormat arg1) {
				// Nothing to initialize
			}

			@Override
			public void execute(IArrayReader arrayReader, IArrayWriter writableArray) {
				biConsumer.accept(arrayReader, writableArray);
			}
		};
	}

	public static IUpdateWhereProcedure fromBiConsumer(AtomicReference<IRecordFormat> recordFormatRef,
			BiConsumer<IArrayReader, IArrayWriter> biConsumer) {
		return new IUpdateWhereProcedure() {
			private static final long serialVersionUID = 1L;

			@Override
			public void init(IRecordFormat recordFormat, IRecordFormat arg1) {
				recordFormatRef.compareAndSet(null, recordFormat);
			}

			@Override
			public void execute(IArrayReader arrayReader, IArrayWriter writableArray) {
				biConsumer.accept(arrayReader, writableArray);
			}
		};
	}

	public static ISelection makeSelection(String baseStore, Iterable<? extends String> fields) {
		return new Selection(baseStore, Iterables.toArray(fields, String.class));
	}
}

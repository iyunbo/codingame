/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.datastore.updatewhere;

import java.util.Collections;
import java.util.concurrent.atomic.AtomicLong;

import org.springframework.jmx.export.annotation.ManagedAttribute;

import com.google.common.annotations.Beta;
import com.qfs.chunk.IArrayReader;
import com.qfs.chunk.IArrayWriter;
import com.qfs.store.IReadableDatastore;

/**
 * Helps implementing an append-only store, but with a technical key in order to workaround append-only store defects
 * (as updateWhere over a single column leading to a full delete/add of the row).
 * 
 * This should be registered as an Insertion-time updateWhere, else insertion will be monothreaded as everything will be
 * submitted to the same partition
 * 
 * @author Benoit Lacelle
 *
 */
@Beta
public class ApexAutoIncrementUpdateWhere extends AApexSimpleUpdateWhereWrapper {
	private static final long serialVersionUID = -8222620732015836199L;

	protected final AtomicLong autoIncrement = new AtomicLong();

	public ApexAutoIncrementUpdateWhere(IReadableDatastore datastore, String storeName, String autoIncrementColumn) {
		super(datastore, storeName, Collections.emptyList(), Collections.singleton(autoIncrementColumn));
	}

	@Override
	protected void doUpdate(IArrayReader reader, IArrayWriter writer) {
		// Generate next index
		long currentRowIndex = autoIncrement.getAndIncrement();

		// Update the row with this unique index
		writer.writeLong(getOutputFieldIndex(0), currentRowIndex);
	}

	@ManagedAttribute
	public long getNextAutoIncrement() {
		return autoIncrement.get();
	}
};
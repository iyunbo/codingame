/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.spring;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.qfs.desc.IDatastoreSchemaDescription;
import com.qfs.desc.IReferenceDescription;
import com.qfs.desc.IStoreDescription;
import com.qfs.desc.IStoreDescriptionBuilder.ICanBuild;
import com.qfs.desc.IStoreDescriptionBuilder.ICanSpecifyDuplicateKeyWithinTransactionBehavior;
import com.qfs.desc.IStoreDescriptionBuilder.IDuplicateKeyWithinTransactionListener;
import com.qfs.desc.impl.DatastoreSchemaDescription;

import blasd.apex.server.config.store.IStoreDescriptionMerger;
import blasd.apex.server.config.store.StoreDescriptionMerger;
import blasd.apex.server.monitoring.loading.IApexDuplicateKeyWithinTransactionListener;

/**
 * Helps to build an {@link IDatastoreSchemaDescription} given {@link IApexStoreConfig}, {@link IStoreDescription} and
 * {@link ICanBuild}
 * 
 * @author Benoit Lacelle
 *
 */
@Configuration
public class ApexDatastoreSchemaSpringConfig {

	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexDatastoreSchemaSpringConfig.class);

	// with IDuplicateKeyWithinTransactionListener
	@Bean
	public IStoreDescriptionMerger apexDatastoreConfigBuilder(ApplicationContext applicationContext,
			IDuplicateKeyWithinTransactionListener duplicateListener) {
		IStoreDescriptionMerger configBuilder = new StoreDescriptionMerger();

		fillDatastoreConfigBuilder(configBuilder, applicationContext, duplicateListener);

		return configBuilder;
	}

	// without IDuplicateKeyWithinTransactionListener
	@Bean
	public IStoreDescriptionMerger apexDatastoreConfigBuilder(ApplicationContext applicationContext) {
		IStoreDescriptionMerger configBuilder = new StoreDescriptionMerger();

		// It is unclear if this should be a bean defined in ApexDatastoreSchemaSpringConfig
		IApexDuplicateKeyWithinTransactionListener duplicateKeyWithinTransactionListener =
				new ApexDatastoreSpringConfig().apexDuplicateKeyWithinTransactionListener();

		fillDatastoreConfigBuilder(configBuilder, applicationContext, duplicateKeyWithinTransactionListener);

		return configBuilder;
	}

	/**
	 * using an {@link ApplicationContext}, we can easily all beans of a given type even if there is none of them
	 */
	protected void fillDatastoreConfigBuilder(IStoreDescriptionMerger configBuilder,
			ApplicationContext applicationContext,
			IDuplicateKeyWithinTransactionListener duplicateListener) {
		// Register all IStoreDescription
		Map<String, IStoreDescription> storeDescriptions = applicationContext.getBeansOfType(IStoreDescription.class);
		configBuilder.addStoreDescriptions(storeDescriptions.values());

		// Build and register all ICanBuild
		Map<String, ICanBuild> canBuildDescriptions = applicationContext.getBeansOfType(ICanBuild.class);
		Collection<? extends IStoreDescription> builtDescription =
				completeStoreDescriptionBuilding(canBuildDescriptions.values(), duplicateListener);
		configBuilder.addStoreDescriptions(builtDescription);
	}

	/**
	 * Here is a nice place to apply some configuration to all stores, like the chunk size
	 * 
	 * @param canBuilds
	 * @param duplicateListener
	 * @return
	 */
	protected Collection<? extends IStoreDescription> completeStoreDescriptionBuilding(
			Collection<? extends ICanBuild> canBuilds,
			IDuplicateKeyWithinTransactionListener duplicateListener) {

		addCustomDuplicateListenerIfNotExplicitelySet(duplicateListener, canBuilds);

		List<IStoreDescription> storeDescriptions = new ArrayList<>();
		for (ICanBuild canBuild : canBuilds) {
			storeDescriptions.add(canBuild.build());
		}

		return storeDescriptions;
	}

	public static void addCustomDuplicateListenerIfNotExplicitelySet(
			IDuplicateKeyWithinTransactionListener duplicateListener,
			Collection<? extends ICanBuild> canBuilds) {
		for (ICanBuild canBuild : canBuilds) {
			IStoreDescription built = canBuild.build();
			IDuplicateKeyWithinTransactionListener duplicateKeyWithinTransaction =
					built.getDuplicateKeyWithinTransaction();
			if (duplicateKeyWithinTransaction == null) {
				// TODO set default duplicateListener only if not set explicitly for current store
				LOGGER.debug("There is no onDuplicateKeyWithinTransaction {} preconfigured");
				((ICanSpecifyDuplicateKeyWithinTransactionBehavior<?>) canBuild).onDuplicateKeyWithinTransaction()
						.callCustomListener(duplicateListener);
			} else {
				LOGGER.info("Keep custom IDuplicateKeyWithinTransactionListener in {}: {}",
						built.getName(),
						built.getDuplicateKeyWithinTransaction());
			}

		}
	}

	/**
	 * 
	 * Schema description bean.
	 * 
	 * @return schema description
	 */
	@Bean
	public IDatastoreSchemaDescription datastoreSchemaDescription(IStoreDescriptionMerger apexDatastoreConfigBuilder,
			ApplicationContext appContext) {
		Collection<IStoreDescription> stores = apexDatastoreConfigBuilder.merge();
		Collection<IReferenceDescription> references = appContext.getBeansOfType(IReferenceDescription.class).values();
		return new DatastoreSchemaDescription(stores, references);
	}
}

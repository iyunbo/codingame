/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.datastore.search;

import java.util.ConcurrentModificationException;
import java.util.function.BooleanSupplier;

import com.qfs.store.record.IRecord;
import com.qfs.store.record.IRecordAcceptor;
import com.qfs.store.record.IRecordFormat;
import com.qfs.store.record.IRecordReader;

/**
 * Protect IRecordReader against concurrent iteration over an ICursor
 * 
 * @author Benoit Lacelle
 *
 */
// We add Cloneable because PMD complains. It is anyway brought by IRecordReader
public class SafeRecordReader implements IRecordReader, Cloneable {

	// Index of the latest row in the cursor
	protected final BooleanSupplier currentRowIsValid;

	// The actual record
	protected final IRecordReader record;

	public SafeRecordReader(BooleanSupplier currentRowIsValid, IRecordReader record) {
		assert currentRowIsValid.getAsBoolean() : "The SafeRecordReader is initially not valid";
		this.currentRowIsValid = currentRowIsValid;
		this.record = record;
	}

	protected void checkIndex() {
		if (!currentRowIsValid.getAsBoolean()) {
			throw new ConcurrentModificationException(
					"You can not read a previous IRecordReader after iterating on an .iterator");
		}
	}

	@Override
	public String toString() {
		checkIndex();
		return record.toString();
	}

	@Override
	public boolean isNull(int index) {
		checkIndex();
		return record.isNull(index);
	}

	@Override
	public Object read(int index) {
		checkIndex();
		return record.read(index);
	}

	@Override
	public boolean readBoolean(int index) {
		checkIndex();
		return record.readBoolean(index);
	}

	@Override
	public int readInt(int index) {
		checkIndex();
		return record.readInt(index);
	}

	@Override
	public long readLong(int index) {
		checkIndex();
		return record.readLong(index);
	}

	@Override
	public double readDouble(int index) {
		checkIndex();
		return record.readDouble(index);
	}

	@Override
	public float readFloat(int index) {
		checkIndex();
		return record.readFloat(index);
	}

	// TODO use super.clone
	@Override
	public IRecord clone() { // NOPMD: TODO
		checkIndex();

		// We are cloning: to need to maintain the safety mechanism
		return record.clone();
	}

	@Override
	public IRecordFormat getFormat() {
		// The format is the same for all entries: no need to check for ConcurrentModificationException
		return record.getFormat();
	}

	@Override
	public void transfer(Object[] index) {
		checkIndex();
		record.transfer(index);
	}

	@Override
	public void transfer(IRecordAcceptor index) {
		checkIndex();
		record.transfer(index);
	}

	@Override
	public int readHashCode(int index) {
		checkIndex();
		return record.readHashCode(index);
	}

	@Override
	public Object read(String index) {
		checkIndex();
		return record.read(index);
	}

}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.datastore.search;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Stream;

import com.google.common.annotations.Beta;
import com.qfs.store.IDatastore;
import com.qfs.store.query.IDictionaryCursor;
import com.qfs.store.record.IRecordReader;

/**
 * Holds a {@link IDatastore} search result
 * 
 * @author Benoit Lacelle
 *
 */
public interface HasCursor {

	/**
	 * 
	 * @return bare-metal
	 */
	IDictionaryCursor asCursor();

	/**
	 * A stream faster for mono-threaded processes, but not able to provide IRecordReader in parallel, nor to collect
	 * them (i.e. moving to next element will corrupt previous IRecordReader). The previous recordReaders are protected
	 * by a SafeRecordReader
	 * 
	 * @return
	 * 
	 * @see SafeRecordReader
	 */
	Stream<? extends IRecordReader> stream();

	/**
	 * Enables parallel process of recordReader, at the cost of cloning entries. It is then safe to register the
	 * IRecordReader, and not just process entries.
	 * 
	 * @return
	 */
	Stream<? extends IRecordReader> parallelStream();

	/**
	 * @deprecated named following Collection.parallelStream
	 */
	@Deprecated
	default Stream<? extends IRecordReader> asMonoCursor() {
		return stream();
	}

	/**
	 * @deprecated named following Collection.parallelStream
	 */
	@Deprecated
	default Stream<? extends IRecordReader> asParallelStream() {
		return parallelStream();
	}

	/**
	 * @return {@link Map} which are still after iterating on next entry, and which has no limitation (e.g. a
	 *         {@link HashMap}), and wrapped in not-lazy List. This could consume a LOT of transient memory
	 */
	List<? extends Map<String, Object>> asFullMapInList();

	// @Beta
	// <T> Iterable<? extends T> asCustom(Function<IRecordReader, T> mapper);

	// TODO: find a way to check there is actually a only single value
	// available
	@Beta
	Optional<? extends IRecordReader> asSingleEntry();

	@Beta
	void withAcceptor(IApexPartitionedResultAcceptor partitionedResultAcceptor);

}
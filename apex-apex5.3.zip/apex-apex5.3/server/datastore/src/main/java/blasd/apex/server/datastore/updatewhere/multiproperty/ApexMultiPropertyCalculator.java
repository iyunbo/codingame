/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.datastore.updatewhere.multiproperty;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;

import com.google.common.collect.Lists;
import com.google.common.primitives.Ints;
import com.qfs.chunk.IArrayReader;
import com.qfs.chunk.IArrayWriter;
import com.qfs.condition.ICondition;
import com.qfs.condition.impl.BaseConditions;
import com.qfs.store.IDatastore;
import com.qfs.store.IDatastoreSchemaMetadata;
import com.qfs.store.IReadableDatastore;
import com.qfs.store.IStoreMetadata;
import com.qfs.store.record.IRecordFormat;
import com.qfs.store.selection.ISelection;
import com.qfs.store.selection.impl.Selection;
import com.qfs.store.transaction.ITransactionManager;
import com.qfs.store.transaction.ITransactionManager.IUpdateWhereProcedure;
import com.quartetfs.fwk.IProperty;
import com.quartetfs.fwk.impl.Property;

import blasd.apex.server.datastore.ApexDatastoreHelper;
import blasd.apex.server.datastore.condition.ApexConditionHelper;
import blasd.apex.server.datastore.transaction.ApexTransactionHelper;
import blasd.apex.server.datastore.updatewhere.ApexCountingDecoratorUpdateWhereProcedure;
import blasd.apex.server.datastore.updatewhere.ApexUpdateWhereHelper;
import blasd.apex.server.datastore.updatewhere.IApexUpdateWhereProcedureWrapper;
import blasd.apex.server.datastore.updatewhere.IHasWrittenFields;
import blasd.apex.server.loading.transaction.IApexCountingUpdateWhereProcedure;
import cormoran.pepper.jmx.PepperJMXHelper;

/**
 * An {@link IUpdateWhereProcedure} which enables to compute a fields based on a chain of expression. The chain will
 * fallback on next elements if the field resolution fails (e.g. the current element is null, or the reference failed)
 * 
 * @author Benoit Lacelle
 *
 */
@ManagedResource
public class ApexMultiPropertyCalculator
		implements IApexUpdateWhereProcedureWrapper, IHasWrittenFields, InitializingBean {
	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexMultiPropertyCalculator.class);

	protected static final Map<String, ?> JOIN_CHAIN_IS_BROKEN = Collections.emptyMap();

	/**
	 * {@link LinkedHashMap} to preserve the ordering of enrichments: a later multiProperty can depend on a previous
	 * multiProperty
	 */
	protected final Map<String, List<IApexMultiPropertyChain>> fieldNameToChainElement = new LinkedHashMap<>();

	protected final IReadableDatastore datastore;
	protected final IDatastoreSchemaMetadata metadata;
	protected final String baseStoreName;
	protected final IRecordFormat baseStoreFormat;

	/**
	 * How many entries has been considered for multiProperty calculation
	 */
	protected final AtomicLong nbConsidered = new AtomicLong();

	/**
	 * How many entries enrichment led to no update
	 */
	protected final AtomicLong nbSkipped = new AtomicLong();

	/**
	 * How many entry enrichment failed with an exception
	 */
	protected final AtomicLong nbException = new AtomicLong();

	protected final AtomicReference<int[]> outputFieldsIndexes = new AtomicReference<>(new int[0]);

	public ApexMultiPropertyCalculator(IReadableDatastore datastore, String baseStoreName) {
		this.datastore = datastore;
		this.baseStoreName = baseStoreName;
		this.metadata = datastore.getSchemaMetadata();
		this.baseStoreFormat = metadata.getStoreMetadata(baseStoreName).getStoreFormat().getRecordFormat();
	}

	protected void updateOutputFieldsIndexes() {
		outputFieldsIndexes.set(ApexDatastoreHelper.getFieldIndexes(baseStoreFormat, fieldNameToChainElement.keySet()));

		if (Ints.contains(outputFieldsIndexes.get(), -1)) {
			throw new RuntimeException("There is an unknwon field in " + fieldNameToChainElement.keySet());
		}
	}

	@Override
	public void afterPropertiesSet() {
		Set<String> computedFields = new HashSet<>();

		// Check chain properties are properly ordered by checking the later elements are not used by earlier elements
		List<String> reverseProperties = Lists.reverse(new ArrayList<>(fieldNameToChainElement.keySet()));

		for (String computedField : reverseProperties) {
			for (IApexMultiPropertyChain propertyChain : fieldNameToChainElement.get(computedField)) {
				String chainElementExpression = propertyChain.getExpression();
				if (computedFields.contains(chainElementExpression)) {
					throw new RuntimeException("The computedField " + computedField
							+ " relies on another computedField "
							+ chainElementExpression
							+ " which is later in the list of multiProperties");
				}
			}

			computedFields.add(computedField);
		}

		updateOutputFieldsIndexes();
	}

	public void addMultiProperty(String fieldName, String... propertyExpressions) {
		List<IProperty> propertyList = new ArrayList<>();

		for (String propertyExpression : propertyExpressions) {
			propertyList.add(new Property(fieldName, propertyExpression));
		}

		addMultiProperty(fieldName, propertyList);
	}

	public void addMultiProperty(String fieldName, List<IProperty> propertyList) {
		Object previous = fieldNameToChainElement.put(fieldName, computeChainElement(propertyList));

		if (previous != null) {
			throw new RuntimeException("One should not set 2 MultiProperty for the same field=" + fieldName);
		}
	}

	private List<IApexMultiPropertyChain> computeChainElement(List<IProperty> propertyList) {
		return propertyList.stream().map(this::computeChain).collect(Collectors.toList());
	}

	private IApexMultiPropertyChain computeChain(IProperty property) {
		List<String> path = ApexDatastoreHelper.splitFieldPath(property.getExpression());
		IStoreMetadata store = ApexDatastoreHelper.getTargetStore(datastore.getSchemaMetadata(), baseStoreName, path);
		String fieldName = ApexDatastoreHelper.getTargetColumn(path);

		return new ApexMultiPropertyChain(property,
				ApexDatastoreHelper.getDefaultValue(datastore, store.getName(), fieldName));
	}

	protected boolean isDefaultValue(Object currentValue, Object defaultValue) {
		return Objects.equals(defaultValue, currentValue);
	}

	public void registerUpdateWhereTrigger() {
		// registerUpdateWhereTrigger enable to be triggered on any row directly
		// inserted/updated, or impacted by a referenced store

		// TODO: we could check the path to decide if we can rely on a
		// TransactionTime
		ApexUpdateWhereHelper.registerContinuousUpdateWhereCommitTime(ApexUpdateWhereHelper.computeTriggerName(this),
				((IDatastore) datastore).getTransactionManager(),
				this,
				0);
	}

	/**
	 * In some cases, the enrichment can fail. Or {@link #updateEntriesOnTransaction()} has simply not been called not
	 * to have a CPU impact at loading time. Then, a human operator can query which facts should be submitted for
	 * enrichment
	 * 
	 * @param template
	 */
	@ManagedOperation
	public void forceEnrich(String template) {
		Map<String, String> templateAsStringMap = PepperJMXHelper.convertToMap(template);
		final Map<String, ?> templateAsMap =
				ApexDatastoreHelper.convertFromStringToObject(metadata, baseStoreName, templateAsStringMap);

		final ITransactionManager transactionManager = ((IDatastore) datastore).getTransactionManager();

		ApexTransactionHelper.updateWhere(transactionManager, new IApexUpdateWhereProcedureWrapper() {

			@Override
			public IApexCountingUpdateWhereProcedure getUpdateWhere() {
				return ApexMultiPropertyCalculator.this.getUpdateWhere();
			}

			@Override
			public ISelection getSelection() {
				return ApexMultiPropertyCalculator.this.getSelection();
			}

			@Override
			public long getNbUpdatedRow() {
				return ApexMultiPropertyCalculator.this.getNbUpdatedRow();
			}

			@Override
			public ICondition getCondition() {
				return ApexConditionHelper.convertToCondition(templateAsMap);
			}
		});
	}

	@Override
	public ISelection getSelection() {
		// We need to detect update of any of the possible enrichment
		Set<String> interestingFields = new HashSet<>();
		for (Entry<String, List<IApexMultiPropertyChain>> referenceDesc : fieldNameToChainElement.entrySet()) {
			// Ability to read current values: this will produce stats to know
			// how many entries has been updated
			interestingFields.add(referenceDesc.getKey());

			// Ability to read the different paths of the property chain
			for (IApexMultiPropertyChain p : referenceDesc.getValue()) {
				String propertyExpression = p.getExpression();

				interestingFields.add(propertyExpression);
			}
		}

		return new Selection(baseStoreName, interestingFields.toArray(new String[0]));
	}

	@Override
	public ICondition getCondition() {
		// The whole store should be maintained up-to-date
		return BaseConditions.TRUE;
	}

	@Override
	public IApexCountingUpdateWhereProcedure getUpdateWhere() {
		// TODO: actually check if there is referenced fields
		// @see ApexUpdateWhereWrapper.hasReferencedFields(ISelection)
		AtomicReference<IRecordFormat> recordFormat = new AtomicReference<>();

		return new ApexCountingDecoratorUpdateWhereProcedure(this.nbConsidered,
				ApexUpdateWhereHelper.fromBiConsumer(recordFormat, (arrayReader, writableArray) -> {
					try {
						fieldNameToChainElement.forEach((key,
								value) -> updateOneRow(arrayReader, writableArray, key, value, recordFormat.get()));
					} catch (RuntimeException e) {
						nbException.incrementAndGet();
						throw e;
					}
				}),
				true);
	}

	protected void updateOneRow(IArrayReader arrayReader,
			IArrayWriter writableArray,
			String fieldToWrite,
			List<IApexMultiPropertyChain> referenceHelper,
			IRecordFormat inputFormat) {
		// Initially, there is no value to set
		Optional<? extends Optional<?>> candidate = referenceHelper.stream()
				.map(candidatePropertyToRead -> valueIfNotOptional(arrayReader, inputFormat, candidatePropertyToRead))
				.filter(Optional::isPresent)
				.findFirst();

		// Set the value to set in the store. If no value to
		// set, leave the original value
		if (candidate.isPresent() && candidate.get().isPresent()) {
			writeSelectedValue(arrayReader, writableArray, inputFormat, fieldToWrite, candidate.get().get());
		}
	}

	protected Optional<?> valueIfNotOptional(IArrayReader arrayReader,
			IRecordFormat inputFormat,
			IApexMultiPropertyChain candidatePropertyToRead) {
		String expression = candidatePropertyToRead.getExpression();
		int inputIndex = inputFormat.getFieldIndex(expression);

		// Resolve this property
		Object valueToSet = arrayReader.read(inputIndex);

		if (valueToSet == null) {
			return Optional.empty();
		} else {
			// TODO: Handle the case the default value come from the base store, instead of the target store, which
			// is relevant if both stores have different default values
			if (isDefaultValue(valueToSet, candidatePropertyToRead.getDefaultValue())) {
				LOGGER.trace("Spot default value for {}", candidatePropertyToRead);
				return Optional.empty();
			} else {
				// We found a value: this is the value
				// to set
				return Optional.of(valueToSet);
			}
		}
	}

	protected void writeSelectedValue(IArrayReader arrayReader,
			IArrayWriter writableArray,
			IRecordFormat inputFormat,
			String fieldToWrite,
			Object valueToSet) {
		int currentValueIndex = inputFormat.getFieldIndex(fieldToWrite);

		Object currentValue = arrayReader.read(currentValueIndex);

		if (Objects.equals(currentValue, valueToSet)) {
			// TODO: Is it helpful to skip some updates?
			nbSkipped.incrementAndGet();
		} else {
			int outputIndex = baseStoreFormat.getFieldIndex(fieldToWrite);

			writableArray.write(outputIndex, valueToSet);
		}
	}

	@ManagedAttribute
	public long getStatsNbException() {
		return nbException.get();
	}

	@ManagedAttribute
	@Override
	public long getNbUpdatedRow() {
		return nbConsidered.get();
	}

	@Override
	public int[] writtenFields() {
		return outputFieldsIndexes.get();
	}

}

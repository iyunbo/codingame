/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.datastore.listener;

import java.util.Collection;
import java.util.Map.Entry;

import com.qfs.store.IDatastoreVersion;
import com.qfs.store.transaction.ITransactionInformation;

/**
 * The default IApexAccumulatedSelectionListener does nothing. It can be extending to reply only to relevant events
 * 
 * @author Benoit Lacelle
 *
 * @param <T>
 */
public class SimpleApexAccumulatedSelectionListener<T> implements IApexAccumulatedSelectionListener<T> {

	@Override
	public void transactionStarted(IDatastoreVersion datastoreVersion, ITransactionInformation transactionInformation) {
		// by default, do nothing
	}

	@Override
	public void transactionRolledBack() {
		// by default, do nothing
	}

	@Override
	public void transactionCommitted(IDatastoreVersion version,
			String storeName,
			Collection<T> added,
			Collection<T> deleted,
			Collection<Entry<T, T>> updated) {
		// by default, do nothing
	}

	@Override
	public void transactionCommittedWithTooManyEntries(IDatastoreVersion version) {
		// by default, do nothing
	}

}

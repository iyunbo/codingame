/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.partition;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.annotations.Beta;
import com.google.common.annotations.VisibleForTesting;
import com.google.common.collect.HashMultimap;
import com.google.common.collect.SetMultimap;
import com.qfs.desc.IDatastoreSchemaDescription;
import com.qfs.desc.IDatastoreSchemaDescriptionPostProcessor;
import com.qfs.desc.IFieldDescription;
import com.qfs.desc.IReferenceDescription;
import com.qfs.desc.IStoreDescription;
import com.qfs.platform.IPlatform;
import com.qfs.store.IDatastore;
import com.quartetfs.fwk.IPair;

import blasd.apex.server.config.description.ApexDescriptionHelper;

/**
 * Provides utility methods for {@link IDatastore} partitions like nice default partitioning
 * 
 * @author Benoit Lacelle
 * 
 */
public class ApexPartitioningHelper {

	private static final int MAX_BEFORE_LESS_PARTITIONS_THAN_CORES = 64;

	private static final int MAX_FOR_DOUBLING_CORES = 16;

	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexPartitioningHelper.class);

	// Prime number used by default in hash computation
	public static final int JAVA_DEFAULT_HASH = 31;

	protected ApexPartitioningHelper() {
		// hidden
	}

	/**
	 * QFS recommends 2 partitions per logical core http://support.quartetfs.com/confluence/display/AP5/Partitioning
	 * 
	 * @return
	 */
	public static int getDefaultNumberOfPartitions() {
		// The application may see only a subset of NUMA nodes: rely on QFS for this information, as
		// Runtime.availableProcessors would return the number of cores in the whole machine, independently of NUMA
		// restrictions
		return getDefaultNumberOfPartitions(IPlatform.CURRENT_PLATFORM.getProcessorCount());
	}

	@VisibleForTesting
	protected static int getDefaultNumberOfPartitions(int availableProcessors) {
		// In Autopivot, they prefer to always divide the number of cores by 2
		// https://github.com/activeviam/autopivot/blob/master/src/main/java/com/av/autopivot/AutoPivotGenerator.java
		if (availableProcessors <= MAX_FOR_DOUBLING_CORES) {
			// Double the number of partitions on small machines
			return availableProcessors * 2;
		} else if (availableProcessors <= MAX_BEFORE_LESS_PARTITIONS_THAN_CORES) {
			return availableProcessors;
		} else {
			// Prevent having too many partitions on large machines
			return availableProcessors / 2;
		}
	}

	public static String makeDefaultHashPartitioning() {
		return makeHashPartitioning(getDefaultNumberOfPartitions());
	}

	public static String makeHashPartitioning(int hashCardinality) {
		return ApexFieldPartitioningDTO.hashPrefix(hashCardinality);
	}

	public static ApexFieldPartitioningDTO makeDefaultHashPartitioning(String fieldName) {
		return ApexFieldPartitioningDTO.hashPartitioning(fieldName, getDefaultNumberOfPartitions());
	}

	public static ApexFieldPartitioningDTO makeHashPartitioning(String fieldName, int hashCardinality) {
		return new ApexFieldPartitioningDTO(fieldName, makeHashPartitioning(hashCardinality));
	}

	public static ApexFieldPartitioningDTO makeValuePartitioniong(String fieldName) {
		return ApexFieldPartitioningDTO.valuePartitioning(fieldName);
	}

	/**
	 * 
	 * @param schemaDescription
	 * @return
	 * 
	 *         TODO: make sure the partitioning is done on a fields used as ILevel
	 */
	@Beta
	public static Map<String, ApexFieldPartitioningDTO> selectPartitionFields(
			IDatastoreSchemaDescription schemaDescription,
			ApexFieldPartitioningDTO firstCandidate,
			ApexFieldPartitioningDTO... candidateFieldNames) {
		// Remember target store to compute partitioning for them automatically
		SetMultimap<String, String> sourceToTarget = HashMultimap.create();
		{
			for (IReferenceDescription ref : schemaDescription.getReferenceDescriptions()) {
				sourceToTarget.put(ref.getOwnerStore(), ref.getTargetStore());
			}
		}

		SetMultimap<String, ApexFieldPartitioningDTO> storeToPartitionField = HashMultimap.create();

		Map<String, IStoreDescription> storeToDescription = new HashMap<>();

		Set<String> consideredStores = new HashSet<>();

		for (IStoreDescription storeDescription : schemaDescription.getStoreDescriptions()) {
			storeToDescription.put(storeDescription.getName(), storeDescription);

			if (sourceToTarget.values().contains(storeDescription.getName())) {
				// There is at least one reference to this store. Then, this
				// partition will be implied by the owner store
				continue;
			} else {
				consideredStores.add(storeDescription.getName());
			}

			ApexFieldPartitioningDTO selectPartitionField =
					selectPartitionField(storeDescription, firstCandidate, candidateFieldNames);

			if (selectPartitionField != null) {
				storeToPartitionField.put(storeDescription.getName(), selectPartitionField);
			}
		}

		while (true) {
			SetMultimap<String, ApexFieldPartitioningDTO> additionalStoreToPartition = HashMultimap.create();

			for (Entry<String, ApexFieldPartitioningDTO> oneStoreToPartition : storeToPartitionField.entries()) {
				ApexFieldPartitioningDTO partitionField = oneStoreToPartition.getValue();

				for (IReferenceDescription reference : schemaDescription.getReferenceDescriptions()) {
					if (reference.getOwnerStore().equals(oneStoreToPartition.getKey())) {
						for (IPair<String, String> fieldMapping : reference.getFieldsMapping()) {
							if (partitionField.fieldName.equals(fieldMapping.getKey())) {
								IFieldDescription targetField = storeToDescription.get(reference.getTargetStore())
										.getField(fieldMapping.getValue());

								ApexFieldPartitioningDTO partitioningDesc =
										new ApexFieldPartitioningDTO(targetField.getName(),
												partitionField.partitioningDescription);
								additionalStoreToPartition.put(reference.getTargetStore(), partitioningDesc);

								break;
							}
						}
					}
				}
			}

			boolean isChanged = storeToPartitionField.putAll(additionalStoreToPartition);

			if (!isChanged) {
				break;
			}
		}

		Map<String, ApexFieldPartitioningDTO> storeToPartition = new HashMap<>();
		for (String storeName : storeToPartitionField.keySet()) {
			Set<ApexFieldPartitioningDTO> partitionFields = storeToPartitionField.get(storeName);
			if (partitionFields.size() == 1) {
				storeToPartition.put(storeName, partitionFields.iterator().next());
			}
		}

		LOGGER.info("Default partitionning (before custom configuration): {}", storeToPartition);

		return storeToPartition;
	}

	/**
	 * @return build the partition description for a given store
	 */
	public static ApexFieldPartitioningDTO selectPartitionField(IStoreDescription storeDescription,
			ApexFieldPartitioningDTO firstCandidate,
			ApexFieldPartitioningDTO... candidateFieldNames) {
		// Try to keep the first preferred field

		if (null != storeDescription.getField(firstCandidate.fieldName)) {
			return firstCandidate;
		}

		for (ApexFieldPartitioningDTO preferedField : candidateFieldNames) {
			IFieldDescription fd = storeDescription.getField(preferedField.fieldName);

			if (fd != null) {
				return preferedField;
			}
		}

		return null;
	}

	public static IDatastoreSchemaDescription applyPartitionning(IDatastoreSchemaDescription schemaDesc,
			Map<? extends String, ?> storeToPartitioning) {
		// Need HashMap as PartitioningPostProcessor will mutate it
		return makeSchemaPostProcessor(storeToPartitioning).process(schemaDesc);
	}

	public static IDatastoreSchemaDescriptionPostProcessor makeSchemaPostProcessor(
			Map<? extends String, ?> storeToPartitioning) {
		return ApexDescriptionHelper.makeSchemaPostProcessor(storeToPartitioning);
	}

	/**
	 * 
	 * @return a new description is returned with the requested partitioning
	 */
	public static IStoreDescription withPartitioning(IStoreDescription storeDescription,
			ApexFieldPartitioningDTO apexFieldPartitioningDTO) {
		return ApexDescriptionHelper.withPartitioning(storeDescription, apexFieldPartitioningDTO.toString());
	}

	/**
	 * A typical partitioning strategy consists in having a field with value partitioning (typically an AsOfDate) and a
	 * hashed partitioning over a well-balanced and medium caridnality field
	 * 
	 * @param storeDescription
	 * @param partitioning
	 * @return
	 */
	public static String makeValueHashPartitioning(String valuePartitioning, String hashedPartitioned, int nbHashed) {
		return makeValuePartitioniong(valuePartitioning) + "|" + makeHashPartitioning(hashedPartitioned, nbHashed);
	}
}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.datastore.updatewhere;

import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedResource;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Sets;
import com.google.common.primitives.Ints;
import com.qfs.chunk.IArrayReader;
import com.qfs.chunk.IArrayWriter;
import com.qfs.condition.impl.BaseConditions;
import com.qfs.store.IReadableDatastore;

/**
 * An {@link AApexSimpleUpdateWhereWrapper} which should prevent updating rows if not necessary. This could lead to
 * better performances if the updateWhere condition is much bigger than the actual set of impacted rows.
 * 
 * @author Benoit Lacelle
 * 
 * @see http://support.quartetfs.com/jira/browse/APS-8304
 * @see http://support.quartetfs.com/jira/browse/APS-8445
 * @see http://support.quartetfs.com/jira/browse/APS-9405
 */
@ManagedResource
public abstract class AApexSkipNoOpUpdateWhereWrapper extends AApexSimpleUpdateWhereWrapper {
	private static final long serialVersionUID = 7280733220507612127L;

	protected static final Logger LOGGER = LoggerFactory.getLogger(AApexSkipNoOpUpdateWhereWrapper.class);

	protected final AtomicLong nbNoOpRow = new AtomicLong();

	protected final List<? extends String> originalInputFieldPathes;
	protected final List<? extends String> originalOutputFieldNames;

	public AApexSkipNoOpUpdateWhereWrapper(IReadableDatastore datastore,
			String storeName,
			Collection<? extends String> inputFieldPathes,
			Collection<? extends String> ouputFields) {
		super(datastore.getSchemaMetadata(),
				datastore.getDictionaries(),
				storeName,
				BaseConditions.TRUE,
				// To prevent no-op, when need to be able to read output fields
				mergeInSet(ouputFields, inputFieldPathes),
				ouputFields);

		this.originalInputFieldPathes = ImmutableList.copyOf(inputFieldPathes);
		this.originalOutputFieldNames = ImmutableList.copyOf(ouputFields);
	}

	@Override
	public int getReadFieldIndex(int indexInSelected) {
		if (indexInSelected == -1) {
			return -1;
		} else {
			String originalFieldIndex = originalInputFieldPathes.get(indexInSelected);

			return getRawReadFieldIndex(originalFieldIndex);
		}
	}

	@Override
	public void execute(IArrayReader reader, IArrayWriter writer) {
		AtomicBoolean isUpdated = new AtomicBoolean();

		// Do the actual update process
		IArrayWriter proxy = proxy(isUpdated, reader, writer);

		doUpdate(reader, proxy);

		if (isUpdated.get()) {
			// Register one more row is updated
			nbUpdatedRow.incrementAndGet();
		} else {
			LOGGER.trace("The updateWHere has triggered writes, but they appeared to be no-op");
			nbNoOpRow.incrementAndGet();
		}
	}

	@ManagedAttribute
	public long getNbNoOpRow() {
		return nbNoOpRow.get();
	}

	protected IArrayWriter proxy(AtomicBoolean isUpdated, IArrayReader reader, IArrayWriter writer) {
		return new ArrayWriterDecorator(writer) {

			@Override
			public void write(int index, Object newValue) {
				int indexInOriginalOutputFields =
						Ints.indexOf(AApexSkipNoOpUpdateWhereWrapper.this.outputFieldIndexes, index);
				String fieldName = originalOutputFieldNames.get(indexInOriginalOutputFields);

				Object currentValue = reader.read(getRawReadFieldIndex(fieldName));

				if (Objects.equals(currentValue, newValue)) {
					LOGGER.trace("Skip update of {} as it is constant to {}", fieldName, currentValue);
				} else {
					LOGGER.trace("Update of {} from {} to {}", fieldName, currentValue, newValue);
					writer.write(index, newValue);
					isUpdated.set(true);
				}
			}

			@Override
			public void writeBoolean(int index, boolean newValue) {
				writer.writeBoolean(index, newValue);
				isUpdated.set(true);
			}

			@Override
			public void writeDouble(int index, double newValue) {
				writer.writeDouble(index, newValue);
				isUpdated.set(true);
			}

			@Override
			public void writeFloat(int index, float newValue) {
				writer.writeFloat(index, newValue);
				isUpdated.set(true);
			}

			@Override
			public void writeInt(int index, int newValue) {
				writer.writeInt(index, newValue);
				isUpdated.set(true);
			}

			@Override
			public void writeLong(int index, long newValue) {
				writer.writeLong(index, newValue);
				isUpdated.set(true);
			}
		};
	}

	public static Collection<? extends String> mergeInSet(Collection<? extends String> ouputFields,
			Collection<? extends String> inputFieldPathes) {
		return Sets.union(ImmutableSet.copyOf(ouputFields), ImmutableSet.copyOf(inputFieldPathes));
	}

}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.datastore.condition;

import java.util.concurrent.TimeoutException;

import com.google.common.annotations.VisibleForTesting;
import com.qfs.concurrent.ICompletionSync;
import com.qfs.store.IDatastoreSchemaVersion;
import com.qfs.store.IStore;
import com.qfs.store.IStorePartitionView;
import com.qfs.store.IStoreVersion;
import com.qfs.store.impl.SchemaHelper;
import com.qfs.store.query.ICompiledQuery;
import com.qfs.store.query.IDictionaryCursor;
import com.qfs.store.query.IPartitionedResultAcceptor;
import com.qfs.store.query.IQueryVisitor;
import com.qfs.store.query.impl.DatastoreQueryHelper;
import com.qfs.store.query.impl.DatastoreQueryHelper.CursorCreator;
import com.qfs.store.query.impl.QueryRunner;
import com.qfs.store.record.IRecordFormat;

/**
 * We extends {@link QueryRunner} to monitor to time needed to prepare the {@link IDictionaryCursor}
 * 
 * @author Benoit Lacelle
 * 
 */
public class ApexQueryRunner extends QueryRunner {
	protected final IApexQueryManagerMonitor apexQueryManager;

	public ApexQueryRunner(IDatastoreSchemaVersion schema, IApexQueryManagerMonitor apexQueryManager) {
		super(schema);

		this.apexQueryManager = apexQueryManager;
	}

	/**
	 * Add a setter else compiledQuery is not visible to {@link ApexQueryManagerVersion}
	 * 
	 * @param compiledQuery
	 */
	protected void setCompiledQuery(ICompiledQuery compiledQuery) {
		this.compiledQuery = compiledQuery;
	}

	/**
	 * As we can't add a constructor in QueryRunner, we override each reference
	 * 
	 * @return
	 */
	protected ICompiledQuery getCompiledQuery() {
		return this.compiledQuery;
	}

	@Override
	protected IDictionaryCursor runCursor() throws TimeoutException {
		IQueryVisitor<DatastoreQueryHelper.CursorCreator> queryVisitor = recordQuery -> {
			ICompiledQuery localCompiledQuery = getCompiledQuery();
			IStore<?, ? extends IStorePartitionView> store =
					getStore(localCompiledQuery.getOriginatingQuery().getStoreName());
			IRecordFormat format = SchemaHelper.getFormat(store.getMetadata(),
					localCompiledQuery.getOriginatingQuery().getSelectedFields());

			return new DatastoreQueryHelper.CursorCreator(localCompiledQuery, format);
		};

		DatastoreQueryHelper.CursorCreator creator = getCompiledQuery().getOriginatingQuery().accept(queryVisitor);

		// Submit in the EventBus as the time required to compute the
		// IDictionaryCursor could be very long
		long start = now();
		try {
			runAndWaitCursor(creator);
		} finally {
			apexQueryManager.onCursorPrepared(getCompiledQuery(), now() - start);
		}

		return creator.getCursor();
	}

	@VisibleForTesting
	protected long now() {
		return System.currentTimeMillis();
	}

	/**
	 * @see com.qfs.store.query.impl.AQueryRunner.runCursor()
	 */
	protected void runAndWaitCursor(CursorCreator creator) throws TimeoutException {
		ICompletionSync sync = runCompletion(creator);
		if (this.timeout > 0L) {
			sync.awaitCompletion(this.timeout, this.timeoutUnit);
		} else {
			sync.awaitCompletion();
		}
	}

	/**
	 * Re-write super.runCompletion to use overridable getCompiledQuery
	 */
	@Override
	protected ICompletionSync runCompletion(IPartitionedResultAcceptor acceptor) {
		IStoreVersion store = this.schema.getStore(getCompiledQuery().getOriginatingQuery().getStoreName());
		if (this.onCurrentThread) {
			getCompiledQuery().run(store, acceptor, this.parameters);
			return CURRENT_THREAD_COMPLETION_SYNC;
		}
		return this.compiledQuery.submit(store, acceptor, this.parameters);
	}
}

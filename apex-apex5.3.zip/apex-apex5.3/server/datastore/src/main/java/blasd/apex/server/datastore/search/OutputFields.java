/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.datastore.search;

import java.util.Optional;

import com.qfs.store.record.IRecordReader;

/**
 * Which fields should be returned by datastore query
 * 
 * @author Benoit Lacelle
 *
 */
public interface OutputFields extends QueryIsReady, IsWherable {
	/**
	 * It may be useful if the search will be used to do removeByKeys
	 * 
	 * @return all key fields defined in the searched store
	 */
	OutputFields selectKeyFields();

	/**
	 * Default behavior
	 * 
	 * @return all fields defined in the searched store
	 */
	OutputFields selectStoreFields();

	/**
	 * It may be usefull if one want to display all the available information
	 * 
	 * @return the query will return all fields of current store and directly and indirectly joined stores
	 */
	OutputFields selectReachableFields();

	OutputFields select(Iterable<? extends String> fields);

	OutputFields select(String... fields);

	// <T> SingleOutputField<T> singleField(String fieldName, Class<T> clazz);

	Optional<IRecordReader> getByKeyIndexes(int... keyIndexes);

	/**
	 * 
	 * @param keyValues
	 * @return Optional.empty if there is no entry matching this key
	 */
	Optional<IRecordReader> getByKey(Object... keyValues);

	IsPrepared<Optional<IRecordReader>> prepareByKey();

}
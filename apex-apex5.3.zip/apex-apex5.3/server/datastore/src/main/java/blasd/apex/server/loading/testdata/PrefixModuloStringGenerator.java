/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.loading.testdata;

import java.util.ArrayList;
import java.util.List;

/**
 * IDatastore column generate for String with a predefined prefix, and suffix given a modulo
 * 
 * @author Benoit Lacelle
 *
 */
// TODO: Cache Strings
public class PrefixModuloStringGenerator extends PrefixStringGenerator {
	protected final int modulo;

	protected final List<String> cache = new ArrayList<>();

	public PrefixModuloStringGenerator(String prefix, int modulo) {
		super(prefix);

		this.modulo = modulo;

		if (modulo < Integer.MAX_VALUE) {
			for (int i = 0; i < modulo; i++) {
				// .toString to precompute hashCode
				cache.add(super.generate(i).toString());
			}
		}
	}

	@Override
	public Object generate(long index) {
		if (modulo < Integer.MAX_VALUE) {
			return cache.get((int) (index % modulo));
		} else {
			return super.generate(index);
		}
	}

	@Override
	protected long cleanIndex(long index) {
		return index % modulo;
	}
}

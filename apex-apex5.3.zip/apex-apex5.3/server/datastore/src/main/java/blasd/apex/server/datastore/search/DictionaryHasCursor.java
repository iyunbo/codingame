/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.datastore.search;

import java.io.Closeable;
import java.io.IOException;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import com.qfs.dic.IDictionary;
import com.qfs.store.query.IDictionaryCursor;
import com.qfs.store.record.IRecordReader;
import com.qfs.store.record.impl.RecordFormat;

/**
 * A AHasCursor for a single field, relying on the undelrying {@link IDictionary}
 * 
 * @author Benoit Lacelle
 *
 */
public class DictionaryHasCursor extends AHasCursor {

	protected final IDictionary<?> dictionary;
	protected final int currentSize;

	protected final String fieldName;

	public DictionaryHasCursor(IDictionary<?> dictionary, String fieldName) {
		this.dictionary = dictionary;
		this.currentSize = dictionary.size();
		this.fieldName = fieldName;
	}

	@Override
	public void withAcceptor(IApexPartitionedResultAcceptor partitionedResultAcceptor) {
		if (partitionedResultAcceptor instanceof Closeable) {
			try {
				((Closeable) partitionedResultAcceptor).close();
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}

		throw new UnsupportedOperationException("TODO");
	}

	@Override
	public Stream<? extends IRecordReader> stream() {
		RecordFormat recordFormat = new RecordFormat(new String[] { fieldName }, 0);
		return IntStream.range(0, currentSize)
				.mapToObj(dictionary::read)
				.map(o -> new ImmutableSingleFieldRecordReader(recordFormat, o));
	}

	@Override
	public Stream<? extends IRecordReader> parallelStream() {
		return stream().parallel();
	}

	@Override
	public Stream<? extends IRecordReader> asMonoCursor() {
		return stream();
	}

	@Override
	public IDictionaryCursor asCursor() {
		throw new UnsupportedOperationException("TODO");
	}

}

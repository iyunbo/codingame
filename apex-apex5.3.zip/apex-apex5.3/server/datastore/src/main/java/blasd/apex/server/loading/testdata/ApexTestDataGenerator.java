/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.loading.testdata;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.LongFunction;
import java.util.stream.LongStream;
import java.util.stream.Stream;

import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.ReflectionUtils;

import com.codahale.metrics.SlidingWindowReservoir;
import com.codahale.metrics.Timer;
import com.codahale.metrics.Timer.Context;
import com.google.common.collect.ImmutableList;
import com.google.common.primitives.Ints;
import com.qfs.literal.ILiteralType;
import com.qfs.store.IDatastore;
import com.qfs.store.IDatastoreSchemaMetadata;
import com.qfs.store.IReadableDatastore;
import com.qfs.store.IStoreMetadata;
import com.qfs.store.Types;
import com.qfs.store.record.IByteRecordFormat;
import com.qfs.store.transaction.ITransactionManager;
import com.quartetfs.biz.pivot.IActivePivotManager;
import com.quartetfs.fwk.Registry;
import com.quartetfs.fwk.format.IParser;
import com.quartetfs.fwk.format.impl.AVectorParser;
import com.quartetfs.fwk.format.impl.AVectorParserSpy;
import com.quartetfs.fwk.util.IMappedTuple;

import blasd.apex.metrics.ApexMetricsHelper;
import blasd.apex.server.datastore.ApexDatastoreHelper;
import blasd.apex.server.datastore.transaction.ApexInTransactionHelper;
import blasd.apex.server.datastore.transaction.ApexTransactionHelper;
import blasd.apex.server.loading.parser.IParserWithClass;
import blasd.apex.server.loading.transaction.ApexTuplizerHelper;
import blasd.apex.server.test.IApexTestConstants;
import cormoran.pepper.logging.PepperLogHelper;

/**
 * Try to generate a default set of data, being aware of references
 * 
 * @author Benoit Lacelle
 */
public class ApexTestDataGenerator implements IApexDataGenerator {

	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexTestDataGenerator.class);

	public static final int DEFAULT_VECTOR_LENGTH = 100;
	public static final int LOG_FIRST_ROWS = 10;

	// We we log some performance info every N generated rows
	public static final int MODULO_LOG_GENERATION_RATE = 100000;

	protected final AtomicInteger generationIndexer = new AtomicInteger();

	protected final ITransactionManager transactionManager;

	/**
	 * 
	 * @param transactionManager
	 *            an {@link IReadableDatastore} as {@link ApexTestDataGenerator} generates data, but is not responsible
	 *            for inserting it
	 */
	public ApexTestDataGenerator(ITransactionManager transactionManager) {
		this.transactionManager = transactionManager;
	}

	// An unsafe constructor for the sake of simplicity
	public ApexTestDataGenerator(IReadableDatastore datastore) {
		this(((IDatastore) datastore).getTransactionManager());
	}

	// An unsafe constructor for the sake of simplicity
	public ApexTestDataGenerator(IActivePivotManager apManager) {
		this(apManager.getDatastore());
	}

	/**
	 * 
	 * @param store
	 * @param fieldName
	 * @param modulo
	 *            the expected cardinality for given field
	 * @return a generator converting an index to a relevant value forgiven store column, with given cardinality
	 */
	protected LongFunction<?> makeGenerator(IStoreMetadata store, String fieldName, final int modulo) {
		int fieldType = store.getStoreFormat()
				.getRecordFormat()
				.getType(store.getStoreFormat().getRecordFormat().getFieldIndex(fieldName));

		if (Types.isPrimitive(fieldType)) {
			// TODO: WHy CONTENT instead of PHYSICAL?
			switch (Types.getContentType(fieldType)) {
			case Types.CONTENT_INT:
				return index -> (int) index % modulo;
			case Types.CONTENT_LONG:
				return index -> index % modulo;
			case Types.CONTENT_FLOAT:
				return index -> (float) index % modulo;
			case Types.CONTENT_DOUBLE:
				return index -> (double) index % modulo;
			case Types.CONTENT_BOOLEAN:
				return index -> {
					if (index % 1 == 0) {
						return Boolean.TRUE;
					} else {
						return Boolean.FALSE;
					}
				};

			default:
				throw new RuntimeException("Unexpected primitive LiteralType for field=" + fieldName);
			}
		} else {
			String parserKey = store.getParserPlugins().get(fieldName);

			if (Types.isArray(fieldType)) {
				switch (Types.getContentType(fieldType)) {
				case Types.CONTENT_FLOAT: {
					int size = getVectorSize(parserKey);

					return makeRandomFloatVector(size, modulo);
				}
				case Types.CONTENT_DOUBLE: {
					int size = getVectorSize(parserKey);

					return makeRandomDoubleVector(size, modulo);
				}
				case Types.CONTENT_INT: {
					int size = getVectorSize(parserKey);

					return makeRandomIntVector(size, modulo);
				}
				case Types.CONTENT_LONG: {
					int size = getVectorSize(parserKey);

					return makeRandomLongVector(size, modulo);
				}
				default:
					// We prefer not to insert an incompatible vector
					return new NullGenerator<Object>();
				}
			} else {
				final LongFunction<Object> objectGenerator = new PrefixModuloStringGenerator(fieldName, modulo);
				switch (parserKey) {
				// The Integer Autoboxed case
				case IParser.INTEGER:
					throw new RuntimeException(IParser.INTEGER + " should be replaced with " + IParser.INT);
				case ILiteralType.STRING:
					return index -> {
						Object generatedValue = objectGenerator.apply(index);

						if (generatedValue == null) {
							return null;
						} else {
							return generatedValue.toString();
						}
					};
				// TODO: where is defined Object? It happens for
				// calculatedColumns
				case "Object":
					return objectGenerator;

				default:
					LongFunction<?> fromParser = makeGeneratorGivenParser(parserKey);
					if (fromParser == null) {
						LOGGER.warn("Generating a random String for field {} with not-handled IParser key: {}",
								fieldName,
								parserKey);

						return objectGenerator;
					} else {
						return fromParser;
					}
				}
			}
		}
	}

	public LongFunction<?> makeGeneratorGivenParser(String parserKey) {
		IParser<?> parser = Registry.getPlugin(IParser.class).valueOf(parserKey);

		if (parser == null) {
			return null;
		}

		// TODO: Introduce a IGenerator type, one for each IParser
		// type?
		if (parser instanceof IParserWithClass<?>) {
			// We assume there is a default ctor
			try {
				Class<?> classToInstanciate = ((IParserWithClass<?>) parser).getParsedClass();

				Object newInstance = null;
				try {
					if (classToInstanciate.getConstructor() != null) {
						newInstance = classToInstanciate.getConstructor().newInstance();
					}
				} catch (NoSuchMethodException | SecurityException | IllegalArgumentException
						| InvocationTargetException e) {
					LOGGER.trace("Missing contructors", e);
				}
				try {
					// Useful for java8 dates
					if (ReflectionUtils.findMethod(classToInstanciate, "now") != null) {
						newInstance = ReflectionUtils.findMethod(classToInstanciate, "now").invoke(null);
					}
				} catch (SecurityException | IllegalArgumentException | InvocationTargetException e) {
					LOGGER.trace("Missing contructors", e);
				}

				if (newInstance == null) {
					return null;
				} else {
					return new ConstantGenerator<>(newInstance);
				}
			} catch (InstantiationException | IllegalAccessException e) {
				throw new RuntimeException(e);
			}
		} else if (parser.key().toString().toLowerCase().startsWith(IParser.DATE.toLowerCase())) {
			return new ConstantGenerator<>(makeRandomDate());
		} else {
			return null;
		}
	}

	protected Object makeRandomValue(IStoreMetadata store, String fieldName, int modulo, long index) {
		return makeGenerator(store, fieldName, modulo).apply(index);
	}

	public static IColumnarGenerator<float[]> makeRandomFloatVector(final int size, final int modulo) {
		return new FloatArrayGenerator(size, modulo);
	}

	public static IColumnarGenerator<double[]> makeRandomDoubleVector(final int size, final int modulo) {
		return new DoubleArrayGenerator(size, modulo);
	}

	public static IColumnarGenerator<int[]> makeRandomIntVector(final int size, final int modulo) {
		return new IntArrayGenerator(size, modulo);
	}

	public static LongFunction<long[]> makeRandomLongVector(final int size, final int modulo) {
		return new LongArrayGenerator(size, modulo);
	}

	protected Date makeRandomDate() {
		// Make a Date corresponding to a round date
		return new LocalDate().toDate();
	}

	protected int getVectorSize(String parserKey) {
		IParser<?> parser = Registry.getPlugin(IParser.class).valueOf(parserKey);

		final int size;
		if (parser instanceof AVectorParser<?>) {
			Integer parserVectorSize = AVectorParserSpy.getVectorSize((AVectorParser<?>) parser);

			if (parserVectorSize == null) {
				size = DEFAULT_VECTOR_LENGTH;
			} else {
				size = parserVectorSize;
			}
		} else {
			size = DEFAULT_VECTOR_LENGTH;
		}

		// TODO: if size = DEFAULT_VECTOR_LENGTH, we should find the size of a
		// vector already in the store, else these vectors won't be compatible
		// for SUM aggregation

		return size;
	}

	@Override
	public void insertLinesWhileInTransaction(OneLineTemplate oneLineTemplate, long nbRows) {
		Map<String, ? extends Stream<?>> dataToPush = prepareData(oneLineTemplate, nbRows);

		for (String store : dataToPush.keySet()) {
			ApexInTransactionHelper.addInTransaction(transactionManager, store, dataToPush.get(store));
		}
	}

	@Override
	public void insertLines(final OneLineTemplate oneLineTemplate, final long nbRows) {
		// TODO: Select only relevant stores
		ApexTransactionHelper.executeInTransaction(transactionManager,
				transactionManager.getMetadata().getStoreNames(),
				() -> insertLinesWhileInTransaction(oneLineTemplate, nbRows));
	}

	@Override
	public Map<String, ? extends Stream<? extends Map<String, ?>>> prepareData(OneLineTemplate oneLineTemplate,
			long nbRows) {
		if (nbRows <= 0) {
			LOGGER.info("Do not insert any rows");
			return Collections.emptyMap();
		}

		String storeName = oneLineTemplate.getStoreName();

		int generationIndex = generationIndexer.getAndIncrement();
		IMappedTuple singleEntry = convertToTupleOfGenerators(generationIndex, oneLineTemplate);

		if (nbRows == 1) {
			// DO not log too often to reduce logs in tests
			LOGGER.trace("Insert {} entries in {} for {}", nbRows, storeName, oneLineTemplate);
		} else {
			LOGGER.debug("Insert {} entries in {} for {}", nbRows, storeName, oneLineTemplate);
		}

		Stream<? extends Map<String, ?>> mainIt = pushBaseStoreEntries(transactionManager.getMetadata()
				.getStoreMetadata(storeName), singleEntry, nbRows, generationIndex);

		return Collections.singletonMap(storeName, mainIt);
	}

	@Override
	public Stream<? extends Map<String, ?>> generate(String storeName, Map<? extends String, ?> template, long nbRows) {
		if (nbRows <= 0) {
			return Stream.empty();
		} else {
			return prepareData(new OneLineTemplate(storeName, template), nbRows).get(storeName);
		}
	}

	/**
	 * Prepare an entry where fields are associated to a clean generator
	 * 
	 * @param generationIndex
	 * @param oneLineTemplate
	 * @param storeToSingleEnrichmentEntry
	 * @param fieldToTargetFields
	 */
	protected IMappedTuple convertToTupleOfGenerators(int generationIndex, OneLineTemplate oneLineTemplate) {
		final IDatastoreSchemaMetadata schemaMetadata = transactionManager.getMetadata();
		IStoreMetadata baseStore = schemaMetadata.getStoreMetadata(oneLineTemplate.storeName);

		// Prepare tuples for concerned stores
		IMappedTuple singleEntry = ApexTuplizerHelper.newTuple(baseStore.getStoreFormat().getRecordFormat());

		// TODO: Check for unused constrain
		for (Entry<? extends String, ?> entry : oneLineTemplate.template.entrySet()) {
			List<String> keyPath = ApexDatastoreHelper.splitFieldPath(entry.getKey());
			IStoreMetadata targetStore =
					ApexDatastoreHelper.getTargetStore(schemaMetadata, baseStore.getName(), keyPath);
			String targetStoreName = targetStore.getName();

			// This class used to handle feeding enrichment store in addition of the base store
			if (!targetStoreName.equals(baseStore.getName())) {
				throw new IllegalArgumentException("We should push only into " + baseStore.getName()
						+ " but received template for "
						+ targetStoreName);
			}

			String key = keyPath.get(keyPath.size() - 1);
			Object value = entry.getValue();

			final Object cleanValue;

			if (value instanceof CharSequence) {
				Object asObject = ApexDatastoreHelper
						.convertFieldValueToObject(schemaMetadata, targetStoreName, key, (CharSequence) value);

				cleanValue = new ConstantGenerator<>(asObject);
			} else if (value == null || value == IApexTestConstants.NULL_MARKER) {
				cleanValue = new ConstantGenerator<>(null);
			} else if (value instanceof Collection<?>) {
				cleanValue = value;
			} else if (value instanceof Object[]) {
				cleanValue = Arrays.asList((Object[]) value);
			} else if (value instanceof LongFunction<?>) {
				// Make a constant generator
				cleanValue = value;
			} else {
				// Make a constant generator
				cleanValue = new ConstantGenerator<>(value);
			}
			singleEntry.put(key, cleanValue);
		}

		return singleEntry;
	}

	/**
	 * 
	 * @param storeMetadata
	 * @param template
	 * @param nbRows
	 * @param generationIndex
	 * @return the data to insert in given store
	 */
	protected Stream<? extends Map<String, ?>> pushBaseStoreEntries(final IStoreMetadata storeMetadata,
			Map<String, Object> template,
			final long nbRows,
			final int generationIndex) {

		IByteRecordFormat recordFormat = storeMetadata.getStoreFormat().getRecordFormat();

		final List<LongFunction<?>> indexToGenerator = new ArrayList<>(recordFormat.getFieldCount());

		int[] keyIndexes = storeMetadata.getStoreFormat().getKeyFields();

		Set<Integer> indexesWithPrimeModulo = new HashSet<>();

		for (int i = 0; i < recordFormat.getFieldCount(); i++) {
			String fieldName = recordFormat.getFieldName(i);
			Object currentValue = template.get(fieldName);

			if (currentValue instanceof LongFunction<?>) {
				indexToGenerator.add((LongFunction<?>) currentValue);
			} else if (currentValue instanceof Object[]) {
				// If the value is a Collection, as it is generally a
				// bad-idea in AP, we insert one of the item
				final List<Object> asList = Arrays.asList((Object[]) currentValue);

				indexToGenerator.add(index -> asList.get((int) (index % asList.size())));

			} else if (currentValue instanceof Collection<?>) {
				// If the value is a Collection, as it is generally a
				// bad-idea in AP, we insert one of the item
				final List<Object> asList = ImmutableList.copyOf((Collection<?>) currentValue);

				indexToGenerator.add(index -> asList.get((int) (index % asList.size())));
			} else if (currentValue != null) {
				indexToGenerator.add(new ConstantGenerator<>(currentValue));
			} else {
				if (Ints.contains(keyIndexes, i)) {
					// Set the keys associated to a constant value (e.g. Date
					// fields)
					Object firstKey = makeRandomValue(storeMetadata, fieldName, Integer.MAX_VALUE, generationIndex);
					Object otherGenerationKey =
							makeRandomValue(storeMetadata, fieldName, Integer.MAX_VALUE, generationIndex + 1L);

					if (firstKey.equals(otherGenerationKey)) {
						// The key is constant: set it once and for all
						indexToGenerator.add(new ConstantGenerator<>(firstKey));
					} else {
						indexesWithPrimeModulo.add(indexToGenerator.size());
						indexToGenerator.add(null);
					}
				} else if (keyIndexes.length == 0) {
					// This is an append-only store (no keyfields)
					int fieldType = recordFormat.getType(recordFormat.getFieldIndex(fieldName));

					if (Types.isPrimitive(fieldType)) {
						// Do not use primitive fields for keyFields in
						// append-only as there is a poor chance they are used
						// as level
						indexToGenerator.add(new ConstantGenerator<>(
								makeRandomValue(storeMetadata, fieldName, Integer.MAX_VALUE, generationIndex)));
					} else {

						indexesWithPrimeModulo.add(indexToGenerator.size());
						indexToGenerator.add(null);
					}
				} else {
					// This is a not-key field of a store with key fields:
					// keep the same value for all entries of this batch
					indexToGenerator.add(new ConstantGenerator<>(
							makeRandomValue(storeMetadata, fieldName, Integer.MAX_VALUE, generationIndex)));
				}
			}
		}

		if (!indexesWithPrimeModulo.isEmpty()) {
			ensureKeyFields(recordFormat, storeMetadata, nbRows, indexToGenerator, indexesWithPrimeModulo);
		}

		// Default is ExponentiallyDecayingReservoir, and is has a lock
		final Timer timer = new Timer(new SlidingWindowReservoir(MODULO_LOG_GENERATION_RATE));

		return LongStream.range(0, nbRows).mapToObj(i -> {
			try (Context context = timer.time()) {
				Map<String, Object> singleEntry =
						generateOneEntry(storeMetadata.getStoreFormat().getRecordFormat(), indexToGenerator, i);

				if (nbRows > 1 && i <= LOG_FIRST_ROWS) {
					// Log only first 10 rows, only if we produce at least 2 rows
					LOGGER.debug("Row {}/{} is: {}",
							i,
							nbRows,
							PepperLogHelper.getFirstChars(singleEntry, PepperLogHelper.THOUSAND));
				}

				return singleEntry;
			} finally {
				long count = timer.getCount();

				boolean log = i == nbRows || nbRows > 1 && count % MODULO_LOG_GENERATION_RATE == 0;

				if (log) {
					long nanos = ApexMetricsHelper.getNanos(timer);
					Object rate = PepperLogHelper.getNiceRate(count, nanos, TimeUnit.NANOSECONDS);
					Object niceTime = PepperLogHelper.humanDuration(nanos, TimeUnit.NANOSECONDS);

					if (i == nbRows) {
						String logTemplate = "Generation finished. Took {} to generate {} entries ({})";
						if (nbRows > TimeUnit.SECONDS.toMillis(1)) {
							// Log only if at least 1 second, else not very important
							LOGGER.info(logTemplate, niceTime, count, rate);
						} else {
							LOGGER.trace(logTemplate, niceTime, count, rate);
						}
					} else {
						LOGGER.info("Took {} (cumulated) to generate {} entries ({})", niceTime, count, rate);
					}
				}
			}
		});
	}

	protected void ensureKeyFields(IByteRecordFormat recordFormat,
			IStoreMetadata storeMetadata,
			long nbRows,
			List<LongFunction<?>> indexToGenerator,
			Set<Integer> indexesWithPrimeModulo) {

		// CHECKSTYLE:OFF
		int[] primes = new int[] { 2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31 };
		// CHECKSTYLE:ONE

		Queue<Integer> primeQueue = new LinkedBlockingQueue<>(Ints.asList(primes));

		long generationCap = 1L;

		Map<Integer, Integer> indexToModulo = new HashMap<>();
		for (int index : indexesWithPrimeModulo) {
			if (primeQueue.isEmpty()) {
				// Too many fields requiring modulo: do not care as we have
				// enough primes to generate Integer.MAX_VALUE different rows
				indexToModulo.put(index, 1);
			} else {
				int modulo = primeQueue.poll();

				generationCap *= modulo;

				// TODO: Handle more the Integer.MAX_VALUE rows
				if (generationCap > Integer.MAX_VALUE) {
					// Handle overflow (generationCap is a long)
					generationCap = Integer.MAX_VALUE;
				}

				indexToModulo.put(index, modulo);
			}
		}

		while (generationCap < nbRows) {
			// We have a few key-fields, and a single prime is not enough to
			// generate the combination
			for (int index : indexesWithPrimeModulo) {
				if (generationCap < nbRows) {
					long modulo = primeQueue.poll();

					generationCap *= modulo;

					if (generationCap > Integer.MAX_VALUE) {
						// Handle overflow (generationCap is a long)
						generationCap = Integer.MAX_VALUE;
					}

					long newModulo = indexToModulo.get(index) * modulo;
					if (newModulo > Integer.MAX_VALUE) {
						newModulo = Integer.MAX_VALUE;
					}

					indexToModulo.put(index, (int) newModulo);
				} else {
					break;
				}
			}
		}

		for (Entry<Integer, Integer> entry : indexToModulo.entrySet()) {
			int index = entry.getKey();
			String fieldName = recordFormat.getFieldName(index);

			LOGGER.trace("Generate along {} with modulo {}", fieldName, entry.getValue());
			indexToGenerator.set(index, makeGenerator(storeMetadata, fieldName, entry.getValue()));
		}
	}

	protected Map<String, Object> generateOneEntry(IByteRecordFormat recordFormat,
			List<LongFunction<?>> indexToGenerator,
			long generationIndex) {
		IMappedTuple singleEntry = ApexTuplizerHelper.newTuple(recordFormat);

		for (int i = 0; i < indexToGenerator.size(); i++) {
			singleEntry.put(i, indexToGenerator.get(i).apply(generationIndex));
		}

		return singleEntry;
	}

	@Deprecated
	public static void addOneRandomLine(IDatastore datastore, String storeName) {
		IApexDataGenerator oneLineDataGenerator = new ApexTestDataGenerator(datastore.getTransactionManager());
		oneLineDataGenerator.insertLines(new OneLineTemplate(storeName, null), 1);
	}

	// TODO Do not delete as it is used by ApexTransactionFlow as it is easier to guess a proper target type given an
	// example object than given an ActivePivot ILiteralType
	@Deprecated
	public static Map<String, ?> makeExampleRow(ITransactionManager transactionManager, String storeName) {
		IApexDataGenerator oneLineDataGenerator = new ApexTestDataGenerator(transactionManager);
		OneLineTemplate oneLineTemplate = new OneLineTemplate(storeName, null);
		return oneLineDataGenerator.prepareData(oneLineTemplate, 1).get(storeName).iterator().next();
	}

}

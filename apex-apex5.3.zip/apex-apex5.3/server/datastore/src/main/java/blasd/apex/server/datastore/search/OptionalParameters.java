/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.datastore.search;

import com.google.common.annotations.Beta;

/**
 * Not required parameters for datastore statements
 * 
 * @author Benoit Lacelle
 *
 */
public interface OptionalParameters {
	QueryIsReady limit(int rowsLimit);

	/**
	 * It might work only for dictionarized fields or set of fields with an index. This differs from DistinctAcceptor as
	 * it does not relies on a Set (and then it has a much smaller memory footprint)
	 * 
	 * @return only one row per combination of output fields
	 */
	@Beta
	QueryIsReady distinct();

	/**
	 * @deprecated Use the typo-fixed .distinct
	 */
	@Deprecated
	@Beta
	default QueryIsReady disctinct() {
		return distinct();
	}

	// PreparedSingleResultQueryIsReady limitOne();

	// TODO: add timeout, IPartitionAcceptor
}
/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.loading.testdata;

import javolution.text.Text;

/**
 * IDatastore column generate for String with a predefined prefix
 * 
 * @author Benoit Lacelle
 *
 */
public class PrefixStringGenerator implements IColumnarGenerator<Object> {
	protected final Text prefix;

	public PrefixStringGenerator(String prefix) {
		this.prefix = new Text(prefix + "_");
	}

	@Override
	public Object generate(long index) {
		return new ConcatenatedStrings(prefix, cleanIndex(index));
	}

	protected long cleanIndex(long index) {
		return index;
	}

}

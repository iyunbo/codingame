/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.datastore.dictionary;

import com.qfs.dic.IKeysUpdate;
import com.qfs.dic.IWritableDictionary.IIntegerDictionary;
import com.qfs.dic.impl.AKeysUpdate.IntKeysUpdate;
import com.qfs.monitoring.statistic.memory.IMemoryStatistic;
import com.qfs.monitoring.statistic.memory.impl.MemoryStatisticBuilder;
import com.qfs.pool.ITasksPerNumaNode;
import com.qfs.pool.impl.TasksPerNumaNode;

import cormoran.pepper.memory.IPepperMemoryConstants;

/**
 * A simple dictionary that simply returns the input
 *
 * @author Benoit Lacelle
 *
 */
// https://support.activeviam.com/jira/browse/APS-8787
public class IdentityDictionaryInteger implements IIntegerDictionary {

	private static final long serialVersionUID = 4778865455229388803L;

	@Override
	public int size() {
		return Integer.MAX_VALUE;
	}

	@Override
	public int getOrder() {
		return Integer.SIZE;
	}

	@Override
	public boolean isNullable() {
		return false;
	}

	@Override
	public int readInt(int position) {
		if (position < 0) {
			// We accept only negative entries
			return -1;
		} else {
			return position;
		}
	}

	@Override
	public long readLong(int position) {
		return readInt(position);
	}

	@Override
	public int getIntPosition(int key) {
		return readInt(key);
	}

	@Override
	public int mapInt(int key) {
		if (key < 0) {
			throw new RuntimeException("Only positive integers are supported. Tried to map " + key);
		}
		return getIntPosition(key);
	}

	@Override
	public int getPosition(Integer key) {
		return getIntPosition(key);
	}

	@Override
	public int map(Integer key) {
		return getPosition(key);
	}

	@Override
	public Integer read(int position) {
		return readInt(position);
	}

	@Override
	public void clear() {
	}

	@Override
	public void destroy() {
	}

	@Override
	public IKeysUpdate getKeyUpdate(int from, int to) {
		// There is never a need to log a key update.
		return IntKeysUpdate.createFromDictionary(null, 0, 0);
	}

	@Override
	public IMemoryStatistic getMemoryStatistic() {
		return new MemoryStatisticBuilder().withName("idendity")
				.withCreatorClasses(this.getClass())
				.withMemoryFootPrint(0, 2 * IPepperMemoryConstants.OBJECT)
				.build();
	}

	///////////////////////////
	// Unsupported operations

	@Override
	public float readFloat(int position) {
		throw new UnsupportedOperationException();
	}

	@Override
	public double readDouble(int position) {
		throw new UnsupportedOperationException();
	}

	@Override
	public int mapLong(long key) {
		throw new UnsupportedOperationException();
	}

	@Override
	public int mapFloat(float key) {
		throw new UnsupportedOperationException();
	}

	@Override
	public int mapDouble(double key) {
		throw new UnsupportedOperationException();
	}

	@Override
	public int getLongPosition(long key) {
		throw new UnsupportedOperationException();
	}

	@Override
	public int getFloatPosition(float key) {
		throw new UnsupportedOperationException();
	}

	@Override
	public int getDoublePosition(double key) {
		throw new UnsupportedOperationException();
	}

	@Override
	public ITasksPerNumaNode compress(boolean destroyOnly) {
		// see com.qfs.dic.impl.IntegerDictionary.compress(boolean)
		return new TasksPerNumaNode();
	}

}
/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.datastore.updatewhere;

import java.util.concurrent.atomic.AtomicLong;

import com.qfs.condition.ICondition;
import com.qfs.store.selection.ISelection;
import com.qfs.store.transaction.ITransactionManager.IUpdateWhereProcedure;

import blasd.apex.server.loading.transaction.IApexCountingUpdateWhereProcedure;

/**
 * Default implementation for {@link IApexUpdateWhereProcedureWrapper}
 * 
 * @author Benoit Lacelle
 * 
 */
public class ApexUpdateWhereProcedureWrapper implements IApexUpdateWhereProcedureWrapper {

	protected final ISelection selection;
	protected final ICondition condition;

	protected final IUpdateWhereProcedure decorated;
	protected final IApexCountingUpdateWhereProcedure updateWhereProcedure;

	protected final AtomicLong nbRowsUpdated = new AtomicLong();

	public ApexUpdateWhereProcedureWrapper(ISelection selection,
			ICondition condition,
			IUpdateWhereProcedure updateWhereProcedure) {
		this.selection = selection;
		this.condition = condition;

		this.decorated = updateWhereProcedure;
		this.updateWhereProcedure = decorateWithRowCounting(nbRowsUpdated, decorated, hasReferencedFields(selection));
	}

	public static boolean hasReferencedFields(ISelection selection) {
		return selection.getFields()
				.stream()
				.filter(selectedField -> selectedField.getExpression()
						.indexOf(IApexUpdateWhereProcedureWrapper.PROPERTY_SEPARATOR) >= 0)
				.findAny()
				.isPresent();
	}

	/**
	 * static as used in constructor
	 */
	public static ApexCountingDecoratorUpdateWhereProcedure decorateWithRowCounting(final AtomicLong nbRowsUpdated,
			final IUpdateWhereProcedure toDecorate,
			final boolean hasReferencedFields) {
		return new ApexCountingDecoratorUpdateWhereProcedure(nbRowsUpdated, toDecorate, hasReferencedFields);
	}

	@Override
	public ISelection getSelection() {
		return selection;
	}

	@Override
	public ICondition getCondition() {
		return condition;
	}

	@Override
	public IApexCountingUpdateWhereProcedure getUpdateWhere() {
		return updateWhereProcedure;
	}

	@Override
	public long getNbUpdatedRow() {
		return nbRowsUpdated.get();
	}

}

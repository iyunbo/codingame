/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.datastore.search;

import com.qfs.store.record.IRecordFormat;

/**
 * A simple AApexObjectRecordReader wrapping a single object in a single field
 * 
 * @author Benoit Lacelle
 *
 */
public final class ImmutableSingleFieldRecordReader extends AApexObjectRecordReader implements Cloneable {
	private final Object o;
	private final IRecordFormat recordFormat;

	public ImmutableSingleFieldRecordReader(IRecordFormat recordFormat, Object o) {
		this.o = o;
		this.recordFormat = recordFormat;
	}

	@Override
	public IRecordFormat getFormat() {
		return recordFormat;
	}

	@Override
	public Object read(int index) {
		if (index == 0) {
			return o;
		} else {
			throw new IllegalArgumentException("index=" + index);
		}
	}

	@Override
	public boolean isNull(int index) {
		if (index == 0) {
			return o == null;
		} else {
			throw new IllegalArgumentException("index=" + index);
		}
	}

	@Override
	public ImmutableSingleFieldRecordReader clone() {
		// This is immutable
		return this;
	}
}
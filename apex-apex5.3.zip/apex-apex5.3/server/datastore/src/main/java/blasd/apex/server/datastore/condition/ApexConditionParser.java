/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.datastore.condition;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.qfs.condition.ICondition;
import com.qfs.condition.IConstantCondition;
import com.qfs.condition.ImplementationCode;
import com.qfs.condition.impl.BaseConditions;
import com.qfs.store.IDatastoreSchema;
import com.qfs.store.IStoreMetadata;
import com.qfs.store.query.IQuery.IOuterReferencePolicy;
import com.qfs.store.query.plan.condition.impl.ConditionParser;
import com.qfs.store.query.plan.condition.impl.ConditionParserSpy;

import blasd.apex.toggle.ApexToggler;
import cormoran.pepper.memory.IPepperMemoryConstants;

/**
 * Add supplementary ICondition rewrite optimisations, like detection of cartesian products.
 * 
 * @author Benoit Lacelle
 * @see ApexConditionHelper#rewrite(ICondition)
 */
public class ApexConditionParser extends ConditionParser {

	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexConditionParser.class);

	// We can not refer to an AtomicInteger given in constructor as .reWrite is called by contructor
	public static int limitMerging = IPepperMemoryConstants.KB_INT;

	public ApexConditionParser(IDatastoreSchema<?, ?> schema,
			IStoreMetadata baseStore,
			ICondition condition,
			IOuterReferencePolicy outerReferencePolicy) {
		super(schema, baseStore, condition, outerReferencePolicy);
	}

	// deprecated: Since AP5.7.8, reWrite is now a static method and can not be overriden
	@Deprecated
	public ICondition deprecatedReWrite(final ICondition condition) {
		if (ApexToggler.rewriteInApexConditionParser()) {
			// Apply core optimizations
			final ICondition coreCondition = superReWrite(condition);

			ICondition apexCondition = optimisationOrOfAndsOfEquals(coreCondition);

			if (apexCondition != coreCondition) {
				// We re-apply the core optimization so that we do not need to
				// implement them in Apex
				apexCondition = superReWrite(apexCondition);
			}

			return apexCondition;
		} else {
			return rawSuperReWrite(condition);
		}
	}

	// Used to skip any Apex behavior
	protected ICondition rawSuperReWrite(ICondition condition) {
		return super.reWrite(condition);
	}

	// https://support.activeviam.com/jira/browse/APS-9611
	// ConditionParser.AndConditionMerger.INSTANCE is not visible
	private static final ConditionParser.IConditionMerger AND_INSTANCE = ConditionParserSpy.AND_INSTANCE;

	// https://support.activeviam.com/jira/browse/APS-9611
	// ConditionParser.AndConditionMerger.INSTANCE is not visible
	private static final ConditionParser.IConditionMerger OR_INSTANCE = ConditionParserSpy.OR_INSTANCE;

	// Performance issues when we have a OR over a very wide number of ANDs
	// https://support.activeviam.com/jira/browse/APS-9611
	// deprecated: Since AP5.7.8, reWrite is now a static method and can not be overriden
	@Deprecated
	protected ICondition superReWrite(ICondition condition) {
		if (this.isMultipleCondition(condition)) {
			IConstantCondition cc = (IConstantCondition) condition;
			ImplementationCode code = cc.getImplementationCode();
			List<ICondition> rwSubConditions = new ArrayList<>();
			super.reWrite(condition, code, rwSubConditions);

			if (rwSubConditions != null && rwSubConditions.size() > limitMerging) {
				// Trivial merging
				if (code == ImplementationCode.AND) {
					return BaseConditions.And(rwSubConditions);
				} else {
					return BaseConditions.Or(rwSubConditions);
				}
			} else {
				// Core merging: very slow in some cases (APS-9611)
				ConditionParser.IConditionMerger merger;
				if (code == ImplementationCode.AND) {
					merger = AND_INSTANCE;
				} else {
					merger = OR_INSTANCE;
				}

				return merger.mergeConditions(rwSubConditions);
			}
		} else {
			return condition;
		}
	}

	protected ICondition optimisationOrOfAndsOfEquals(ICondition condition) {
		return ApexConditionHelper.rewrite(condition);
	}

	@Override
	protected void addToCursor(ICondition unit) {
		super.addToCursor(unit);

		if (unit == rootCondition && BaseConditions.FALSE.equals(unit)) {
			// it is useless for the core to add FALSE as a cursor condition as the tree as correctly turned to an empty
			// tree. Then, no need to report this case
			LOGGER.debug("We are going to consider an AConditionCursor for {} as part of {}", unit, this.rootCondition);
		} else {
			// It is generally a slow case as we are building a cursor and for each entry matching the tree (a fast
			// condition), we will have to apply this condition. It happens for complex condition
			LOGGER.info("Performance notice: We are going to consider an AConditionCursor for {} as part of {}",
					unit,
					this.rootCondition);
		}

	}
}

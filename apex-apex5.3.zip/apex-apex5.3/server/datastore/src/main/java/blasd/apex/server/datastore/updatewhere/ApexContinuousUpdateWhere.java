/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.datastore.updatewhere;

import java.util.Collections;
import java.util.OptionalLong;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;

import com.google.common.annotations.Beta;
import com.google.common.util.concurrent.ListeningScheduledExecutorService;
import com.qfs.condition.ICondition;
import com.qfs.condition.impl.BaseConditions;
import com.qfs.store.selection.ISelection;
import com.qfs.store.transaction.ITransactionManager;
import com.qfs.store.transaction.ITransactionManager.IUpdateWhereProcedure;

import blasd.apex.server.datastore.condition.ApexConditionHelper;
import blasd.apex.server.datastore.transaction.ApexTransactionHelper;
import cormoran.pepper.thread.PepperExecutorsHelper;

/**
 * This point of this class is to enable a piece of logic maintaining some advanced state in a datastore.
 * 
 * This this to work correctly, any rows inserted or updated has to update its column with getBlockIndex()
 * 
 * @author Benoit Lacelle
 *
 */
@Beta
@ManagedResource
public class ApexContinuousUpdateWhere implements InitializingBean {
	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexContinuousUpdateWhere.class);

	/**
	 * The name of this continuous update where
	 */
	protected final String columnName;

	protected final ITransactionManager transactionManager;

	/**
	 * the index of current block. We consider this blockIndex in order to update date only by small chunks
	 */
	protected final AtomicLong nextRowIndex = new AtomicLong();
	protected final int blockSize;

	/**
	 * Which block is the next to update
	 */
	protected final AtomicLong nextBlockToRead = new AtomicLong();

	protected final IUpdateWhereProcedure updateWhereProcedure;

	protected final ISelection selection;

	/**
	 * 
	 * @param columnName
	 *            the column holding the blockIndex as given by .getBlockIndex() This column should be updated one EVERY
	 *            insertions AND updates
	 * @param blockSize
	 *            the maximum number of rows to update at each iteration
	 */
	public ApexContinuousUpdateWhere(ITransactionManager transactionManager,
			String columnName,
			int blockSize,
			IUpdateWhereProcedure updateWhereProcedure,
			ISelection selection) {
		this.transactionManager = transactionManager;
		this.columnName = columnName;
		this.blockSize = blockSize;
		this.updateWhereProcedure = updateWhereProcedure;
		this.selection = selection;
	}

	@ManagedAttribute
	public String getColumnName() {
		return columnName;
	}

	@ManagedAttribute
	public int getBlockSize() {
		return blockSize;
	}

	@ManagedAttribute
	public long getNextRowIndex() {
		return nextRowIndex.get();
	}

	@ManagedAttribute
	public long getNextBlockToRead() {
		return nextBlockToRead.get();
	}

	public int getBlockIndex() {
		return (int) (nextRowIndex.getAndIncrement() % blockSize);
	}

	public ICondition getUpdateCondition() {
		OptionalLong updateBlockIndex = getUpdateBlockIndex();

		if (updateBlockIndex.isPresent()) {
			return ApexConditionHelper.convertToCondition(Collections.singletonMap(columnName, updateBlockIndex));
		} else {
			return BaseConditions.FALSE;
		}
	}

	public OptionalLong getUpdateBlockIndex() {
		// Ensure next writes are done for next block;
		long nextWriteIndex = nextRowIndex.get();

		long currentlyWrittenBlock = nextWriteIndex / blockSize;

		while (true) {
			long currentlyReadBlock = nextBlockToRead.get();
			if (currentlyReadBlock < currentlyWrittenBlock) {
				// We are late updating blocks
				if (nextBlockToRead.compareAndSet(currentlyReadBlock, currentlyReadBlock + 1)) {
					return OptionalLong.of(currentlyReadBlock);
				} else {
					// Block consumed in the meantime: retry
					continue;
				}
			} else if (currentlyReadBlock == currentlyWrittenBlock) {
				// We want to update the block currently being written: no more rows should be written in this block
				if (nextWriteIndex % blockSize == 0) {
					// We have not written anything in current block
					return OptionalLong.empty();
				} else {
					// We have starting writing in current block but we want to update it while not having fulfilled it
					long nbPartialWrite = nextWriteIndex % blockSize;

					if (nextRowIndex.compareAndSet(nextWriteIndex, nextWriteIndex + (blockSize - nbPartialWrite))) {
						if (nextBlockToRead.compareAndSet(currentlyReadBlock, currentlyReadBlock + 1)) {
							return OptionalLong.of(currentlyReadBlock);
						} else {
							// Block consumed in the meantime: retry
							continue;
						}
					} else {
						// Row written in the meantime: retry
						continue;
					}
				}
			} else {
				throw new IllegalStateException(
						currentlyReadBlock + " > " + currentlyWrittenBlock + " which is not expected");
			}
		}
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		ListeningScheduledExecutorService es =
				PepperExecutorsHelper.newSingleThreadScheduledExecutor("ApexContinuousUpdateWhere-" + columnName);

		// Try to update a block, waiting 1 second between each try
		es.scheduleWithFixedDelay(() -> {
			try {
				updateNextBlock();
			} catch (RuntimeException | Error e) {
				// Log and swallow to prevent Future from being cancelled
				LOGGER.error("Issue while updating " + columnName, e);
			}
		}, 1, 1, TimeUnit.SECONDS);

	}

	@ManagedOperation
	public void updateAllLeftOvers() {
		while (updateNextBlock()) {
			LOGGER.info("May have more to update on {}", getColumnName());
		}
	}

	protected boolean updateNextBlock() {
		ICondition c = getUpdateCondition();

		if (BaseConditions.FALSE.equals(c)) {
			LOGGER.trace("There is nothing to update");
			return false;
		} else {
			ApexUpdateWhereProcedureWrapper updateWhereWrapper =
					new ApexUpdateWhereProcedureWrapper(getSelection(), c, getUpdateWhere());
			ApexTransactionHelper.updateWhere(transactionManager, updateWhereWrapper);

			return true;
		}
	}

	protected IUpdateWhereProcedure getUpdateWhere() {
		return updateWhereProcedure;
	}

	protected ISelection getSelection() {
		return selection;
	}
}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.datastore;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.logging.Level;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.annotations.VisibleForTesting;
import com.qfs.dic.IDictionaryFactory;
import com.qfs.dic.IStorageSpecification;
import com.qfs.dic.IWritableDictionary;
import com.qfs.store.Types;
import com.qfs.store.impl.DictionaryManager;
import com.qfs.store.impl.DictionaryManagerSpy;

import blasd.apex.server.datastore.dictionary.IdentityDictionaryInteger;

/**
 * Used to enable the usage of identity dictionary to lower memory foot-print of very high-cardinality fields appearing
 * in an index field
 * 
 * @author Benoit Lacelle
 *
 */
// https://support.activeviam.com/jira/browse/APS-8787
public class ApexDictionaryManager extends DictionaryManager {
	// CHECKSTYLE:OFF
	private static final java.util.logging.Logger logger =
			java.util.logging.Logger.getLogger(DictionaryManager.class.getName());
	// CHECKSTYLE:ON

	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexDictionaryManager.class);

	@VisibleForTesting
	public static final List<List<String>> IDENTITY_DICTIONARIES = new CopyOnWriteArrayList<>();

	public static void addForIdentityDictionary(String storeName, String fieldName) {
		LOGGER.info("Registering IdentityDictionary for {}/{}", storeName, fieldName);
		IDENTITY_DICTIONARIES.add(Arrays.asList(storeName, fieldName));
	}

	public ApexDictionaryManager(IDictionaryFactory dictionaryFactory) {
		super(dictionaryFactory);
	}

	protected boolean shouldUseIdentityDictionary(IStorageSpecification spec) {
		if (useIdentityDictionary(spec)) {
			if (Types.getContentType(spec.getFieldType()) != Types.CONTENT_INT) {
				throw new IllegalArgumentException("Unexpected type for field " + spec.getFieldName()
						+ ". Was "
						+ Types.toString(spec.getFieldType())
						+ " while only int types are supported. Specification is: "
						+ spec);
			}
			LOGGER.info("Using an identity dictionary for field {}", spec.getFieldName());
			return true;
		} else {
			return false;
		}
	}

	protected boolean useIdentityDictionary(IStorageSpecification spec) {
		// spec.getOptimization().equals(Optimization.IDENTITY_DICTIONARY)
		return IDENTITY_DICTIONARIES.contains(Arrays.asList(spec.getStore().getName(), spec.getFieldName()));
	}

	/**
	 * Create all {@link com.qfs.dic.IDictionary} from {@link IStorageSpecification} in the dependencies graph.
	 */
	// HACK provided in https://support.activeviam.com/jira/browse/APS-8787
	// TODO CHECKSTYLE
	// CHECKSTYLE:OFF
	@Override
	protected void createSingleFieldDictionaries(
			final Map<Set<IStorageSpecification>, DictionaryParameters> singleFieldDictionaries) {
		for (final Entry<Set<IStorageSpecification>, DictionaryParameters> entry : singleFieldDictionaries.entrySet()) {
			final Set<IStorageSpecification> sameDictionarySpecifications = entry.getKey();
			final DictionaryParameters parameters = entry.getValue();
			if (sameDictionarySpecifications.size() > 1) {
				// If there is more than one specification, sharing occured.
				// At the time this was implemented, this was only possible if
				// at least one of the specification requires dictionarization.
				logger.log(Level.FINE,
						"Creating dictionary for " + sameDictionarySpecifications.size()
								+ " specifications ("
								+ sameDictionarySpecifications
								+ ")");
				final List<IWritableDictionary<?>> dictionary = Collections.singletonList(
						dictionaryFactory.createSingle(DictionaryManagerSpy.getParametersType(parameters),
								DictionaryManagerSpy.getParametersAllocationSettings(parameters)));

				// CUSTOM CODE START
				boolean useIdentityDictionary = false;
				for (final IStorageSpecification spec : sameDictionarySpecifications) {
					if (spec.getStoreFields().size() == 1) {
						if (shouldUseIdentityDictionary(spec)) {
							useIdentityDictionary = true;
							break;
						} else {
							dependencies.put(spec, dictionary);
						}
					}
				}
				if (useIdentityDictionary) {
					// All fields in the group need to use the same dictionary! Otherwise references will fail.
					logger.log(Level.FINE, "Using identity dictionary for group: " + sameDictionarySpecifications);
					final IWritableDictionary<?> identityDictionary = new IdentityDictionaryInteger();
					for (final IStorageSpecification spec : sameDictionarySpecifications) {
						dependencies.put(spec, Collections.singletonList(identityDictionary));
					}
				}
				// CUSTOM CODE END
			} else {
				final IStorageSpecification spec = sameDictionarySpecifications.iterator().next();
				if (spec.getOptimization().requireDictionary()) {
					logger.log(Level.FINE,
							"Creating dictionary for dictionarized field " + sameDictionarySpecifications);
					final List<IWritableDictionary<?>> dictionary;

					// CUSTOM CODE START
					if (shouldUseIdentityDictionary(spec)) {
						dictionary = Collections.singletonList(new IdentityDictionaryInteger());
					} else {
						dictionary = Collections.singletonList(
								dictionaryFactory.createSingle(DictionaryManagerSpy.getParametersType(parameters),
										DictionaryManagerSpy.getParametersAllocationSettings(parameters)));
					}

					// CUSTOM CODE END
					dependencies.put(spec, dictionary);
				}
			}
		}
	}
	// CHECKSTYLE:ON
}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.loading.testdata;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import blasd.apex.server.test.IApexTestConstants;

/**
 * The template can define for any column a single value, a Collection of values, or use an {@link IColumnarGenerator}
 * 
 * @author Benoit Lacelle
 * 
 * @see ApexTestDataGenerator
 * 
 */
public class OneLineTemplate {
	protected static final Logger LOGGER = LoggerFactory.getLogger(OneLineTemplate.class);

	// Used to easily mark null in ImmutableMap templates in OneLineTemplate
	public static final Object NULL = IApexTestConstants.NULL_MARKER;

	/**
	 * The store where to insert the data
	 */
	public final String storeName;

	/**
	 * Express constrains to generate the data.
	 * 
	 * The key should a path to a field: "fieldName", or Arrays.asList("enrichmentStore", "enrichmentFieldName")
	 * 
	 * The value could be either a brand value, or a Collection, or an IGenerator
	 */
	public final Map<? extends String, ?> template;

	/**
	 * @deprecated Rely on constructor not having the 'insertInEnrichmentStore' parameter
	 */
	@Deprecated
	public OneLineTemplate(String storeName, boolean insertInEnrichmentStore, Map<? extends String, ?> template) {
		this(storeName, template);

		// Later switch to warn, and later remove the constructor
		LOGGER.debug("Parameter 'insertInEnrichmentStore' ({}) is deprecated", insertInEnrichmentStore);
	}

	public OneLineTemplate(String storeName, Map<? extends String, ?> template) {
		this.storeName = storeName;

		// Make an immutable copy
		if (template == null) {
			this.template = Collections.emptyMap();
		} else {
			// Can-not use ImmutableMap as values could hold null
			this.template = Collections.unmodifiableMap(new HashMap<>(template));
		}
	}

	@Override
	public String toString() {
		return "OneLineTemplate [storeName=" + storeName + ", template=" + template + "]";
	}

	public String getStoreName() {
		return storeName;
	}

	public Map<? extends String, ?> getTemplate() {
		return template;
	}
}

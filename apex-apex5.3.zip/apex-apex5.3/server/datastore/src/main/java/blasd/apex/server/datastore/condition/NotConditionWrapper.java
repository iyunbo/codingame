/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.datastore.condition;

import java.io.Serializable;

/**
 * Helps wrapping a NOT condition in a Map.
 * 
 * @author Benoit Lacelle
 * @see ApexConditionHelper
 * @param <T>
 */
// TODO Should could we rely on a NotCondition? Not easy as NotCOndition would rely on EqualsCOndition which expect a
// key field
public final class NotConditionWrapper<T> implements Serializable {

	// Serializable if wrapped in Serializable
	private static final long serialVersionUID = -3757074143218634798L;

	// As T may be not Serializable, we prefer to mark the field as transient (else Sonar cry)
	public final transient T decorated;

	/**
	 * 
	 * @param decorated
	 *            Prefer using {@link ApexConditionHelper#notValue(Object)}
	 */
	@Deprecated
	public NotConditionWrapper(T decorated) {
		this.decorated = decorated;

		// It is legit to search entries with a non-null value
		// Objects.requireNonNull(decorated);
	}

	@Override
	public String toString() {
		return "NotConditionWrapper [decorated=" + decorated + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result;
		if (decorated != null) {
			result += decorated.hashCode();
		}
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		NotConditionWrapper<?> other = (NotConditionWrapper<?>) obj;
		if (decorated == null) {
			if (other.decorated != null) {
				return false;
			}
		} else if (!decorated.equals(other.decorated)) {
			return false;
		}
		return true;
	}

	/**
	 * @deprecated use .wrap
	 */
	@Deprecated
	public static <S> NotConditionWrapper<S> notCondition(S not) {
		return wrap(not);
	}

	public static <S> NotConditionWrapper<S> wrap(S wrapMe) {
		// TODO: Should we handle null specifically ?
		return new NotConditionWrapper<S>(wrapMe);
	}

}

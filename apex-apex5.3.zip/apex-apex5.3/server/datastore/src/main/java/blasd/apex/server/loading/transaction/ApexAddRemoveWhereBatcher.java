/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.loading.transaction;

import java.lang.management.ManagementFactory;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Optional;
import java.util.Properties;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import org.apache.cxf.management.annotation.ManagedAttribute;
import org.apache.cxf.management.annotation.ManagedOperation;
import org.apache.cxf.management.annotation.ManagedResource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

import com.codahale.metrics.Gauge;
import com.codahale.metrics.Meter;
import com.codahale.metrics.MetricRegistry;
import com.codahale.metrics.Timer;
import com.codahale.metrics.Timer.Context;
import com.google.common.annotations.Beta;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Iterables;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.common.primitives.Ints;
import com.google.common.util.concurrent.AtomicLongMap;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.common.util.concurrent.ListeningScheduledExecutorService;
import com.google.common.util.concurrent.MoreExecutors;
import com.qfs.condition.ICondition;
import com.qfs.store.IDatastoreSchemaMetadata;
import com.qfs.store.IStoreFormat;
import com.qfs.store.transaction.DatastoreTransactionException;
import com.qfs.store.transaction.IDatastoreSchemaTransactionInformation;
import com.qfs.store.transaction.ITransactionManager;
import com.qfs.store.transaction.ITransactionWrapper;
import com.qfs.store.transaction.impl.TransactionManager;
import com.qfs.store.transaction.impl.TransactionWrapper;
import com.quartetfs.fwk.AgentException;
import com.quartetfs.fwk.impl.AAtomicAgent;

import blasd.apex.metrics.ApexMetricsHelper;
import blasd.apex.server.config.partition.ApexPartitioningHelper;
import blasd.apex.server.datastore.transaction.ApexInTransactionHelper;
import blasd.apex.server.datastore.transaction.ApexTransactionHelper;
import blasd.apex.server.datastore.updatewhere.IApexUpdateWhereProcedureWrapper;
import blasd.apex.server.monitoring.loading.ApexTransactionManager;
import blasd.apex.server.monitoring.loading.IApexDatastoreSchemaTransactionInformation;
import cormoran.pepper.jmx.PepperJMXHelper;
import cormoran.pepper.jvm.IHeapIsTooHigh;
import cormoran.pepper.logging.PepperLogHelper;
import cormoran.pepper.thread.IHasAsyncTasks;
import cormoran.pepper.thread.PepperExecutorsHelper;

/**
 * This {@link ITransactionWrapper} provides finer access to asynchronous transactions than {@link TransactionWrapper}.
 * 
 * It enables for instance submitting to several stores in parallel: a transaction on a big store should not prevent a
 * small transaction on an independent store. Or large transactions on independent base stores should be possible.
 * 
 * Also, beware that by batching several send with both additions and removals, the latest removals won't be applied on
 * the additions of the earliest additions. One could use the same submissionId to prevent 2 send operations from being
 * batched together (e.g. if the dealdId is the submission Id, different dealId would be batched together but another
 * submit on the same dealId will wait for the first dealId to be processed before processing the second submission)
 * 
 * https://support.quartetfs.com/jira/browse/APS-5665
 * 
 * https://support.quartetfs.com/jira/browse/APS-6399
 * 
 * @author Benoit Lacelle
 * 
 */
@ManagedResource
public class ApexAddRemoveWhereBatcher extends AAtomicAgent
		implements IApexAddRemoveWhereBatcher, InitializingBean, DisposableBean, IHasAsyncTasks {
	private static final long serialVersionUID = 5640050874529349255L;

	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexAddRemoveWhereBatcher.class);

	protected final transient ITransactionManager transactionManager;
	protected final int storesCount;

	public static final long DEFAULT_BATCH_FREQUENCY_MS = 100;
	protected final AtomicLong batchFrequencyMillis = new AtomicLong(DEFAULT_BATCH_FREQUENCY_MS);
	protected final AtomicReference<ScheduledFuture<?>> consumptionFuture = new AtomicReference<>();

	public static final long DEFAULT_MIN_MS_FOR_ASYNCHRONOUS_PUBLISH_LOG = 10;

	// TODO: This variable should be set to true when the refactoring is completed
	private static boolean reuseTransactionHelper = false;

	protected final AtomicInteger heapRatioWriteLimitPercent = new AtomicInteger();

	protected final AtomicLong nbAsyncSubmission = new AtomicLong();

	protected final AtomicLongMap<Integer> storeIdToSizeBeingConsumed = AtomicLongMap.create();

	protected final AtomicLongMap<Set<Integer>> batchToNbImpacted = AtomicLongMap.create();
	protected final AtomicLongMap<Set<Integer>> batchToTimeInTransaction = AtomicLongMap.create();

	/**
	 * Transactions are batched only when submitting for the same set of Stores
	 */
	protected final transient ConcurrentMap<Set<Integer>, IApexAddRemoveWhereBatchUnit> storesToInsertAndRemoveBatch =
			new ConcurrentHashMap<>();

	protected final transient Map<IApexAddRemoveWhereBatchUnit, ListenableFuture<IDatastoreSchemaTransactionInformation>> batchToTransactionFuture =
			new ConcurrentHashMap<>();

	protected final String name;

	/**
	 * By default, we automatically start the asynchronous consumption of batches
	 */
	protected final AtomicBoolean startOnInit = new AtomicBoolean(true);

	// The drain of batches should be done by a single thread
	protected final transient ListeningScheduledExecutorService batchDrainerExecutionService;

	// We enable concurrent transactions
	protected final transient ListeningScheduledExecutorService transactionExecutorService;

	protected transient IApexNotificationPropagator apexNotificationPropagator;

	protected final AtomicLongMap<Set<Integer>> errorCount = AtomicLongMap.create();
	protected final AtomicInteger commitFailure = new AtomicInteger();

	/**
	 * Time waiting for the transaction lock
	 */
	protected final transient Timer startTransactionTimer = new Timer();
	/**
	 * Time to tuplize and apply insertionTimeContinuousUpdateWhere
	 */
	protected final transient Timer publishContentTimer = new Timer();
	/**
	 * Time to commit and publish to listeners (including cubes)
	 */
	protected final transient Timer commitTransactionTimer;

	protected final transient Meter totalAddInTransaction;

	protected final transient IHeapIsTooHigh heapIsTooHigh;

	/**
	 * 
	 * @param name
	 * @param transactionManager
	 * @param metricRegistry
	 */
	public ApexAddRemoveWhereBatcher(String name,
			ITransactionManager transactionManager,
			IHeapIsTooHigh heapIsTooHigh) {
		this.name = name;
		this.transactionManager = transactionManager;
		this.heapIsTooHigh = heapIsTooHigh;

		this.storesCount = transactionManager.getMetadata().getStoreCount();

		// IT IS VERY IMPORTANT TO HAVE A SINGLE THREAD
		// The single thread will guarantee committing data in the same order it
		// has been submitted originally
		batchDrainerExecutionService = PepperExecutorsHelper.newSingleThreadScheduledExecutor(name + "-Drainer");

		// We enable concurrent transactions, for example to several base stores
		// TODO: restrict nbThreads to nbStores?
		// TODO Pepper1.19 will enable configure of nbThreads: rely on
		//
		transactionExecutorService =
				newShrinkableScheduledThreadPool(ApexPartitioningHelper.getDefaultNumberOfPartitions(),
						name + "-Transaction",
						PepperExecutorsHelper.DEFAULT_REJECTION_POLICY);

		commitTransactionTimer = new Timer();
		totalAddInTransaction = new Meter();
	}

	// TODO Remove with pepper1.19
	@Deprecated
	private static ListeningScheduledExecutorService newShrinkableScheduledThreadPool(int nbThreads,
			String threadNamePrefix,
			RejectedExecutionHandler rejectedExecutionHandler) {
		ScheduledThreadPoolExecutor tpExecutor = new ScheduledThreadPoolExecutor(nbThreads,
				PepperExecutorsHelper.makeDaemonThreadFactory(threadNamePrefix),
				rejectedExecutionHandler);

		// Allow core threads to shutdown when there is no task to process
		tpExecutor.setKeepAliveTime(PepperExecutorsHelper.CORE_KEEP_ALIVE_IN_SECONDS, TimeUnit.SECONDS);
		tpExecutor.allowCoreThreadTimeOut(true);

		// http://stackoverflow.com/questions/15888366/meaning-of-core-pool-size-in-scheduledthreadpoolexecutors-constructor
		// ScheduledThreadPoolExecutor makes no use of maximumPoolSize being greater than corePoolSize

		return MoreExecutors.listeningDecorator(tpExecutor);
	}

	/**
	 * Register multiple metrics provided by this into given {@link MetricRegistry}
	 * 
	 * @param metricRegistry
	 */
	public void registerConsumingGauge(MetricRegistry metricRegistry) {
		metricRegistry.register(MetricRegistry.name(this.getClass(), name, "Commit"), commitTransactionTimer);
		metricRegistry.register(MetricRegistry.name(this.getClass(), name, "NbAdd"), totalAddInTransaction);

		// How many elements are currently being consumed
		String consumingGaugeName = MetricRegistry.name(this.getClass(), name, "ConsumingSize");
		metricRegistry.register(consumingGaugeName, (Gauge<Long>) () -> storeIdToSizeBeingConsumed.sum());
	}

	protected long getMaxHeap() {
		return ManagementFactory.getMemoryMXBean().getHeapMemoryUsage().getMax();
	}

	@Override
	public String getName() {
		return name;
	}

	/**
	 * By default, startOnInit == true
	 */
	public void setStartOnInit(boolean startOnInit) {
		this.startOnInit.set(startOnInit);
	}

	public void setApexNotificationPropagator(IApexNotificationPropagator apexNotificationPropagator) {
		this.apexNotificationPropagator = apexNotificationPropagator;
	}

	@Override
	protected void doStart(State previousState) throws AgentException {
		super.doStart(previousState);

		scheduleConsumption();
	}

	private void scheduleConsumption() {
		long localBatchFrequencyMillis = batchFrequencyMillis.get();

		ScheduledFuture<?> future;
		if (localBatchFrequencyMillis == Long.MAX_VALUE) {
			future = null;
		} else {
			future = batchDrainerExecutionService.scheduleWithFixedDelay(() -> {
				// This process is mono-threaded
				try {
					groupThenDrainThenCommitThenWaitAndReport(storesToInsertAndRemoveBatch.values());
				} catch (RuntimeException e) {
					// Log and do not re-throw as we want to continue trying
					// to consume batches
					LOGGER.error("Issue while consuming data", e);
				}

			}, 1, localBatchFrequencyMillis, TimeUnit.MILLISECONDS);
		}

		ScheduledFuture<?> previousFuture = consumptionFuture.getAndSet(future);
		if (previousFuture != null) {
			// Cancel future with previous batchFrequency
			previousFuture.cancel(false);
		}
	}

	protected void groupThenDrainThenCommitThenWaitAndReport(Collection<IApexAddRemoveWhereBatchUnit> batches) {
		try {
			List<ListenableFuture<IDatastoreSchemaTransactionInformation>> futures = groupThenDrainThenCommit(batches);

			if (futures.isEmpty()) {
				LOGGER.trace("Nothing to drain in {}", getName());
			} else {
				List<IDatastoreSchemaTransactionInformation> result = Futures.allAsList(futures).get();

				LOGGER.debug("Process done for {}: {}", batches, result);
			}
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
			// Log and do not re-throw as we want to continue trying
			// to consume batches
			LOGGER.error("Issue while consuming data of " + batches, e);
		} catch (RuntimeException | ExecutionException e) {
			// Log and do not re-throw as we want to continue trying
			// to consume batches
			LOGGER.error("Issue while consuming data of " + batches, e);
		}
	}

	// THIS SHOULD BE CALLED IN A MONOTHREADED FASHION, with the help of batchDrainerExecutionService
	protected List<ListenableFuture<IDatastoreSchemaTransactionInformation>> groupThenDrainThenCommit(
			Collection<IApexAddRemoveWhereBatchUnit> allBatches) {
		Map<Set<Integer>, Set<IApexAddRemoveWhereBatchUnit>> storeToLockToBatches =
				groupBatchesByTransaction(allBatches);

		List<ListenableFuture<IDatastoreSchemaTransactionInformation>> futures = new ArrayList<>();

		transactionGroup: for (final Set<IApexAddRemoveWhereBatchUnit> batches : storeToLockToBatches.values()) {

			// Check and register we are going to start a transaction for these batches
			for (IApexAddRemoveWhereBatchUnit batch : batches) {
				if (batchToTransactionFuture.containsKey(batch)) {
					if (batchToTransactionFuture.get(batch).isDone()) {
						// We do not need this info anymore
						batchToTransactionFuture.remove(batch);
					} else {
						// This batch is still being committed: we must wait before starting a
						// transaction for it as we must prevent a single batch having 2 concurrent
						// transactions
						LOGGER.debug("We wait for {} to finish its current transaction", batch);
						continue transactionGroup;
					}
				}
			}

			// Submit one transaction per group of batches
			ListenableFuture<IDatastoreSchemaTransactionInformation> future =
					transactionExecutorService.submit(() -> drainBatchesAndCommit(batches));

			// Register this single future for all associated batches
			for (IApexAddRemoveWhereBatchUnit batch : batches) {
				batchToTransactionFuture.put(batch, future);
			}

			futures.add(future);
		}

		return futures;
	}

	/**
	 * This grouping operation should never associate several batches associated to the same storeIds. Typically because
	 * we could have some add/removeWhere for a single storeId but in different batch. These 2 add/removeWhere needs to
	 * be done in 2 different transactions.
	 */
	protected Map<Set<Integer>, Set<IApexAddRemoveWhereBatchUnit>> groupBatchesByTransaction(
			Collection<IApexAddRemoveWhereBatchUnit> batches) {
		Map<Set<Integer>, Set<IApexAddRemoveWhereBatchUnit>> grouped = new HashMap<>();

		// TODO: for now we do no grouping. We would like to group together a base store and its enrichment tables
		for (IApexAddRemoveWhereBatchUnit batch : batches) {
			boolean hadLock = false;

			while (!hadLock) {
				// We will call several methods of the batch: .getActuallyWrittenStores and .isEmpty: we have to make
				// sure there is no .send in the meantime
				Lock batchLock = batch.getLock();
				try {
					hadLock = batchLock.tryLock(batchFrequencyMillis.get(), TimeUnit.MILLISECONDS);
				} catch (InterruptedException e) {
					Thread.currentThread().interrupt();
					throw new RuntimeException(e);
				}
				if (!hadLock) {
					LOGGER.debug("We failed acquiring the lock. Retrying...");
				} else {
					// We have the lock
					try {
						Set<? extends Integer> storeIds = batch.getActuallyWrittenStores();

						if (storeIds.isEmpty()) {
							if (!batch.isEmpty()) {
								throw new IllegalStateException("No impacted stores but batch not empty: " + batch);
							}
							LOGGER.trace("Skip {} as it is empty", batch);
						} else {
							// Snapshot storeIds
							grouped.put(ImmutableSet.copyOf(storeIds), Collections.singleton(batch));
						}
					} finally {
						batchLock.unlock();
					}
				}
			}
		}

		return grouped;
	}

	/**
	 * 
	 * @param batches
	 * @return
	 */
	protected IDatastoreSchemaTransactionInformation drainBatchesAndCommit(Set<IApexAddRemoveWhereBatchUnit> batches) {
		Map<Integer, Collection<Stream<? extends Object[]>>> objectsToAdd = new HashMap<>();
		Map<Integer, Collection<ICondition>> removeWheres = new HashMap<>();
		Map<Integer, Collection<IApexUpdateWhereProcedureWrapper>> updateWheres = new HashMap<>();
		List<IApexAddRemoveWhereBatcherListener> listeners = new ArrayList<>();

		for (IApexAddRemoveWhereBatchUnit batch : batches) {
			drainBatch(batch, objectsToAdd, removeWheres, updateWheres, listeners);
		}

		Set<Integer> storeIds = ImmutableSet.<Integer>builder()
				.addAll(objectsToAdd.keySet())
				.addAll(removeWheres.keySet())
				.addAll(updateWheres.keySet())
				.build();

		long start = now();
		try {
			IDatastoreSchemaTransactionInformation transactionInfo =
					doTransaction(objectsToAdd, removeWheres, updateWheres, listeners);

			logNbAdded(storeIds, transactionInfo);

			return transactionInfo;
		} catch (RuntimeException e) {
			errorCount.incrementAndGet(storeIds);

			throw e;
		} finally {
			batchToTimeInTransaction.addAndGet(storeIds, now() - start);
		}
	}

	protected void logNbAdded(Set<Integer> storeIds, IDatastoreSchemaTransactionInformation transactionInfo) {
		if (transactionInfo instanceof IApexDatastoreSchemaTransactionInformation) {
			IApexDatastoreSchemaTransactionInformation apexInfo =
					(IApexDatastoreSchemaTransactionInformation) transactionInfo;

			long nbAdded = Arrays.stream(apexInfo.getWritableStoreIndexToNbAdded()).sum();
			long nbRemoved = Arrays.stream(apexInfo.getWritableStoreIndexToNbRemoved()).sum();
			long nbUpdated = Arrays.stream(apexInfo.getWritableStoreIndexToNbUpdated()).sum();

			long totalBatchSize = nbAdded + nbRemoved + nbUpdated;

			batchToNbImpacted.addAndGet(storeIds, totalBatchSize);
		}
	}

	// Enable unit-testing
	protected long now() {
		return System.currentTimeMillis();
	}

	protected void drainBatch(IApexAddRemoveWhereBatchUnit batch,
			Map<Integer, Collection<Stream<? extends Object[]>>> objectsToAdd,
			Map<Integer, Collection<ICondition>> removeWheres,
			Map<Integer, Collection<IApexUpdateWhereProcedureWrapper>> updateWheres,
			List<IApexAddRemoveWhereBatcherListener> listeners) {
		if (batch.isEmpty()) {
			// Nothing to drain from here
			return;
		}

		batch.getLock().lock();
		try {
			batch.drainTo(objectsToAdd, removeWheres, updateWheres, listeners);
			batch.signalDrained();

			// We are still in the lock: check the batch has
			// actually been flushed
			assert batch.isEmpty();
		} finally {
			batch.getLock().unlock();
		}
	}

	@Override
	protected void doStop(State previousState) throws AgentException {
		super.doStop(previousState);

		batchDrainerExecutionService.shutdown();
		transactionExecutorService.shutdown();
	}

	@Override
	public String getType() {
		return "Apex";
	}

	@Override
	public IDatastoreSchemaMetadata getMetadata() {
		return transactionManager.getMetadata();
	}

	public void setBatchFrequency(long batchFrequencyMillis) {
		this.batchFrequencyMillis.set(batchFrequencyMillis);

		if (getStatus() == State.STARTED) {
			scheduleConsumption();
		}
	}

	/**
	 * 
	 * @param ratioForTooHigh
	 *            if the heap is over this limit, we will stop accumulating data in queue: we continue accepting
	 *            transactions but we try to do transactions as small as possible
	 */
	@ManagedAttribute
	public void setRatioForTooHigh(int ratioForTooHigh) {
		heapIsTooHigh.setRatioForTooHigh(ratioForTooHigh);
	}

	protected int getStoreId(String storeName) {
		return getMetadata().getStoreId(storeName);
	}

	protected String getStoreName(int storeId) {
		return getMetadata().getStoreMetadata(storeId).getName();
	}

	/**
	 * 
	 * @return a mapped Stream to Object[], as expected by the TransactionManger. The tuplization is done lazily, when
	 *         the Stream is closed/consumed
	 */
	protected Stream<? extends Object[]> mapToTuples(final int storeId, Stream<?> asMap, boolean onlyKeyFields) {
		String storeName = getStoreName(storeId);

		return ApexTuplizerHelper.convertIteratorToTuples(getMetadata(), storeName, asMap, onlyKeyFields);
	}

	@Override
	public boolean send(Object submissionId, Map<String, ? extends Collection<?>> storeNameToTuplesToInsert) {
		Map<String, ? extends Stream<?>> toAddStream;

		if (storeNameToTuplesToInsert == null) {
			toAddStream = Collections.emptyMap();
		} else {
			toAddStream = storeNameToTuplesToInsert.entrySet()
					.stream()
					.collect(Collectors.toMap(Entry::getKey, e -> e.getValue().stream()));
		}

		return sendStream(submissionId, toAddStream, null, null, null);
	}

	@Override
	public boolean send(Object submissionId,
			String storeName,
			Stream<?> toAdd,
			ICondition removeWhere,
			IApexAddRemoveWhereBatcherListener listener) {

		Map<String, ICondition> toRemove;
		if (removeWhere == null) {
			toRemove = Collections.emptyMap();
		} else {
			toRemove = Collections.singletonMap(storeName, removeWhere);
		}

		Map<String, Stream<?>> storeToAdd;
		if (toAdd == null) {
			storeToAdd = Collections.emptyMap();
		} else {
			storeToAdd = Collections.singletonMap(storeName, toAdd);
		}
		return sendStream(submissionId, storeToAdd, toRemove, null, listener);
	}

	protected boolean sendStream(Object submissionId,
			Map<String, ? extends Stream<?>> storeNameToTuplesToInsert,
			Map<String, ? extends ICondition> removeWheres,
			Map<String, ? extends Collection<? extends IApexUpdateWhereProcedureWrapper>> updateWheres,
			IApexAddRemoveWhereBatcherListener listener) {
		if (listener != null) {
			listener.onSubmitted(now());
		}

		if (storeNameToTuplesToInsert == null) {
			storeNameToTuplesToInsert = Collections.emptyMap();
		}
		if (removeWheres == null) {
			removeWheres = Collections.emptyMap();
		}
		if (updateWheres == null) {
			updateWheres = Collections.emptyMap();
		}

		Map<Integer, Stream<? extends Object[]>> toAddTuplized;
		Map<Integer, ICondition> storeIdToRemoveWhere;
		Map<Integer, Collection<? extends IApexUpdateWhereProcedureWrapper>> storeIdToUpdateWhere;

		// TODO: Compute the tuples in a concurrent way
		toAddTuplized = new ConcurrentHashMap<>();
		storeNameToTuplesToInsert.forEach((storeName, toAdd) -> {
			int storeId = getStoreId(storeName);
			toAddTuplized.put(storeId, mapToTuples(storeId, toAdd, false));
		});

		storeIdToRemoveWhere = new ConcurrentHashMap<>();
		for (Entry<String, ? extends ICondition> entry : removeWheres.entrySet()) {
			int storeId = getStoreId(entry.getKey());

			storeIdToRemoveWhere.put(storeId, entry.getValue());
		}

		storeIdToUpdateWhere = new ConcurrentHashMap<>();
		for (Entry<String, ? extends Collection<? extends IApexUpdateWhereProcedureWrapper>> entry : updateWheres
				.entrySet()) {
			int storeId = getStoreId(entry.getKey());

			storeIdToUpdateWhere.put(storeId, entry.getValue());
		}

		if (listener != null) {
			listener.onTuplized(now());
		}

		ApexTransactionHolder holder =
				new ApexTransactionHolder(toAddTuplized, storeIdToRemoveWhere, storeIdToUpdateWhere);
		return sendTuples(submissionId, holder, listener);
	}

	@Override
	public boolean sendUpdateWhere(String storeName,
			Collection<? extends IApexUpdateWhereProcedureWrapper> updateWhere,
			IApexAddRemoveWhereBatcherListener listener) {
		return sendStream(IApexAddRemoveWhereBatchUnit.FORCE_DEDICATED_TRANSACTION_SUBMISSION_ID,
				Collections.emptyMap(),
				Collections.emptyMap(),
				Collections.singletonMap(storeName, updateWhere),
				listener);
	}

	protected boolean sendTuples(Object submissionId,
			IApexTransactionHolder apexTransactionHolder,
			IApexAddRemoveWhereBatcherListener listener) {
		nbAsyncSubmission.incrementAndGet();

		Set<Integer> explicitelyImpactedStore = new HashSet<>();

		explicitelyImpactedStore.addAll(apexTransactionHolder.getToAddTuplized().keySet());
		explicitelyImpactedStore.addAll(apexTransactionHolder.getStoreIdToRemoveWhere().keySet());
		explicitelyImpactedStore.addAll(apexTransactionHolder.getStoreIdToUpdateWhere().keySet());

		IApexAddRemoveWhereBatchUnit batchRecord = findBatchRecord(explicitelyImpactedStore);

		return doPublish(submissionId, batchRecord, apexTransactionHolder, listener);
	}

	/**
	 * 
	 * @return the stores which will be locked by ActivePivot: it is all pivot which has a direct or indirect reference
	 *         to the explicitly modified stores
	 */
	protected int[] computeRelatedStores(Set<Integer> explicitelyImpactedStore) {
		TransactionManager actualTM = (TransactionManager) transactionManager;
		return TransactionManager.getStoresToLock(convertToPrimitive(explicitelyImpactedStore),
				actualTM.getSchemaTransactionManager().getDatastoreSchema());
	}

	/**
	 * The default implementation has the following goals:
	 * 
	 * If a thread submit facts on the main store and another threads facts on a enrichment store, the transaction on
	 * the main store should NOT drain the enrichment entries as these enrichment entries could lead to a huge
	 * transaction (by reference update) and we prefer to have low latency and the main store
	 * 
	 * @return the {@link ApexTransactionWrapperBatch} holding the data to submit to this set of stores
	 */
	protected IApexAddRemoveWhereBatchUnit findBatchRecord(Set<Integer> explicitelyImpactedStore) {
		// Initialize the ApexTransactionWrapperBatch for this set of stores
		if (!storesToInsertAndRemoveBatch.containsKey(explicitelyImpactedStore)) {
			// Order lexicographically
			Set<String> storeNames = new TreeSet<>();

			for (Integer storeId : explicitelyImpactedStore) {
				storeNames.add(getStoreName(storeId));
			}

			storesToInsertAndRemoveBatch.putIfAbsent(explicitelyImpactedStore,
					makeApexTransactionWrapperBatch(storeNames));
		}

		return storesToInsertAndRemoveBatch.get(explicitelyImpactedStore);
	}

	protected IApexAddRemoveWhereBatchUnit makeApexTransactionWrapperBatch(Set<String> storeNames) {
		return new ApexTransactionWrapperBatch(heapIsTooHigh, storeNames);
	}

	@ManagedOperation
	@Override
	public void pause() throws AgentException {
		super.pause();
	}

	@ManagedOperation
	@Override
	public void resume() throws AgentException {
		super.resume();
	}

	/**
	 * 
	 * @param submissionId
	 * @param batchRecord
	 * @param toAddTuplized
	 * @param removeWhere
	 * @param updateWheres
	 * @param listener
	 * @return true if we encountered collision or full batch
	 */
	protected boolean doPublish(Object submissionId,
			final IApexAddRemoveWhereBatchUnit batchRecord,
			IApexTransactionHolder apexTransactionHolder,
			IApexAddRemoveWhereBatcherListener listener) {

		if (this.getStatus() == State.STOPPED) {
			LOGGER.warn("We dismiss {} as transactionWrapper is stopped", batchRecord);
			return false;
		} else if (this.getStatus() != State.STARTED) {
			throw new RuntimeException(
					"One can not submit data to a not-started " + this.getClass() + ". Name=" + name);
		}

		// Check for emptiness. THese is still a change the holder is empty as we may have received an empty stream
		if (publishIsEmpty(apexTransactionHolder)) {
			return false;
		}

		long start = now();

		int nbConsume = 0;

		AtomicBoolean collisionOrFull = new AtomicBoolean();

		boolean publishSucceeded = false;
		AtomicBoolean logFulled = new AtomicBoolean();

		while (!publishSucceeded) {
			boolean hasLock;
			Lock batchLock = batchRecord.getLock();
			try {
				hasLock = batchLock.tryLock(batchFrequencyMillis.get(), TimeUnit.MILLISECONDS);
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
				throw new RuntimeException(e);
			}
			if (!hasLock) {
				LOGGER.debug("We failed acquiring the lock. Retrying...");
			} else {
				// We have the lock
				try {
					publishSucceeded = publishInsideLock(submissionId,
							batchRecord,
							collisionOrFull,
							logFulled,
							apexTransactionHolder,
							listener);
				} finally {
					batchLock.unlock();
				}
			}
		}

		long time = now() - start;

		if (time > DEFAULT_MIN_MS_FOR_ASYNCHRONOUS_PUBLISH_LOG) {
			LOGGER.debug("It took {} ms to publish asynchronous operations with {} synchronous transactions",
					time,
					nbConsume);
		}

		return collisionOrFull.get();
	}

	protected boolean publishInsideLock(Object submissionId,
			IApexAddRemoveWhereBatchUnit batchRecord,
			AtomicBoolean collisionOrFull,
			AtomicBoolean logFulled,
			IApexTransactionHolder apexTransactionHolder,
			IApexAddRemoveWhereBatcherListener listener) {
		final boolean publishSucceeded;
		if (batchRecord.isFull()) {
			if (!logFulled.get()) {
				logBatchIsFull(batchRecord);
				logFulled.set(true);
			}

			publishSucceeded = false;
		} else if (!batchRecord.addSubmissionId(submissionId)) {

			// This submissionId is already present in current
			// batch: empty the batch synchronously
			LOGGER.debug("We encountered a collision for {} on {}", submissionId, batchRecord);

			publishSucceeded = false;
		} else {
			// TODO: add Trace log with submission content
			batchRecord.addRemoveWhere(apexTransactionHolder, listener);

			// We succeeded inserting the data
			publishSucceeded = true;
		}

		if (!publishSucceeded) {
			collisionOrFull.set(true);
			// If we get here, it means we need to wait for the batch to be drained

			// First, we ask drain right now: useful if we have a large batchFrequency (or deactivated
			// automatic flushing)
			requestFlushingRightNow(batchRecord);

			// Await drained while keeping the lock: this will release the lock, to let the drain operation
			// happens in the transaction pool, and awaitDrained will return after the drain and lock is
			// available
			try {
				// We do a timed waited to skip the risk of missing the signal
				batchRecord.awaitDrained(batchFrequencyMillis.get(), TimeUnit.MILLISECONDS);
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
				throw new RuntimeException(e);
			}
		}

		return publishSucceeded;
	}

	protected boolean publishIsEmpty(IApexTransactionHolder apexTransactionHolder) {
		boolean allEmpty = true;

		// TODO THere is a change we say the transactionHolder is not empty while it holds only empty toAdd: it would be
		// too complex to detect if a stream is empty. The user should have checkthis earlier
		// https://stackoverflow.com/questions/26649062/how-to-check-if-a-java-8-stream-is-empty
		if (!apexTransactionHolder.getToAddTuplized().isEmpty()) {
			allEmpty = false;
		}

		allEmpty &= apexTransactionHolder.getStoreIdToRemoveWhere().isEmpty();

		allEmpty &= !apexTransactionHolder.getStoreIdToUpdateWhere()
				.values()
				.stream()
				.flatMap(c -> c.stream())
				.findAny()
				.isPresent();

		return allEmpty;
	}

	protected void logBatchIsFull(IApexAddRemoveWhereBatchUnit batchRecord) {
		long totalTimeInNanos = ApexMetricsHelper.getNanos(commitTransactionTimer);
		long totalAdd = totalAddInTransaction.getCount();

		Object rate = PepperLogHelper.getNiceRate(totalAdd, totalTimeInNanos, TimeUnit.NANOSECONDS);

		LOGGER.warn(
				"{} is full. We are publishing in batcher faster than ITransactionManager can consume."
						+ " {} ({} entry in )",
				batchRecord,
				rate,
				totalAdd,
				PepperLogHelper.humanDuration(totalTimeInNanos, TimeUnit.NANOSECONDS));
	}

	protected void requestFlushingRightNow(final IApexAddRemoveWhereBatchUnit batchRecord) {
		// We should register the nbDrain while locked
		assert ((ReentrantLock) batchRecord.getLock()).isHeldByCurrentThread();

		// snapshot current number of drains: we want to wait for an additional drain
		final long nbDrained = batchRecord.nbDrained();

		// Request for a transaction right now: we do not want to wait
		// for batchFrequencyMillis as either the batch is full, either
		// there is a collision
		// DO NOT DO THE TRANSACTION IN CURRENT THREAD, else it would
		// break the 'commit in same order than publish' constrain
		batchDrainerExecutionService.execute(() -> {
			// batchDrainerExecutionService is mono-threaded: if nbDrained has not increased, it means we need to do
			// the requested drain
			if (batchRecord.nbDrained() > nbDrained) {
				LOGGER.debug("{} has been drained in the meantime", batchRecord);
			} else {
				LOGGER.debug("We are about to early drain {}", batchRecord);
				groupThenDrainThenCommitThenWaitAndReport(Collections.singleton(batchRecord));
			}
		});
	}

	protected void onStartTransactionFailure(int[] storeIds,
			Set<Integer> objectsToAdd,
			DatastoreTransactionException ex) {
		// Duplicated from TransactionWrapper
		LOGGER.error("Could not start transaction.", ex);
	}

	/**
	 * By default, we throw on a transaction failure. One could decide to have more advanced behavior like closing the
	 * {@link ITransactionWrapper}
	 */
	protected void onStoreModificationFailure(Throwable e,
			int storeId,
			Map<Integer, ? extends Collection<? extends Stream<? extends Object[]>>> objectsToAdd,
			Map<Integer, Collection<ICondition>> removeWheres) {
		ApexTransactionHelper.behaveOnTransactionException(e, transactionManager);
	}

	/**
	 * This method should always be called in the same thread, to prevent race-condition. Even in case of a call to
	 * .flush, we should guarantee all data is submitted in the initial submission order.
	 * 
	 * This constrain can be soften for different batches: a transaction on storeA can be done concurrently to a
	 * transaction in storeB
	 * 
	 * @param objectsToAdd
	 * @param removeWheres
	 * @param updateWheres
	 * @param listeners
	 * @return a {@link IDatastoreSchemaTransactionInformation} if successful
	 */
	protected IDatastoreSchemaTransactionInformation doTransaction(
			Map<Integer, Collection<Stream<? extends Object[]>>> objectsToAdd,
			Map<Integer, Collection<ICondition>> removeWheres,
			Map<Integer, Collection<IApexUpdateWhereProcedureWrapper>> updateWheres,
			Iterable<? extends IApexAddRemoveWhereBatcherListener> listeners) {

		// Duplicated from TransactionWrapper
		// Merge adds, removals and updates storeIds
		int[] storeIds = computeStoreIds(objectsToAdd, removeWheres, updateWheres);

		Set<String> storeNames = new TreeSet<>();

		if (reuseTransactionHelper) {
			return ApexTransactionHelper.executeInTransaction(transactionManager, storeIds, transactionId -> {
				storeNames.addAll(submitWhileInsideTransaction(storeIds, objectsToAdd, removeWheres, updateWheres));

				LOGGER.debug("Flushed to ITransactionManager for transactionId={} and stores={}. Still need to commit",
						transactionId,
						storeNames);
				onTransactionPublished(transactionId, listeners);
			});
		} else {

			long transactionId;
			try (Context context = startTransactionTimer.time()) {
				if (storeIds == null || storeIds.length == 0) {
					transactionId = transactionManager.startTransaction();
				} else {
					transactionId = transactionManager.startTransaction(storeIds);
				}

				LOGGER.debug("Started ITransaction for transactionId={}", transactionId);

				onTransactionStarted(transactionId, listeners);
			} catch (DatastoreTransactionException e) {
				onStartTransactionFailure(storeIds, objectsToAdd.keySet(), e);
				return null;
			}

			int currentStoreId = -1;
			try (Context context = publishContentTimer.time()) {
				storeNames.addAll(submitWhileInsideTransaction(storeIds, objectsToAdd, removeWheres, updateWheres));

				LOGGER.debug("Flushed to ITransactionManager for transactionId={} and stores={}. Still need to commit",
						transactionId,
						storeNames);
				onTransactionPublished(transactionId, listeners);
			} catch (RuntimeException | Error e) {
				try {
					// This will throw an Exception
					onStoreModificationFailure(e, currentStoreId, objectsToAdd, removeWheres);
				} finally {
					// This will notify listeners
					afterPublishContentFailedCommit(transactionId, listeners, e);
				}
			}
			try (Context time = commitTransactionTimer.time()) {
				IDatastoreSchemaTransactionInformation transactionCommited = transactionManager.commitTransaction();

				LOGGER.debug("Committed to ITransactionManager for transactionId={} and stores={}",
						transactionId,
						storeNames);

				afterTransactionCommit(transactionCommited, listeners);
				return transactionCommited;
			} catch (DatastoreTransactionException | RuntimeException | Error e) {
				onCommitFailure(transactionId, storeNames, e, listeners);
				return null;
			}
		}
	}

	/**
	 * 
	 * @param storeIds
	 * @param objectsToAdd
	 * @param removeWheres
	 * @param updateWheres
	 * @return the name of the store which are directly impacted by the submission (i.e. store in which we
	 *         add/remove/update)
	 */
	protected Collection<? extends String> submitWhileInsideTransaction(int[] storeIds,
			Map<Integer, Collection<Stream<? extends Object[]>>> objectsToAdd,
			Map<Integer, Collection<ICondition>> removeWheres,
			Map<Integer, Collection<IApexUpdateWhereProcedureWrapper>> updateWheres) {
		if (storeIds == null) {
			return Collections.emptySet();
		}
		return IntStream.of(storeIds)
				.peek(storeId -> submitWhileInsideTransaction(storeId,
						objectsToAdd.get(storeId),
						removeWheres.get(storeId),
						updateWheres.get(storeId)))
				.mapToObj(storeId -> getStoreName(storeId))
				.collect(Collectors.toSet());
	}

	protected int[] computeStoreIds(Map<Integer, ? extends Collection<?>> objectsToAdd,
			Map<Integer, Collection<ICondition>> removeWheres,
			Map<Integer, Collection<IApexUpdateWhereProcedureWrapper>> updateWheres) {
		Set<Integer> allStores =
				Sets.newTreeSet(Iterables.concat(objectsToAdd.keySet(), removeWheres.keySet(), updateWheres.keySet()));

		return Ints.toArray(allStores);
	}

	protected void submitWhileInsideTransaction(int storeId,
			Collection<? extends Stream<? extends Object[]>> objectsToAdd,
			Collection<ICondition> removeWheres,
			Collection<IApexUpdateWhereProcedureWrapper> updateWheres) {
		String storeName = getStoreName(storeId);

		// First, we do removals

		// Do not do an OR condition as it leads to
		// full-scans in the Datastore

		AtomicInteger nbRemove = new AtomicInteger();
		Optional.ofNullable(removeWheres).map(c -> c.stream()).orElse(Stream.empty()).forEach(removeWhere -> {
			// The API does not accept int storeId for removeWhere
			ApexInTransactionHelper.removeInTransaction(transactionManager, storeName, removeWhere);
			nbRemove.incrementAndGet();
		});

		final AtomicLong nbAdd = new AtomicLong();

		// Then we do insertions
		Optional.ofNullable(objectsToAdd).ifPresent(toAdd -> {
			long nbAdded = addInTransactionManager(storeId, (Collection<? extends Stream<Object[]>>) toAdd);

			nbAdd.set(nbAdded);
			totalAddInTransaction.mark(nbAdded);
		});

		// Then we to updateWheres
		AtomicInteger nbUpdate = new AtomicInteger();

		// Do not do an OR condition as it leads to
		// full-scans in the Datastore
		Optional.ofNullable(updateWheres).map(c -> c.stream()).orElse(Stream.empty()).forEach(updateWhere -> {
			ApexInTransactionHelper.executeUpdateWhere(transactionManager,
					updateWhere.getSelection(),
					updateWhere.getCondition(),
					updateWhere.getUpdateWhere());
			nbUpdate.incrementAndGet();
		});

		LOGGER.debug("Published to ITransactionManager {} adds, {} removals and {} updates to {}",
				nbAdd,
				nbRemove,
				nbUpdate,
				storeName);
	}

	/**
	 * 
	 * @param storeId
	 * @param entriesToAdd
	 * @return the number of added entries
	 */
	protected long addInTransactionManager(final int storeId, Collection<? extends Stream<Object[]>> entriesToAdd) {
		// By using a stream, we make sure all
		// entries are not materialized right away
		final IStoreFormat storeFormat = getMetadata().getStoreMetadata(storeId).getStoreFormat();

		Stream<? extends Object[]> toAdd = entriesToAdd.stream()
				// We handle the Input Streams in parallel as we may have many of them
				.parallel()
				// Each underlying Stream is turned parallel in order to handle large ones
				.flatMap(s -> s.parallel())
				.map(record -> enrichInTransaction(storeId, record))
				.filter(Objects::nonNull);

		// We expect such an add operation to be done on a group of values without duplicates. Else, it should be
		// handled either by the submissionId in IApexTransactionBatcher.send or with an
		// IDuplicateKeyWithinTransactionListener
		return ApexInTransactionHelper.addInTransaction(transactionManager, storeFormat.getStoreName(), toAdd);
	}

	/**
	 * @param storeId
	 * @return an enriched version of the input tuple
	 * 
	 * @see #getFieldIndex(int, String)
	 */
	protected Object[] enrichInTransaction(int storeId, Object[] toAdd) {
		return toAdd;
	}

	protected void onTransactionStarted(long transactionId,
			Iterable<? extends IApexAddRemoveWhereBatcherListener> listeners) {
		long transactionStarted = now();
		for (IApexAddRemoveWhereBatcherListener listener : listeners) {
			listener.onTransactionStarted(transactionId, transactionStarted);
		}
	}

	protected void onTransactionPublished(long transactionId,
			Iterable<? extends IApexAddRemoveWhereBatcherListener> listeners) {
		long transactionPublished = now();
		for (IApexAddRemoveWhereBatcherListener listener : listeners) {
			listener.onTransactionPublished(transactionId, transactionPublished);
		}
	}

	/**
	 * We log but do not throw an Exception which would prevent the IApexAddRemoveWhereTransactionWrapper from doing
	 * more transaction
	 */
	protected void onCommitFailure(long transactionId,
			Set<String> storeNames,
			Throwable t,
			Iterable<? extends IApexAddRemoveWhereBatcherListener> listeners) {
		LOGGER.error("Exception while commiting in " + storeNames, t);
		long transactionCommitFailed = now();
		for (IApexAddRemoveWhereBatcherListener listener : listeners) {
			listener.onCommitFailure(transactionId, transactionCommitFailed, t);
		}
	}

	protected void afterPublishContentFailedCommit(long transactionId,
			Iterable<? extends IApexAddRemoveWhereBatcherListener> listeners,
			Throwable t) {
		long transactionCommitFailed = now();
		for (IApexAddRemoveWhereBatcherListener listener : listeners) {
			listener.onPublishContentFailure(transactionId, transactionCommitFailed, t);
		}
	}

	protected Set<String> getStoreNames(int[] storeIds) {
		return ApexTransactionManager.getStoreNames(storeIds, getMetadata());
	}

	@ManagedAttribute
	public List<String> getAllStoreNames() {
		return PepperJMXHelper.convertToJMXList(getMetadata().getStoreNames());
	}

	protected void afterTransactionCommit(IDatastoreSchemaTransactionInformation transactionCommited,
			final Iterable<? extends IApexAddRemoveWhereBatcherListener> listeners) {
		if (listeners.iterator().hasNext()) {
			long transactionCommitedTime = now();

			for (IApexAddRemoveWhereBatcherListener listener : listeners) {
				listener.onTransactionCommited(transactionCommited, transactionCommitedTime);
			}

			if (apexNotificationPropagator == null) {
				LOGGER.warn("Missing {} for publishing transaction events", IApexNotificationPropagator.class);
				return;
			} else {
				apexNotificationPropagator.propagateNotification(transactionCommited, listeners);
			}
		}
	}

	protected int[] convertToPrimitive(Set<? extends Integer> keySet) {
		return Ints.toArray(keySet);
	}

	@ManagedOperation
	public int flushAndAwaitTransactions() throws InterruptedException {
		return flushAndAwaitTransactions(ImmutableSet.copyOf(getMetadata().getStoreNames())).size();
	}

	// We can not guarantee to do everything in a single transaction as some batches may reference the same store with
	// add/removeWhere operations
	@Beta
	@Override
	public Collection<? extends IDatastoreSchemaTransactionInformation> flushAndAwaitTransactions(
			final Set<? extends String> storeNamesToFlush) throws InterruptedException {
		// DoConsume in the main thread so that this flush does not lead to an
		// early transaction which might insert data in a different order than
		// the original order
		final Set<Integer> storeIdsToFlush;

		if (storeNamesToFlush == null) {
			storeIdsToFlush = null;
		} else {
			storeIdsToFlush = new HashSet<>();

			for (String storeName : storeNamesToFlush) {
				storeIdsToFlush.add(getStoreId(storeName));
			}
		}

		final Set<IApexAddRemoveWhereBatchUnit> toFlush = new HashSet<>();

		// TODO: we should register here some kind of modificationId, and then drain until modificationIds are greater
		// than those selected

		for (Entry<Set<Integer>, IApexAddRemoveWhereBatchUnit> entry : storesToInsertAndRemoveBatch.entrySet()) {
			// Check this batch holds entry on at at least one
			// of the impacted stores
			if (storeIdsToFlush == null || !Sets.intersection(storeIdsToFlush, entry.getKey()).isEmpty()) {
				toFlush.add(entry.getValue());
			}
		}

		ListenableFuture<List<ListenableFuture<IDatastoreSchemaTransactionInformation>>> flushFuture =
				batchDrainerExecutionService.submit(() -> computeFutures(toFlush));

		try {
			return Futures.allAsList(flushFuture.get()).get();
		} catch (ExecutionException e) {
			throw new RuntimeException(e);
		}
	}

	private List<ListenableFuture<IDatastoreSchemaTransactionInformation>> computeFutures(
			Set<IApexAddRemoveWhereBatchUnit> toFlush) throws InterruptedException, ExecutionException {
		List<ListenableFuture<IDatastoreSchemaTransactionInformation>> allFutures = new ArrayList<>();

		for (IApexAddRemoveWhereBatchUnit batch : toFlush) {
			if (batch.isEmpty()) {
				// The batch is empty: we need to ensure current transaction (if any) is
				// consumed
				ListenableFuture<IDatastoreSchemaTransactionInformation> future = batchToTransactionFuture.get(batch);

				if (future != null && !future.isDone()) {
					LOGGER.debug("Wait future associated to {}", batch);

					// Add a wait on current transaction
					allFutures.add(future);
				} else {
					LOGGER.debug("Nothing to flush in {}", batch);
				}
			} else {
				// Batch is not empty: waiting for its drain to be committed will ensure current
				// transaction is finished

				ListenableFuture<IDatastoreSchemaTransactionInformation> future = batchToTransactionFuture.get(batch);

				if (future != null && !future.isDone()) {
					// There is a running transaction on this batch: trying to process it right
					// now
					// would lead to batch rejection as a batch can be in a single transaction
					// at a time
					LOGGER.debug("Wait synchronsouly for end of transaction on {}", batch);
					future.get();
				}

				LOGGER.debug("Add flush operation for {}", batch);
			}
		}

		allFutures.addAll(groupThenDrainThenCommit(toFlush));

		return allFutures;
	}

	@Override
	public boolean send(Object submissionId,
			String storeName,
			Collection<?> toAdd,
			ICondition removeWhere,
			IApexAddRemoveWhereBatcherListener listener) {
		Map<String, ? extends Stream<?>> toAddAsMap;
		if (toAdd == null) {
			toAddAsMap = null;
		} else {
			toAddAsMap = Collections.singletonMap(storeName, toAdd.stream());
		}
		Map<String, ICondition> removeWhereAsMap;
		if (removeWhere == null) {
			removeWhereAsMap = null;
		} else {
			removeWhereAsMap = Collections.singletonMap(storeName, removeWhere);
		}

		return sendStream(submissionId, toAddAsMap, removeWhereAsMap, Collections.emptyMap(), listener);
	}

	@Override
	public void doEmptyTransaction(Collection<? extends String> storeNames) {
		Map<Integer, Collection<Stream<? extends Object[]>>> storeIdToEmptyMap = new HashMap<>();

		for (String storeName : storeNames) {
			storeIdToEmptyMap.put(getStoreId(storeName), Collections.emptySet());
		}

		// Exception case where doTransaction could be called out on the unique
		// thread. It is valid as this .doTransaction does not submit anything
		doTransaction(storeIdToEmptyMap, Collections.emptyMap(), Collections.emptyMap(), Collections.emptyList());
	}

	@Override
	public void afterPropertiesSet() throws AgentException {
		init(propertiesForInit());

		if (startOnInit.get()) {
			start();
		} else {
			LOGGER.info("The {} has NOT been started (as requested by conf)", this.getName());
		}
	}

	@ManagedAttribute
	public String getStatusAsString() {
		return super.getStatus().toString();
	}

	protected Properties propertiesForInit() {
		// By default, we init without any Properties
		return new Properties();
	}

	@Override
	public void destroy() throws AgentException {
		stop();
	}

	@ManagedAttribute
	@Override
	public Set<String> getPendingStores() {
		Set<String> pendingStoreNames = storesToInsertAndRemoveBatch.values()
				.stream()
				.flatMap(s -> s.getActuallyWrittenStores().stream())
				.map(storeIndex -> getMetadata().getStoreMetadata(storeIndex).getName())
				.collect(Collectors.toSet());

		return PepperJMXHelper.convertToJMXSet(pendingStoreNames);
	}

	@ManagedAttribute
	public long getErrorCount() {
		return errorCount.sum() + commitFailure.get();
	}

	@ManagedAttribute
	public long getNbAsyncSubmission() {
		return nbAsyncSubmission.get();
	}

	@ManagedAttribute
	public long getBatchFrequency() {
		return batchFrequencyMillis.get();
	}

	@ManagedAttribute
	public String getFutureStatus() {
		ScheduledFuture<?> future = consumptionFuture.get();
		if (future == null) {
			return "null";
		} else if (future.isCancelled()) {
			return "Cancelled";
		} else if (future.isDone()) {
			return "Done";
		} else {
			return "Other";
		}
	}

	@ManagedAttribute
	public Map<String, Long> getBatchToNbImpacted() {
		// We prefer to have big batches first, and then order by storeName
		Map<String, Long> stringKey = new TreeMap<>();
		for (Entry<Set<Integer>, Long> sizeEntry : batchToNbImpacted.asMap().entrySet()) {
			Set<Integer> storeIds = sizeEntry.getKey();

			String storeNames = getStoreNames(Ints.toArray(storeIds)).toString();
			stringKey.put(storeNames, sizeEntry.getValue());
		}

		return PepperJMXHelper.convertToJMXValueOrderedMap(stringKey, true);
	}

	@ManagedAttribute
	public Map<String, Long> getBatchToTransactionRatePerSecond() {
		Map<String, Long> stringKey = new TreeMap<>();
		for (Entry<Set<Integer>, Long> sizeEntry : batchToNbImpacted.asMap().entrySet()) {
			Set<Integer> storeIds = sizeEntry.getKey();
			long timeMs = batchToTimeInTransaction.get(storeIds);

			if (timeMs > 0) {
				// *1000D to convert time to seconds
				String storeNames = getStoreNames(Ints.toArray(storeIds)).toString();
				stringKey.put(storeNames, TimeUnit.MILLISECONDS.toSeconds(sizeEntry.getValue() / timeMs));
			}
		}

		return PepperJMXHelper.convertToJMXValueOrderedMap(stringKey, true);
	}

	@ManagedAttribute
	public Map<String, Long> getStoreIdToSizeBeingConsumed() {
		// We prefer to have big batches first, and then order by storeName
		Map<String, Long> stringKey = PepperJMXHelper.convertToJMXMapKeyString(this.storeIdToSizeBeingConsumed.asMap());

		// Keep only batches with more than 1 entry
		stringKey = Maps.filterValues(stringKey, input -> input > 0);

		return PepperJMXHelper.convertToJMXValueOrderedMap(stringKey, true);
	}

	@ManagedAttribute
	public double getStartTransactionMeanRate() {
		return startTransactionTimer.getMeanRate();
	}

	@ManagedAttribute
	public double getPublishContentMeanRate() {
		return publishContentTimer.getMeanRate();
	}

	@ManagedAttribute
	public double getCommitTransactionMeanRate() {
		return commitTransactionTimer.getMeanRate();
	}

	@ManagedAttribute
	public long getMillisInTransaction() {
		double timeToStart = ApexMetricsHelper.getNanos(startTransactionTimer);
		double timeToAdd = ApexMetricsHelper.getNanos(publishContentTimer);
		double timeToCommit = ApexMetricsHelper.getNanos(commitTransactionTimer);
		return TimeUnit.NANOSECONDS.toMillis((long) (timeToStart + timeToAdd + timeToCommit));
	}

	@ManagedAttribute
	public long getNbAdded() {
		return totalAddInTransaction.getCount();
	}

	@ManagedAttribute
	public String getNiceTimeInTransaction() {
		return PepperLogHelper.humanDuration(getMillisInTransaction()).toString();
	}

	@Override
	public boolean isActive() {
		long activeCount = batchToTransactionFuture.values().stream().filter(e -> !e.isDone()).count();

		if (activeCount > 0L) {
			// We have at least one batch being processed
			return true;
		}

		// We have at least one batch with pending data: consider this as active
		return getHasPending();
	}

	@Override
	public boolean isHasPending() {
		return storesToInsertAndRemoveBatch.values().stream().filter(batch -> !batch.isEmpty()).findAny().isPresent();
	}

}

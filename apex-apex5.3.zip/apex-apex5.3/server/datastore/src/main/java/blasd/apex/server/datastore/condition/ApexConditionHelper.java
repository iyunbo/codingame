/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.datastore.condition;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.annotations.Beta;
import com.google.common.base.Optional;
import com.google.common.collect.Iterables;
import com.google.common.collect.Sets;
import com.qfs.condition.IBaseCondition;
import com.qfs.condition.ICondition;
import com.qfs.condition.IConstantCondition;
import com.qfs.condition.IDynamicCondition;
import com.qfs.condition.ImplementationCode;
import com.qfs.condition.impl.BaseConditions;
import com.qfs.condition.impl.DynamicCondition;
import com.quartetfs.fwk.filtering.impl.AndCondition;

import blasd.apex.server.datastore.ApexDatastoreHelper;
import cormoran.pepper.collection.CartesianProductHelper;
import cormoran.pepper.logging.PepperLogHelper;
import cormoran.pepper.memory.IPepperMemoryConstants;

/**
 * Helps for {@link ICondition}, typically to convert Map to ICondition
 * 
 * @author Benoit Lacelle
 *
 */
public class ApexConditionHelper {
	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexConditionHelper.class);

	protected ApexConditionHelper() {
		// hidden
	}

	/**
	 * Same as BaseConditions#createDynamicCondition
	 */
	public static IDynamicCondition createDynamicCondition(String field, ImplementationCode code) {
		return new DynamicCondition(new String[] { field }, code, IDynamicCondition.PARAMETER_NAME_NOT_GIVEN, -1);
	}

	protected static List<ICondition> convertToSubConditions(Map<? extends String, ?> template) {
		List<ICondition> conditions = new ArrayList<>();

		// If the template is null, we search for everything
		if (template != null) {
			for (Entry<? extends String, ?> coordinateEntry : template.entrySet()) {
				// TODO: introduce a way to query for entries associated to the
				// value null
				if (coordinateEntry.getValue() != null) {
					ICondition subCondition = convertToCondition(coordinateEntry.getKey(), coordinateEntry.getValue());

					conditions.add(subCondition);
				}
			}
		}

		return conditions;
	}

	protected static ICondition wrapToAndCondition(List<ICondition> subConditions) {

		ICondition fullCondition;
		if (subConditions.isEmpty()) {
			fullCondition = BaseConditions.TRUE;
		} else if (subConditions.size() == 1) {
			// This optimization seems useless as it is done in ConditionParser
			fullCondition = subConditions.get(0);
		} else {
			fullCondition = BaseConditions.And(subConditions);
		}

		return fullCondition;
	}

	/**
	 * @return an {@link ICondition} which is a {@link AndCondition} for each entry of the {@link Map} template
	 */
	public static ICondition convertToCondition(Map<? extends String, ?> template) {
		List<ICondition> subConditions = convertToSubConditions(template);

		return wrapToAndCondition(subConditions);
	}

	public static ICondition convertToCondition(String key, Object value) {
		if (value instanceof Collection<?>) {
			Collection<?> valueAsCollection = (Collection<?>) value;

			if (valueAsCollection.isEmpty()) {
				// No value to match: can not match anything
				return BaseConditions.False();
			} else if (valueAsCollection.size() == 1) {
				// Simplify to EQ for single possible value
				return BaseConditions.Equal(key, valueAsCollection.iterator().next());
			} else {
				// The template is a Collection: we want to filter rows
				// with a value contained by this Collection
				return BaseConditions.In(key, valueAsCollection);
			}
		} else if (value instanceof NotConditionWrapper<?>) {
			NotConditionWrapper<?> valueInWrapper = (NotConditionWrapper<?>) value;

			// The template is a NotConditionWrapper: we want to
			// filter rows
			// with a value different from input
			return BaseConditions.Not(convertToCondition(key, valueInWrapper.decorated));
		} else {
			return BaseConditions.Equal(key, value);
		}
	}

	@Beta
	public static ICondition convertToCondition(Stream<? extends Map<? extends String, ?>> templates) {
		if (templates == null) {
			// No subConditions to an OR: empty result
			return BaseConditions.FALSE;
		} else {
			return convertToCondition(templates.collect(Collectors.toList()));
		}
	}

	/**
	 * 
	 * @param templates
	 * @return a single condition equivalent to the input Iterable of AND conditions
	 */
	public static ICondition convertToCondition(Iterable<? extends Map<? extends String, ?>> templates) {
		if (templates == null) {
			// No subConditions to an OR: empty result
			return BaseConditions.FALSE;
		} else {
			Map<String, Object> common = new LinkedHashMap<>();

			// TODO: This should be used to keep keys ordered, but it is not used yet
			Set<String> orderedKeys = new LinkedHashSet<>();

			Map<Map<? extends String, ?>, Map<? extends String, ?>> originalToReduced = new LinkedHashMap<>();
			for (Map<? extends String, ?> template : templates) {
				// prepare for mutation
				originalToReduced.put(template, new LinkedHashMap<>(template));
				orderedKeys.addAll(template.keySet());
			}

			Set<Entry<? extends String, ?>> allEntries =
					Sets.newLinkedHashSet(Iterables.concat(Iterables.transform(templates, input -> input.entrySet())));

			nextEntry: for (Entry<? extends String, ?> oneEntry : allEntries) {
				for (Map<? extends String, ?> template : templates) {
					if (!template.entrySet().contains(oneEntry)) {
						// At least one entry does not contain this entry: reject as common
						continue nextEntry;
					}
				}

				// This is an entry common to all Maps
				common.put(oneEntry.getKey(), oneEntry.getValue());
				for (Map<? extends String, ?> reduced : originalToReduced.values()) {
					Object value = reduced.remove(oneEntry.getKey());
					assert Objects.equals(value, oneEntry.getValue());
				}
			}

			if (common.isEmpty()) {
				return convertToOrAndCondition(templates);
			} else {
				List<ICondition> subConditions = new ArrayList<>();

				subConditions.addAll(convertToSubConditions(common));

				Collection<? extends Map<? extends String, ?>> leftConditions = originalToReduced.values();

				ICondition orOrNotCommon = convertToOrAndCondition(leftConditions);
				if (!BaseConditions.TRUE.equals(orOrNotCommon)) {
					// Add only if the OR is relevant
					subConditions.add(orOrNotCommon);
				}

				return wrapToAndCondition(subConditions);
			}
		}
	}

	public static ICondition convertToOrAndCondition(Iterable<? extends Map<? extends String, ?>> templates) {
		List<ICondition> conditions;

		// If the template is null, we search for everything
		if (templates == null) {
			conditions = Collections.emptyList();
		} else {
			conditions = new ArrayList<>();
			for (Map<? extends String, ?> template : templates) {
				ICondition singleCondition = convertToCondition(template);

				if (BaseConditions.TRUE.equals(singleCondition)) {
					// One of the underlying condition is TRUE: the OR is TRUE
					return BaseConditions.TRUE;
				} else {
					conditions.add(singleCondition);
				}
			}
		}

		ICondition fullCondition;

		if (conditions.isEmpty()) {
			// We are supposed to do a OR between templates. If there is not a
			// single template, we should not match anything
			fullCondition = BaseConditions.FALSE;
		} else if (conditions.size() == 1) {
			fullCondition = conditions.get(0);
		} else {
			fullCondition = BaseConditions.Or(conditions);
		}

		return fullCondition;
	}

	public static ICondition convertToPreparedCondition(Map<? extends String, ?> template) {
		List<ICondition> conditions = new ArrayList<>();

		// If the template is null, we search for everything
		if (template != null) {
			for (Entry<? extends String, ?> coordinateEntry : template.entrySet()) {
				String key = coordinateEntry.getKey();

				// TODO: introduce a way to query for entries associated to the
				// value null
				if (coordinateEntry.getValue() instanceof Collection<?>) {
					// The template is a Collection: we want to filter rows
					// with a value contained by this Collection
					conditions.add(BaseConditions.In(key).parametrized(key));
				} else if (coordinateEntry.getValue() instanceof NotConditionWrapper<?>) {
					Object wrapped = ((NotConditionWrapper<?>) coordinateEntry.getValue()).decorated;

					if (wrapped instanceof Collection<?>) {
						conditions.add(BaseConditions.Not(BaseConditions.In(key).parametrized(key)));
					} else {
						// Even if the Map tells we query a single value, one may still use the templated condition on a
						// Collection
						conditions.add(BaseConditions.Not(BaseConditions.In(key).parametrized(key)));

						// Add logger for sonar as the other if branch holds the same code
						LOGGER.trace("Grumph");
					}
				} else {
					// Even if the Map tells we query a single value, one may still use the templated condition on a
					// Collection
					conditions.add(BaseConditions.In(key).parametrized(key));
				}
			}
		}

		return wrapToAndCondition(conditions);
	}

	public static ICondition rewrite(ICondition condition) {
		condition = rewriteOrAndsEquals(condition);

		return condition;
	}

	/**
	 * 
	 * @param condition
	 * @return a potentially rewritten condition, trying to convert a OR of various ANDs to a OR of ANDs of INs
	 */
	public static ICondition rewriteOrAndsEquals(final ICondition condition) {
		if (!(condition instanceof IBaseCondition)) {
			// Not an IBaseCondition: Not an OR
			return condition;
		} else {
			IBaseCondition baseCondition = (IBaseCondition) condition;

			// TODO: an actual recursivity
			if (baseCondition.getImplementationCode() == ImplementationCode.AND) {
				List<ICondition> newSubCondition = new ArrayList<>();

				int nbChange = 0;
				for (ICondition subCondition : baseCondition.getSubConditions()) {
					ICondition rewrittenSubCondition = rewriteOrAndsEquals(subCondition);
					newSubCondition.add(rewrittenSubCondition);

					if (rewrittenSubCondition != subCondition) {
						nbChange++;
					}
				}

				if (nbChange > 0) {
					return BaseConditions.And(newSubCondition);
				} else {
					// Stick to the original condition
					return condition;
				}
			} else if (baseCondition.getImplementationCode() == ImplementationCode.OR) {
				int nbSubConditions = baseCondition.getSubConditions().length;
				if (nbSubConditions <= 1) {
					// An OR of a single AND should have been handled by the core. This is
					// maybe some advanced case
					LOGGER.debug("Skip rewriting of {}", condition);
					return condition;
				}

				// We expect to transform each subCondition to a single Map expressing an AND
				Set<Map<String, ?>> listOfTempaltes = new LinkedHashSet<>(nbSubConditions);

				for (ICondition subCondition : baseCondition.getSubConditions()) {
					if (!(subCondition instanceof IBaseCondition)) {
						// The subCondition is not an AND
						return condition;
					} else {
						IBaseCondition subBaseCondition = (IBaseCondition) subCondition;

						final Optional<Map<String, Object>> asMap;

						if (subBaseCondition.getImplementationCode() == ImplementationCode.AND) {
							asMap = convertAndEqToMap(subBaseCondition.getSubConditions());
						} else if (subBaseCondition.getImplementationCode() == ImplementationCode.EQ) {
							// This is like having a AND with a single sub-EQ
							asMap = convertAndEqToMap(subBaseCondition);
						} else if (subBaseCondition.getImplementationCode() == ImplementationCode.IN) {
							// This is like having a AND with a single sub-EQ
							asMap = convertAndEqToMap(subBaseCondition);
						} else {
							// Not handled condition
							asMap = Optional.absent();
						}

						if (asMap.isPresent()) {
							listOfTempaltes.add(asMap.get());
						} else {
							// The subCondition is not an AND: can not rewrite
							return condition;
						}
					}
				}

				// We received a list of Map representing each AND condition: convert it back to an ICondition
				// As this computation may be very long
				// to compute, we check occasionally the
				// timeout
				Set<? extends Map<String, ?>> coveringMaps =
						CartesianProductHelper.groupByKeyAndInValues(listOfTempaltes,
								any -> ApexDatastoreHelper.checkInterruption(CartesianProductHelper.class.getName()));
				ICondition rewritten = convertToCondition(coveringMaps);

				// Helps Sonar as it computes coveringMaps could be null
				int size;
				if (coveringMaps == null) {
					size = 0;
				} else {
					size = coveringMaps.size();
				}

				LOGGER.info("We converted (#{} sub-conditions) {}-{} to (#{}) {}",
						nbSubConditions,
						baseCondition.getImplementationCode(),
						PepperLogHelper.getFirstChars(Arrays.asList(baseCondition.getSubConditions()),
								IPepperMemoryConstants.KB_INT),
						size,
						PepperLogHelper.getFirstChars(rewritten, IPepperMemoryConstants.KB_INT));

				return rewritten;
			} else {
				// This is not a OR of AND
				return condition;
			}
		}
	}

	public static Optional<Map<String, Object>> convertAndEqToMap(ICondition... subConditions) {
		// Maintain original order
		Map<String, Object> asMap = new LinkedHashMap<>();

		for (ICondition andComponent : subConditions) {
			if (andComponent instanceof IConstantCondition
					&& ((IConstantCondition) andComponent).getImplementationCode() == ImplementationCode.EQ) {
				IConstantCondition andBaseComponent = (IConstantCondition) andComponent;

				if (andBaseComponent.getFields().length != 1) {
					// This is not a OR of AND of simple EQ
					return Optional.absent();
				}

				String key = andBaseComponent.getFields()[0];
				Object value = andBaseComponent.getOperand();

				if (key == null) {
					// This case is probably an error: let the core handle it
					return Optional.absent();
				} else if (value == null) {
					// Value == null is replaced by a TRUE condition in the
					// core: let the core handle it
					return Optional.absent();
				} else {
					asMap.put(key, value);
				}
			} else {
				// This is not a OR of AND of simple EQ
				return Optional.absent();
			}
		}

		return Optional.of(asMap);
	}

	/**
	 * @return A value which can be used to generate a NotCondition while converting with
	 *         {@link #convertToCondition(Map)}
	 */
	// We have a deprecation warning because NotConditionWrapper constructor is deprecated for public use
	@SuppressWarnings("deprecation")
	public static Object notValue(Object value) {
		return new NotConditionWrapper<Object>(value);
	}
}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.config.spring;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.google.common.eventbus.EventBus;
import com.qfs.desc.IDatastoreSchemaDescription;
import com.qfs.desc.IDatastoreSchemaDescriptionPostProcessor;
import com.qfs.desc.IReferenceDescription;
import com.qfs.desc.impl.CompressIndexesPostProcessor;
import com.qfs.desc.impl.DictionarizeObjectsPostProcessor;
import com.qfs.desc.impl.UpdateOnlyIfDifferentForReferencedStoresPostProcessor;
import com.qfs.security.IBranchPermissionsManager;
import com.qfs.security.impl.BranchPermissionsManager;
import com.qfs.store.IDatastore;
import com.qfs.store.IMultiVersionDatastoreSchema;
import com.qfs.store.IReadableDatastore;
import com.qfs.store.build.IDatastoreBuilder;
import com.qfs.store.build.IDatastoreBuilder.IBuildableDatastore;
import com.qfs.store.impl.Datastore;
import com.qfs.store.impl.ReadableDatastore;
import com.qfs.store.log.ILogConfiguration;
import com.qfs.store.log.ReplayException;
import com.qfs.store.query.ICompiledQuery;
import com.qfs.store.query.IQueryVisitor;
import com.qfs.store.transaction.ITransactionManager;
import com.quartetfs.fwk.monitoring.jmx.impl.JMXEnabler;

import blasd.apex.server.datastore.condition.ApexQueryManagerMonitor;
import blasd.apex.server.datastore.condition.IApexQueryManagerMonitor;
import blasd.apex.server.loading.transaction.ApexAddRemoveWhereBatcher;
import blasd.apex.server.loading.transaction.IApexAddRemoveWhereBatcher;
import blasd.apex.server.loading.transaction.IApexNotificationPropagator;
import blasd.apex.server.monitoring.loading.ApexDatastoreBuilder;
import blasd.apex.server.monitoring.loading.ApexDuplicateKeyWithinTransactionListener;
import blasd.apex.server.monitoring.loading.ApexTransactionManager;
import blasd.apex.server.monitoring.loading.ApexTransactionManagerMonitoring;
import blasd.apex.server.monitoring.loading.IApexDuplicateKeyWithinTransactionListener;
import blasd.apex.server.monitoring.loading.IApexTransactionManagerMonitoring;
import cormoran.pepper.jvm.HeapIsTooHigh;
import cormoran.pepper.jvm.IHeapIsTooHigh;

/**
 * The {@link ApexDatastoreSpringConfig} will fetch for all {@link Bean}s of type {@link IApexStoreConfig} and
 * {@link IReferenceDescription} to compile them in a constant set of {@link StoreDescriptionCompiler} and
 * {@link ReferenceDescriptionCompiler}.
 * 
 * This compilation enables having several files with different formats to be merged to fill a single store.
 * 
 * Then, datastoreSchemaDescription(ApexDatastoreConfigBuilder, StoreDescriptionCompiler, ReferenceDescriptionCompiler)
 * is used to produce an {@link IDatastoreSchemaDescription}
 * 
 * @author Benoit Lacelle
 * 
 */
@Configuration
public class ApexDatastoreSpringConfig {
	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexDatastoreSpringConfig.class);

	/**
	 * @see DictionarizeObjectsPostProcessor
	 */
	@Bean
	public IDatastoreSchemaDescriptionPostProcessor apexDictionarizeObjectsPostProcessor() {
		return new DictionarizeObjectsPostProcessor();
	}

	/**
	 * @see UpdateOnlyIfDifferentForReferencedStoresPostProcessor
	 */
	@Bean
	public IDatastoreSchemaDescriptionPostProcessor apexUpdateOnlyIfDifferentForReferencedStoresPostProcessor() {
		return new UpdateOnlyIfDifferentForReferencedStoresPostProcessor();
	}

	/**
	 * @see CompressIndexesPostProcessor
	 */
	@Bean
	public IDatastoreSchemaDescriptionPostProcessor apexCompressIndexesPostProcessor() {
		return new CompressIndexesPostProcessor();
	}

	@Bean
	public IApexQueryManagerMonitor apexQueryManagerMonitor() {
		return new ApexQueryManagerMonitor();
	}

	@Bean
	public IApexTransactionManagerMonitoring apexTransactionManagerMonitoring(EventBus eventBus,
			IApexDuplicateKeyWithinTransactionListener duplicateKeyWithinTransactionListener) {
		return new ApexTransactionManagerMonitoring(eventBus::post, duplicateKeyWithinTransactionListener);
	}

	// Add another definition in case there is no EvenBus available
	@Bean
	public IApexTransactionManagerMonitoring apexTransactionManagerMonitoring(
			IApexDuplicateKeyWithinTransactionListener duplicateKeyWithinTransactionListener) {
		LOGGER.warn("There is no eventBus in the ApplicationContext");
		EventBus noopEventBus = new EventBus() {
			@Override
			public void post(Object event) {
				LOGGER.debug("Swallowing event: {}", event);
			}
		};
		return new ApexTransactionManagerMonitoring(noopEventBus::post, duplicateKeyWithinTransactionListener);
	}

	// TODO: unclear if this should be in ApexDatastoreSchemaSpringConfig
	@Bean
	public IApexDuplicateKeyWithinTransactionListener apexDuplicateKeyWithinTransactionListener() {
		return new ApexDuplicateKeyWithinTransactionListener();
	}

	/**
	 * 
	 * @return a {@link IDatastoreBuilder} which builds {@link IDatastore} based on {@link ApexTransactionManager}
	 */
	@Bean
	public IDatastoreBuilder apexDatastoreBuilder(final IApexQueryManagerMonitor apexQueryManagerMonitor,
			final IApexTransactionManagerMonitoring apexTransactionManagerMonitoring) {
		return new ApexDatastoreBuilder(apexQueryManagerMonitor, apexTransactionManagerMonitoring);
	}

	@Bean
	public IBranchPermissionsManager apexBranchPermissionsManager() {
		// TODO Is it legal to have an empty set of branchCreators?
		// return new ContentServiceBranchPermissionsManager(contentService, Collections.emptySet());
		return BranchPermissionsManager.forTests();
	}

	/**
	 * Instantiate the datastore.
	 * 
	 * @return datastore bean
	 */
	@Bean
	public IBuildableDatastore apexBuildableDatastore(IDatastoreBuilder datastoreBuilder,
			IDatastoreSchemaDescription schemaDescription,
			IBranchPermissionsManager branchPermissionsManager,
			List<IDatastoreSchemaDescriptionPostProcessor> schemaDescriptionPostProcessor) {
		// TODO: should we make sure ActivePivotDatastorePostProcessor is first?
		for (IDatastoreSchemaDescriptionPostProcessor postProcessor : schemaDescriptionPostProcessor) {
			datastoreBuilder.addSchemaDescriptionPostProcessors(postProcessor);
		}

		IBuildableDatastore b = datastoreBuilder.setSchemaDescription(schemaDescription);

		// b = b.setLogConfiguration(logConfiguration);
		b.setBranchPermissionsManager(branchPermissionsManager);

		return b;
	}

	/**
	 * This {@link Bean} could be overridden to replay an {@link ILogConfiguration} with
	 * buildableDatastore.setReplayConfiguration(new LogConfiguration(someFolder)).build();
	 */
	// IDatastoreConfig requires the bean to be associated to given name. However, we do not want to be identified with
	// "datastore" else Apex may override a custom piece of config
	@Bean(destroyMethod = "stop", name = "datastore")
	public IDatastore apexDatastore(IBuildableDatastore buildableDatastore) throws ReplayException {
		IDatastore datastore = buildableDatastore.build();

		// Register the JMX layer right now not to have to wait before seeing
		// the MBeans
		datastoreJmxEnabler(datastore);

		return datastore;
	}

	@Bean
	public ITransactionManager apexDatastoreTransactionManager(IDatastore datastore) {
		return datastore.getTransactionManager();
	}

	@Bean
	public IMultiVersionDatastoreSchema apexMultiVersionDatastoreSchema(IDatastore datastore) {
		return ((ReadableDatastore) datastore).getSchema();
	}

	/**
	 * ApexQueryCompiler provides in a MBean the latest slow datastore queries
	 */
	@Bean
	public IQueryVisitor<ICompiledQuery> apexQueryCompiler(ITransactionManager transactionManager) {
		if (transactionManager instanceof ApexTransactionManager) {
			// Typically a ApexDatastoreBuilder.makeQueryCompiler(IQueryPlanner, IDatastoreSchema<?, ?>)
			return ((ApexTransactionManager) transactionManager).getQueryCompiler();
		} else {
			return null;
		}
	}

	@Bean
	public IHeapIsTooHigh heapIsTooHigh() {
		return new HeapIsTooHigh();
	}

	// With IApexNotificationPropagator
	@Bean
	public IApexAddRemoveWhereBatcher apexTransactionWrapper(ITransactionManager transactionManager,
			IHeapIsTooHigh heapIsTooHigh,
			IApexNotificationPropagator apexNotificationPropagator) {
		// Do not call the overloaded apexTransactionWrapper else Spring would initialize it
		ApexAddRemoveWhereBatcher tw = rawApexTransactionWrapper(transactionManager, heapIsTooHigh);

		tw.setApexNotificationPropagator(apexNotificationPropagator);

		return tw;
	}

	// Without IApexNotificationPropagator
	@Bean
	public IApexAddRemoveWhereBatcher apexTransactionWrapper(ITransactionManager transactionManager,
			IHeapIsTooHigh heapIsTooHigh) {
		return rawApexTransactionWrapper(transactionManager, heapIsTooHigh);
	}

	protected ApexAddRemoveWhereBatcher rawApexTransactionWrapper(ITransactionManager transactionManager,
			IHeapIsTooHigh heapIsTooHigh) {
		String name = "ApexTransactionWrapper";

		ApexAddRemoveWhereBatcher tw = new ApexAddRemoveWhereBatcher(name, transactionManager, heapIsTooHigh);

		return tw;
	}

	/**
	 * Also defined in ApexServerMonitoringConfig
	 */
	@Bean
	public JMXEnabler datastoreJmxEnabler(IReadableDatastore datastore) {
		return makeDatastoreJmxEnabler(datastore);
	}

	// Also used in ApexServerMonitoringConfig
	public static JMXEnabler makeDatastoreJmxEnabler(IReadableDatastore datastore) {
		// Keep the default JMX name
		JMXEnabler je = new JMXEnabler(Datastore.class.getSimpleName(), datastore);

		je.setEnableAllStatisticsAtStartup(true);

		return je;
	}
}

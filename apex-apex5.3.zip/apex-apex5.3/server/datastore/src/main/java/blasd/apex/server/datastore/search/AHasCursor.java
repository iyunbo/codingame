/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.datastore.search;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Spliterator;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.qfs.store.query.IDictionaryCursor;
import com.qfs.store.query.impl.MergeCursor;
import com.qfs.store.record.IRecordReader;

import blasd.apex.server.loading.transaction.ApexTuplizerHelper;

/**
 * Default implementatin of HasCursor
 * 
 * @author Benoit Lacelle
 *
 */
public abstract class AHasCursor implements HasCursor {

	protected static final Logger LOGGER = LoggerFactory.getLogger(AHasCursor.class);

	@Override
	public Stream<? extends IRecordReader> stream() {
		// See BufferedReader.lines()
		IDictionaryCursor asCursor = asCursor();

		if (asCursor instanceof MergeCursor) {
			// TODO
			LOGGER.trace("TODO: We could make a splittable iterator");
		}

		AtomicLong index = new AtomicLong(-1L);

		// AbstractSpliterator in Spliterators allows a limited parallelism in batching in an array: it would not work
		// as ActivePivot cursors are stateful
		return StreamSupport.stream(new Spliterator<IRecordReader>() {

			@Override
			public boolean tryAdvance(Consumer<? super IRecordReader> action) {
				if (asCursor.next()) {
					long nextIndex = index.incrementAndGet();

					// Provide the next IRecordReader. We protect it with a SafeRecordReader as, if the cursor is moved
					// forward, this entry will not be readable anymore
					SafeRecordReader safeRecord =
							new SafeRecordReader(() -> nextIndex == index.get(), asCursor.getRecord());
					action.accept(safeRecord);

					return true;
				}
				return false;
			}

			@Override
			public Spliterator<IRecordReader> trySplit() {
				// MergeCursor is stateful: it can not be split as it holds a state in MergeCursor.currentIndex
				return null;
			}

			@Override
			public long estimateSize() {
				return Long.MAX_VALUE;
			}

			@Override
			public int characteristics() {
				// We always iterator in the same order -> Spliterator.ORDERED
				// We never returns null IRecordReader -> Spliterator.NONNULL
				return Spliterator.ORDERED | Spliterator.NONNULL;
			}
		}, false);
	}

	@Override
	public Stream<? extends IRecordReader> parallelStream() {
		// TODO: Is it a proper way to make a parallel stream?
		// Some javac version fails on this with "java.lang.BootstrapMethodError: call site initialization exception"
		// https://bugs.openjdk.java.net/browse/JDK-8175806
		// return asMonoCursor().map(IRecordReader::clone).parallel();
		return stream().map(rr -> rr.clone());

		// not parallel.
		// blasd.apex.server.datastore.vector.TestApexVectorDictionarizer.testVectorSeveralConsecutiveTimes() breaks in
		// the contrary
		// .parallel()
	}

	@Override
	public List<? extends Map<String, Object>> asFullMapInList() {
		// Do not rely on .parallelStream as anyway, .asFullMapInList should be called only on small results
		return stream().map(ApexTuplizerHelper.makeLongLivedConvertor()).collect(Collectors.toList());
	}

	@Override
	public Optional<? extends IRecordReader> asSingleEntry() {
		// TODO: should enforce limit(1)

		return stream().findFirst();
	}
}
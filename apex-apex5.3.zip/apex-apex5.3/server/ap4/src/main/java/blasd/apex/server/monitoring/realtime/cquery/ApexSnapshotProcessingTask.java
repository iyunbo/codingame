/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.monitoring.realtime.cquery;

import gnu.trove.map.TIntLongMap;
import gnu.trove.map.TIntObjectMap;
import gnu.trove.map.TObjectIntMap;
import gnu.trove.map.hash.TIntIntHashMap;
import gnu.trove.map.hash.TIntLongHashMap;
import gnu.trove.map.hash.TIntObjectHashMap;
import gnu.trove.map.hash.TObjectIntHashMap;
import gnu.trove.procedure.TIntProcedure;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

import jsr166e.ForkJoinTask;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import blasd.apex.server.monitoring.query.IApexUserTowerControl;
import blasd.apex.shared.monitoring.metrics.AutoCloseableTaskStartEvent;
import blasd.apex.shared.monitoring.metrics.TaskStartEvent;

import com.google.common.annotations.Beta;
import com.google.common.eventbus.EventBus;
import com.quartetfs.biz.pivot.IActivePivotSession;
import com.quartetfs.biz.pivot.ILocation;
import com.quartetfs.biz.pivot.cellset.ICellSet;
import com.quartetfs.biz.pivot.cellset.IScopedCellSet;
import com.quartetfs.biz.pivot.context.IQueriesTimeLimit;
import com.quartetfs.biz.pivot.context.UserContextRestrictionException;
import com.quartetfs.biz.pivot.context.impl.ContextualCancellableRecursiveAction;
import com.quartetfs.biz.pivot.context.impl.ContextualCancellableRecursiveBoundedAction;
import com.quartetfs.biz.pivot.context.impl.ContextualCancellableRecursiveTask;
import com.quartetfs.biz.pivot.cube.hierarchy.IDimension;
import com.quartetfs.biz.pivot.distribution.IActivePivotRemoteTransactionInfo;
import com.quartetfs.biz.pivot.impl.LocationSet;
import com.quartetfs.biz.pivot.query.IQueryCache;
import com.quartetfs.biz.pivot.query.aggregates.IAggregatesContinuousHandler;
import com.quartetfs.biz.pivot.query.aggregates.IAggregatesContinuousQuery;
import com.quartetfs.biz.pivot.query.aggregates.IAggregatesContinuousQueryEngine;
import com.quartetfs.biz.pivot.query.aggregates.IImpact;
import com.quartetfs.biz.pivot.query.aggregates.RetrievalException;
import com.quartetfs.biz.pivot.query.aggregates.impl.AAggregatesContinuousQueryEngineSpy;
import com.quartetfs.biz.pivot.query.aggregates.impl.AggregatesContinuousQueryEngine;
import com.quartetfs.biz.pivot.query.aggregates.impl.AggregatesContinuousQueryEngine.ContinuousAggregatesRetriever;
import com.quartetfs.biz.pivot.query.aggregates.impl.AggregatesEntry;
import com.quartetfs.biz.pivot.query.aggregates.impl.ContextNode;
import com.quartetfs.biz.pivot.query.aggregates.impl.ContextNodeStatistics;
import com.quartetfs.biz.pivot.query.aggregates.impl.NegativeCellSet;
import com.quartetfs.biz.pivot.query.aggregates.impl.NotificationTaskCreator;
import com.quartetfs.biz.pivot.query.impl.ImpactComputationTaskSpy;
import com.quartetfs.biz.pivot.query.impl.StreamEventProcessingQuery.ImpactComputationTask;
import com.quartetfs.biz.pivot.streaming.IMdxStream;
import com.quartetfs.fwk.QuartetRuntimeException;
import com.quartetfs.fwk.Registry;
import com.quartetfs.tech.bitmap.IBitmap;
import com.quartetfs.tech.bitmap.IMatchProcedure;

/**
 * Provides a huge amount of statistics on a per stream basis
 * 
 * @author Benoit Lacelle
 * 
 * @see ApexSnapshotProcessingTask
 * 
 */
@Beta
public class ApexSnapshotProcessingTask<EventType> extends
		ContextualCancellableRecursiveTask<Collection<NotificationTaskCreator<EventType>>> {
	private static final long serialVersionUID = -632029248796212259L;

	public static final int DEFAULT_QUERY_TIMEOUT_SECONDS = 30;

	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexSnapshotProcessingTask.class);

	protected final IActivePivotSession session;
	protected final ContextNode<EventType>.Snapshot snapshot;
	protected final EventType event;
	protected int queriesTimeLimit;

	protected final EventBus eventBus;
	protected final IApexUserTowerControl utc;

	protected ApexSnapshotProcessingTask(IActivePivotSession session, ContextNode<EventType>.Snapshot snapshot,
			EventType event, EventBus eventBus, IApexUserTowerControl utc) {
		super(session.getPivot().getContext(), snapshot.getContext());
		this.session = session;
		this.snapshot = snapshot;
		this.event = event;

		this.eventBus = eventBus;
		this.utc = utc;
	}

	@Override
	protected void pushExecutionContext() {
		super.pushExecutionContext();
		final IQueriesTimeLimit qtl = this.contextToSet.getShared(IQueriesTimeLimit.class);
		if (qtl == null) {
			this.queriesTimeLimit = DEFAULT_QUERY_TIMEOUT_SECONDS;
		} else {
			this.queriesTimeLimit = qtl.getTimeLimitInSeconds();
		}
		this.contextToSet.restrictToLocalAccess();
		this.contextToSet.set(IQueryCache.class, Registry.create(IQueryCache.class));
	}

	@Override
	protected Collection<NotificationTaskCreator<EventType>> compute() {
		final ContextNodeStatistics statistics = this.snapshot.getStatistics();
		final AtomicInteger nbOfImpactComputations = new AtomicInteger();
		statistics.beginEvent();
		final AggregatesContinuousQueryEngine.ContinuousAggregatesRetriever retriever =
				new AggregatesContinuousQueryEngine.ContinuousAggregatesRetriever(this.session,
						this.snapshot.getContext());
		final TIntObjectMap<IImpact> entry2Impact = new TIntObjectHashMap<>();

		final TIntLongMap entry2PrepareImpactTime = new TIntLongHashMap();
		try {
			for (final Entry<IAggregatesContinuousHandler<EventType>, TIntIntHashMap> handlerEntry : this.snapshot.getHandlersIndexation()
					.entrySet()) {
				final IAggregatesContinuousHandler<EventType> handler = handlerEntry.getKey();
				final TIntIntHashMap handlerEntries = handlerEntry.getValue();
				final TObjectIntMap<ILocation> locations = new TObjectIntHashMap<>();
				handlerEntries.forEachKey(new TIntProcedure() {
					@Override
					public boolean execute(int row) {
						locations.put(snapshot.getEntry(row).getLocation(), row);
						return true;
					}
				});
				final Map<ILocation, IImpact> impacts;
				try (AutoCloseableTaskStartEvent startEvent =
						TaskStartEvent.post(eventBus, session.getPivot().getId(), "PrepareImpact")) {
					impacts = computeImpacts(locations, handler, entry2PrepareImpactTime);
				}
				nbOfImpactComputations.addAndGet(impacts.size());
				try (AutoCloseableTaskStartEvent startEvent =
						TaskStartEvent.post(eventBus, session.getPivot().getId(), "PrefetchImpact")) {
					prefetchImpact(handlerEntries, impacts, retriever, entry2Impact);
				}
			}
			final IScopedCellSet executionResults;
			long startExecuteAll = System.currentTimeMillis();
			try (AutoCloseableTaskStartEvent startEvent =
					TaskStartEvent.post(eventBus, session.getPivot().getId(), "ExecuteImpact")) {
				executionResults = retriever.executeAll();
			} catch (RetrievalException re) {
				final Throwable cause = re.getCause();
				if (cause != null && cause instanceof UserContextRestrictionException) {
					throw new QuartetRuntimeException("An illegal access to a context value has been intercepted."
							+ " Please check that all your post-processors correctly expose their context dependencies.",
							cause);
				} else {
					throw new QuartetRuntimeException("An underlying query failed during continuous query refresh.", re);
				}
			}
			Collection<NotificationTaskCreator<EventType>> results;

			try (AutoCloseableTaskStartEvent startEvent =
					TaskStartEvent.post(eventBus, session.getPivot().getId(), "PrepareNotificationTaskCreator")) {
				results =
						prepareNotificationTaskCreator(executionResults,
								entry2Impact,
								entry2PrepareImpactTime,
								System.currentTimeMillis() - startExecuteAll);
			}

			return results;
		} finally {
			statistics.setNbOfImpacts(retriever.countRetrievals());
			statistics.setNbOfImpactComputations(nbOfImpactComputations.get());
			statistics.setNbOfEntriesProcessed(entry2Impact.size());
			statistics.endEvent();
		}
	}

	protected Map<ILocation, IImpact> computeImpacts(final TObjectIntMap<ILocation> locationToHandlerRow,
			IAggregatesContinuousHandler<EventType> handler, final TIntLongMap entry2PrepareImpactTime) {
		ILocation[] locationsArray = locationToHandlerRow.keys(new ILocation[locationToHandlerRow.size()]);
		ImpactComputationTask<EventType> task =
				new ImpactComputationTask<EventType>(queriesTimeLimit,
						snapshot,
						session,
						locationsArray,
						handler,
						event) {
					@Override
					protected IImpact computeImpact(ILocation location) {
						IImpact impact;
						long start = System.currentTimeMillis();
						impact = super.computeImpact(location);

						int row = locationToHandlerRow.get(location);
						entry2PrepareImpactTime.put(row, System.currentTimeMillis() - start);

						return impact;
					}
				};

		new ContextualCancellableRecursiveBoundedAction(session.getPivot().getContext(), task).invoke();
		return ImpactComputationTaskSpy.getResult(task);
	}

	protected void prefetchImpact(TIntIntHashMap handlerEntries, final Map<ILocation, IImpact> impacts,
			final ContinuousAggregatesRetriever retriever, final TIntObjectMap<IImpact> entry2Impact) {
		handlerEntries.forEachKey(new TIntProcedure() {
			@Override
			public boolean execute(final int row) {
				final AggregatesEntry entry = ApexSnapshotProcessingTask.this.snapshot.getEntry(row);
				final ILocation location = entry.getLocation();
				final IImpact impact = impacts.get(location);
				if (impact != ImpactComputationTask.EMPTY_IMPACT) {
					try {
						retriever.prefetch(entry, impact);
					} catch (RetrievalException e) {
						throw new QuartetRuntimeException("Unexpected exception thrown during prefetch phase.",
								(Throwable) e);
					}
				}
				entry2Impact.put(row, impact);
				return true;
			}
		});
	}

	protected Collection<NotificationTaskCreator<EventType>> prepareNotificationTaskCreator(
			final IScopedCellSet executionResults, final TIntObjectMap<IImpact> entry2Impact,
			final TIntLongMap entry2PrepareImpactTime, final long executeAllTimeMs) {
		final Collection<NotificationTaskCreator<EventType>> results = new ConcurrentLinkedQueue<>();
		final List<ForkJoinTask<Void>> cQueryTasks = new ArrayList<>();
		for (final Entry<IAggregatesContinuousQuery, IBitmap> cQueryEntry : this.snapshot.getQueriesIndexation()
				.entrySet()) {
			final IAggregatesContinuousQuery cQuery = cQueryEntry.getKey();
			final IBitmap cQueryEntries = cQueryEntry.getValue();
			if (cQueryEntries == null) {
				continue;
			}
			cQueryTasks.add(new ContextualCancellableRecursiveAction(this.session.getPivot().getContext()) {
				private static final long serialVersionUID = 1L;

				@Override
				protected void compute() {
					final Set<String> accumulatedMeasures = new HashSet<>();
					final Set<ILocation> accumulatedLocations = new LocationSet();
					final Map<String, Set<ILocation>> accumulatedRemovedCandidates =
							new HashMap<String, Set<ILocation>>();

					final AtomicLong totalPrepareImpactTime = new AtomicLong();

					cQueryEntries.forEachBit(new IMatchProcedure() {
						@Override
						public boolean match(final long row) {
							final AggregatesEntry entry = ApexSnapshotProcessingTask.this.snapshot.getEntry((int) row);
							final IImpact impact = entry2Impact.get((int) row);
							if (impact != null && impact != ImpactComputationTask.EMPTY_IMPACT) {
								final String measure = entry.getMeasure();
								accumulatedMeasures.add(measure);
								if (impact.getImpact() != null) {
									accumulatedLocations.addAll(impact.getImpact());
								}
								if (impact.getRemovedPointCandidates() != null) {
									Set<ILocation> candidates = accumulatedRemovedCandidates.get(measure);
									if (candidates == null) {
										candidates = new LocationSet();
										accumulatedRemovedCandidates.put(measure, candidates);
									}
									candidates.addAll(impact.getRemovedPointCandidates());
								}
							}
							totalPrepareImpactTime.addAndGet(entry2PrepareImpactTime.get((int) row));

							return true;
						}
					});
					if (!accumulatedMeasures.isEmpty()
							&& (!accumulatedLocations.isEmpty() || !accumulatedRemovedCandidates.isEmpty())) {
						final ICellSet added;
						final ICellSet removed;
						if (cQuery.isPushEnabled()) {
							if (executionResults == null) {
								added = null;
							} else {
								added = executionResults.getPartialCellSet(accumulatedLocations, accumulatedMeasures);
							}
							List<IDimension> ncsDims = null;
							if (event instanceof IActivePivotRemoteTransactionInfo) {
								final IActivePivotRemoteTransactionInfo transacInf =
										(IActivePivotRemoteTransactionInfo) event;
								final List<IDimension> removals = transacInf.getDimensionsForRemoval();
								if (removals != null) {
									ncsDims = new ArrayList<IDimension>(session.getPivot().getDimensions());
									for (int i = 1; i < ncsDims.size(); ++i) {
										if (removals.get(i) != null) {
											ncsDims.set(i, removals.get(i));
										}
									}
								}
							}
							removed = new NegativeCellSet(accumulatedRemovedCandidates, added);
						} else {
							added = null;
							removed = null;
						}
						results.add(new NotificationTaskCreator<>(session.getPivot(),
								cQuery,
								snapshot.getContext(),
								added,
								removed,
								event));
					}

					monitorImpact(cQuery,
							totalPrepareImpactTime.get(),
							accumulatedLocations,
							accumulatedRemovedCandidates,
							executeAllTimeMs);
				}
			});
		}
		ForkJoinTask.invokeAll(cQueryTasks);

		return results;
	}

	protected void monitorImpact(IAggregatesContinuousQuery cQuery, long prepareImpactTimeMs,
			Set<ILocation> positiveImpacts, Map<String, Set<ILocation>> negativeCandidateImpacts, long executeAllTimeMs) {
		try {
			if (utc != null) {
				IAggregatesContinuousQueryEngine engine = this.session.getAggregatesContinuousQueryEngine();

				if (engine instanceof AggregatesContinuousQueryEngine) {
					Set<? extends IMdxStream> streams =
							AAggregatesContinuousQueryEngineSpy.getStreams((AggregatesContinuousQueryEngine) engine,
									cQuery);

					int totalImpactedLocations = 0;
					totalImpactedLocations += positiveImpacts.size();
					for (Set<ILocation> negativeImpact : negativeCandidateImpacts.values()) {
						totalImpactedLocations += negativeImpact.size();
					}

					for (IMdxStream mdxStream : streams) {
						// TODO: executeAllTimeMs should be splitted a way or
						// another through the different continuous queries
						utc.contributeTimeToStream(mdxStream,
								prepareImpactTimeMs,
								totalImpactedLocations,
								executeAllTimeMs);
					}
				}
			}
		} catch (RuntimeException e) {
			// Do not let monitoring break the application
			LOGGER.warn("Issue when monitoring impact on " + cQuery, e);
		}
	}
}
/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.location;

import gnu.trove.list.TIntList;
import gnu.trove.list.array.TIntArrayList;
import gnu.trove.map.TObjectIntMap;
import gnu.trove.map.hash.TObjectIntHashMap;
import gnu.trove.set.TIntSet;
import gnu.trove.set.hash.TIntHashSet;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.quartetfs.biz.pivot.IActivePivot;
import com.quartetfs.biz.pivot.ILocation;
import com.quartetfs.biz.pivot.context.subcube.ISubCubeProperties;
import com.quartetfs.biz.pivot.cube.hierarchy.IDimension;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevel;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevel.ClassificationType;
import com.quartetfs.biz.pivot.impl.LocationUtil;
import com.quartetfs.biz.pivot.impl.ModifiedLocation;
import com.quartetfs.biz.pivot.query.impl.QueryHelper;

/**
 * 
 * @author Benoit Lacelle
 * 
 */
public class ApexLocationHelper {
	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexLocationHelper.class);

	protected ApexLocationHelper() {
		// hidden
	}

	public static final int MAX_LOCATION_COUNT = 1000;

	/**
	 * @return the level depth along this {@link IDimension}. It is equal to the {@link ILevel} ordinal +1 (AllMember is
	 *         ordinal 0 and length 1)
	 */
	public static int getLevelDepth(ILocation location, IDimension hierarchy) {
		// The index is the ordinal minus 1 as we need to skip the measure
		// hierarchy
		return location.getLevelDepth(hierarchy.getOrdinal() - 1);
	}

	/**
	 * 
	 * @param location
	 * @param level
	 * @return true if the {@link ILocation} has a coordinate expressed for
	 */
	public static boolean checkCoordinate(ILocation location, ILevel level) {
		return getLevelDepth(location, level.getDimension()) > level.getOrdinal();
	}

	public static boolean checkCoordinate(ILocation rangeLocation, IDimension hierarchy) {
		if (isSlicingHierarchy(hierarchy)) {
			// This is a slicing dimension: check we have a coordinate on the
			// first level
			return getLevelDepth(rangeLocation, hierarchy) > 0;
		} else {
			// This is an AllMember dimension: check we express at least the
			// second level
			return getLevelDepth(rangeLocation, hierarchy) >= 2;
		}
	}

	/**
	 * 
	 * @param location
	 * @param level
	 * @return 0 if this level is the deepest expressed, +n if n levels are expressed under this level, -n if the
	 *         deepest expressed coordinate is n level above this level
	 */
	public static int checkDeepEnough(ILocation location, ILevel level) {
		// Adjust with -1 as the ordinal 0 leads to a depth of 1
		return getLevelDepth(location, level.getDimension()) - level.getOrdinal() - 1;
	}

	/**
	 * 
	 * @param location
	 * @param necessarylevels
	 * @return the {@link List} of not expressed {@link ILevel}
	 */

	public static List<ILevel> checkCoordinates(ILocation location, List<ILevel> necessarylevels) {
		List<ILevel> missingLevels = new ArrayList<ILevel>();

		for (ILevel necessarylevel : necessarylevels) {
			// Check is the level is expressed
			if (!checkCoordinate(location, necessarylevel)) {
				missingLevels.add(necessarylevel);
			}
		}

		return missingLevels;
	}

	/**
	 * 
	 * @param location
	 * @param level
	 * @return null if the {@link ILevel} is null, else the coordinate of given {@link ILevel} on given
	 *         {@link ILocation}
	 */
	public static Object getCoordinate(ILocation location, ILevel level) {
		if (level == null) {
			return null;
		} else {
			return location.getCoordinate(level.getDimension().getOrdinal() - 1, level.getOrdinal());
		}
	}

	/**
	 * 
	 * @param location
	 *            the base {@link ILocation}
	 * @param level
	 *            the {@link ILevel} where to set the coordinate
	 * @param coordinate
	 *            the coordinate to set
	 * @param reduceIfDeeper
	 *            if true, if the input {@link ILocation} is deeper than the input ILevel, the output {@link ILocation}
	 *            won't express levels under the input {@link ILevel}
	 * @return
	 * 
	 * @warning beware this may return a range {@link ILocation} from a point {@link ILocation} (e.g. if the level has
	 *          depth 3 and the original location has depth 1 along this level)
	 */
	public static ILocation setCoordinates(ILocation location, ILevel level, Object coordinate, boolean reduceIfDeeper) {
		int hierarchyIndex = level.getDimension().getOrdinal() - 1;

		return new ModifiedLocation(location, hierarchyIndex, prepareNewCoordinates(location,
				level,
				coordinate,
				reduceIfDeeper));
	}

	/**
	 * 
	 * @param location
	 * @param levelToFilteredDrillUp
	 * @param reduceIfDeeper
	 * @return a new {@link ILocation} where the coordinate for given {@link ILevel} has been modified
	 */
	public static ILocation setCoordinates(ILocation location, Map<? extends ILevel, ?> levelToFilteredDrillUp,
			boolean reduceIfDeeper) {
		ILocation newLocation = location;

		int nbLevels = levelToFilteredDrillUp.size();

		if (nbLevels == 0) {
			// Early quit
			return location;
		}

		// We use directly an Object[][] as TIntObject.values() would not
		// produce an actual 2d array
		Object[][] modifiedCoordinates = new Object[nbLevels][];

		TIntList hierarchyIndexes = new TIntArrayList(nbLevels);
		TIntSet hierarchyIndexesSet = new TIntHashSet(nbLevels);

		for (Entry<? extends ILevel, ?> entry : levelToFilteredDrillUp.entrySet()) {
			int hierarchyIndex = entry.getKey().getDimension().getOrdinal() - 1;
			if (hierarchyIndexesSet.add(hierarchyIndex)) {
				hierarchyIndexes.add(hierarchyIndex);
				modifiedCoordinates[hierarchyIndexes.size() - 1] =
						prepareNewCoordinates(newLocation, entry.getKey(), entry.getValue(), reduceIfDeeper);
			} else {
				int previousPosition = hierarchyIndexes.indexOf(hierarchyIndex);

				assert previousPosition >= 0;

				Object[] previousCoordinates = modifiedCoordinates[previousPosition];

				if (previousCoordinates.length <= entry.getKey().getOrdinal()) {
					// Grow the array
					previousCoordinates = Arrays.copyOf(previousCoordinates, entry.getKey().getOrdinal() + 1);

					// Save the new array in place of the previous array
					modifiedCoordinates[previousPosition] = previousCoordinates;
				}

				previousCoordinates[entry.getKey().getOrdinal()] = entry.getValue();
			}
		}

		if (modifiedCoordinates.length > hierarchyIndexes.size()) {
			// Several levels on same hierarchy: we initially allocated too many
			// Object[]
			modifiedCoordinates = Arrays.copyOf(modifiedCoordinates, hierarchyIndexes.size());
		}

		return new ModifiedLocation(location, hierarchyIndexes.toArray(), modifiedCoordinates);
	}

	public static ILocation setCoordinates2(ILocation location, Map<? extends ILevel, ?> levelToFilteredDrillUp,
			boolean reduceIfDeeper) {
		return setCoordinates(location, levelToFilteredDrillUp, reduceIfDeeper);
	}

	public static Object[] prepareNewCoordinates(ILocation location, ILevel level, Object coordinate,
			boolean reduceIfDeeper) {
		Object[] newCoordinates;

		int hierarchyIndex = level.getDimension().getOrdinal() - 1;
		int levelOrdinal = level.getOrdinal();
		if (reduceIfDeeper) {
			// Go down the expressed level
			newCoordinates = new Object[levelOrdinal + 1];
		} else {
			// Go down the expressed level, or even deeper if the base location
			// was deeper
			newCoordinates = new Object[Math.max(location.getLevelDepth(hierarchyIndex), levelOrdinal + 1)];
		}

		for (int i = 0; i < newCoordinates.length; i++) {
			if (i == levelOrdinal) {
				newCoordinates[i] = coordinate;
			} else {
				if (location.getLevelDepth(hierarchyIndex) > i) {
					newCoordinates[i] = location.getCoordinate(hierarchyIndex, i);
				} else {
					// Leave null as this level is not expressed
					newCoordinates[i] = null;
				}
			}
		}

		return newCoordinates;
	}

	/**
	 * Like LocationUtil.expandAll, but taking a List of {@link IDimension} as input
	 * 
	 * @see LocationUtil.expandAll
	 */
	public static Set<ILocation> expandAll(List<? extends IDimension> dimensions, Set<ILocation> locations) {
		return LocationUtil.expandAll(Collections.unmodifiableList(dimensions), locations);
	}

	/**
	 * 
	 * @param originalLocation
	 * @param currencyLevel
	 * @return a new {@link ILocation} where the coordinates for given {@link IDimension} has been either drilledUp to
	 *         given level, or drilledDown by adding null
	 */
	public static ILocation drillUpOrDown(ILocation originalLocation, ILevel currencyLevel) {
		int targetDepth = currencyLevel.getOrdinal() + 1;

		int currentDepth = ApexLocationHelper.getLevelDepth(originalLocation, currencyLevel.getDimension());

		if (targetDepth == currentDepth) {
			return originalLocation;
		}

		int hierarchyOrdinal = currencyLevel.getDimension().getOrdinal();
		Object[] newCoordinates = new Object[targetDepth];

		// Iterate down to either given level or down the deepest available
		// coordinate, leaving null on additional levels
		for (int i = 0; i < Math.min(targetDepth, currentDepth); i++) {
			// -1 to shift for the measure hierarchy
			newCoordinates[i] = originalLocation.getCoordinate(hierarchyOrdinal - 1, i);
		}

		return setPath(originalLocation, currencyLevel.getDimension(), newCoordinates);
	}

	private static final Object[] ALL_MEMBER_PATH = new Object[] { ILevel.ALLMEMBER };

	public static ILocation drillUpAllMember(ILocation originalLocation, IDimension hierarchyInfo) {
		return new ModifiedLocation(originalLocation, hierarchyInfo.getOrdinal() - 1, ALL_MEMBER_PATH);
	}

	/**
	 * 
	 * @param originalLocation
	 * @param hierarchyInfo
	 * @return the coordinates along the given {@link IDimension}, including the optional ALL {@link ILevel}
	 */
	public static Object[] getPath(ILocation originalLocation, IDimension hierarchyInfo) {
		return LocationUtil.copyPath(originalLocation, hierarchyInfo.getOrdinal() - 1);
	}

	/**
	 * 
	 * @param originalLocation
	 * @param hierarchy
	 * @param newCoordinates
	 * @return an {@link ILocation} where the coordinates along the {@link IDimension} has been replaced by the provided
	 *         coordinates
	 */
	public static ILocation setPath(ILocation originalLocation, IDimension hierarchy, Object[] newCoordinates) {
		return new ModifiedLocation(originalLocation, hierarchy.getOrdinal() - 1, newCoordinates);
	}

	/**
	 * 
	 * @param hierarchy
	 * @return true if the first {@link ILevel} of this {@link IDimension} is not {@link ClassificationType}.ALL
	 * 
	 */
	public static boolean isSlicingHierarchy(IDimension hierarchy) {
		return hierarchy.getLevels().get(0).getClassificationType() != ClassificationType.ALL;
	}

	/**
	 * 
	 * @param pivot
	 * @return an {@link ILocation} pointing on AllMember for each ALL {@link ILevel}, and the wildcard if the
	 *         {@link IDimension} is slicing
	 */
	public static final ILocation makeTopLocation(IActivePivot pivotVersion) {
		return new QueryHelper(pivotVersion).computeLocation(Collections.<String, Object> emptyMap());
	}

	public static TObjectIntMap<String> retrieveExpressedLevels(ILocation location, ISubCubeProperties subCube,
			List<? extends IDimension> hierarchies) {

		final TObjectIntMap<String> hierarchyToLevelDepth = new TObjectIntHashMap<>();

		ApexLocationAcceptor.acceptLocation(location, subCube, hierarchies, new IApexCoordinatesVisitor() {

			@Override
			public void visitCoordinate(String hierarchyName, int levelDepth, Object coordinate) {
				// We do not care about the first ILevel (levelDepth == 0) as it
				// is always
				// expressed (some member for slicing hierarchies and
				// AllMember for ALL ILevel)
				if (levelDepth >= 1) {
					// -1 on levelDepth to express levelIndex (i.e. firstLevel
					// has index 0)
					if (hierarchyToLevelDepth.containsKey(hierarchyName)) {
						// The actual depth is the deeper between the
						// ILocation depth and the ISubCubeProperties depth

						// Not -1 as restrictionDepth is already in basis 0
						hierarchyToLevelDepth.put(hierarchyName,
								Math.max(levelDepth, hierarchyToLevelDepth.get(hierarchyName)));
					} else {
						// This level is not expressed in the ILocation
						hierarchyToLevelDepth.put(hierarchyName, levelDepth);
					}
				}
			}
		});

		return hierarchyToLevelDepth;
	}

}

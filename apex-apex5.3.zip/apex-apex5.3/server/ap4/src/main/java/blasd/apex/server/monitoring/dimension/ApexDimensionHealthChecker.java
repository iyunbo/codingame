/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.monitoring.dimension;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NavigableSet;
import java.util.Set;
import java.util.TreeSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import blasd.apex.server.query.hierarchy.ApexHierarchyHelper;
import blasd.apex.shared.comparator.ObjectWithEqualsDefinedByComparator;
import blasd.apex.shared.thread.PepperExecutorsHelper;

import com.google.common.base.Optional;
import com.google.common.base.Predicates;
import com.google.common.collect.Iterables;
import com.google.common.collect.Iterators;
import com.google.common.collect.MultimapBuilder;
import com.google.common.collect.SetMultimap;
import com.quartetfs.biz.pivot.IActivePivot;
import com.quartetfs.biz.pivot.cube.hierarchy.IDimension;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevel;
import com.quartetfs.biz.pivot.cube.hierarchy.axis.IAxisDimension;
import com.quartetfs.biz.pivot.cube.hierarchy.axis.IAxisMember;
import com.quartetfs.fwk.ordering.IComparator;

/**
 * This class will run a set of consistency checks over {@link IDimension}
 * 
 * @author Benoit Lacelle
 * @deprecated it seems not to work: the corruption of the TreeMap is stronger than this check
 */
@Deprecated
public class ApexDimensionHealthChecker {
	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexDimensionHealthChecker.class);

	@Deprecated
	public SetMultimap<String, ILevel> checkHierarchies(Iterable<? extends IActivePivot> pivots) {
		SetMultimap<String, ILevel> pivotIdToDirtyLevels = MultimapBuilder.hashKeys().hashSetValues().build();

		for (IActivePivot pivot : pivots) {
			pivotIdToDirtyLevels.putAll(pivot.getId(), checkHierarchies(pivot));
		}

		return pivotIdToDirtyLevels;
	}

	@Deprecated
	public Set<ILevel> checkHierarchies(IActivePivot pivot) {
		LOGGER.info("Checking the hierarchies of {}", pivot.getId());

		Set<ILevel> dirtyLevels = new HashSet<>();

		for (IDimension hierarchy : pivot.getDimensions()) {
			if (hierarchy instanceof IAxisDimension) {
				Set<ILevel> currentDirtyLevels = checkHierarchy((IAxisDimension) hierarchy);

				dirtyLevels.addAll(currentDirtyLevels);
			}
		}

		return dirtyLevels;
	}

	@Deprecated
	public Set<ILevel> checkHierarchy(IAxisDimension hierarchy) {
		int nbLevels = hierarchy.getLevels().size();

		List<Set<Object>> levelDepthToObjectList = new ArrayList<>();
		for (int i = 0; i < nbLevels; i++) {
			// Not a tree set as we do not want to check the comparator for now
			levelDepthToObjectList.add(new HashSet<>());
		}

		for (IAxisMember member : hierarchy.retrieveMembers(0)) {
			processMembersThenChildren(member, levelDepthToObjectList);
		}

		Set<ILevel> dirtyLevels = new HashSet<>();
		for (int i = 0; i < nbLevels; i++) {
			ILevel levelInfo = hierarchy.getLevels().get(i);
			boolean isDirty = checkLevelMembers(levelDepthToObjectList.get(i), levelInfo);

			if (isDirty) {
				dirtyLevels.add(levelInfo);
			}
		}

		return dirtyLevels;
	}

	protected boolean checkLevelMembers(Set<Object> members, ILevel levelInfo) {
		LOGGER.info("Checking the members of {}", ApexHierarchyHelper.levelName(levelInfo));

		boolean isDirtyLevel = false;

		Map<String, Object> discriminatorStringToDiscriminator = new HashMap<>();
		List<ObjectWithEqualsDefinedByComparator> equalsDefinedByComparator = new ArrayList<>();

		IComparator<Object> levelComparator = levelInfo.getComparator();
		NavigableSet<Object> orderedMembers = new TreeSet<>(levelComparator);
		NavigableSet<Object> reverseOrderedMembers = new TreeSet<>(Collections.reverseOrder(levelComparator));

		for (Object member : members) {
			{
				Object previous = discriminatorStringToDiscriminator.put(member.toString(), member);
				if (previous != null) {
					isDirtyLevel = true;
					LOGGER.error("There is 2 discriminators ({} and {}) with the same .toString: {}",
							member.getClass(),
							previous.getClass(),
							member);
				}
			}

			{
				if (!orderedMembers.add(member)) {
					isDirtyLevel = true;

					Optional<?> previous = Iterables.tryFind(orderedMembers, Predicates.equalTo(member));

					if (previous.isPresent()) {
						LOGGER.error(
								"While the insertion of {} failed, there is one equals ({}) which means this is an inconsistent Comparator: {}",
								member,
								previous.get(),
								levelComparator);
					} else {
						Object lower = orderedMembers.lower(member);
						Object higher = orderedMembers.higher(member);
						LOGGER.error(
								"While the insertion of {} failed, there is no equals. Previous is {} and after is {}. Inconsistent Comparator: {}",
								member,
								lower,
								higher,
								levelComparator);
					}
				}
			}

			{
				if (!reverseOrderedMembers.add(member)) {
					isDirtyLevel = true;

					Optional<?> previous = Iterables.tryFind(reverseOrderedMembers, Predicates.equalTo(member));

					if (previous.isPresent()) {
						LOGGER.error(
								"While the insertion of {} failed, there is one equals ({}) which means this is an inconsistent Comparator: {}",
								member,
								previous.get(),
								levelComparator);
					} else {
						Object lower = reverseOrderedMembers.lower(member);
						Object higher = reverseOrderedMembers.higher(member);
						LOGGER.error(
								"While the insertion of {} failed, there is no equals. Previous is {} and after is {}. Inconsistent Comparator: {}",
								member,
								lower,
								higher,
								levelComparator);
					}
				}
			}

			// As for each member, we compare it with all existing member, this
			// part could get very slow on high cardinality dimensions
			if (equalsDefinedByComparator.size() < PepperExecutorsHelper.DEFAULT_PARTITION_TASK_SIZE) {
				ObjectWithEqualsDefinedByComparator equalityCyComparator =
						new ObjectWithEqualsDefinedByComparator(member, levelComparator);

				// We need to check for all .equality, as if we use a HashSet,
				// the clean hashcode could hide errors in .equals as 2 objects
				// equals by the comparator would have different hashcode
				Optional<?> previous =
						Iterables.tryFind(equalsDefinedByComparator, Predicates.equalTo(equalityCyComparator));

				// Add after having search for inconsistency
				equalsDefinedByComparator.add(equalityCyComparator);

				if (previous.isPresent()) {
					isDirtyLevel = true;

					LOGGER.error(
							"There is 2 discriminators ({} and {}) which are NOT equals but equals given their comparator: {}",
							member,
							previous.get(),
							levelComparator);
				}
			}
		}

		NavigableSet<Object> insertedInReverseOrder = new TreeSet<>(levelInfo.getComparator());
		{
			Iterators.addAll(insertedInReverseOrder, orderedMembers.descendingIterator());
		}

		if (!orderedMembers.equals(members)) {
			isDirtyLevel = true;
			LOGGER.error("The ordering is inconsistent as pushing in order gives a different Set");
		}
		if (!reverseOrderedMembers.equals(members)) {
			isDirtyLevel = true;
			LOGGER.error("The ordering is inconsistent as pushing with reverse-comparator gives a different Set");
		}
		if (!insertedInReverseOrder.equals(members)) {
			isDirtyLevel = true;
			LOGGER.error("The ordering is inconsistent as pushing in reverse-order gives a different Set");
		}

		if (!Iterators.elementsEqual(orderedMembers.iterator(), reverseOrderedMembers.descendingIterator())) {
			isDirtyLevel = true;
			LOGGER.error("The ordering is inconsistent between ordered and descending on reverse-order");
		}

		if (!Iterators.elementsEqual(orderedMembers.iterator(), insertedInReverseOrder.iterator())) {
			isDirtyLevel = true;
			LOGGER.error("The ordering is inconsistent between ordered sets filled in different order");
		}

		return isDirtyLevel;
	}

	protected void processMembersThenChildren(IAxisMember member, List<Set<Object>> levelDepthToObjectList) {
		levelDepthToObjectList.get(member.getDepth()).add(member.getDiscriminator());

		Iterator<? extends IAxisMember> members = member.getChildren().values().iterator();
		while (members.hasNext()) {
			processMembersThenChildren(members.next(), levelDepthToObjectList);
		}
	}
}

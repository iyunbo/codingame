/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.getaggregates;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;

import blasd.apex.server.query.ApexQueryCubeHelper;
import blasd.apex.shared.thread.PepperExecutorsHelper;

import com.google.common.annotations.Beta;
import com.google.common.base.Function;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.common.util.concurrent.MoreExecutors;
import com.quartetfs.biz.pivot.IActivePivot;
import com.quartetfs.biz.pivot.ILocation;
import com.quartetfs.biz.pivot.cellset.ICellSet;
import com.quartetfs.biz.pivot.cellset.impl.CompositeCellSet;

@Beta
public class ApexGetAggregatesQueryExecutor implements IApexGetAggregatesQueryExecutor {

	protected final boolean oneQueryForAllLocations;

	public ApexGetAggregatesQueryExecutor(boolean oneQueryForAllLocations) {
		this.oneQueryForAllLocations = oneQueryForAllLocations;
	}

	@Override
	public ICellSet executeGetAggregatesQuery(IActivePivot pivot, ILocation location, String... measures) {
		return executeGetAggregatesQuery(pivot, Arrays.asList(location), Arrays.asList(measures));
	}

	@Override
	public ICellSet executeGetAggregatesQuery(IActivePivot pivot, ILocation location,
			Iterable<? extends String> measures) {
		return executeGetAggregatesQuery(pivot, Arrays.asList(location), measures);
	}

	@Override
	public ICellSet executeGetAggregatesQuery(IActivePivot pivot, Iterable<? extends ILocation> locations,
			String... measures) {
		return executeGetAggregatesQuery(pivot, locations, Arrays.asList(measures));
	}

	@Override
	public ICellSet executeGetAggregatesQuery(final IActivePivot pivot, Iterable<? extends ILocation> locations,
			final Iterable<? extends String> measures) {
		final Collection<? extends Callable<? extends ICellSet>> tasks = prepareCallables(pivot, locations, measures);

		List<? extends ListenableFuture<ICellSet>> cellSets;
		try {
			cellSets = PepperExecutorsHelper.invokeAll(tasks, MoreExecutors.newDirectExecutorService());
		} catch (InterruptedException e) {
			throw new RuntimeException(e);
		}

		try {
			return new CompositeCellSet(Collections.unmodifiableList(Futures.allAsList(cellSets).get()));
		} catch (InterruptedException | ExecutionException e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public Collection<? extends Callable<ICellSet>> prepareCallables(final IActivePivot pivot,
			final Iterable<? extends ILocation> locations, final Iterable<? extends String> measures) {
		if (oneQueryForAllLocations) {
			// Do all ILocation in a single GetAggregatesQuery
			return Collections.singleton(new Callable<ICellSet>() {

				@Override
				public ICellSet call() throws Exception {
					return ApexQueryCubeHelper.executeGetAggregates(pivot, locations, measures);
				}
			});
		} else {
			// Do one GetAggregatesQuery per ILocation. We might lose sharing,
			// but we enable not to materialize a huge ICellSet
			return Lists.newArrayList(Iterables.transform(locations, new Function<ILocation, Callable<ICellSet>>() {

				@Override
				public Callable<ICellSet> apply(final ILocation input) {
					return new Callable<ICellSet>() {

						@Override
						public ICellSet call() {
							return ApexQueryCubeHelper.executeGetAggregates(pivot, Arrays.asList(input), measures);
						}
					};
				}

			}));
		}
	}

}

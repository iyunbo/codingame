/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.shared.client.query.realtime;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.util.concurrent.AtomicLongMap;
import com.quartetfs.biz.pivot.dto.AggregateDTO;
import com.quartetfs.biz.pivot.dto.CellSetDTO;
import com.quartetfs.biz.pivot.streaming.IAggregatesEvent;
import com.quartetfs.biz.pivot.streaming.ICellEvent;
import com.quartetfs.biz.pivot.streaming.ICellSetEvent;
import com.quartetfs.tech.streaming.IDomainStreamEvent;
import com.quartetfs.tech.streaming.IFailureEvent;
import com.quartetfs.tech.streaming.IStreamEvent;

public class CountQueryEventAP4 {
	protected static final Logger LOGGER = LoggerFactory.getLogger(CountQueryEventAP4.class);

	public boolean consume(Collection<? extends IDomainStreamEvent> eventQueue) {
		Iterator<? extends IDomainStreamEvent> iterator = eventQueue.iterator();

		AtomicLongMap<String> mdxToNbEvents = AtomicLongMap.create();

		boolean isOk = true;

		while (iterator.hasNext()) {
			IDomainStreamEvent next = iterator.next();

			isOk = isOk && consumeDomainEvent(next, mdxToNbEvents);
		}

		return isOk;
	}

	protected boolean consumeDomainEvent(IDomainStreamEvent domainEvent, AtomicLongMap<String> mdxToNbEvents) {
		for (IStreamEvent event : domainEvent.getEvents()) {
			String streamId = event.getStreamId();

			final long viewImpactSize = computeStreamEventSize(event);

			LOGGER.info("Impact Size={} for {}", viewImpactSize, streamId);

			if (event instanceof IFailureEvent) {
				LOGGER.warn("IFailureEvent received for streamId={}: {}", streamId, event);
				return false;
			}
		}

		return true;
	}

	public static long computeStreamEventSize(IStreamEvent event) {
		long viewImpactSize;

		if (event instanceof IFailureEvent) {
			// Return 1 to count also unknown events
			viewImpactSize = 1;
		} else if (event instanceof IAggregatesEvent) {
			List<AggregateDTO> aggregates = ((IAggregatesEvent) event).getAggregates();

			if (aggregates == null) {
				viewImpactSize = 1;
			} else {
				viewImpactSize = aggregates.size();
			}
		} else if (event instanceof ICellEvent) {
			viewImpactSize = ((ICellEvent) event).getCells().size();
		} else if (event instanceof ICellSetEvent) {
			CellSetDTO cellSet = ((ICellSetEvent) event).getCellSet();

			if (cellSet != null && cellSet.getCells() != null) {
				viewImpactSize = ((ICellSetEvent) event).getCellSet().getCells().size();
			} else {
				// cellSet might be null. Is this an empty
				// view?
				viewImpactSize = 1;
			}
		} else {
			// Return 1 to count also unknown events
			viewImpactSize = 1;
			LOGGER.warn("Unexpected EventType={}", event);
		}

		return viewImpactSize;
	}
}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.monitoring;

import java.util.Collection;
import java.util.Collections;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.eventbus.EventBus;
import com.quartetfs.biz.pivot.context.IContextSnapshot;
import com.quartetfs.biz.pivot.cube.hierarchy.measures.IMeasureDimension;
import com.quartetfs.biz.pivot.impl.ActivePivot;
import com.quartetfs.biz.pivot.impl.ActivePivotSession;
import com.quartetfs.biz.pivot.query.IGetAggregatesQuery;
import com.quartetfs.biz.pivot.query.aggregates.IActivePivotAggregatesRetriever;
import com.quartetfs.biz.pivot.query.aggregates.IAggregatesRetrievalExecutor;
import com.quartetfs.biz.pivot.query.aggregates.impl.CachedAggregatesRetrievalExecutor;
import com.quartetfs.biz.pivot.query.aggregates.impl.HistoricalAggregatesRetrievalExecutor;
import com.quartetfs.biz.pivot.query.impl.ActivePivotSyncActionQuery;
import com.quartetfs.biz.pivot.query.impl.ActivePivotSyncUtils.IAction;
import com.quartetfs.biz.xmla.discovery.impl.IPivotDiscoveryHandler;
import com.quartetfs.fwk.QuartetExtendedPluginValue;
import com.quartetfs.fwk.QuartetType;
import com.quartetfs.fwk.query.IQuery;
import com.quartetfs.pivot.mdx.impl.SelectStatementExecutor;
import com.quartetfs.pivot.mdx.impl.SelectStatementExecutorSpy;

/**
 * Enable injection of {@link ApexAggregatesRetrievalExecutor}
 * 
 * @author Benoit Lacelle
 * 
 */
@QuartetType(description = "The active pivot session", interfaceName = "com.quartetfs.biz.pivot.IActivePivotSession")
@QuartetExtendedPluginValue(interfaceName = "blasd.apex.server.query.monitoring.IApexActivePivotSession", key = ApexActivePivotSession.PLUGIN_KEY)
public class ApexActivePivotSession extends ActivePivotSession implements IApexActivePivotSession,
		IApexActivePivotQueryMonitor {
	private static final long serialVersionUID = -944943642633066668L;

	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexActivePivotSession.class);

	public static final String PLUGIN_KEY = "APEX";

	protected EventBus eventBus;

	public void setEventBus(EventBus eventBus) {
		this.eventBus = eventBus;
	}

	public EventBus getEventBus() {
		return eventBus;
	}

	/**
	 * Duplicate createContinousAggregatesRetriever but introduce makeAggregatesRetrievalExecutor
	 */
	@Override
	public IActivePivotAggregatesRetriever createAggregatesRetriever(Collection<String> measures) {
		Collection<String> filteringMeasures;
		if (measures == null || measures.isEmpty()) {
			filteringMeasures = Collections.singleton(IMeasureDimension.COUNT_ID);
		} else {
			filteringMeasures = measures;
		}

		IContextSnapshot contextSnapshot = this.pivot.getContext().computeMeasureFilteredContext(filteringMeasures);

		IAggregatesRetrievalExecutor executor = makeAggregatesRetrievalExecutor(this.pivot, contextSnapshot);

		if (this.pivot.getAggregatesCache() != null) {
			executor = new CachedAggregatesRetrievalExecutor(this.pivot, executor);
		}

		if (this.historicalAggregatesEngine != null) {
			executor = new HistoricalAggregatesRetrievalExecutor(this.pivot, this.historicalAggregatesEngine, executor);
		}

		return createAggregatesRetriever(executor);
	}

	/**
	 * Duplicate createContinousAggregatesRetriever but introduce makeAggregatesRetrievalExecutor
	 */
	@Override
	public IActivePivotAggregatesRetriever createContinousAggregatesRetriever(IContextSnapshot snapshot) {
		IAggregatesRetrievalExecutor executor = makeAggregatesRetrievalExecutor(this.pivot, snapshot);

		if (this.historicalAggregatesEngine != null) {
			executor = new HistoricalAggregatesRetrievalExecutor(this.pivot, this.historicalAggregatesEngine, executor);

		}

		return createAggregatesRetriever(executor);
	}

	protected IAggregatesRetrievalExecutor makeAggregatesRetrievalExecutor(ActivePivot pivot, IContextSnapshot snapshot) {
		return new ApexAggregatesRetrievalExecutor(pivot, snapshot);
	}

	@Override
	public void onQueryDone(IQuery<?> query, long time) {

		if (query instanceof ActivePivotSyncActionQuery<?, ?>) {
			IAction<?, ?> action = ((ActivePivotSyncActionQuery<?, ?>) query).getAction();

			if (action.getClass().isAnonymousClass()) {
				Class<?> enclosingClass = action.getClass().getEnclosingClass();

				if (IPivotDiscoveryHandler.class.isAssignableFrom(enclosingClass)) {
					onDiscoveryQuery(query, time);
				} else {
					onOtherQueryDone(query, time);
				}
			} else if (action.getClass().isMemberClass()) {
				Class<?> enclosingClass = action.getClass().getEnclosingClass();

				if (SelectStatementExecutor.class.isAssignableFrom(enclosingClass)) {
					String mdx = SelectStatementExecutorSpy.getMdx(action);

					if (mdx == null) {
						LOGGER.warn("Missing mdx from {}", action);
					} else {
						onMDXQuery(mdx, time);
					}
				} else {
					onOtherQueryDone(query, time);
				}
			} else {
				onOtherQueryDone(query, time);
			}

			// if (action.getClass())
		} else if (query instanceof IGetAggregatesQuery) {
			onGetAggregatesQuery((IGetAggregatesQuery) query, time);
		} else {
			onOtherQueryDone(query, time);
		}
	}

	protected void onOtherQueryDone(IQuery<?> query, long time) {
		// TODO Auto-generated method stub

	}

	protected void onMDXQuery(String mdx, long time) {
		// TODO Auto-generated method stub

	}

	protected <ResultType> void onDiscoveryQuery(IQuery<ResultType> query, long time) {
		// TODO Auto-generated method stub

	}

	protected void onGetAggregatesQuery(IGetAggregatesQuery query, long time) {
		// TODO Auto-generated method stub

	}

	@Override
	public String getType() {
		return PLUGIN_KEY;
	}
}
/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.hierarchy;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Function;
import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import com.quartetfs.biz.pivot.IActivePivot;
import com.quartetfs.biz.pivot.context.IContext;
import com.quartetfs.biz.pivot.context.IContextValue;
import com.quartetfs.biz.pivot.cube.hierarchy.IAnalysisDimension;
import com.quartetfs.biz.pivot.cube.hierarchy.IDimension;
import com.quartetfs.biz.pivot.cube.hierarchy.IDimension.DimensionType;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevel;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevel.ClassificationType;
import com.quartetfs.biz.pivot.postprocessing.impl.APostProcessor;

/**
 * 
 * @author Benoit Lacelle
 * 
 */
public class ApexHierarchyHelper {
	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexHierarchyHelper.class);

	public static final String ALL = ClassificationType.ALL.toString();

	public static final String LEVEL_SEPARATOR = "@";

	public static final int SIZE_LEVEL_AT_HIER = "l@h".split(LEVEL_SEPARATOR).length;
	public static final int SIZE_LEVEL_ALONE = "l".split(LEVEL_SEPARATOR).length;

	protected ApexHierarchyHelper() {
		// hidden
	}

	/**
	 * 
	 * @param level
	 * @return the default discriminator of an ILevel, expected to be from an {@link IAnalysisHierarchy}
	 */
	public static Object getDefaultDiscriminator(ILevel level) {
		if (level.getDimension() instanceof IAnalysisDimension) {
			if (level.getClassificationType() == ClassificationType.ALL) {
				// The core throws an exception when retrieving default member
				// on ALL: we prefer returning AllMember
				return ILevel.ALLMEMBER;
			} else {
				return ((IAnalysisDimension) level.getDimension()).getDefaultDiscriminator(level.getOrdinal());
			}
		} else {
			throw new RuntimeException("We expect an " + IAnalysisDimension.class + " for " + level);
		}
	}

	/**
	 * 
	 * @param hierarchy
	 * @return true if the input {@link IDimension} is an {@link IAnalysisHierarchy}
	 */
	public static boolean isAnalysisHierarchy(IDimension hierarchyInfo) {
		if (hierarchyInfo instanceof IAnalysisDimension) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Like {@link HierarchiesUtil#extractHierarchies(List)} but returns a generic {@link List}.
	 * 
	 * Beware this method will request for {@link IAsOfEpoch} {@link IContextValue}, which may fail for {@link IContext}
	 * restriction reasons.
	 */
	public static List<? extends IDimension> extractAxisHierarchiesInfo(IActivePivot pivot) {
		return filterAxisHierarchiesInfo(pivot.getDimensions());
	}

	public static List<? extends IDimension> filterAxisHierarchiesInfo(List<? extends IDimension> hierarchies) {
		if (hierarchies.get(0).getDimensionType() == DimensionType.MEASURE) {
			hierarchies = hierarchies.subList(1, hierarchies.size());
		}

		return hierarchies;
	}

	/**
	 * We can not use {@link IDimension} as it does not hold a reference to the {@link ILevel}
	 * 
	 * @param hierarchy
	 * @return
	 */
	public static boolean isAllMembersEnabled(IDimension hierarchy) {
		return hierarchy.getLevels().get(0).getClassificationType() == ClassificationType.ALL;
	}

	public static boolean isSlicing(IDimension hierarchy) {
		return !isAllMembersEnabled(hierarchy);
	}

	public static boolean isSlicing(IActivePivot pivot, IDimension expressedHierarchy) {
		return isSlicing(expressedHierarchy);
	}

	/**
	 * 
	 * @param findHierarchy
	 * @param depth
	 *            the depth of the targeted {@link ILevel}
	 * @return the {@link String} identifying the {@link ILevel} with a format like levelName@hierarchyName@dimensionName
	 */
	public static String levelName(IDimension hierarchy, int levelDepth) {
		return levelName(hierarchy.getLevels().get(levelDepth));
	}

	public static String levelName(IActivePivot pivot, IDimension hierarchy, int levelDepth) {
		return levelName(pivot.getDimensions().get(hierarchy.getOrdinal()), levelDepth);
	}

	public static String levelName(ILevel levelInfo) {
		return levelName(levelInfo.getDimension().getName(), levelInfo.getName());
	}

	public static String levelName(String hierarchyName, String levelName) {
		return Joiner.on(LEVEL_SEPARATOR).join(levelName, hierarchyName);
	}

	/**
	 * 
	 * @param pivot
	 * @param dimensionName
	 * @return the {@link IDimension} with with provided name, or null if it can't be found
	 */

	public static IDimension findDimension(IActivePivot pivot, String dimensionName) {
		for (IDimension d : pivot.getDimensions()) {
			if (d.getName().equals(dimensionName)) {
				return d;
			}
		}

		List<String> dimensionNames = Lists.transform(pivot.getDimensions(), new Function<IDimension, String>() {

			@Override
			public String apply(IDimension input) {
				return input.getName();
			}
		});

		throw new RuntimeException("There is no dimension named: " + dimensionName + ". Dimensions: " + dimensionNames);
	}

	public static IDimension findHierarchy(IActivePivot pivot, String dimensionName, String hierarchyName) {
		List<? extends IDimension> hierarchies = findHierarchies(pivot, dimensionName);

		for (IDimension h : hierarchies) {
			if (h.getName().equals(hierarchyName)) {
				return h;
			}
		}

		// Try to find from its ordinal
		if (dimensionName == null) {
			try {
				int asInt = Integer.parseInt(hierarchyName);

				if (asInt <= hierarchies.size()) {
					return hierarchies.get(asInt);
				}
			} catch (NumberFormatException e) {
				// Not an ordinal
				LOGGER.trace("{} is not an ordinal", hierarchyName);
			}
		}

		List<String> hierarchyNames = Lists.transform(hierarchies, new Function<IDimension, String>() {

			@Override
			public String apply(IDimension input) {
				return input.getName();
			}
		});

		Set<String> orderedHierarchyNames = new TreeSet<>(hierarchyNames);

		throw new RuntimeException("There is no hierarchy named: " + hierarchyName + ". Hierarchies: "
				+ orderedHierarchyNames);
	}

	/**
	 * 
	 * @param pivot
	 * @param dimensionName
	 *            null if we should return all IDimension
	 * @return a List of IDimension, matching the dimensionName if provided
	 */
	public static List<? extends IDimension> findHierarchies(IActivePivot pivot, String dimensionName) {
		if (dimensionName == null) {
			return pivot.getDimensions();
		} else {
			return Arrays.asList(findDimension(pivot, dimensionName));
		}
	}

	public static IDimension findHierarchy(IActivePivot pivot, String hierarchyNameAtDimensionName) {
		return findDimension(pivot, hierarchyNameAtDimensionName);
	}

	/**
	 * 
	 * @param pivot
	 *            an IActivePivot object
	 * @param dimensionName
	 * @param hierarchyName
	 * @param levelName
	 * @return an {@link ILevel}
	 */
	public static ILevel findLevel(IActivePivot pivot, String dimensionName, String levelName) {
		IDimension hierarchy = findHierarchy(pivot, dimensionName);

		if (hierarchy == null) {
			return null;
		} else {
			ILevel l = findLevelNoFail(hierarchy, levelName);

			if (l == null) {
				throw failLevelInHierarchy(hierarchy, levelName);
			} else {
				return l;
			}
		}
	}

	protected static RuntimeException failLevelInHierarchy(IDimension hierarchy, String levelName) {
		String hierarchyName;
		if (hierarchy == null) {
			hierarchyName = "(All hierarchies)";
		} else {
			hierarchyName = hierarchy.getName();
		}

		throw new RuntimeException("In hierarchy " + hierarchyName + ", there is no level named: " + levelName);
	}

	protected static ILevel findLevelNoFail(IDimension hierarchy, String levelName) {
		for (ILevel l : hierarchy.getLevels()) {
			if (l.getName().equals(levelName)) {
				return l;
			}
		}

		return null;
	}

	/**
	 * 
	 * @param pivot
	 * @param levelNameAtHierarchyNameAtDimensionName
	 * @return the {@link ILevel} given an expression like 'levelName@dimensionName' or
	 *         'levelName@hierarchyName@dimensionName'
	 */
	public static ILevel findLevel(IActivePivot pivot, String levelNameAtHierarchyNameAtDimensionName) {
		if (levelNameAtHierarchyNameAtDimensionName == null || levelNameAtHierarchyNameAtDimensionName.isEmpty()) {
			throw new RuntimeException("Argument is empty. It should be like 'levelName@dimensionName' or 'levelName@hierarchyName@dimensionName'");
		}

		// Limiting to 3 @ enables having @ in the dimension name
		String[] splitted = levelNameAtHierarchyNameAtDimensionName.split("@", SIZE_LEVEL_AT_HIER);

		if (splitted.length > 0 && splitted[splitted.length - 1].isEmpty()) {
			// The last element ends by @ (e.g. 'Country @'): we need to remove
			// the empty levelName as @ as actually in the dimension name
			splitted = Arrays.copyOf(splitted, splitted.length - 1);
			splitted[splitted.length - 1] = splitted[splitted.length - 1] + "@";
		}

		String dimensionName;
		String levelName;
		if (splitted.length == SIZE_LEVEL_ALONE) {
			levelName = splitted[0];
			dimensionName = null;
		} else if (splitted.length == SIZE_LEVEL_AT_HIER) {
			levelName = splitted[0];
			dimensionName = splitted[1];
		} else {
			throw new RuntimeException(levelNameAtHierarchyNameAtDimensionName
					+ " should be like 'levelName@hierarchyName'");
		}

		return findLevel(pivot, dimensionName, levelName);
	}

	public static List<ILevel> findLevels(IActivePivot pivot, String levelNameAtHierarchyNameAtDimensionNameComa) {
		if (levelNameAtHierarchyNameAtDimensionNameComa == null
				|| levelNameAtHierarchyNameAtDimensionNameComa.isEmpty()) {
			throw new RuntimeException("Argument is empty. It should be like 'levelName1@dimensionName1,levelName2@dimensionName2' or"
					+ "'levelName1@hierarchyName1@dimensionName1,levelName2@hierarchyName2@dimensionName2'");
		}

		String[] splitted = levelNameAtHierarchyNameAtDimensionNameComa.split(APostProcessor.SEPARATOR);

		List<ILevel> found = new ArrayList<>();

		for (String oneLevelDes : splitted) {
			found.add(findLevel(pivot, oneLevelDes));
		}

		return found;
	}
}

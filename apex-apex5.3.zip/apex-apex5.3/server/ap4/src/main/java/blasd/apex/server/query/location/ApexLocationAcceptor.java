/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.location;

import java.util.Collections;
import java.util.List;
import java.util.Set;

import com.quartetfs.biz.pivot.ILocation;
import com.quartetfs.biz.pivot.context.IContextValue;
import com.quartetfs.biz.pivot.context.subcube.ISubCubeProperties;
import com.quartetfs.biz.pivot.cube.hierarchy.IDimension;
import com.quartetfs.biz.pivot.cube.hierarchy.IDimension.DimensionType;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevel;

/**
 * This helper enables iterating only on the relevant {@link IHierarchy} expressed in an {@link ILocation}. An
 * {@link IHierarchy} is not relevant if the only expressed coordinates is AllMember
 * 
 * @author Benoit Lacelle
 * 
 */
public class ApexLocationAcceptor {
	protected ApexLocationAcceptor() {
		// hidden
	}

	/**
	 * 
	 * @param location
	 *            the ILocation to be visited
	 * @param locationVisitor
	 *            the {@link IApexLocationVisitor} to call on each relevant {@link IHierarchy}
	 */
	public static void acceptLocation(ILocation location, IApexLocationVisitor locationVisitor) {
		int hierarchyCount = location.getDimensionCount();

		for (int hIndex = 0; hIndex < hierarchyCount; ++hIndex) {
			if (location.getLevelDepth(hIndex) == 1 && ILevel.ALLMEMBER.equals(location.getCoordinate(hIndex, 0))) {
				// We express a single ILevel and the only coordinates is
				// AllMember: this IHierarchy is not useful
				continue;
			} else {
				// We are not on AllMember: either it is not expressed, or it is
				// a slicing hierarchy, or anything else which is interesting
				locationVisitor.visit(location, hIndex);
			}
		}
	}

	public static void acceptLocation(ILocation location, ISubCubeProperties subCube,
			List<? extends IDimension> hierarchies, IApexCoordinatesVisitor apexCoordinatesVisitor) {
		acceptLocation(location, Collections.singletonList(subCube), hierarchies, apexCoordinatesVisitor);
	}

	public static void acceptLocation(ILocation location, Iterable<? extends IContextValue> contextValues,
			final List<? extends IDimension> hierarchies, final IApexCoordinatesVisitor apexCoordinatesVisitor) {
		final int hierarchyShift;

		if (hierarchies == null) {
			hierarchyShift = Integer.MIN_VALUE;
		} else {
			if (hierarchies.get(0).getDimensionType() == DimensionType.MEASURE) {
				hierarchyShift = 1;
			} else {
				hierarchyShift = 0;
			}
		}

		acceptLocation(location, new IApexLocationVisitor() {

			@Override
			public void visit(ILocation location, int hierarchyIndex) {

				String hierarchyName;
				if (hierarchies == null) {
					hierarchyName = Integer.toString(hierarchyIndex);
				} else {
					IDimension d = hierarchies.get(hierarchyIndex + hierarchyShift);
					hierarchyName = d.getName();
				}

				for (int levelDepth = 0; levelDepth < location.getLevelDepth(hierarchyIndex); levelDepth++) {
					Object coordinate = location.getCoordinate(hierarchyIndex, levelDepth);

					// d is generally an ISubCubeDimension. Then .getLevels()
					// could be a bit slow. So we restrict ourselves to the
					// level depth and not
					// the level name
					// Moreover, we often do not have access neither to the
					// IDimension object, nor to the ILevel list
					apexCoordinatesVisitor.visitCoordinate(hierarchyName, levelDepth, coordinate);
				}
			}
		});

		if (contextValues != null) {
			for (IContextValue contextValue : contextValues) {
				if (contextValue instanceof ISubCubeProperties) {
					ISubCubeProperties subCube = (ISubCubeProperties) contextValue;

					for (String restrictedDimension : subCube.getRestrictedDimensions()) {
						Set<List<?>> restrictedMembers = subCube.getGrantedMembers(restrictedDimension);

						for (List<?> restrictedPath : restrictedMembers) {
							for (int levelDepth = 0; levelDepth < restrictedPath.size(); levelDepth++) {
								Object coordinate = restrictedPath.get(levelDepth);

								apexCoordinatesVisitor.visitCoordinate(restrictedDimension, levelDepth, coordinate);
							}
						}
					}
				}
			}
		}
	}
}

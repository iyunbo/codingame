/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.monitoring;

import java.util.Collections;
import java.util.Map;
import java.util.concurrent.locks.ReadWriteLock;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import blasd.apex.shared.monitoring.metrics.AutoCloseableTaskStartEvent;
import blasd.apex.shared.monitoring.metrics.EndMetricEvent;
import blasd.apex.shared.monitoring.metrics.TaskStartEvent;

import com.google.common.collect.ImmutableMap;
import com.google.common.eventbus.EventBus;
import com.quartetfs.biz.pivot.IActivePivotSession;
import com.quartetfs.biz.pivot.IProjection;
import com.quartetfs.biz.pivot.definitions.IActivePivotDescription;
import com.quartetfs.biz.pivot.impl.ActivePivot;
import com.quartetfs.biz.pivot.impl.ActivePivotSession;
import com.quartetfs.fwk.QuartetType;
import com.quartetfs.fwk.Registry;
import com.quartetfs.fwk.cache.ICache;
import com.quartetfs.fwk.query.IQuery;
import com.quartetfs.fwk.query.QueryException;
import com.quartetfs.fwk.security.ISecurityDetails;
import com.quartetfs.fwk.security.ISecurityFacade;
import com.quartetfs.tech.column.IColumnManager;
import com.quartetfs.tech.indexer.IField;
import com.quartetfs.tech.indexer.IIndexer;
import com.quartetfs.tech.publisher.IPublisherManager;

/**
 * Intercept query execution for monitoring purposes
 * 
 * @author Benoit Lacelle
 * 
 */
@QuartetType(interfaceName = "com.quartetfs.biz.pivot.IActivePivot", description = "ActivePivot implementation, the Quartet real time object based Olap engine")
public class ApexActivePivot extends ActivePivot {
	private static final long serialVersionUID = -4199724786135064667L;

	public static final long QUERY_TIME_MS_SWITCH_INFO = 100;

	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexActivePivot.class);

	// Too many parameters for Checkstyle
	// CHECKSTYLE:OFF
	public ApexActivePivot(String id, IActivePivotDescription description, Map<String, IField> fieldMap,
			IPublisherManager publisherManager, ICache cache, IIndexer<IProjection> indexer,
			ReadWriteLock readWriteLock, IColumnManager columnManager) {
		super(id, description, fieldMap, publisherManager, cache, indexer, readWriteLock, columnManager);
	}

	// CHECKSTYLE:ON

	public ApexActivePivot(String id, IActivePivotDescription description, Map<String, IField> fieldMap) {
		super(id, description, fieldMap);
	}

	public ApexActivePivot(String id, IActivePivotDescription description) {
		super(id, description);
	}

	@Override
	protected ActivePivotSession createSession() {
		return (ActivePivotSession) Registry.getExtendedPlugin(IApexActivePivotSession.class)
				.valueOf(ApexActivePivotSession.PLUGIN_KEY)
				.create();
	}

	protected String getUserName() {
		return getSpringUserName();
	}

	public static String getSpringUserName() {
		ISecurityFacade securityFacade = Registry.create(ISecurityFacade.class);
		ISecurityDetails securityDetails = securityFacade.snapshotSecurityDetails();

		if (securityDetails != null) {
			return securityDetails.getUserName();
		} else {
			return null;
		}
	}

	@Override
	public <ResultType> ResultType execute(IQuery<ResultType> query) throws QueryException {
		IActivePivotSession session = getSession();

		EventBus eventBus = ((ApexActivePivotSession) session).getEventBus();
		AutoCloseableTaskStartEvent startEvent;
		if (session instanceof ApexActivePivotSession) {
			final Map<String, ?> details;

			String userName = getUserName();
			if (userName == null) {
				details = Collections.emptyMap();
			} else {
				details = ImmutableMap.of(TaskStartEvent.KEY_USERNAME, userName);
			}

			startEvent = TaskStartEvent.post(eventBus, query, details, getId());
		} else {
			startEvent = null;
		}

		try {
			return super.execute(query);
		} finally {
			EndMetricEvent endEvent = EndMetricEvent.post(eventBus, startEvent);

			onQueryDone(getSession(), query, endEvent.durationInMs());
		}
	}

	protected <ResultType> void onQueryDone(IActivePivotSession session, IQuery<ResultType> query, long time) {
		if (session instanceof IApexActivePivotQueryMonitor) {
			((IApexActivePivotQueryMonitor) session).onQueryDone(query, time);
		} else {
			if (time >= QUERY_TIME_MS_SWITCH_INFO) {
				LOGGER.info("Query lasted {}ms: {}", query, time);
			} else {
				LOGGER.debug("Query lasted {}ms: {}", query, time);
			}
		}
	}
}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.location;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import blasd.apex.server.query.hierarchy.ApexHierarchyHelper;
import blasd.apex.server.query.location.ApexLocationHelper;

import com.quartetfs.biz.pivot.IActivePivot;
import com.quartetfs.biz.pivot.ILocation;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevel;
import com.quartetfs.biz.pivot.query.impl.QueryHelper;

public class ApexLocationBuilder implements IApexLocationBuilder {
	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexLocationBuilder.class);

	protected final IActivePivot pivotVersion;

	protected final Map<ILevel, Object> levelToValueToSet = new HashMap<>();

	/**
	 * By default, we keep wildcards on slicing hierarchies to see all top {@link ILocation}
	 */
	protected boolean defaultValuesOnNotExpressedSlicingHierarchies;

	protected ILocation baseLocation;

	/**
	 * 
	 * @param pivotVersion
	 *            we need an actual version for default member resolution
	 */
	public ApexLocationBuilder(IActivePivot pivotVersion) {
		this.pivotVersion = pivotVersion;
	}

	public static IApexLocationBuilder on(IActivePivot pivot) {
		return new ApexLocationBuilder(pivot);
	}

	@Override
	public IApexLocationBuilder filter(Map<String, ?> levelNamesToValues) {
		for (Entry<String, ?> entry : levelNamesToValues.entrySet()) {
			filter(entry.getKey(), entry.getValue());
		}

		return this;
	}

	/**
	 * Beware using only actual value could lead to range locations. For instance, if you set only the third level of a
	 * dimension, the second level will be left with a wildacard while originally the location was on AllMember
	 */
	@Override
	public IApexLocationBuilder filter(String levelAsString, Object value) {
		ILevel level = ApexHierarchyHelper.findLevel(pivotVersion, levelAsString);

		filter(level, value);

		return this;
	}

	@Override
	public IApexLocationBuilder wildcard(Iterable<? extends ILevel> wildcardLevels) {
		for (ILevel wildcardLevel : wildcardLevels) {
			filter(wildcardLevel, null);
		}

		return this;
	}

	@Override
	public IApexLocationBuilder wildcard(Collection<? extends String> wildcardLevels) {
		for (String wildcardLevel : wildcardLevels) {
			filter(wildcardLevel, null);
		}

		return this;
	}

	@Override
	public IApexLocationBuilder filter(ILevel level, Object value) {
		if (levelToValueToSet.containsKey(level)) {
			Object previousValue = levelToValueToSet.get(level);

			if (previousValue == null) {
				// Keep the new condition which is more restricted
				levelToValueToSet.put(level, value);
			} else if (value == null) {
				LOGGER.trace("Keep the old value");
			} else if (!Objects.equals(previousValue, value)) {
				throw new IllegalArgumentException(
						"The level " + level + " is already set to " + previousValue + ", can not set to " + value);
			} else {
				// TODO: should we throw an IllegalArgumentException?
				assert previousValue.equals(value);
			}
		} else {
			levelToValueToSet.put(level, value);
		}

		return this;
	}

	@Override
	public IApexLocationBuilder setDefaultValuesOnSlicingHierarchies() {
		defaultValuesOnNotExpressedSlicingHierarchies = true;

		return this;
	}

	@Override
	public ILocation build() {
		// Cache this location
		// ActivePivotVersionQheryHelper will keep null on slicing hierarchies
		ILocation topLocation;
		if (baseLocation == null) {
			topLocation = new QueryHelper(pivotVersion).computeLocation(Collections.<String, Object>emptyMap());
		} else {
			topLocation = baseLocation;
		}

		return ApexLocationHelper.setCoordinates2(topLocation, levelToValueToSet, false);
	}

	@Override
	public IApexLocationBuilder wildcard(String... wildcardLevels) {
		wildcard(Arrays.asList(wildcardLevels));

		return this;
	}

	@Override
	public IApexLocationBuilder baseLocation(ILocation baseLocation) {
		this.baseLocation = baseLocation;

		return this;
	}
}

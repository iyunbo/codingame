/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.location;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import blasd.apex.server.location.ApexLocationBuilder;
import blasd.apex.server.query.hierarchy.ApexHierarchyHelper;

import com.quartetfs.biz.pivot.IActivePivot;
import com.quartetfs.biz.pivot.ILocation;
import com.quartetfs.biz.pivot.cube.hierarchy.IDimension;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevel;
import com.quartetfs.biz.pivot.cube.hierarchy.measures.IMeasureDimension;
import com.quartetfs.biz.pivot.impl.Location;
import com.quartetfs.biz.pivot.impl.LocationUtil;

/**
 * This {@link ILocationFormatter} reports only the {@link IHierarchy} which are not on the AllMember coordinate of an
 * ALL {@link ILevel}
 * 
 * @author Benoit Lacelle
 * 
 */
public class ApexShortLocationFormatter {
	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexShortLocationFormatter.class);

	public static final String AFTER_HIERARCHY_SEPARATOR =
			System.getProperty("activepivot.location.separator.hierarchyname", ":");

	protected ApexShortLocationFormatter() {
		// hidden
	}

	public static void format(final StringBuilder buff, ILocation location, List<? extends IDimension> rawHierarchies) {
		if (location == null) {
			buff.append("null");
		} else {
			// This flag is used to add separators correctly
			final AtomicBoolean hasFirstDimension = new AtomicBoolean();

			final List<? extends IDimension> hierarchies;
			if (rawHierarchies == null) {
				hierarchies = null;
			} else if (rawHierarchies.get(0) instanceof IMeasureDimension) {
				hierarchies = rawHierarchies.subList(1, rawHierarchies.size());
			} else {
				hierarchies = rawHierarchies;
			}

			ApexLocationAcceptor.acceptLocation(location, new IApexLocationVisitor() {

				@Override
				public void visit(ILocation location, int hierarchyIndex) {
					int levelDepth = location.getLevelDepth(hierarchyIndex);

					if (hasFirstDimension.get()) {
						buff.append(ILocation.DIMENSION_SEPARATOR);
					} else {
						hasFirstDimension.set(true);
					}

					String hierarchyName;
					if (hierarchies == null) {
						hierarchyName = Integer.toString(hierarchyIndex);
					} else {
						hierarchyName = hierarchies.get(hierarchyIndex).getName();
					}

					buff.append(hierarchyName);
					buff.append(AFTER_HIERARCHY_SEPARATOR);

					for (int l = 0; l < levelDepth; ++l) {
						if (l > 0) {
							buff.append(ILocation.LEVEL_SEPARATOR);
						}
						Object coordinate = location.getCoordinate(hierarchyIndex, l);
						if (coordinate == null) {
							buff.append(ILocation.WILDCARD);
						} else {
							buff.append(coordinate);
						}
					}
				}
			});
		}
	}

	public static ILocation locationFromString(IActivePivot pivot, String locationAsString) {
		List<? extends IDimension> hierarchiesInfo = ApexHierarchyHelper.extractAxisHierarchiesInfo(pivot);

		String[] hierarchies = locationAsString.split(Pattern.quote(ILocation.DIMENSION_SEPARATOR), -1);
		if (hierarchies.length == hierarchiesInfo.size()) {
			// All hierarchies are expressed
			for (String hierarchy : hierarchies) {
				if (!hierarchy.contains(AFTER_HIERARCHY_SEPARATOR)) {
					// And at least one of then does not have the format of a
					// short .toString: it is certainly a core .toString
					return new Location(LocationUtil.stringToArrayLocation(locationAsString));
				}
			}

		}

		{
			// Not all hierarchies are expressed or all of them has the short
			// format: this is certainly a ShortLocationFormatter .toString
			Map<String, Object> template = new HashMap<String, Object>();

			IActivePivot latestVersion = pivot;

			for (String expressedHierarchy : hierarchies) {
				String[] nameToPath = expressedHierarchy.split(Pattern.quote(AFTER_HIERARCHY_SEPARATOR), 2);

				String[] path = nameToPath[1].split(Pattern.quote(ILocation.LEVEL_SEPARATOR), -1);

				for (int depth = 0; depth < path.length; depth++) {
					template.put(ApexHierarchyHelper.levelName(ApexHierarchyHelper.findHierarchy(latestVersion,
							nameToPath[0]), depth), path[depth]);
				}
			}

			return ApexLocationBuilder.on(latestVersion).filter(template).build();
		}
	}
}

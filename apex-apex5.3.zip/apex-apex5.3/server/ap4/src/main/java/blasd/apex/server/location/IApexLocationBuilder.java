/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.location;

import java.util.Collection;
import java.util.Map;

import com.quartetfs.biz.pivot.ILocation;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevel;

public interface IApexLocationBuilder {

	/**
	 * By default, we leave null on slicing {@link IHierarchy}
	 */
	IApexLocationBuilder setDefaultValuesOnSlicingHierarchies();

	IApexLocationBuilder filter(Map<String, ?> levelNamesToValues);

	IApexLocationBuilder filter(ILevel level, Object value);

	IApexLocationBuilder filter(String level, Object value);

	IApexLocationBuilder wildcard(Iterable<? extends ILevel> wildcardLevels);

	IApexLocationBuilder wildcard(Collection<? extends String> wildcardLevels);

	IApexLocationBuilder wildcard(String... levels);

	ILocation build();

	IApexLocationBuilder baseLocation(ILocation location);
}

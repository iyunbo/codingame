/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.shared.client.query.realtime;

import java.util.Date;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

import blasd.apex.shared.client.query.mdx.IApexQueryProvider;

import com.quartetfs.fwk.query.IQuery;
import com.quartetfs.tech.streaming.IBulkedStreamEvents;
import com.quartetfs.tech.streaming.IDomainStreamEvent;
import com.quartetfs.tech.streaming.IIdGenerator;
import com.quartetfs.tech.streaming.ILongPollingService;
import com.quartetfs.tech.streaming.IStreamProperties;
import com.quartetfs.tech.streaming.IStreamProperties.InitialState;
import com.quartetfs.tech.streaming.IStreamingService;
import com.quartetfs.tech.streaming.impl.StreamProperties;

public class ApexQueryStreamingClientAP4 extends ApexQueryStreamingClient implements InitializingBean, DisposableBean {

	public ApexQueryStreamingClientAP4(String baseUrl, String userName, String password,
			IApexQueryProvider<?> mdxProvider) {
		super(baseUrl, userName, password, mdxProvider);
	}

	@Override
	protected void initRemoteServices() {
		// Setup Spring HTTP Invoker for the id generator service
		idGenerator = makeRemoteService(IIdGenerator.class, "IdGenerator");

		// Setup Spring HTTP Invoker for the streaming service
		streamingService = makeRemoteService(IStreamingService.class, "Streaming" + "Service");

		// Setup Spring HTTP Invoker for the long polling service
		longPollingService = makeRemoteService(ILongPollingService.class, "LongPolling" + "Service");
	}

	@Override
	protected <T> T makeRemoteService(Class<? extends T> serviceClass, String afterBaseUrl) {
		return ApexQueryStreamingClient.staticMakeRemoteService(serviceClass, baseUrl + afterBaseUrl);
	}

	@Override
	public void destroy() throws Exception {
		listenExecutorService.shutdownNow();
	}

	@Override
	public String makeListenerId() {
		return idGenerator.generateListenerIds(1)[0];
	}

	@Override
	public String makeStreamId() {
		return idGenerator.generateStreamIds(1)[0];
	}

	@Override
	public String registerListenerIdToDomain(String listenerId) {
		// Register the client as a real-time listener
		String domain = makeDomain();
		longPollingService.addListener(domain, listenerId);
		LOGGER.info("Client registered to domain {} with listener id: {}", domain, listenerId);

		return domain;
	}

	@Override
	public void registerStreamToListenerId(String domain, Map<IQuery<?>, String> mdxToStreamId) {
		registerStreamToDomain(domain, mdxToStreamId);
	}

	@Override
	protected void registerStreamToDomain(String domain, Map<IQuery<?>, String> mdxToStreamId) {
		for (IQuery<?> query : mdxProvider.getQueries()) {
			String streamId = registerMdx(query, domain);

			// Not expected to fail as we expect AP to return different
			// streamIds
			mdxToStreamId.put(query, streamId);
		}
	}

	@Override
	protected String registerMdx(IQuery<?> query, String domain) {
		String streamId = makeStreamId();

		IStreamProperties properties = new StreamProperties(streamId, domain, InitialState.STARTED, true);
		streamingService.createStream(query, properties);

		LOGGER.info("Created stream {} for query {}", streamId, query);

		return streamId;
	}

	@Override
	protected String makeDomain() {
		return "Apex-" + UUID.randomUUID().toString();
	}

	public ScheduledFuture<?> asyncConsumeEventsAP4(final String listenerId, final long nbSecondBetweenListen,
			final BlockingQueue<? super IDomainStreamEvent> queue) {
		// We need to never wait more than N seconds between previous
		// ILongPollingService.listen return and next call

		// The issue is ILongPollingService.listen could bring a very large
		// event, and its deserialization could take more than X seconds itself.
		// Then, one way to guarantee never to be disconnected is to request
		// .listen every X seconds independently of the return of previous
		// .listen (as we can not differentiate between the server blocking our
		// call the a huge event being deserialized)
		final AtomicReference<Date> latestBeforeListen = new AtomicReference<>(new Date(0));

		final AtomicReference<ScheduledFuture<?>> futureRef = new AtomicReference<>();

		ScheduledFuture<?> future = listenExecutorService.scheduleAtFixedRate(new Runnable() {

			@Override
			public void run() {
				if (System.currentTimeMillis() - latestBeforeListen.get().getTime() < nbSecondBetweenListen
						* ONE_SECOND) {
					// Another such Runnable has recently called .listen: no
					// need for this additional thread
					return;
				}

				try {
					authenticateCurrentThread();

					while (!listenExecutorService.isShutdown()) {
						LOGGER.info("Call ILongPollingService.listen(");

						latestBeforeListen.set(new Date());
						IBulkedStreamEvents event = longPollingService.listen(listenerId);

						if (event == null || event.getDomainEvents() == null || event.getDomainEvents().isEmpty()) {
							LOGGER.debug("Received no event during long polling wait period.");
						} else {
							LOGGER.info("Received {} domainEvents.", event.getDomainEvents().size());
							queue.addAll(event.getDomainEvents());
						}
					}
				} catch (RuntimeException e) {
					if (e != null && e.getMessage() != null
							&& e.getMessage().contains("There is no registered listener for listener id ")) {
						LOGGER.error("The listener has been disconnected", e);

						if (futureRef.get() != null) {
							ScheduledFuture<?> future = futureRef.getAndSet(null);
							if (future != null) {
								LOGGER.error("We cancel the regular call to .listen", e);
								future.cancel(true);
								queue.add(new DisconnectionEventAP4(e));
							}
						}
					} else {
						LOGGER.warn("Issue when polling events", e);
					}
				}
			}

		},
				1,
				nbSecondBetweenListen,
				TimeUnit.SECONDS);

		futureRef.set(future);

		return future;
	}
}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.NavigableMap;
import java.util.TreeMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import blasd.apex.server.query.hierarchy.ApexHierarchyHelper;
import blasd.apex.server.query.location.ApexLocationAcceptor;
import blasd.apex.server.query.location.ApexLocationHelper;
import blasd.apex.server.query.location.IApexLocationVisitor;
import blasd.apex.shared.cellset.UnsafeNavigableMapListValueComparator;

import com.google.common.annotations.Beta;
import com.google.common.base.Functions;
import com.google.common.collect.Lists;
import com.quartetfs.biz.pivot.IActivePivot;
import com.quartetfs.biz.pivot.IActivePivotManager;
import com.quartetfs.biz.pivot.IActivePivotSchema;
import com.quartetfs.biz.pivot.ILocation;
import com.quartetfs.biz.pivot.IProjection;
import com.quartetfs.biz.pivot.cellset.ICellProcedure;
import com.quartetfs.biz.pivot.cellset.ICellSet;
import com.quartetfs.biz.pivot.cellset.ICellsProcedure;
import com.quartetfs.biz.pivot.cube.hierarchy.IDimension;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevel;
import com.quartetfs.biz.pivot.cube.hierarchy.IMember;
import com.quartetfs.biz.pivot.cube.hierarchy.axis.IAxisDimension;
import com.quartetfs.biz.pivot.cube.hierarchy.axis.IAxisMember;
import com.quartetfs.biz.pivot.query.IGetAggregatesQuery;
import com.quartetfs.biz.pivot.query.IMDXQuery;
import com.quartetfs.biz.pivot.query.impl.ActivePivotSyncActionQuery;
import com.quartetfs.biz.pivot.query.impl.ActivePivotSyncUtils.IAction;
import com.quartetfs.biz.pivot.query.impl.GetAggregatesQuery;
import com.quartetfs.biz.pivot.query.impl.MDXQuery;
import com.quartetfs.biz.xmla.discovery.impl.IPivotDiscoveryHandler;
import com.quartetfs.fwk.query.IQuery;
import com.quartetfs.fwk.query.QueryException;
import com.quartetfs.pivot.mdx.IExecutor;
import com.quartetfs.pivot.mdx.realtime.impl.RTSelectSupervisor;
import com.quartetfs.pivot.mdx.realtime.impl.RTSelectSupervisorSpy;
import com.quartetfs.tech.indexer.IIndexer;

public class ApexQueryCubeHelper {
	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexQueryCubeHelper.class);

	protected ApexQueryCubeHelper() {
		// hidden
	}

	/**
	 * Handle {@link Iterable} instead of {@link Collection} and throw {@link RuntimeException}
	 * 
	 * @return
	 */
	public static ICellSet executeGetAggregates(IActivePivot pivot, Iterable<? extends ILocation> locations,
			Iterable<? extends String> measures) {
		try {
			return pivot.execute(new GetAggregatesQuery(Lists.newArrayList(locations), Lists.newArrayList(measures)));
		} catch (QueryException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * @see #executeGetAggregates(IActivePivotVersion, Iterable, Iterable)
	 */
	public static ICellSet executeGetAggregates(IActivePivot pivot, Iterable<? extends ILocation> locations,
			String... measures) {
		return executeGetAggregates(pivot, locations, Arrays.asList(measures));
	}

	public static ICellSet executeGetAggregates(IActivePivot pivot, ILocation location,
			Iterable<? extends String> measures) {
		return executeGetAggregates(pivot, Arrays.asList(location), measures);
	}

	public static ICellSet executeGetAggregates(IActivePivot pivot, ILocation location, String... underlyingMeasures) {
		return executeGetAggregates(pivot, Arrays.asList(location), Arrays.asList(underlyingMeasures));
	}

	@Beta
	public static List<ILocation> partitionLocation(final IActivePivot pivot, ILocation location,
			IDimension partitionHierarchyInfo) {
		IDimension partitionHierarchy = pivot.getDimensions().get(partitionHierarchyInfo.getOrdinal());
		ILevel partitionLevel;

		// We must partition along the first interesting ILevel, as we can not
		// partition by describing 2 levels at the same time
		if (ApexHierarchyHelper.isAllMembersEnabled(partitionHierarchy)) {
			partitionLevel = partitionHierarchy.getLevels().get(1);
		} else {
			partitionLevel = partitionHierarchy.getLevels().get(0);
		}

		{
			if (!ApexLocationHelper.checkCoordinate(location, partitionLevel)) {
				LOGGER.info("Can not partition {} along IDimension {}. Do simple query", location, partitionHierarchy);
				return Arrays.asList(location);
			} else {
				Object coordinate = ApexLocationHelper.getCoordinate(location, partitionLevel);

				if (coordinate == null) {
					LOGGER.debug("Partition {} with a wildcard along IDimension {}", location, partitionHierarchy);
				} else if (coordinate instanceof Collection<?>) {
					// TODO: this case could be handled easily
					LOGGER.info("Can not partition {} along IDimension {}. Do simple query",
							location,
							partitionHierarchy);
					return Arrays.asList(location);
				} else {
					LOGGER.info("Can not partition {} along IDimension {}. Do simple query",
							location,
							partitionHierarchy);
					return Arrays.asList(location);
				}
			}
		}

		// We only have to handle the wildcard case
		List<? extends IMember> members = partitionHierarchy.retrieveMembers(partitionLevel.getOrdinal());

		List<ILocation> locations = new ArrayList<>();

		int nbQueries = getTargetNbQueries();
		int nbPartition = 1 + Math.max(0, members.size() / nbQueries - 1);

		for (List<? extends IMember> partition : Lists.partition(members, nbPartition)) {
			List<Object> discriminators = new ArrayList<Object>();

			// Fetch all coordinate for current partition
			for (IMember member : partition) {
				if (member instanceof IAxisMember) {
					discriminators.add(((IAxisMember) member).getDiscriminator());
				}
			}

			// Prepare a partition ILocation
			ILocation partitionLocation =
					ApexLocationHelper.setCoordinates(location, partitionLevel, discriminators, false);

			locations.add(partitionLocation);
		}

		LOGGER.info("{} partitions {} with a wildcard along IDimension {}",
				locations.size(),
				location,
				partitionHierarchy);

		return locations;
	}

	private static int getTargetNbQueries() {
		// We target one query per core
		// return PepperExecutorsHelper.DEFAULT_NB_CORES;

		// We expect the higher number of queries, for smallest query chunks
		return Integer.MAX_VALUE;
	}

	/**
	 * The best {@link IDimension} to consider is the one with a cardinality a few times the query pool
	 * 
	 * @param pivot
	 * @param location
	 * @return the best {@link IDimension} to consider for {@link GetAggregatesQuery} partitionning
	 */
	@Beta
	public static IDimension guessBestPartitionHierarchy(final IActivePivot pivot, ILocation location) {
		double bestScore = -1d;
		IDimension bestHierarchy = null;

		// Select the IDimension with the maximum number of elements on the
		// first level
		for (IDimension hierarchy : pivot.getDimensions()) {
			if (hierarchy instanceof IAxisDimension) {
				final int cardinality;
				if (ApexHierarchyHelper.isSlicing(hierarchy)) {
					cardinality = hierarchy.retrieveMembers(0).size();
				} else {
					cardinality = hierarchy.retrieveMembers(1).size();
				}

				// We expects the cardinality to be near getTargetNbQueries
				double currentScore = 1D / (1D + Math.abs(getTargetNbQueries() - cardinality));

				if (currentScore > bestScore) {
					bestScore = currentScore;
					bestHierarchy = hierarchy;
				}
			}
		}

		return bestHierarchy;
	}

	/**
	 * 
	 * @param apManager
	 * @param pivotId
	 * @return the store name which is the base store of given {@link IActivePivot}
	 */
	public static IIndexer<IProjection> findBaseStore(IActivePivotManager apManager, String pivotId) {
		for (IActivePivotSchema apSchema : apManager.getSchemas().values()) {
			if (apSchema.getPivotIds().contains(pivotId)) {
				return apSchema.getIndexer();
			}
		}

		// We found no matching store
		return null;
	}

	protected static NavigableMap<String, List<?>> computeCoordinates(final ILocation pointLocation,
			final List<? extends IDimension> hierarchies) {
		final NavigableMap<String, List<?>> pointCoordinate = new TreeMap<>();

		// Add each relevant Axis coordinate
		ApexLocationAcceptor.acceptLocation(pointLocation, new IApexLocationVisitor() {

			@Override
			public void visit(ILocation location, int hierarchyIndex) {
				IDimension hierarchy = hierarchies.get(hierarchyIndex);

				pointCoordinate.put(hierarchy.getName(),
						Arrays.asList(ApexLocationHelper.getPath(location, hierarchies.get(hierarchyIndex))));
			}
		});

		return pointCoordinate;
	}

	public static NavigableMap<NavigableMap<String, List<?>>, Object> convertToOneDimensionalMap(ICellSet cellset,
			List<? extends IDimension> rawHierarchies) {
		final NavigableMap<NavigableMap<String, List<?>>, Object> humanReadable =
				new TreeMap<>(new UnsafeNavigableMapListValueComparator());

		// Remove the Measure hierarchy
		final List<? extends IDimension> hierarchies = ApexHierarchyHelper.filterAxisHierarchiesInfo(rawHierarchies);

		// Iterate on each aggregate
		cellset.forEachCell(new ICellProcedure() {

			@Override
			public boolean execute(ILocation paramILocation, String measureName, Object paramObject) {
				final NavigableMap<String, List<?>> pointCoordinate = new TreeMap<>();

				// Add the measure coordinate
				pointCoordinate.put("Measure", Collections.singletonList(measureName));

				// Add each relevant Axis coordinate
				ApexLocationAcceptor.acceptLocation(paramILocation, new IApexLocationVisitor() {

					@Override
					public void visit(ILocation location, int hierarchyIndex) {
						IDimension hierarchy = hierarchies.get(hierarchyIndex);

						pointCoordinate.put(hierarchy.getName(),
								Arrays.asList(ApexLocationHelper.getPath(location, hierarchies.get(hierarchyIndex))));
					}
				});

				// Associate this coordinate to current measure value
				humanReadable.put(pointCoordinate, paramObject);

				return true;
			}

			// Explicit availableMeasures as some ICellSet need it (e.g.
			// composite cellset)
			// http://support.quartetfs.com/jira/browse/APS-7099
		},
				cellset.availableMeasures());

		return humanReadable;
	}

	public static NavigableMap<NavigableMap<String, List<?>>, List<?>> convertToTwoDimensionalMap(ICellSet cellset,
			List<? extends IDimension> rawHierarchies) {
		final NavigableMap<NavigableMap<String, List<?>>, List<?>> humanReadable =
				new TreeMap<>(new UnsafeNavigableMapListValueComparator());

		// Remove the Measure hierarchy
		final List<? extends IDimension> hierarchies = ApexHierarchyHelper.filterAxisHierarchiesInfo(rawHierarchies);

		// Iterate on each aggregate
		cellset.forEachLocation(new ICellsProcedure() {

			@Override
			public boolean execute(ILocation pointLocation, int pointIndex, Object[] measureValues) {
				// Associate this coordinate to the list of values
				// We copy the input array for safety as we are typically
				// provided a buffered Object[]
				humanReadable.put(computeCoordinates(pointLocation, hierarchies), Lists.newArrayList(measureValues));

				return true;
			}

			// Explicit availableMeasures as some ICellSet need it (e.g.
			// composite cellset)
			// http://support.quartetfs.com/jira/browse/APS-7099
		}, cellset.availableMeasures());

		return humanReadable;
	}

	public static void dispatchQuery(IQuery<?> query, IApexQueryHandler apexQueryHandler) {
		if (query instanceof ActivePivotSyncActionQuery<?, ?>) {
			IAction<?, ?> action = ((ActivePivotSyncActionQuery<?, ?>) query).getAction();

			if (action.getClass().isAnonymousClass()) {
				Class<?> enclosingClass = action.getClass().getEnclosingClass();

				if (IPivotDiscoveryHandler.class.isAssignableFrom(enclosingClass)) {
					apexQueryHandler.onDiscoveryQuery(query, (Class<? extends IPivotDiscoveryHandler>) enclosingClass);
				} else {
					apexQueryHandler.onOtherQueryDone(query);
				}
			} else if (action.getClass().isMemberClass()) {
				Class<?> enclosingClass = action.getClass().getEnclosingClass();

				if (IExecutor.class.isAssignableFrom(enclosingClass)) {
					String mdx = getMdxFromEnclosing(action);

					if (mdx == null) {
						apexQueryHandler.onOtherQueryDone(query);
					} else {
						apexQueryHandler.onMDXQuery(new MDXQuery(mdx));
					}
				} else if (RTSelectSupervisor.class.isAssignableFrom(enclosingClass)) {
					String mdx = RTSelectSupervisorSpy.getMdx(action);

					if (mdx == null) {
						apexQueryHandler.onOtherQueryDone(query);
					} else {
						apexQueryHandler.onMDXQuery(new MDXQuery(mdx));
					}
				} else {
					apexQueryHandler.onOtherQueryDone(query);
				}
			} else {
				apexQueryHandler.onOtherQueryDone(query);
			}
		} else if (query instanceof IGetAggregatesQuery) {
			apexQueryHandler.onGetAggregatesQuery((IGetAggregatesQuery) query);
		} else if (query instanceof IMDXQuery) {
			apexQueryHandler.onMDXQuery((IMDXQuery) query);
		} else {
			apexQueryHandler.onOtherQueryDone(query);
		}
	}

	/**
	 * Dirty way to extract the MDX from an {@link IAction}
	 * 
	 * @param action
	 * @return
	 */
	private static String getMdxFromEnclosing(IAction<?, ?> action) {
		Field executorField;
		try {
			// OK for:
			// SelectStatementExecutor.MdxAction
			// BasicSelectExecutor.Action
			executorField = action.getClass().getDeclaredField("executor");
			executorField.setAccessible(true);

			IExecutor<?> outer = (IExecutor<?>) executorField.get(action);
			return outer.getMdx();
		} catch (NoSuchFieldException | SecurityException | IllegalArgumentException | IllegalAccessException e) {
			return null;
		}
	}

	public static <T> Map<NavigableMap<String, List<String>>, T> convertKeyToStringCoordinates(
			NavigableMap<NavigableMap<String, List<?>>, T> objectMap) {
		@SuppressWarnings("unchecked")
		Map<NavigableMap<String, List<String>>, T> stringKey =
				new TreeMap<NavigableMap<String, List<String>>, T>((Comparator<? super NavigableMap<String, List<String>>>) objectMap.comparator());

		for (Entry<NavigableMap<String, List<?>>, T> entry : objectMap.entrySet()) {
			stringKey.put(convertToStringCoordinates(entry.getKey()), entry.getValue());
		}

		return stringKey;
	}

	public static NavigableMap<String, List<String>> convertToStringCoordinates(NavigableMap<String, List<?>> objectMap) {
		NavigableMap<String, List<String>> stringKey = new TreeMap<String, List<String>>(objectMap.comparator());

		for (Entry<String, List<?>> entry : objectMap.entrySet()) {
			stringKey.put(entry.getKey(), convertToStringList(entry.getValue()));
		}

		return stringKey;
	}

	public static List<String> convertToStringList(List<?> value) {
		// Make JMX compatible
		return new ArrayList<String>(Lists.transform(value, Functions.toStringFunction()));
	}

	public static String[] arrayToStringArray(Object[] input) {
		if (input == null) {
			return null;
		}

		String[] output = new String[input.length];

		for (int i = 0; i < input.length; i++) {
			Object element = input[i];

			if (element != null) {
				output[i] = element.toString();
			}
		}

		return output;
	}

}

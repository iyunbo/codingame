/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.monitoring.realtime.cquery;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import jsr166e.ForkJoinTask;
import blasd.apex.server.monitoring.query.IApexUserTowerControl;

import com.google.common.annotations.Beta;
import com.google.common.eventbus.EventBus;
import com.quartetfs.biz.pivot.IActivePivotSession;
import com.quartetfs.biz.pivot.query.aggregates.impl.ContextNode;
import com.quartetfs.biz.pivot.query.aggregates.impl.NotificationTaskCreator;
import com.quartetfs.biz.pivot.query.impl.StreamEventProcessingQuery;
import com.quartetfs.biz.pivot.query.impl.StreamEventProcessingQuerySpy;
import com.quartetfs.fwk.QuartetExtendedPluginValue;
import com.quartetfs.fwk.query.QueryException;
import com.quartetfs.fwk.query.impl.AAttachedQuery;

/**
 * Provides a huge amount of statistics on a per stream basis
 * 
 * @author Benoit Lacelle
 * 
 * @see ApexSnapshotProcessingTask
 * 
 */
@Beta
@QuartetExtendedPluginValue(interfaceName = "com.quartetfs.fwk.query.IAttachedQuery", key = ApexStreamEventProcessingAttachedQuery.PLUGIN_KEY)
public class ApexStreamEventProcessingAttachedQuery<E> extends
		AAttachedQuery<List<NotificationTaskCreator<E>>, IActivePivotSession> {
	private static final long serialVersionUID = 8493433980979796293L;

	public static final String PLUGIN_KEY = StreamEventProcessingQuery.PLUGIN_TYPE;

	protected EventBus eventBus;
	protected IApexUserTowerControl utc;

	public ApexStreamEventProcessingAttachedQuery(final StreamEventProcessingQuery<E> originatingQuery,
			final IActivePivotSession session) {
		super(originatingQuery, session);
	}

	public void setEventBus(EventBus eventBus) {
		this.eventBus = eventBus;
	}

	public void setApexUserTowerControl(IApexUserTowerControl utc) {
		this.utc = utc;
	}

	@Override
	public String getType() {
		return PLUGIN_KEY;
	}

	@Override
	public List<NotificationTaskCreator<E>> execute() throws QueryException {
		final StreamEventProcessingQuery<E> query = (StreamEventProcessingQuery<E>) this.getOriginatingQuery();
		StreamEventProcessingQuerySpy.getSnapshot(query).getStatistics().beginEvent();
		try {
			final List<ContextNode<E>.Snapshot> contextSnapshots =
					StreamEventProcessingQuerySpy.getSnapshot(query).getContextSnapshots();
			final List<ApexSnapshotProcessingTask<E>> nodeTasks = new ArrayList<>(contextSnapshots.size());
			for (final ContextNode<E>.Snapshot s : contextSnapshots) {
				final ApexSnapshotProcessingTask<E> nodeTask =
						new ApexSnapshotProcessingTask<E>(session,
								s,
								StreamEventProcessingQuerySpy.getEvent(query),
								eventBus,
								utc);
				nodeTasks.add(nodeTask);
			}
			ForkJoinTask.invokeAll(nodeTasks);
			final List<NotificationTaskCreator<E>> notificationtasks = new ArrayList<NotificationTaskCreator<E>>();
			for (final ApexSnapshotProcessingTask<E> task : nodeTasks) {
				notificationtasks.addAll((Collection<? extends NotificationTaskCreator<E>>) task.getRawResult());
			}
			return notificationtasks;
		} finally {
			StreamEventProcessingQuerySpy.getSnapshot(query).getStatistics().endEvent();
		}
	}
}

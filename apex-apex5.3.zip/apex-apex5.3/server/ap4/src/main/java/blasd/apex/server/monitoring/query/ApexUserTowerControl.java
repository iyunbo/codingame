/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.monitoring.query;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import javolution.util.function.Consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;

import blasd.apex.server.query.ApexQueryCubeHelper;
import blasd.apex.server.query.IApexQueryHandler;
import blasd.apex.shared.monitoring.jmx.PepperJMXHelper;
import blasd.apex.shared.monitoring.metrics.EndMetricEvent;
import blasd.apex.shared.monitoring.metrics.TaskStartEvent;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.google.common.eventbus.AllowConcurrentEvents;
import com.google.common.eventbus.Subscribe;
import com.google.common.util.concurrent.AtomicLongMap;
import com.quartetfs.biz.pivot.query.IGetAggregatesQuery;
import com.quartetfs.biz.pivot.query.IMDXQuery;
import com.quartetfs.biz.pivot.query.impl.StreamEventProcessingQuery;
import com.quartetfs.biz.xmla.discovery.impl.IPivotDiscoveryHandler;
import com.quartetfs.fwk.AgentException;
import com.quartetfs.fwk.IAgent.State;
import com.quartetfs.fwk.monitoring.IMonitoredComponent;
import com.quartetfs.fwk.query.IQuery;
import com.quartetfs.tech.streaming.IStream;
import com.quartetfs.tech.streaming.impl.AStream;
import com.quartetfs.tech.streaming.sharing.IStreamNode;
import com.quartetfs.tech.streaming.sharing.impl.StreamRegister;

@ManagedResource
public class ApexUserTowerControl implements IApexUserTowerControl {
	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexUserTowerControl.class);

	protected final List<StreamRegister<? extends IStreamNode<?, ?>, ? extends IStream<?>, ? extends IQuery<?>>> streamRegisters =
			new CopyOnWriteArrayList<>();

	public static final int DEFAULT_USER_TIMEOUT = 10;

	protected int userTimeout = DEFAULT_USER_TIMEOUT;

	/**
	 * Holds the userName which has been active recently (typically as they produced a {@link TaskStartEvent} or an
	 * {@link EndMetricEvent})
	 */
	protected volatile Cache<String, String> recentUserNames = CacheBuilder.newBuilder()
			.expireAfterWrite(userTimeout, TimeUnit.MINUTES)
			.build();

	/**
	 * This captures time with active calls for each user. This measure is not precise as it could count several tasks
	 * running in parallel in the {@link ForkJoinPool}, but it is still a relevant indicator of each user activity
	 */
	protected final AtomicLongMap<String> userNameToActiveTime = AtomicLongMap.create();
	/**
	 * Beware a single {@link IMDXQuery} could contribute several {@link IGetAggregatesQuery}
	 */
	protected final AtomicLongMap<String> userNameToNbGetAggregatesQuery = AtomicLongMap.create();

	/**
	 * This captures times in ActivePivot query engine
	 */
	protected final AtomicLongMap<String> userNameToTimeInGetAggregatesQuery = AtomicLongMap.create();

	protected final AtomicLongMap<String> streamToNbImpact = AtomicLongMap.create();
	protected final AtomicLongMap<String> streamToNbImpactedLocation = AtomicLongMap.create();

	protected final AtomicLongMap<String> streamToTimeMsInPrepareImpact = AtomicLongMap.create();
	protected final AtomicLongMap<String> streamToTimeMsInExecuteImpact = AtomicLongMap.create();

	public final void setStreamRegisters(
			List<? extends StreamRegister<? extends IStreamNode<?, ?>, ? extends IStream<?>, ? extends IQuery<?>>> streamRegisters) {
		this.streamRegisters.clear();

		this.streamRegisters.addAll(streamRegisters);
	}

	public void setUserTimeout(int userTimeout) {
		this.userTimeout = userTimeout;

		Cache<String, String> oldRecentUsers = recentUserNames;
		recentUserNames = CacheBuilder.newBuilder().expireAfterWrite(userTimeout, TimeUnit.MINUTES).build();

		// Re-register previous users
		recentUserNames.putAll(oldRecentUsers.asMap());
	}

	@Subscribe
	@AllowConcurrentEvents
	public void onStartEvent(TaskStartEvent startEvent) {
		Object userName = startEvent.getDetail(TaskStartEvent.KEY_USERNAME);

		if (userName != null) {
			recentUserNames.put(userName.toString(), userName.toString());
		}
	}

	@Subscribe
	@AllowConcurrentEvents
	public void onEndEvent(EndMetricEvent endEvent) {
		Object userName = endEvent.startEvent.getDetail(TaskStartEvent.KEY_USERNAME);

		if (userName != null) {
			final String userNameAsString = userName.toString();
			recentUserNames.put(userNameAsString, userNameAsString);

			final long durationInMs = endEvent.durationInMs();
			userNameToActiveTime.addAndGet(userNameAsString, durationInMs);

			if (endEvent.source instanceof IQuery<?>) {
				ApexQueryCubeHelper.dispatchQuery((IQuery<?>) endEvent.source, new IApexQueryHandler() {

					@Override
					public void onOtherQueryDone(IQuery<?> query) {
						ApexUserTowerControl.this.onOtherQueryDone(query, userNameAsString, durationInMs);
					}

					@Override
					public void onMDXQuery(IMDXQuery query) {
						ApexUserTowerControl.this.onMDXQuery(query, userNameAsString, durationInMs);
					}

					@Override
					public void onGetAggregatesQuery(IGetAggregatesQuery query) {
						ApexUserTowerControl.this.onGetAggregatesQuery(query, userNameAsString, durationInMs);
					}

					@Override
					public void onDiscoveryQuery(IQuery<?> query, Class<? extends IPivotDiscoveryHandler> handlerClass) {
						ApexUserTowerControl.this.onDiscoveryQuery(query, handlerClass, userNameAsString, durationInMs);
					}

					@Override
					public void onStreamEventProcessingQuery(StreamEventProcessingQuery<?> query) {
						ApexUserTowerControl.this.onStreamEventProcessingQuery(query, durationInMs);
					}
				});
			}
		}
	}

	protected void onGetAggregatesQuery(IGetAggregatesQuery getAggregatesQuery, String userName, long timeInMs) {
		if (userName == null) {
			userName = String.valueOf((Object) null);
		}

		userNameToTimeInGetAggregatesQuery.addAndGet(userName, timeInMs);
		userNameToNbGetAggregatesQuery.incrementAndGet(userName);
	}

	protected void onMDXQuery(IMDXQuery query, String userNameAsString, long durationInMs) {
		// TODO Auto-generated method stub
	}

	protected void onDiscoveryQuery(IQuery<?> query, Class<? extends IPivotDiscoveryHandler> handlerClass,
			String userNameAsString, long durationInMs) {
		// TODO Auto-generated method stub
	}

	protected void onOtherQueryDone(IQuery<?> query, String userNameAsString, long durationInMs) {
		// TODO Auto-generated method stub
	}

	protected void onStreamEventProcessingQuery(StreamEventProcessingQuery<?> streamEventProcessingQuery, long timeInMs) {
		// TODO Auto-generated method stub
	}

	@Override
	public void contributeTimeToStream(IStream<?> stream, long prepareImpactTimeMs, int nbImpactedLocations,
			long totalExecuteTimeMs) {
		streamToNbImpact.incrementAndGet(stream.getId());
		streamToNbImpactedLocation.addAndGet(stream.getId(), nbImpactedLocations);

		streamToTimeMsInPrepareImpact.addAndGet(stream.getId(), prepareImpactTimeMs);
		streamToTimeMsInExecuteImpact.addAndGet(stream.getId(), totalExecuteTimeMs);

		if (stream instanceof AStream<?>) {
			String username = ((AStream<?>) stream).getUserName();
			if (username != null) {
				userNameToActiveTime.addAndGet(username, prepareImpactTimeMs + totalExecuteTimeMs);
			}
		}
	}

	/**
	 * 
	 * @return userNames which has at least one connected {@link IStream}. They may consume resources even without any
	 *         user interaction
	 */
	@ManagedAttribute
	public Set<String> getConnectedThroughStreamUsers() {
		Set<String> users = new TreeSet<>();

		for (StreamRegister<? extends IStreamNode<?, ?>, ? extends IStream<?>, ? extends IQuery<?>> streamRegister : streamRegisters) {
			for (IMonitoredComponent streamNode : streamRegister.getMonitoredChildren().values()) {
				for (IMonitoredComponent rawStream : streamNode.getMonitoredChildren().values()) {
					if (rawStream instanceof AStream<?>) {
						AStream<?> stream = (AStream<?>) rawStream;

						String userName = stream.getUserName();

						if (userName != null) {
							users.add(userName);
						}
					}
				}
			}
		}

		return users;
	}

	/**
	 * 
	 * @param userName
	 * @return the number of {@link IStream} which have been disconnected
	 */
	@ManagedOperation
	@Override
	public int disconnectUser(final String userName) {
		if (userName == null) {
			return 0;
		}

		final AtomicInteger nbDisconnectedStreams = new AtomicInteger();

		forEachAStream(new Consumer<AStream<?>>() {

			@Override
			public void accept(AStream<?> stream) {
				if (userName.equals(stream.getUserName())) {
					try {
						// To stop an IAgent, AAtomicAgent requires the
						// IAgent to be started
						{
							if (stream.getStatus() == State.NONE) {
								stream.init(new Properties());
							}

							if (stream.getStatus() == State.INIT) {
								stream.start();
							}
						}

						if (stream.getStatus() != State.STOPPED) {
							stream.stop();
							nbDisconnectedStreams.incrementAndGet();
						}
					} catch (AgentException | RuntimeException e) {
						LOGGER.warn("Failure while disconnected " + stream, e);
					}
				}
			}
		});

		return nbDisconnectedStreams.get();
	}

	protected void forEachAStream(Consumer<AStream<?>> consumer) {
		for (StreamRegister<? extends IStreamNode<?, ?>, ? extends IStream<?>, ? extends IQuery<?>> streamRegister : streamRegisters) {
			for (IMonitoredComponent streamNode : streamRegister.getMonitoredChildren().values()) {
				for (IMonitoredComponent rawStream : streamNode.getMonitoredChildren().values()) {
					if (rawStream instanceof AStream<?>) {
						consumer.accept((AStream<?>) rawStream);
					}
				}
			}
		}
	}

	@ManagedAttribute
	@Override
	public Map<String, ?> getUserDetail(final String userName) {
		final Map<String, Object> userDetails = new LinkedHashMap<>();

		userDetails.put("activeTime", userNameToActiveTime.get(userName));
		userDetails.put("timeInGetAggregatesQuery", userNameToTimeInGetAggregatesQuery.get(userName));
		userDetails.put("nbGetAggregatesQuery", userNameToNbGetAggregatesQuery.get(userName));

		forEachAStream(new Consumer<AStream<?>>() {

			@Override
			public void accept(AStream<?> stream) {
				if (userName.equals(stream.getUserName())) {
					// Keep the Query as a String
					userDetails.put(stream.getId(), String.valueOf(stream.getQuery()));
				}
			}
		});

		return userDetails;
	}

	/**
	 * 
	 * @return userNames which has been active recently
	 */
	@ManagedAttribute
	public Set<String> getRecentUsers() {
		return new TreeSet<>(recentUserNames.asMap().keySet());
	}

	/**
	 * 
	 * @return a {@link Map} from the userNames to the number of executed {@link IGetAggregatesQuery}
	 */
	@ManagedAttribute
	public Map<String, Long> getUsernameToNbGetAggregatesQuery() {
		// JMX Compatible
		return PepperJMXHelper.convertToJMXValueOrderedMap(userNameToNbGetAggregatesQuery.asMap(), true);
	}

	/**
	 * 
	 * @return a {@link Map} from the userNames to the time spent executing an {@link IGetAggregatesQuery}
	 */
	@ManagedAttribute
	public Map<String, Long> getUsernameToTimeInGetAggregatesQuery() {
		// JMX Compatible
		return PepperJMXHelper.convertToJMXValueOrderedMap(userNameToTimeInGetAggregatesQuery.asMap(), true);
	}

	@ManagedAttribute
	@Override
	public Map<String, Long> getUserNameToActiveTimeMs() {
		// JMX Compatible
		return PepperJMXHelper.convertToJMXValueOrderedMap(userNameToActiveTime.asMap(), true);
	}

	@ManagedAttribute
	@Override
	public Map<String, Long> getStreamToNbImpact() {
		// JMX Compatible
		return PepperJMXHelper.convertToJMXValueOrderedMap(streamToNbImpact.asMap(), true);
	}

	@ManagedAttribute
	@Override
	public Map<String, Long> getStreamToNbImpactedLocation() {
		// JMX Compatible
		return PepperJMXHelper.convertToJMXValueOrderedMap(streamToNbImpactedLocation.asMap(), true);
	}

	@ManagedAttribute
	public Map<String, Long> getStreamToPrepareImpactMs() {
		// JMX Compatible
		return PepperJMXHelper.convertToJMXValueOrderedMap(streamToTimeMsInPrepareImpact.asMap(), true);
	}

	@ManagedAttribute
	public Map<String, Long> getStreamToExecuteImpactMs() {
		// JMX Compatible
		return PepperJMXHelper.convertToJMXValueOrderedMap(streamToTimeMsInExecuteImpact.asMap(), true);
	}

	@ManagedOperation
	public void clear() {
		recentUserNames.invalidateAll();
		userNameToActiveTime.clear();

		streamToNbImpact.clear();
		streamToTimeMsInPrepareImpact.clear();
		streamToTimeMsInExecuteImpact.clear();

		userNameToNbGetAggregatesQuery.clear();
		userNameToTimeInGetAggregatesQuery.clear();
	}
}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.zip.GZIPOutputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;

import blasd.apex.server.datastore.ApexDatastoreHelper;
import blasd.apex.server.location.ApexLocationBuilder;
import blasd.apex.server.monitoring.dimension.ApexDimensionHealthChecker;
import blasd.apex.server.query.getaggregates.ApexGetAggregatesQueryExecutor;
import blasd.apex.server.query.hierarchy.ApexHierarchyHelper;
import blasd.apex.server.query.location.ApexLocationHelper;
import blasd.apex.server.query.location.ApexShortLocationFormatter;
import blasd.apex.shared.csv.WriteRowsToWriterPredicate;
import blasd.apex.shared.monitoring.jmx.PepperJMXHelper;
import blasd.apex.shared.thread.PepperExecutorsHelper;

import com.google.common.base.Function;
import com.google.common.base.Strings;
import com.google.common.base.Supplier;
import com.google.common.collect.Iterables;
import com.google.common.collect.ListMultimap;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.MultimapBuilder;
import com.google.common.collect.Multimaps;
import com.google.common.collect.SetMultimap;
import com.google.common.collect.Sets;
import com.google.common.util.concurrent.ListeningExecutorService;
import com.google.common.util.concurrent.MoreExecutors;
import com.quartetfs.biz.pivot.IActivePivot;
import com.quartetfs.biz.pivot.IActivePivotManager;
import com.quartetfs.biz.pivot.ILocation;
import com.quartetfs.biz.pivot.IProjection;
import com.quartetfs.biz.pivot.cellset.ICellSet;
import com.quartetfs.biz.pivot.cellset.ICellsProcedure;
import com.quartetfs.biz.pivot.cube.hierarchy.IDimension;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevel;
import com.quartetfs.biz.pivot.cube.hierarchy.axis.IAxisDimension;
import com.quartetfs.biz.pivot.cube.hierarchy.measures.IMeasureDimension;
import com.quartetfs.fwk.Registry;
import com.quartetfs.tech.indexer.IIndexer;

@ManagedResource
public class ApexActivePivotManagerTowerControl implements IApexActivePivotManagerTowerControl {

	protected static final Logger LOGGER = LoggerFactory.getLogger(ApexActivePivotManagerTowerControl.class);

	protected final Supplier<? extends IActivePivotManager> apManager;

	// BEWARE : ActivePivot must NOT be submitted in a QFS pool as
	// ActivePivot will run the query asynchronously: it will block main
	// thread. Bug in
	// com.quartetfs.biz.pivot.impl.ActivePivotVersion.execute(IQuery<ResultType>)
	// ?
	protected final ListeningExecutorService les =
			MoreExecutors.listeningDecorator(PepperExecutorsHelper.newShrinkableFixedThreadPool(PepperExecutorsHelper.DEFAULT_NB_CORES,
					"ApexActivePivotManagerTowerControl",
					Integer.MAX_VALUE,
					PepperExecutorsHelper.DEFAULT_ABORT_POLICY));

	/**
	 * 
	 * @param apManagerSupplier
	 *            we do not provide {@link IActivePivotManager} else it leads to issue with the {@link Registry} as
	 *            injecting the {@link IActivePivotManager} means instantiating many objects
	 */
	public ApexActivePivotManagerTowerControl(Supplier<? extends IActivePivotManager> apManagerSupplier) {
		this.apManager = apManagerSupplier;
	}

	protected Map<? extends String, ? extends IActivePivot> getActivePivots() {
		return apManager.get().getActivePivots();
	}

	/**
	 * Execute a GetAggregatesQuery out of any user restriction.
	 * 
	 * @param location
	 * @param measure
	 * @return
	 */
	@ManagedOperation
	public Map<NavigableMap<String, List<String>>, Object> executeGetAggregatesQuery(String pivotId,
			String locationAsString, String measuresAsString) {
		pivotId = PepperJMXHelper.convertToString(pivotId);

		// Get the pivot
		IActivePivot pivot = guessPivotOrThrow(pivotId);

		ILocation location;
		if (Strings.isNullOrEmpty(locationAsString) || PepperJMXHelper.JMX_DEFAULT_STRING.equals(locationAsString)) {
			location = ApexLocationBuilder.on(pivot).build();
		} else {
			location = ApexShortLocationFormatter.locationFromString(pivot, locationAsString);
		}

		List<String> measures = getMeasuresFromJMX(measuresAsString);

		// Execute the query
		final ICellSet result = executeGetAggregatesQuery(pivot, Arrays.asList(location), measures);

		Map<NavigableMap<String, List<String>>, Object> stringMap =
				ApexQueryCubeHelper.convertKeyToStringCoordinates(ApexQueryCubeHelper.convertToOneDimensionalMap(result,
						ApexHierarchyHelper.extractAxisHierarchiesInfo(pivot)));

		// Convert to human readable
		return PepperJMXHelper.convertToJMXMap(stringMap);
	}

	protected ICellSet executeGetAggregatesQuery(IActivePivot pivot, Iterable<? extends ILocation> locations,
			Iterable<? extends String> measures) {
		return getApexGetAggregatesQueryExecutor().executeGetAggregatesQuery(pivot, locations, measures);
	}

	protected ApexGetAggregatesQueryExecutor getApexGetAggregatesQueryExecutor() {
		return new ApexGetAggregatesQueryExecutor(true);
	}

	protected Collection<? extends Callable<ICellSet>> prepareCallables(IActivePivot pivot,
			Iterable<? extends ILocation> locations, Iterable<? extends String> measures) {
		return getApexGetAggregatesQueryExecutor().prepareCallables(pivot, locations, measures);
	}

	protected IActivePivot guessPivotOrThrow(String pivotId) {
		if ((pivotId == null || pivotId.isEmpty()) && getActivePivots().size() == 1) {
			// Select automatically the single available cube
			pivotId = getActivePivots().keySet().iterator().next();
		}

		// Get the pivot
		IActivePivot pivot = null;

		for (IActivePivot candidate : getActivePivots().values()) {
			if (candidate.getId().equals(pivotId)) {
				pivot = candidate;
				break;
			}
		}

		if (pivot == null) {
			throw new RuntimeException("There is no cube with name=" + pivotId + ". Availables are: "
					+ getActivePivots().keySet());
		}

		return pivot;
	}

	@ManagedOperation
	public String executeGetAggregatesQuery(String pivotId, String filtersAsString, String wildcardsAsString,
			String measuresAsString, String fileName) {
		pivotId = PepperJMXHelper.convertToString(pivotId);

		IIndexer<IProjection> storeName = ApexQueryCubeHelper.findBaseStore(apManager.get(), pivotId);

		final Map<String, Object> filters =
				ApexDatastoreHelper.convertFromStringToObject(storeName, PepperJMXHelper.convertToMap(filtersAsString));

		final List<String> measureNames = getMeasuresFromJMX(measuresAsString);

		final IActivePivot pivot = guessPivotOrThrow(pivotId);

		final List<String> cleanWildcards;
		{
			List<String> wildcards = PepperJMXHelper.convertToList(wildcardsAsString);
			cleanWildcards = addMissingWildcards(pivot, wildcards, filters);
		}

		ILocation location = ApexLocationBuilder.on(pivot).filter(filters).wildcard(cleanWildcards).build();

		LOGGER.debug("We built as ILocation: {}", location);

		fileName = clearFileName(fileName);

		try (final WriteRowsToWriterPredicate predicate = preparePredicate(fileName)) {
			long start = System.currentTimeMillis();

			final Iterable<String> levelNames = Iterables.concat(filters.keySet(), cleanWildcards);

			final AtomicLong nbRows = new AtomicLong();

			predicate.apply(Iterables.concat(levelNames, measureNames));

			Collection<? extends Callable<ICellSet>> callables =
					prepareCallables(pivot, Arrays.asList(location), measureNames);

			CompletionService<ICellSet> cs = new ExecutorCompletionService<>(les);

			for (Callable<ICellSet> callable : callables) {
				cs.submit(callable);
			}

			int nbTasks = callables.size();
			for (int i = 0; i < nbTasks; i++) {
				Future<ICellSet> future = cs.poll(1, TimeUnit.SECONDS);

				if (future == null) {
					LOGGER.info("{} parts done out of {} requested", i, nbTasks);
				} else {
					int nbRowsWritten = writeCellSetToWriter(future.get(), predicate, pivot, levelNames, measureNames);

					nbRows.addAndGet(nbRowsWritten);
					// TODO: log progress
				}
			}

			LOGGER.info("We wrote {} chars for {} rows, in {}ms",
					predicate.getNbCharWritten(),
					nbRows,
					System.currentTimeMillis() - start);

			if (Strings.isNullOrEmpty(fileName)) {
				return predicate.getWriter().toString();
			} else {
				return "Written to " + fileName;
			}
		} catch (InterruptedException e) {
			throw new RuntimeException(e);
		} catch (ExecutionException e) {
			throw new RuntimeException(e);
		}
	}

	protected WriteRowsToWriterPredicate preparePredicate(String fileName) {
		WriteRowsToWriterPredicate predicate;

		if (Strings.isNullOrEmpty(fileName)) {
			predicate = new WriteRowsToWriterPredicate(new StringWriter());
		} else {
			if (new File(fileName).exists()) {
				throw new IllegalArgumentException(fileName + "There  already exists");
			}

			if (fileName.endsWith(".gz")) {
				try {
					predicate =
							new WriteRowsToWriterPredicate(new OutputStreamWriter(new GZIPOutputStream(new FileOutputStream(fileName))));
				} catch (IOException e) {
					throw new RuntimeException(e);
				}
			} else {
				predicate = new WriteRowsToWriterPredicate(fileName);
			}

		}

		return predicate;
	}

	protected String clearFileName(String fileName) {
		String cleared = PepperJMXHelper.convertToString(fileName);

		if (cleared.toLowerCase().equals("tmp") || cleared.toLowerCase().equals("temp")) {
			try {
				Path tmp = Files.createTempFile("apex", ".tmp");

				tmp.toFile().delete();

				return tmp.toAbsolutePath().toString();
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		} else if (cleared.toLowerCase().equals("tmp.gz") || cleared.toLowerCase().equals("temp.gz")) {
			try {
				Path tmp = Files.createTempFile("apex", ".tmp.gz");

				tmp.toFile().delete();

				return tmp.toAbsolutePath().toString();
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		} else {
			return cleared;
		}
	}

	/**
	 * We need to add slicing hierarchies which are not expressed explicitly, and levels which are wildcarded explicitly
	 * by expressed their children level
	 */
	protected List<String> addMissingWildcards(IActivePivot pivot, List<String> wildcards, Map<String, Object> filters) {
		Set<IDimension> slicingHierarchies = new LinkedHashSet<>();

		for (IDimension h : pivot.getDimensions()) {
			if (h instanceof IAxisDimension && ApexHierarchyHelper.isSlicing(h)) {
				slicingHierarchies.add(h);
			}
		}

		if (slicingHierarchies.isEmpty()) {
			return wildcards;
		}

		// Linked so that IHierarchies are maintained in there definition
		// ordered
		ListMultimap<IDimension, ILevel> expressedHierarchiesToLevels =
				MultimapBuilder.linkedHashKeys().arrayListValues().build();

		for (String level : wildcards) {
			ILevel expressedLevel = ApexHierarchyHelper.findLevel(pivot, level);
			expressedHierarchiesToLevels.put(expressedLevel.getDimension(), expressedLevel);
		}
		for (String level : filters.keySet()) {
			ILevel expressedLevel = ApexHierarchyHelper.findLevel(pivot, level);
			expressedHierarchiesToLevels.put(expressedLevel.getDimension(), expressedLevel);
		}

		List<String> newWildcards = new ArrayList<>(wildcards);

		for (IDimension expressedHierarchy : expressedHierarchiesToLevels.keySet()) {
			List<ILevel> expressedLevels = expressedHierarchiesToLevels.get(expressedHierarchy);

			Set<Integer> expressedOrdinals = new TreeSet<>();
			int maxOrdinal = Integer.MIN_VALUE;
			for (ILevel expressedLevel : expressedLevels) {
				expressedOrdinals.add(expressedLevel.getOrdinal());
				maxOrdinal = Math.max(maxOrdinal, expressedLevel.getOrdinal());
			}

			int firstOrdinal;
			if (ApexHierarchyHelper.isSlicing(pivot, expressedHierarchy)) {
				// The first ILevel is an Axis level
				firstOrdinal = 0;
			} else {
				// The first ILevel in an ALL level
				firstOrdinal = 1;
			}

			for (int i = firstOrdinal; i < maxOrdinal; i++) {
				if (!expressedOrdinals.contains(i)) {
					// Add this level which is expressed implicitely by other
					// wildcards/filters, but not explcitely
					newWildcards.add(ApexHierarchyHelper.levelName(pivot, expressedHierarchy, i));
				}
			}
		}

		for (IDimension missingSlicingInfo : Sets.difference(slicingHierarchies, expressedHierarchiesToLevels.keySet())) {
			IDimension missingSlicing = pivot.getDimensions().get(missingSlicingInfo.getOrdinal());
			newWildcards.add(ApexHierarchyHelper.levelName(missingSlicing, 0));
		}

		return newWildcards;
	}

	protected List<String> getMeasuresFromJMX(String measuresAsString) {
		List<String> asList = PepperJMXHelper.convertToList(measuresAsString);

		if (asList.isEmpty()) {
			// If no measure has been provided, we query explicitly for a
			// default measure
			return Arrays.asList(IMeasureDimension.COUNT_ID);
		} else {
			return asList;
		}
	}

	protected int writeCellSetToWriter(ICellSet cellset, final WriteRowsToWriterPredicate predicate,
			IActivePivot pivot, Iterable<? extends String> levelNames, final Iterable<? extends String> measureNames) {

		// Fetch all ILevel from which coordinates will have to be extracted
		final List<ILevel> levels = new ArrayList<>();
		for (String filteredLevel : levelNames) {
			levels.add(ApexHierarchyHelper.findLevel(pivot, filteredLevel));
		}

		final int nbMeasures = Iterables.size(measureNames);
		int nbColumns = levels.size() + nbMeasures;

		// Initialize with the right number of elements
		final List<Object> buffer = Arrays.asList(new Object[nbColumns]);

		final AtomicInteger nbRows = new AtomicInteger();
		cellset.forEachLocation(new ICellsProcedure() {

			@Override
			public boolean execute(ILocation pointLocation, int rowId, Object[] measures) {
				// Add filtered values
				int nbFiltered = levels.size();
				for (int i = 0; i < nbFiltered; i++) {
					buffer.set(i, ApexLocationHelper.getCoordinate(pointLocation, levels.get(i)));
				}

				// Add measure values
				for (int i = 0; i < nbMeasures; i++) {
					buffer.set(nbFiltered + i, measures[i]);
				}

				// Each rows has to be written autonomously
				synchronized (predicate) {
					predicate.apply(buffer);
				}

				nbRows.incrementAndGet();

				// Continue to next row
				return true;
			}
		}, Lists.newArrayList(measureNames).toArray(new String[0]));

		return nbRows.get();
	}

	@ManagedOperation
	public Map<String, String> checkDimensions() {
		ApexDimensionHealthChecker dimensionChecker = new ApexDimensionHealthChecker();

		SetMultimap<String, ILevel> pivotIdToDirtyLevels =
				dimensionChecker.checkHierarchies(getActivePivots().values());

		Map<String, Iterable<String>> asString =
				Maps.transformValues(Multimaps.asMap(pivotIdToDirtyLevels),
						new Function<Set<ILevel>, Iterable<String>>() {

							@Override
							public Iterable<String> apply(Set<ILevel> input) {
								return Iterables.transform(input, new Function<ILevel, String>() {

									@Override
									public String apply(ILevel levelInfo) {
										return ApexHierarchyHelper.levelName(levelInfo);
									}
								});
							}
						});

		return PepperJMXHelper.convertToJMXMapString(asString);
	}
}

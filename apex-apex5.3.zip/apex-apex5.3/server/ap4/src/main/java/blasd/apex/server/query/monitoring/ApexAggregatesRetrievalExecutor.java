/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package blasd.apex.server.query.monitoring;

import java.util.Collection;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import blasd.apex.server.query.location.ApexShortLocationFormatter;

import com.quartetfs.biz.pivot.ILocation;
import com.quartetfs.biz.pivot.cellset.ICellSet;
import com.quartetfs.biz.pivot.cellset.IScopedCellSet;
import com.quartetfs.biz.pivot.context.IContextSnapshot;
import com.quartetfs.biz.pivot.cube.hierarchy.IDimension;
import com.quartetfs.biz.pivot.impl.ActivePivot;
import com.quartetfs.biz.pivot.query.IGetAggregatesQuery;
import com.quartetfs.biz.pivot.query.IQueryCache;
import com.quartetfs.biz.pivot.query.aggregates.IAggregatesRetrieval;
import com.quartetfs.biz.pivot.query.aggregates.IAggregatesRetriever;
import com.quartetfs.biz.pivot.query.aggregates.IBufferedCellSetWriterFactory;
import com.quartetfs.biz.pivot.query.aggregates.IPostProcessedRetrieval;
import com.quartetfs.biz.pivot.query.aggregates.RetrievalException;
import com.quartetfs.biz.pivot.query.aggregates.impl.AggregatesRetrievalExecutor;
import com.quartetfs.fwk.QuartetException;

/**
 * Log more information on {@link IGetAggregatesQuery}
 * 
 * @author Benoit Lacelle
 * 
 */
public class ApexAggregatesRetrievalExecutor extends AggregatesRetrievalExecutor {

	private static final Logger LOGGER = LoggerFactory.getLogger(ApexAggregatesRetrievalExecutor.class);

	private static final AtomicInteger QUERY_INDEX = new AtomicInteger();

	private static final int LIMIT_FOR_DEBUG = 1000;

	public ApexAggregatesRetrievalExecutor(ActivePivot pivot, IContextSnapshot contextValues) {
		super(pivot, contextValues);
	}

	protected Object locationToShortString(List<IDimension> hierarchies, ILocation location) {
		StringBuilder sb = new StringBuilder();

		ApexShortLocationFormatter.format(sb, location, hierarchies);

		return sb.toString();
	}

	@Override
	public IScopedCellSet retrievePrimitiveAggregates(Collection<? extends IAggregatesRetrieval> retrievals)
			throws RetrievalException {

		long start = System.currentTimeMillis();
		IScopedCellSet output = null;
		try {
			output = super.retrievePrimitiveAggregates(retrievals);

			return output;
		} finally {
			long diffInMs = System.currentTimeMillis() - start;

			StringBuilder location = new StringBuilder();

			for (IAggregatesRetrieval retrieval : retrievals) {
				location.append(retrieval.getMeasure().getName())
						.append(" on ")
						.append(locationToShortString(pivot.getDimensions(), retrieval.getLocation()))
						.append(";");
			}

			int queryIndex = getQueryIndex();

			String locationCount;
			if (output == null) {
				locationCount = "?";
			} else {
				// getLocationCount seems a bit slow on very large cubes and
				// very
				// large queries
				// int locationCount = output.getLocationCount();
				locationCount = "?";
			}
			if (diffInMs >= LIMIT_FOR_DEBUG) {
				LOGGER.info("#query={} - {}ms for {}points on {}", queryIndex, diffInMs, locationCount, location);
			} else {
				LOGGER.debug("#query={} - {}ms for {}points on {}", queryIndex, diffInMs, locationCount, location);
			}
		}
	}

	protected int getQueryIndex() {
		IQueryCache qc = pivot.getContext().get(IQueryCache.class);
		if (qc == null) {
			// Sometimes, the queryCache is not in the IActivePivotContext
			qc = this.queryCache;
		}
		if (qc == null) {
			// When does it happen?
			return -1;
		}
		Integer queryIndex = (Integer) qc.get(ApexAggregatesRetrievalExecutor.class);
		if (queryIndex == null) {
			// Use an alternative query index

			// TODO when do we enter this execution path?
			queryIndex = QUERY_INDEX.getAndIncrement();
			qc.put(ApexAggregatesRetrievalExecutor.class, queryIndex);
		}

		return queryIndex;
	}

	@Override
	public void evalutePostProcessedMeasure(IPostProcessedRetrieval retrieval, final IAggregatesRetriever retriever,
			IBufferedCellSetWriterFactory writerFactory) throws QuartetException {

		final AtomicInteger nbWrite = new AtomicInteger();
		final AtomicInteger underlyingCellSetSize = new AtomicInteger();

		IAggregatesRetriever proxyRetriever = new IAggregatesRetriever() {

			@Override
			public void write(ILocation arg0, Object arg1) {
				nbWrite.incrementAndGet();
				retriever.write(arg0, arg1);
			}

			@Override
			public ICellSet retrieveAggregates(Collection<ILocation> arg0, Collection<String> arg1)
					throws RetrievalException {
				ICellSet cellset = retriever.retrieveAggregates(arg0, arg1);

				// cellset. getLocationCount seems a bit slow on very large
				// cubes and very large queries
				// int locationCount = output.getLocationCount();
				underlyingCellSetSize.addAndGet(1);

				return cellset;
			}
		};

		long start = System.currentTimeMillis();

		super.evalutePostProcessedMeasure(retrieval, proxyRetriever, writerFactory);

		long diffInMs = System.currentTimeMillis() - start;

		if (nbWrite.get() == 0 && underlyingCellSetSize.get() == 0 && diffInMs == 0) {
			// Do not log instantaneousPP which work on no underlying cellset
			// and returned no cells
			return;
		}

		int queryIndex = getQueryIndex();

		if (diffInMs >= LIMIT_FOR_DEBUG) {
			LOGGER.info("#query={} - {}ms for {} writes on {} after retrieving {}cells on {}",
					queryIndex,
					diffInMs,
					nbWrite,
					retrieval.getMeasure(),
					underlyingCellSetSize.get(),
					locationToShortString(pivot.getDimensions(), retrieval.getLocation()));
		} else {
			LOGGER.debug("#query={} - {}ms for {} writes on {} after retrieving {}cells on {}",
					queryIndex,
					diffInMs,
					nbWrite,
					retrieval.getMeasure(),
					underlyingCellSetSize.get(),
					locationToShortString(pivot.getDimensions(), retrieval.getLocation()));
		}

	}

}

/**
 * Copyright (C) 2014 Benoit Lacelle (benoit.lacelle@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.quartetfs.biz.pivot.query.aggregates.impl;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import com.quartetfs.biz.pivot.query.aggregates.IAggregatesContinuousQuery;
import com.quartetfs.biz.pivot.query.aggregates.IMultiGetAggregatesNotificationContinuousQuery;
import com.quartetfs.biz.pivot.streaming.IMdxStream;
import com.quartetfs.fwk.query.IContinuousQueryListener;
import com.quartetfs.pivot.mdx.realtime.impl.RTSelectSupervisor;
import com.quartetfs.pivot.mdx.realtime.impl.RTSelectSupervisorSpy;

public class AAggregatesContinuousQueryEngineSpy {
	protected AAggregatesContinuousQueryEngineSpy() {
		// hidden
	}

	public static Set<? extends IMdxStream> getStreams(AggregatesContinuousQueryEngine engine,
			IAggregatesContinuousQuery query) {
		IMultiGetAggregatesNotificationContinuousQuery multiQuery = engine.queryToMultiQuery.get(query);

		Set<IMdxStream> mdxStreams = new HashSet<>();

		if (multiQuery == null) {
			return Collections.emptySet();
		} else {
			for (IContinuousQueryListener<? super int[]> mdxListener : multiQuery.getListeners()) {

				try {
					java.lang.reflect.Field enclosingInstanceField = mdxListener.getClass().getDeclaredField("this$0");
					enclosingInstanceField.setAccessible(true);

					Object outer = enclosingInstanceField.get(mdxListener);

					if (outer instanceof RTSelectSupervisor) {
						return RTSelectSupervisorSpy.getAStreams((RTSelectSupervisor) outer);
					} else {
						return Collections.emptySet();
					}
				} catch (NoSuchFieldException | SecurityException | IllegalArgumentException | IllegalAccessException e) {
					return Collections.emptySet();
				}
			}
		}

		return mdxStreams;
	}
}
